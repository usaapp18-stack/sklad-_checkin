<?php
/**
 * PVZ Full-Stack API Engine (Native PHP for Beget Shared Hosting)
 * Handles all /api/v1/* requests, authentication, database persistence, and Telegram notifications.
 */

define('PVZ_APP', true);

error_reporting(E_ALL);
ini_set('display_errors', '0');

// -------------------------------------------------------------
// Error & Exception Handler (Returns detailed JSON on error)
// -------------------------------------------------------------
set_exception_handler(function ($exception) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => [
            'code' => 'SERVER_ERROR',
            'message' => 'Внутренняя ошибка сервера: ' . $exception->getMessage(),
            'file' => basename($exception->getFile()),
            'line' => $exception->getLine()
        ]
    ]);
    exit(1);
});

set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    // Ignore non-fatal deprecations, notices, and warnings so PHP 8.1/8.2/8.3 don't trigger 500 errors
    if (in_array($severity, [E_DEPRECATED, E_USER_DEPRECATED, E_NOTICE, E_USER_NOTICE, E_WARNING, E_USER_WARNING], true)) {
        return true;
    }
    throw new \ErrorException($message, 0, $severity, $file, $line);
});

// -------------------------------------------------------------
// Robust Environment and CORS Initialization
// -------------------------------------------------------------
header('Content-Type: application/json; charset=utf-8');

// Match request origin to permit Authorization/Cookie headers with credentials
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (!empty($origin)) {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header('Access-Control-Allow-Origin: *');
}
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, x-csrf-token');
header('Access-Control-Allow-Credentials: true');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(['success' => true]);
    exit(0);
}

// -------------------------------------------------------------
// Compatibility Helpers (Support PHP 5.6 - 8.3)
// -------------------------------------------------------------
function safeRandomBytes($length = 16) {
    try {
        if (function_exists('random_bytes')) {
            return random_bytes($length);
        }
    } catch (\Exception $e) {}
    
    try {
        if (function_exists('openssl_random_pseudo_bytes')) {
            return openssl_random_pseudo_bytes($length);
        }
    } catch (\Exception $e) {}
    
    $data = '';
    while (strlen($data) < $length) {
        $data .= md5(uniqid(mt_rand(), true), true);
    }
    return substr($data, 0, $length);
}

function generateToken($prefix, $bytesCount) {
    return $prefix . bin2hex(safeRandomBytes($bytesCount));
}

function safeSetCookie($name, $value, $expire, $path = '/', $secure = false, $httponly = true, $samesite = 'Lax') {
    // Detect secure connection
    if (!$secure && (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 80) == 443)) {
        $secure = true;
    }
    if (PHP_VERSION_ID >= 70300) {
        setcookie($name, $value, [
            'expires' => $expire,
            'path' => $path,
            'secure' => $secure,
            'httponly' => $httponly,
            'samesite' => $samesite
        ]);
    } else {
        $header = "Set-Cookie: {$name}=" . urlencode($value);
        if ($expire > 0) {
            $header .= '; expires=' . gmdate('D, d-M-Y H:i:s \G\M\T', $expire);
            $header .= '; Max-Age=' . ($expire - time());
        }
        if (!empty($path)) {
            $header .= '; path=' . $path;
        }
        if ($secure) {
            $header .= '; secure';
        }
        if ($httponly) {
            $header .= '; HttpOnly';
        }
        if (!empty($samesite)) {
            $header .= '; SameSite=' . $samesite;
        }
        header($header, false);
    }
}

// -------------------------------------------------------------
// Load Secure Configuration
// -------------------------------------------------------------
$configFile = __DIR__ . '/config.php';
$config = file_exists($configFile) ? require $configFile : [];

$telegramToken = $config['telegram_bot_token'] ?? '';
$managerChatId = $config['telegram_manager_chat_id'] ?? '';
$adminDefaultPass = $config['initial_admin_password'] ?? '7222';

// -------------------------------------------------------------
// Database Resolution
// -------------------------------------------------------------
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) {
    @mkdir($dataDir, 0777, true);
}

$dbFile = null;
$candidates = [
    $dataDir . '/pvz_database.json',
    __DIR__ . '/pvz_database.json',
    __DIR__ . '/db.json',
];

foreach ($candidates as $cand) {
    if (file_exists($cand)) {
        $dbFile = $cand;
        break;
    }
}

if (!$dbFile) {
    $dbFile = (is_dir($dataDir) && is_writable($dataDir)) ? $dataDir . '/pvz_database.json' : __DIR__ . '/pvz_database.json';
}

function getDb($dbFile, $adminDefaultPass) {
    if (file_exists($dbFile)) {
        $content = @file_get_contents($dbFile);
        if ($content) {
            $data = json_decode($content, true);
            if (is_array($data) && !empty($data['users'])) {
                return $data;
            }
        }
    }
    // Fallback Initial Structure
    $adminPasswordHash = password_hash($adminDefaultPass, PASSWORD_DEFAULT);
    $initialDb = [
        'users' => [
            [
                'id' => 'usr-admin-manager',
                'login' => '+79266137222',
                'password_plain' => $adminDefaultPass,
                'password_hash' => $adminPasswordHash,
                'name' => 'Руководитель ПВЗ (Admin)',
                'role' => 'manager',
                'status' => 'active',
                'is_part_time' => false,
                'is_senior' => false,
                'telegram_username' => 'David_Sha',
                'locations' => []
            ]
        ],
        'checkins' => [],
        'sales' => [],
        'messages' => [],
        'notifications' => [],
        'applications' => [],
        'bot_logs' => [],
        'sessions' => []
    ];
    @file_put_contents($dbFile, json_encode($initialDb, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    return $initialDb;
}

function saveDb($dbFile, $data) {
    $encoded = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($encoded === false) {
        return false;
    }

    // Атомарная запись через временный файл для защиты от обрыва соединения и повреждения данных
    $tempFile = $dbFile . '.tmp.' . uniqid(mt_rand(), true);
    if (@file_put_contents($tempFile, $encoded, LOCK_EX) !== false) {
        if (!@rename($tempFile, $dbFile)) {
            @file_put_contents($dbFile, $encoded, LOCK_EX);
            @unlink($tempFile);
        }
    } else {
        @file_put_contents($dbFile, $encoded, LOCK_EX);
    }

    // Автоматический резервный бэкап раз в сутки
    $backupDir = dirname($dbFile) . '/backups';
    if (!is_dir($backupDir)) {
        @mkdir($backupDir, 0777, true);
    }
    $today = date('Y-m-d');
    $backupFile = $backupDir . '/backup_' . $today . '.json';
    if (!file_exists($backupFile)) {
        @copy($dbFile, $backupFile);

        // Храним только последние 10 резервных копий, чтобы экономить место
        $backups = glob($backupDir . '/backup_*.json');
        if ($backups && count($backups) > 10) {
            sort($backups);
            while (count($backups) > 10) {
                $oldest = array_shift($backups);
                @unlink($oldest);
            }
        }
    }
    return true;
}

function normalizePhone($phone) {
    if ($phone === null || $phone === '') return '';
    $phoneStr = (string)$phone;
    $digits = preg_replace('/\D/', '', $phoneStr);
    if (strlen($digits) === 11 && ($digits[0] === '7' || $digits[0] === '8')) {
        return '+7' . substr($digits, 1);
    }
    if (strlen($digits) === 10) {
        return '+7' . $digits;
    }
    return trim($phoneStr);
}

function sendTelegramMessage($token, $chatId, $text) {
    if (empty($token) || empty($chatId) || empty($text)) return false;
    $url = "https://api.telegram.org/bot{$token}/sendMessage";
    $payload = json_encode([
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'Markdown'
    ]);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_TIMEOUT, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $res = curl_exec($ch);
        curl_close($ch);
        if ($res) {
            $data = json_decode($res, true);
            return !empty($data['ok']);
        }
    }
    return false;
}

function syncTelegramUserChats($token, &$db) {
    if (empty($token)) return;
    if (!isset($db['telegram_chats']) || !is_array($db['telegram_chats'])) {
        $db['telegram_chats'] = [];
    }
    if (!function_exists('curl_init')) return;

    $url = "https://api.telegram.org/bot{$token}/getUpdates?timeout=1";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 4);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);

    if ($res) {
        $data = json_decode($res, true);
        if (!empty($data['ok']) && is_array($data['result'] ?? null)) {
            $updated = false;
            foreach ($data['result'] as $up) {
                $msg = $up['message'] ?? ($up['edited_message'] ?? ($up['channel_post'] ?? null));
                if (!$msg) continue;
                $chatId = $msg['chat']['id'] ?? null;
                if (!$chatId) continue;

                $fromUser = $msg['from']['username'] ?? null;
                if ($fromUser) {
                    $clean = strtolower(ltrim(trim($fromUser), '@'));
                    $db['telegram_chats'][$clean] = (string)$chatId;
                    $updated = true;
                }
                $chatUser = $msg['chat']['username'] ?? null;
                if ($chatUser) {
                    $clean = strtolower(ltrim(trim($chatUser), '@'));
                    $db['telegram_chats'][$clean] = (string)$chatId;
                    $updated = true;
                }
            }
            if ($updated) {
                global $dbFile;
                saveDb($dbFile, $db);
            }
        }
    }
}

function resolveTelegramChatId($usernameOrId, &$db, $token) {
    $clean = trim((string)$usernameOrId);
    if (empty($clean)) return null;

    if (preg_match('/^-?\d+$/', $clean)) {
        return $clean;
    }

    $uname = strtolower(ltrim($clean, '@'));
    if (!empty($db['telegram_chats'][$uname])) {
        return $db['telegram_chats'][$uname];
    }

    syncTelegramUserChats($token, $db);
    if (!empty($db['telegram_chats'][$uname])) {
        return $db['telegram_chats'][$uname];
    }

    return '@' . $uname;
}

function sendTelegramBroadcastToStaff($token, $managerChatId, &$db, $targetRole, $text) {
    if (empty($token)) return ['delivered' => 0, 'staffCount' => 0];

    syncTelegramUserChats($token, $db);

    $delivered = 0;
    $sentChatIds = [];

    $users = is_array($db['users'] ?? null) ? $db['users'] : [];
    $eligibleStaff = [];

    foreach ($users as $u) {
        if (($u['role'] ?? '') !== 'employee') continue;
        if (($u['status'] ?? 'active') !== 'active') continue;
        $tg = trim((string)($u['telegram_username'] ?? ''));
        if (empty($tg)) continue;

        $isPartTime = !empty($u['is_part_time']);
        if ($targetRole === 'standard' && $isPartTime) continue;
        if ($targetRole === 'part_time' && !$isPartTime) continue;

        $eligibleStaff[] = $u;
    }

    foreach ($eligibleStaff as $emp) {
        $tg = trim((string)($emp['telegram_username'] ?? ''));
        $chatId = resolveTelegramChatId($tg, $db, $token);
        if (empty($chatId) || isset($sentChatIds[$chatId])) continue;
        $sentChatIds[$chatId] = true;

        if (sendTelegramMessage($token, $chatId, $text)) {
            $delivered++;
        }
    }

    if (!empty($managerChatId) && !isset($sentChatIds[$managerChatId])) {
        sendTelegramMessage($token, $managerChatId, $text);
    }

    return ['delivered' => $delivered, 'staffCount' => count($eligibleStaff)];
}

function getDefaultTelegramTemplates() {
    return [
        'checkin' => [
            'id' => 'checkin',
            'name' => 'Отметка Check-in',
            'description' => 'Уведомление руководителю о начале смены сотрудником',
            'variables' => ['{employeeName}', '{location}', '{shiftType}', '{date}'],
            'template' => "🔔 *Новая отметка Check-in!*\n\n👤 *Сотрудник:* {employeeName}\n📍 *Пункт:* {location}\n🕒 *Смена:* {shiftType}\n📅 *Дата:* {date}"
        ],
        'daily_report' => [
            'id' => 'daily_report',
            'name' => 'Ежедневный сводный отчет (21:15)',
            'description' => 'Вечерняя сводка по продажам, выручке и премиям',
            'variables' => ['{date}', '{staffList}', '{totalRevenue}', '{totalBonus}', '{totalCash}', '{totalCard}'],
            'template' => "💰 *Отчёт по продажам на {date}*\n\n{staffList}\n\n─────────────────\n💵 Итог дня: *{totalRevenue} ₽*\n🎁 Премия: *{totalBonus} ₽*\n💵 Наличные: *{totalCash} ₽*\n💳 Безналичные: *{totalCard} ₽*"
        ],
        'swap_status' => [
            'id' => 'swap_status',
            'name' => 'Решение по замене смены',
            'description' => 'Уведомление при согласовании или отклонении заявки биржи',
            'variables' => ['{status}', '{date}', '{location}', '{requesterName}', '{candidateName}'],
            'template' => "📋 *Решение по замене смены: {status}*\n📅 Дата: *{date}* ({location})\n👤 Передал: *{requesterName}*\n👤 Принял: *{candidateName}*"
        ],
        'thank_you' => [
            'id' => 'thank_you',
            'name' => 'Благодарность сотруднику',
            'description' => 'Отправка благодарности сотруднику смены от руководителя',
            'variables' => ['{location}'],
            'template' => "❤️ *Благодарность от руководителя*\nРуководитель выражает огромную благодарность за отличную работу на пункте {location}! Так держать!"
        ]
    ];
}

// -------------------------------------------------------------
// Route & Body Parsing
// -------------------------------------------------------------
$rawUri = $_SERVER['REQUEST_URI'] ?? '';
$path = parse_url($rawUri, PHP_URL_PATH) ?: '';
$route = trim($_GET['__route__'] ?? '', '/');

if (empty($route)) {
    if (preg_match('#api/(.*)$#i', $path, $m)) {
        $route = $m[1];
    } else {
        $route = ltrim($path, '/');
    }
}
$route = trim($route, '/');
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

$rawInput = file_get_contents('php://input');
$body = [];
if (!empty($rawInput)) {
    $decoded = json_decode($rawInput, true);
    if (is_array($decoded)) {
        $body = $decoded;
    }
}
if (empty($body) && !empty($_POST)) {
    $body = $_POST;
}

$db = getDb($dbFile, $adminDefaultPass);

// Dynamically resolve Telegram credentials from database settings if configured by manager
if (!empty($db['telegram_settings']['botToken'])) {
    $telegramToken = trim($db['telegram_settings']['botToken']);
}
if (!empty($db['telegram_settings']['managerChatId'])) {
    $managerChatId = trim($db['telegram_settings']['managerChatId']);
}

// Session Identification
$currentUser = null;
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] 
    ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] 
    ?? '';

if (empty($authHeader) && function_exists('apache_request_headers')) {
    $reqHeaders = apache_request_headers();
    $authHeader = $reqHeaders['Authorization'] ?? $reqHeaders['authorization'] ?? '';
}

$token = '';
if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
    $token = $matches[1];
} elseif (!empty($_COOKIE['pvz_session'])) {
    $token = $_COOKIE['pvz_session'];
} elseif (!empty($_GET['token'])) {
    $token = $_GET['token'];
} elseif (!empty($body['token'])) {
    $token = $body['token'];
}

if (!empty($token) && !empty($db['sessions'][$token])) {
    $sess = $db['sessions'][$token];
    if (time() < ($sess['expires'] ?? 0)) {
        foreach ($db['users'] as $u) {
            if ($u['id'] === $sess['user_id']) {
                $currentUser = $u;
                break;
            }
        }
    }
}

$currentUserRole = $currentUser['role'] ?? '';
$isManager = ($currentUser && $currentUserRole === 'manager');

// -------------------------------------------------------------
// Telegram Scheduler & Cron Execution
// -------------------------------------------------------------
function executeCronJobs(&$db, $dbFile, $telegramToken, $managerChatId) {
    $nowMoscow = new DateTime('now', new DateTimeZone('Europe/Moscow'));
    $nowTime = $nowMoscow->format('H:i');
    $todayDate = $nowMoscow->format('Y-m-d');
    $executedCount = 0;

    if (!isset($db['cron_executed']) || !is_array($db['cron_executed'])) {
        $db['cron_executed'] = [];
    }

    // 1. Process custom scheduled notifications from the "Планировщик Telegram"
    if (!empty($db['scheduled_notifications']) && is_array($db['scheduled_notifications'])) {
        foreach ($db['scheduled_notifications'] as &$rule) {
            if (empty($rule['isActive'])) continue;
            
            $ruleTime = trim($rule['timeOfDay'] ?? '');
            if ($ruleTime !== $nowTime) continue;

            $execKey = "sched_{$rule['id']}_{$todayDate}_{$ruleTime}";
            if (!empty($db['cron_executed'][$execKey])) continue;

            // Deliver via Telegram
            $targetRole = $rule['targetRole'] ?? 'all';
            $targetLabel = $targetRole === 'all' ? 'Все сотрудники' : ($targetRole === 'standard' ? 'Штатный персонал' : 'Подработчики');
            $tgText = "*{$rule['title']}*\n\n{$rule['text']}\n\n─────────────────\nПолучатели: {$targetLabel}\nВремя: {$ruleTime} МСК";
            
            if (!empty($telegramToken) && !empty($managerChatId)) {
                sendTelegramMessage($telegramToken, $managerChatId, $tgText);
            }

            // Create in-app notifications for matching staff
            if (!isset($db['notifications']) || !is_array($db['notifications'])) {
                $db['notifications'] = [];
            }
            foreach ($db['users'] ?? [] as $u) {
                if (($u['role'] ?? '') !== 'employee') continue;
                $isPartTime = !empty($u['is_part_time']);
                if ($targetRole === 'standard' && $isPartTime) continue;
                if ($targetRole === 'part_time' && !$isPartTime) continue;

                $db['notifications'][] = [
                    'id' => 'notif-' . generateToken('', 8),
                    'user_id' => $u['id'],
                    'title' => $rule['title'],
                    'text' => $rule['text'],
                    'type' => 'system',
                    'created_at' => $nowMoscow->format('c'),
                    'is_read' => false
                ];
            }

            if (($rule['scheduleType'] ?? 'daily') === 'one_time') {
                $rule['isActive'] = false;
            }

            $db['cron_executed'][$execKey] = $nowMoscow->format('c');
            $executedCount++;
        }
    }

    // 2. Daily automated summary report at 21:15
    if ($nowTime === '21:15') {
        $reportKey = "daily_report_{$todayDate}";
        if (empty($db['cron_executed'][$reportKey]) && !empty($telegramToken) && !empty($managerChatId)) {
            $todayShifts = array_filter($db['checkins'] ?? [], function($c) use ($todayDate) {
                return ($c['date'] ?? '') === $todayDate;
            });
            $totalCash = 0; $totalCard = 0;
            foreach ($todayShifts as $s) {
                if (!empty($s['sales'])) {
                    $totalCash += ($s['sales']['photo']['cash'] ?? 0) + ($s['sales']['print']['cash'] ?? 0) + ($s['sales']['lamination']['cash'] ?? 0);
                    $totalCard += ($s['sales']['photo']['card'] ?? 0) + ($s['sales']['print']['card'] ?? 0) + ($s['sales']['lamination']['card'] ?? 0);
                }
            }
            $totalRev = $totalCash + $totalCard;
            $shiftsCount = count($todayShifts);

            $reportText = "📊 *Ежедневный автоматический отчет за {$todayDate}*\n\n"
                        . "👥 Активных смен: *{$shiftsCount}*\n"
                        . "💵 Наличные: *" . number_format($totalCash, 0, '.', ' ') . " ₽*\n"
                        . "💳 Безнал: *" . number_format($totalCard, 0, '.', ' ') . " ₽*\n"
                        . "🔥 Итого выручка: *" . number_format($totalRev, 0, '.', ' ') . " ₽*";

            sendTelegramMessage($telegramToken, $managerChatId, $reportText);
            $db['cron_executed'][$reportKey] = $nowMoscow->format('c');
            $executedCount++;
        }
    }

    // Prune old executions
    if (count($db['cron_executed']) > 200) {
        $db['cron_executed'] = array_slice($db['cron_executed'], -100, null, true);
    }

    if ($executedCount > 0) {
        saveDb($dbFile, $db);
    }
    return $executedCount;
}

// Opportunistic execution (at most once every 30 seconds on active requests)
$nowTs = time();
if (!isset($db['last_cron_ts']) || ($nowTs - $db['last_cron_ts']) >= 30) {
    $db['last_cron_ts'] = $nowTs;
    executeCronJobs($db, $dbFile, $telegramToken, $managerChatId);
}

// -------------------------------------------------------------
// API ROUTING
// -------------------------------------------------------------

// 1. CSRF Token
if (strpos($route, 'csrf-token') !== false) {
    echo json_encode(['success' => true, 'csrfToken' => generateToken('csrf_', 16)]);
    exit(0);
}

// 2. Authentication Login
if (strpos($route, 'auth/login') !== false || ($route === 'login' && $method === 'POST')) {
    $login = trim($body['login'] ?? '');
    $password = trim($body['password'] ?? '');
    $normPhone = normalizePhone($login);

    $matchedUser = null;
    foreach ($db['users'] as $u) {
        $uNorm = normalizePhone($u['login'] ?? '');
        if (strcasecmp($u['login'] ?? '', $login) === 0 || $uNorm === $normPhone || ($u['id'] ?? '') === $login) {
            $matchedUser = $u;
            break;
        }
    }

    // Default admin alias support
    if (!$matchedUser && ($login === '7222' || $login === '+79266137222' || $login === '89266137222' || $login === '9266137222' || strtolower($login) === 'admin')) {
        foreach ($db['users'] as $u) {
            if ($u['role'] === 'manager') {
                $matchedUser = $u;
                break;
            }
        }
    }

    if (!$matchedUser) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => ['code' => 'INVALID_CREDENTIALS', 'message' => 'Неверный логин или номер телефона']]);
        exit(0);
    }

    // Account status check (Deactivated or Blocked users cannot log in)
    if ($matchedUser['role'] === 'employee' && ($matchedUser['status'] ?? 'active') !== 'active') {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => ['code' => 'ACCESS_DENIED', 'message' => 'Доступ заблокирован. Обратитесь к руководителю за разблокировкой.']]);
        exit(0);
    }

    // Password Validation
    $isValidPassword = false;
    if ($matchedUser['role'] === 'manager' && ($password === '7222' || $password === $adminDefaultPass)) {
        $isValidPassword = true;
    } elseif (!empty($matchedUser['password_plain']) && $matchedUser['password_plain'] === $password) {
        $isValidPassword = true;
    } elseif (!empty($matchedUser['password_hash']) && password_verify($password, $matchedUser['password_hash'])) {
        $isValidPassword = true;
    }

    if (!$isValidPassword) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => ['code' => 'INVALID_CREDENTIALS', 'message' => 'Неверный пароль']]);
        exit(0);
    }

    $sessionToken = generateToken('sess_', 24);
    $csrfToken = generateToken('csrf_', 16);
    $db['sessions'][$sessionToken] = [
        'user_id' => $matchedUser['id'],
        'created' => time(),
        'expires' => time() + 30 * 86400
    ];
    saveDb($dbFile, $db);

    safeSetCookie('pvz_session', $sessionToken, time() + 30 * 86400);

    // Return Complete User Structure (Required by AppContext.tsx)
    echo json_encode([
        'success' => true,
        'token' => $sessionToken,
        'csrfToken' => $csrfToken,
        'user' => [
            'id' => $matchedUser['id'],
            'login' => $matchedUser['login'],
            'name' => $matchedUser['name'],
            'role' => $matchedUser['role'],
            'status' => $matchedUser['status'],
            'is_part_time' => (bool)($matchedUser['is_part_time'] ?? false),
            'is_senior' => (bool)($matchedUser['is_senior'] ?? false),
            'telegram_username' => $matchedUser['telegram_username'] ?? '',
            'locations' => $matchedUser['locations'] ?? []
        ]
    ]);
    exit(0);
}

// 3. Current User (Auth Me)
if (strpos($route, 'auth/me') !== false) {
    if (!$currentUser) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => ['code' => 'UNAUTHORIZED', 'message' => 'Сессия истекла или не авторизован']]);
        exit(0);
    }
    echo json_encode([
        'success' => true,
        'csrfToken' => generateToken('csrf_', 8),
        'user' => [
            'id' => $currentUser['id'],
            'login' => $currentUser['login'],
            'name' => $currentUser['name'],
            'role' => $currentUser['role'],
            'status' => $currentUser['status'],
            'is_part_time' => (bool)($currentUser['is_part_time'] ?? false),
            'is_senior' => (bool)($currentUser['is_senior'] ?? false),
            'telegram_username' => $currentUser['telegram_username'] ?? '',
            'locations' => $currentUser['locations'] ?? []
        ]
    ]);
    exit(0);
}

// 4. Logout
if (strpos($route, 'auth/logout') !== false && $method === 'POST') {
    if (!empty($token) && isset($db['sessions'][$token])) {
        unset($db['sessions'][$token]);
        saveDb($dbFile, $db);
    }
    setcookie('pvz_session', '', time() - 3600, '/');
    echo json_encode(['success' => true]);
    exit(0);
}

// 5. Staff Management
if (strpos($route, 'staff') !== false) {
    $isManager = ($currentUser && ($currentUser['role'] ?? '') === 'manager');

    if ($method === 'GET') {
        $staffList = [];
        foreach ($db['users'] as $u) {
            if ($u['role'] === 'employee') {
                $status = $u['status'] ?? 'active';
                if ($status === 'blocked') {
                    $status = 'deactivated';
                }
                $staffList[] = [
                    'id' => $u['id'],
                    'name' => $u['name'],
                    'login' => $u['login'],
                    'password' => $isManager ? ($u['password_plain'] ?? '') : '',
                    'role' => $u['role'],
                    'status' => $status,
                    'isPartTime' => (bool)($u['is_part_time'] ?? false),
                    'isSenior' => (bool)($u['is_senior'] ?? false),
                    'hasAccess' => ($status === 'active'),
                    'locations' => $u['locations'] ?? [],
                    'telegramUsername' => $u['telegram_username'] ?? ''
                ];
            }
        }
        echo json_encode(['success' => true, 'staff' => $staffList]);
        exit(0);
    }

    if ($method === 'POST') {
        if (!$isManager) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Действие разрешено только руководителю']]);
            exit(0);
        }
        $newId = 'usr-' . generateToken('', 8);
        $newStaff = [
            'id' => $newId,
            'name' => trim($body['name'] ?? ''),
            'login' => trim($body['login'] ?? ''),
            'password_plain' => trim($body['password'] ?? '1234'),
            'password_hash' => password_hash(trim($body['password'] ?? '1234'), PASSWORD_DEFAULT),
            'role' => 'employee',
            'status' => 'active',
            'is_part_time' => (bool)($body['isPartTime'] ?? false),
            'isSenior' => (bool)($body['isSenior'] ?? false),
            'locations' => $body['locations'] ?? [],
            'telegram_username' => trim($body['telegramUsername'] ?? '')
        ];
        $db['users'][] = $newStaff;
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'employee' => $newStaff]);
        exit(0);
    }

    if ($method === 'PATCH') {
        if (!$isManager) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Действие разрешено только руководителю']]);
            exit(0);
        }
        preg_match('#staff/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        foreach ($db['users'] as &$u) {
            if ($u['id'] === $targetId) {
                if (isset($body['status'])) $u['status'] = $body['status'];
                if (isset($body['login'])) $u['login'] = trim($body['login']);
                if (!empty($body['password'])) {
                    $u['password_plain'] = trim($body['password']);
                    $u['password_hash'] = password_hash(trim($body['password']), PASSWORD_DEFAULT);
                }
                if (isset($body['locations'])) $u['locations'] = $body['locations'];
                if (isset($body['isPartTime'])) $u['is_part_time'] = (bool)$body['isPartTime'];
                if (isset($body['isSenior'])) $u['is_senior'] = (bool)$body['isSenior'];
                if (isset($body['telegramUsername'])) $u['telegram_username'] = trim($body['telegramUsername']);
                break;
            }
        }
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }

    if ($method === 'DELETE') {
        if (!$isManager) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Действие разрешено только руководителю']]);
            exit(0);
        }
        preg_match('#staff/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['users'] = array_values(array_filter($db['users'], function($u) use ($targetId) {
            return $u['id'] !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 6. Check-ins
if (strpos($route, 'checkins') !== false) {
    if ($method === 'GET') {
        // Return records deduplicated by employeeId and date (keeping the latest)
        $raw = $db['checkins'] ?? [];
        $unique = [];
        $seen = [];
        foreach (array_reverse($raw) as $c) {
            $key = ($c['employeeId'] ?? '') . '_' . ($c['date'] ?? '');
            if (!isset($seen[$key])) {
                $seen[$key] = true;
                $unique[] = $c;
            }
        }
        $records = array_reverse($unique);
        echo json_encode(['success' => true, 'records' => $records]);
        exit(0);
    }

    if ($method === 'POST') {
        $empId = $body['employeeId'] ?? ($currentUser['id'] ?? 'usr-unknown');
        
        $empName = 'Сотрудник';
        foreach ($db['users'] as $u) {
            if ($u['id'] === $empId) {
                $empName = $u['name'];
                break;
            }
        }

        $now = new DateTime('now', new DateTimeZone('Europe/Moscow'));
        $dateStr = $body['date'] ?? $now->format('Y-m-d');
        $timeStr = $now->format('H:i');

        if (!isset($db['checkins']) || !is_array($db['checkins'])) {
            $db['checkins'] = [];
        }

        // Check if there is ALREADY an existing check-in for this employee on this date
        $existingIndex = -1;
        foreach ($db['checkins'] as $idx => $c) {
            if (($c['employeeId'] ?? '') === $empId && ($c['date'] ?? '') === $dateStr) {
                $existingIndex = $idx;
                break;
            }
        }

        $fallbackLoc = $db['locations'][0]['code'] ?? '';
        if ($existingIndex !== -1) {
            // Update existing shift (preserving sales, ID, and original check-in time)
            $db['checkins'][$existingIndex]['shiftType'] = $body['shiftType'] ?? 'standard';
            $db['checkins'][$existingIndex]['location'] = $body['location'] ?? $fallbackLoc;
            $db['checkins'][$existingIndex]['timestamp'] = $dateStr . 'T' . $timeStr . ':00';
            if (empty($db['checkins'][$existingIndex]['checkedInAt'])) {
                $db['checkins'][$existingIndex]['checkedInAt'] = $dateStr . 'T' . $timeStr . ':00';
            }
            if (isset($body['initialCash'])) {
                $db['checkins'][$existingIndex]['initialCash'] = floatval($body['initialCash']);
            }
            if (isset($body['cashNotes'])) {
                $db['checkins'][$existingIndex]['cashNotes'] = trim($body['cashNotes']);
            }
            $record = $db['checkins'][$existingIndex];
        } else {
            $recId = 'chk-' . generateToken('', 8);
            $record = [
                'id' => $recId,
                'employeeId' => $empId,
                'employeeName' => $empName,
                'shiftType' => $body['shiftType'] ?? 'standard',
                'location' => $body['location'] ?? $fallbackLoc,
                'date' => $dateStr,
                'timestamp' => $dateStr . 'T' . $timeStr . ':00',
                'checkedInAt' => $dateStr . 'T' . $timeStr . ':00',
                'initialCash' => isset($body['initialCash']) ? floatval($body['initialCash']) : 0,
                'cashNotes' => trim($body['cashNotes'] ?? ''),
                'hasConflict' => false
            ];
            $db['checkins'][] = $record;
        }

        // Clean up any historical duplicate entries for this employee + date, keeping only the final record
        $filtered = [];
        $seen = [];
        foreach (array_reverse($db['checkins']) as $c) {
            $key = ($c['employeeId'] ?? '') . '_' . ($c['date'] ?? '');
            if (!isset($seen[$key])) {
                $seen[$key] = true;
                $filtered[] = $c;
            }
        }
        $db['checkins'] = array_reverse($filtered);
        saveDb($dbFile, $db);

        $tgText = "🟢 *Отметка о выходе/изменении смены*\n"
                . "👤 Сотрудник: *{$empName}*\n"
                . "📍 Локация: *{$record['location']}*\n"
                . "⏰ Время: *{$timeStr}* (МСК)\n"
                . "📅 Дата: *{$dateStr}*";
        sendTelegramMessage($telegramToken, $managerChatId, $tgText);

        echo json_encode(['success' => true, 'record' => $record]);
        exit(0);
    }

    if ($method === 'PATCH') {
        preg_match('#checkins/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $found = false;
        foreach ($db['checkins'] as &$c) {
            if (($c['id'] ?? '') === $targetId) {
                if (isset($body['shiftType'])) $c['shiftType'] = $body['shiftType'];
                if (isset($body['location'])) $c['location'] = $body['location'];
                if (isset($body['date'])) $c['date'] = $body['date'];
                $found = true;
                break;
            }
        }
        if ($found) {
            saveDb($dbFile, $db);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Запись не найдена']);
        }
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#checkins/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['checkins'] = array_values(array_filter($db['checkins'], function($c) use ($targetId) {
            return ($c['id'] ?? '') !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 7. Sales
if (strpos($route, 'sales') !== false) {
    if ($method === 'GET') {
        echo json_encode(['success' => true, 'sales' => $db['sales'] ?? []]);
        exit(0);
    }

    if ($method === 'POST') {
        $saleId = 'sale-' . generateToken('', 8);
        $empId = $body['employeeId'] ?? ($currentUser['id'] ?? 'usr-unknown');
        $empName = 'Сотрудник';
        foreach ($db['users'] as $u) {
            if ($u['id'] === $empId) {
                $empName = $u['name'];
                break;
            }
        }

        $now = new DateTime('now', new DateTimeZone('Europe/Moscow'));
        $dateStr = $body['date'] ?? $now->format('Y-m-d');

        $saleEntry = [
            'id' => $saleId,
            'employeeId' => $empId,
            'employeeName' => $empName,
            'date' => $dateStr,
            'sales' => $body['sales'] ?? [],
            'initialCash' => isset($body['initialCash']) ? floatval($body['initialCash']) : 0,
            'finalCash' => isset($body['finalCash']) ? floatval($body['finalCash']) : 0,
            'collectedCash' => isset($body['collectedCash']) ? floatval($body['collectedCash']) : 0,
            'cashNotes' => trim($body['cashNotes'] ?? ''),
            'timestamp' => $now->format('c')
        ];

        $db['sales'][] = $saleEntry;

        // Also attach sales & cash to checkin record
        if (isset($db['checkins']) && is_array($db['checkins'])) {
            foreach ($db['checkins'] as &$c) {
                if (($c['employeeId'] ?? '') === $empId && ($c['date'] ?? '') === $dateStr) {
                    $c['sales'] = $body['sales'] ?? [];
                    $c['salesSubmittedAt'] = $now->format('c');
                    if (isset($body['finalCash'])) $c['finalCash'] = floatval($body['finalCash']);
                    if (isset($body['collectedCash'])) $c['collectedCash'] = floatval($body['collectedCash']);
                    if (isset($body['initialCash'])) $c['initialCash'] = floatval($body['initialCash']);
                    if (isset($body['cashNotes'])) $c['cashNotes'] = trim($body['cashNotes']);
                    break;
                }
            }
        }

        saveDb($dbFile, $db);

        $photoCash = $body['sales']['photo']['cash'] ?? 0;
        $photoCard = $body['sales']['photo']['card'] ?? 0;
        $printCash = $body['sales']['print']['cash'] ?? 0;
        $printCard = $body['sales']['print']['card'] ?? 0;
        $lamCash = $body['sales']['lamination']['cash'] ?? 0;
        $lamCard = $body['sales']['lamination']['card'] ?? 0;
        $total = $photoCash + $photoCard + $printCash + $printCard + $lamCash + $lamCard;

        $tgText = "💰 *Отчет по выручке внесен!*\n"
                . "👤 Сотрудник: *{$empName}*\n"
                . "📅 Дата: *{$dateStr}*\n"
                . "💵 Наличные: *" . ($photoCash + $printCash + $lamCash) . " ₽*\n"
                . "💳 Безнал: *" . ($photoCard + $printCard + $lamCard) . " ₽*\n"
                . "🔥 Итого: *{$total} ₽*";
        
        if (!empty($body['finalCash'])) {
            $tgText .= "\n🏦 Остаток в кассе: *{$body['finalCash']} ₽*";
        }
        if (!empty($body['collectedCash'])) {
            $tgText .= "\n💼 Инкассация: *{$body['collectedCash']} ₽*";
        }

        sendTelegramMessage($telegramToken, $managerChatId, $tgText);

        echo json_encode(['success' => true, 'sale' => $saleEntry]);
        exit(0);
    }
}

// 8. Messages
if (strpos($route, 'messages') !== false) {
    if ($method === 'GET') {
        echo json_encode(['success' => true, 'messages' => $db['messages'] ?? []]);
        exit(0);
    }

    if ($method === 'POST') {
        if (strpos($route, 'read-all') !== false) {
            foreach ($db['messages'] as &$m) {
                $m['read'] = true;
            }
            saveDb($dbFile, $db);
            echo json_encode(['success' => true]);
            exit(0);
        }

        $msgId = 'msg-' . generateToken('', 8);
        $senderName = $currentUser['name'] ?? 'Сотрудник';
        $text = trim($body['message'] ?? '');

        $newMsg = [
            'id' => $msgId,
            'senderId' => $currentUser['id'] ?? 'unknown',
            'senderName' => $senderName,
            'message' => $text,
            'timestamp' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c'),
            'read' => false
        ];
        $db['messages'][] = $newMsg;
        saveDb($dbFile, $db);

        $tgText = "💬 *Новое сообщение руководителю:*\n"
                . "От: *{$senderName}*\n"
                . "Текст: _{$text}_";
        sendTelegramMessage($telegramToken, $managerChatId, $tgText);

        echo json_encode(['success' => true, 'message' => $newMsg]);
        exit(0);
    }

    if ($method === 'PATCH') {
        preg_match('#messages/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        foreach ($db['messages'] as &$msg) {
            if ($msg['id'] === $targetId) {
                $msg['read'] = true;
                break;
            }
        }
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 9. Scheduled Telegram Notifications & In-app Notifications
if (strpos($route, 'notifications/schedules') !== false) {
    if (!isset($db['scheduled_notifications']) || !is_array($db['scheduled_notifications'])) {
        $db['scheduled_notifications'] = [];
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'schedules' => $db['scheduled_notifications']]);
        exit(0);
    }

    if ($method === 'POST') {
        // Test send via Telegram
        if (strpos($route, 'test') !== false) {
            preg_match('#schedules/([^/?]+)/test#', $route, $m);
            $targetId = $m[1] ?? '';
            $found = null;
            foreach ($db['scheduled_notifications'] as $r) {
                if ($r['id'] === $targetId) {
                    $found = $r;
                    break;
                }
            }
            if ($found) {
                $targetRole = $found['targetRole'] ?? 'all';
                $bRes = sendTelegramBroadcastToStaff($telegramToken, $managerChatId, $db, $targetRole, $tgText);
                $delivered = $bRes['delivered'] ?? 0;
                echo json_encode([
                    'success' => true,
                    'sent' => true,
                    'deliveredCount' => $delivered,
                    'message' => "Рассылка отправлена в Telegram" . ($delivered > 0 ? " ({$delivered} сотрудн. с Telegram)" : "")
                ]);
                exit(0);
            }
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => ['message' => 'Правило не найдено']]);
            exit(0);
        }

        // Create schedule
        $title = trim($body['title'] ?? '');
        $text = trim($body['text'] ?? '');
        $scheduleType = $body['scheduleType'] ?? 'daily';
        $timeOfDay = trim($body['timeOfDay'] ?? '20:50');
        $targetRole = $body['targetRole'] ?? 'all';

        if (empty($title) || empty($text) || empty($timeOfDay)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => ['message' => 'Заполните все обязательные поля']]);
            exit(0);
        }

        $newSchedule = [
            'id' => 'sched-' . generateToken('', 8),
            'title' => $title,
            'text' => $text,
            'scheduleType' => $scheduleType,
            'timeOfDay' => $timeOfDay,
            'targetRole' => $targetRole,
            'isActive' => true,
            'createdAt' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c')
        ];

        $db['scheduled_notifications'][] = $newSchedule;
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'schedule' => $newSchedule]);
        exit(0);
    }

    if ($method === 'PATCH') {
        preg_match('#schedules/([^/?]+)/toggle#', $route, $m);
        $targetId = $m[1] ?? '';
        $isActive = isset($body['isActive']) ? (bool)$body['isActive'] : true;
        foreach ($db['scheduled_notifications'] as &$r) {
            if ($r['id'] === $targetId) {
                $r['isActive'] = $isActive;
                break;
            }
        }
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#schedules/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['scheduled_notifications'] = array_values(array_filter($db['scheduled_notifications'], function($r) use ($targetId) {
            return $r['id'] !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

if (strpos($route, 'notifications') !== false) {
    if ($method === 'GET') {
        echo json_encode(['success' => true, 'notifications' => $db['notifications'] ?? []]);
        exit(0);
    }

    if ($method === 'POST') {
        if (strpos($route, 'thank-you') !== false) {
            $loc = $body['location'] ?? ($db['locations'][0]['code'] ?? '');
            $notif = [
                'id' => 'notif-' . generateToken('', 8),
                'type' => 'thank_you',
                'title' => 'Благодарность от руководителя',
                'message' => 'Спасибо за отличную смену на пункте ' . $loc . '!',
                'location' => $loc,
                'timestamp' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c'),
                'read' => false
            ];
            $db['notifications'][] = $notif;
            saveDb($dbFile, $db);

            sendTelegramMessage($telegramToken, $managerChatId, "❤️ Отправлена благодарность сотруднику смены ({$loc})");
            echo json_encode(['success' => true]);
            exit(0);
        }

        if (strpos($route, 'read-all') !== false) {
            foreach ($db['notifications'] as &$n) {
                $n['read'] = true;
            }
            saveDb($dbFile, $db);
            echo json_encode(['success' => true]);
            exit(0);
        }
    }

    if ($method === 'PATCH') {
        preg_match('#notifications/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        foreach ($db['notifications'] as &$n) {
            if ($n['id'] === $targetId) {
                $n['read'] = true;
                break;
            }
        }
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#notifications/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['notifications'] = array_values(array_filter($db['notifications'], function($n) use ($targetId) {
            return $n['id'] !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 10. Applications
if (strpos($route, 'applications') !== false) {
    if ($method === 'GET') {
        echo json_encode(['success' => true, 'applications' => $db['applications'] ?? []]);
        exit(0);
    }

    if ($method === 'POST') {
        $appId = 'app-' . generateToken('', 8);
        $newApp = [
            'id' => $appId,
            'name' => trim($body['name'] ?? ''),
            'telegramUsername' => trim($body['telegramUsername'] ?? ''),
            'status' => 'pending',
            'createdAt' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c')
        ];
        $db['applications'][] = $newApp;
        saveDb($dbFile, $db);

        $tgText = "📝 *Новая заявка на регистрацию сотрудника!*\n"
                . "ФИО: *{$newApp['name']}*\n"
                . "Telegram: @" . ltrim($newApp['telegramUsername'], '@');
        sendTelegramMessage($telegramToken, $managerChatId, $tgText);

        echo json_encode([
            'success' => true,
            'applicationId' => $appId,
            'id' => $appId,
            'application' => $newApp
        ]);
        exit(0);
    }

    if ($method === 'PATCH') {
        preg_match('#applications/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $action = $body['action'] ?? '';
        $isAccept = ($action === 'accept' || $action === 'approve');

        foreach ($db['applications'] as &$app) {
            if ($app['id'] === $targetId) {
                $app['status'] = $isAccept ? 'accepted' : 'rejected';
                $app['note'] = $body['note'] ?? '';
                if ($isAccept && !empty($body['generatedLogin'])) {
                    $newStaff = [
                        'id' => 'usr-' . generateToken('', 8),
                        'name' => $app['name'],
                        'login' => trim($body['generatedLogin']),
                        'password_plain' => trim($body['generatedPassword'] ?? '1234'),
                        'password_hash' => password_hash(trim($body['generatedPassword'] ?? '1234'), PASSWORD_DEFAULT),
                        'role' => 'employee',
                        'status' => 'active',
                        'locations' => $body['assignedLocations'] ?? [],
                        'telegram_username' => $app['telegramUsername']
                    ];
                    $db['users'][] = $newStaff;
                }
                break;
            }
        }
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 11. Bot Logs & Restart
if (strpos($route, 'bot/logs') !== false) {
    echo json_encode(['success' => true, 'logs' => $db['bot_logs'] ?? []]);
    exit(0);
}

if (strpos($route, 'bot/restart') !== false && $method === 'POST') {
    $log = [
        'id' => 'log-' . generateToken('', 8),
        'timestamp' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c'),
        'status' => 'SUCCESS',
        'message' => 'Сервер и бот успешно перезапущены руководителем'
    ];
    $db['bot_logs'][] = $log;
    saveDb($dbFile, $db);

    sendTelegramMessage($telegramToken, $managerChatId, "🔄 Бот успешно перезапущен руководителем.");
    echo json_encode(['success' => true, 'log' => $log]);
    exit(0);
}

// 12. Shift Swaps (Биржа смен и замен)
if (strpos($route, 'swaps') !== false) {
    if (!isset($db['swaps']) || !is_array($db['swaps'])) {
        $db['swaps'] = [];
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'swaps' => $db['swaps']]);
        exit(0);
    }

    if ($method === 'POST') {
        $action = $body['action'] ?? 'create';
        
        if ($action === 'claim') {
            $swapId = $body['swapId'] ?? '';
            $candId = $body['candidateId'] ?? ($currentUser['id'] ?? 'usr-unknown');
            $candName = 'Сотрудник';
            foreach ($db['users'] as $u) {
                if ($u['id'] === $candId) {
                    $candName = $u['name'];
                    break;
                }
            }

            foreach ($db['swaps'] as &$sw) {
                if ($sw['id'] === $swapId && $sw['status'] === 'open') {
                    $sw['candidateId'] = $candId;
                    $sw['candidateName'] = $candName;
                    $sw['status'] = 'claimed';
                    saveDb($dbFile, $db);

                    $tgText = "🤝 *Отклик на подмену на бирже смен!*\n"
                            . "👤 Хочет выйти: *{$candName}*\n"
                            . "📅 Дата: *{$sw['date']}*\n"
                            . "📍 Пункт: *{$sw['location']}*\n"
                            . "👤 Кто передает: *{$sw['requesterName']}*\n"
                            . "⚡ Требуется подтверждение руководителя в панели.";
                    sendTelegramMessage($telegramToken, $managerChatId, $tgText);

                    echo json_encode(['success' => true, 'swap' => $sw]);
                    exit(0);
                }
            }
            echo json_encode(['success' => false, 'error' => 'Заявка на подмену не найдена или уже занята']);
            exit(0);
        }

        // Create new swap request
        $swapId = 'swp-' . generateToken('', 8);
        $reqId = $body['requesterId'] ?? ($currentUser['id'] ?? 'usr-unknown');
        $reqName = 'Сотрудник';
        foreach ($db['users'] as $u) {
            if ($u['id'] === $reqId) {
                $reqName = $u['name'];
                break;
            }
        }

        $now = new DateTime('now', new DateTimeZone('Europe/Moscow'));
        $newSwap = [
            'id' => $swapId,
            'requesterId' => $reqId,
            'requesterName' => $reqName,
            'date' => $body['date'] ?? $now->format('Y-m-d'),
            'shiftType' => $body['shiftType'] ?? 'standard',
            'location' => $body['location'] ?? ($db['locations'][0]['code'] ?? ''),
            'reason' => trim($body['reason'] ?? ''),
            'status' => 'open',
            'createdAt' => $now->format('c')
        ];

        $db['swaps'][] = $newSwap;
        saveDb($dbFile, $db);

        $tgText = "📢 *Запрос на подмену / открытая смена на бирже!*\n"
                . "👤 Сотрудник: *{$reqName}*\n"
                . "📅 Дата: *{$newSwap['date']}*\n"
                . "📍 Пункт: *{$newSwap['location']}*\n"
                . "💬 Причина: _{$newSwap['reason']}_";
        sendTelegramMessage($telegramToken, $managerChatId, $tgText);

        echo json_encode(['success' => true, 'swap' => $newSwap]);
        exit(0);
    }

    if ($method === 'PATCH') {
        preg_match('#swaps/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $decision = $body['status'] ?? ($body['action'] === 'approve' ? 'approved' : 'rejected');

        foreach ($db['swaps'] as &$sw) {
            if ($sw['id'] === $targetId) {
                $sw['status'] = $decision;
                $sw['resolvedAt'] = (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c');
                
                // If approved and has candidate, transfer schedule / checkin
                if ($decision === 'approved' && !empty($sw['candidateId'])) {
                    if (isset($db['schedules']) && is_array($db['schedules'])) {
                        foreach ($db['schedules'] as &$sch) {
                            if ($sch['date'] === $sw['date'] && $sch['location'] === $sw['location']) {
                                $sch['employeeId'] = $sw['candidateId'];
                                $sch['employeeName'] = $sw['candidateName'] ?? 'Сотрудник';
                            }
                        }
                    }
                }

                saveDb($dbFile, $db);

                $statusLabel = ($decision === 'approved') ? '✅ ОДОБРЕНА' : '❌ ОТКЛОНЕНА';
                $tgText = "📋 *Решение по замене смены: {$statusLabel}*\n"
                        . "📅 Дата: *{$sw['date']}* ({$sw['location']})\n"
                        . "👤 Передал: *{$sw['requesterName']}*\n"
                        . "👤 Принял: *" . ($sw['candidateName'] ?? '—') . "*";
                sendTelegramMessage($telegramToken, $managerChatId, $tgText);

                echo json_encode(['success' => true, 'swap' => $sw]);
                exit(0);
            }
        }
        echo json_encode(['success' => false, 'error' => 'Заявка не найдена']);
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#swaps/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['swaps'] = array_values(array_filter($db['swaps'], function($sw) use ($targetId) {
            return ($sw['id'] ?? '') !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 13a. Schedule Templates (Шаблоны и сценарии графиков)
if (strpos($route, 'schedules/templates') !== false) {
    if (!isset($db['schedule_templates']) || !is_array($db['schedule_templates'])) {
        $db['schedule_templates'] = [];
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'templates' => $db['schedule_templates']]);
        exit(0);
    }

    if ($method === 'POST') {
        $id = $body['id'] ?? ('tpl-' . generateToken('', 8));
        $name = trim($body['name'] ?? '');
        $location = trim($body['location'] ?? ($db['locations'][0]['code'] ?? ''));
        $scenarioType = $body['scenarioType'] ?? '2/2';
        $mainStaffIds = is_array($body['mainStaffIds'] ?? null) ? $body['mainStaffIds'] : [];
        $partTimeStaffIds = is_array($body['partTimeStaffIds'] ?? null) ? $body['partTimeStaffIds'] : [];
        $defaultShiftType = $body['defaultShiftType'] ?? 'standard';

        $db['schedule_templates'] = array_values(array_filter($db['schedule_templates'], function($t) use ($id) {
            return ($t['id'] ?? '') !== $id;
        }));

        $newTpl = [
            'id' => $id,
            'name' => $name,
            'location' => $location,
            'scenarioType' => $scenarioType,
            'mainStaffIds' => $mainStaffIds,
            'partTimeStaffIds' => $partTimeStaffIds,
            'defaultShiftType' => $defaultShiftType,
            'createdAt' => date('c')
        ];

        $db['schedule_templates'][] = $newTpl;
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'templates' => $db['schedule_templates'], 'template' => $newTpl]);
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#schedules/templates/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['schedule_templates'] = array_values(array_filter($db['schedule_templates'], function($t) use ($targetId) {
            return ($t['id'] ?? '') !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'templates' => $db['schedule_templates']]);
        exit(0);
    }
}

// 13b. Schedule Publish Broadcast (Публикация графика)
if (strpos($route, 'schedules/publish') !== false && $method === 'POST') {
    if (!isset($db['notifications']) || !is_array($db['notifications'])) {
        $db['notifications'] = [];
    }

    $month = $body['month'] ?? '';
    $loc = $body['location'] ?? '';
    $publishedAt = date('c');

    $notif = [
        'id' => 'notif-' . generateToken('', 8),
        'toEmployeeId' => 'all',
        'title' => '📅 Опубликован график смен ' . ($month ? "на $month" : ''),
        'text' => 'Руководитель утвердил и разослал график смен' . ($loc ? " для пункта $loc" : '') . '. Проверьте свои запланированные смены в календаре!',
        'type' => 'status_update',
        'timestamp' => $publishedAt,
        'read' => false
    ];

    array_unshift($db['notifications'], $notif);
    if (count($db['notifications']) > 200) {
        $db['notifications'] = array_slice($db['notifications'], 0, 200);
    }

    saveDb($dbFile, $db);
    echo json_encode(['success' => true, 'publishedAt' => $publishedAt]);
    exit(0);
}

// 13. Monthly Schedules & Planning (График смен)
if (strpos($route, 'schedules') !== false) {
    if (!isset($db['schedules']) || !is_array($db['schedules'])) {
        $db['schedules'] = [];
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'schedules' => $db['schedules']]);
        exit(0);
    }

    if ($method === 'POST') {
        if (isset($body['batch']) && is_array($body['batch'])) {
            $replaceMonth = $body['replaceMonth'] ?? null;
            $replaceLoc = $body['replaceLocation'] ?? null;

            if ($replaceMonth) {
                $db['schedules'] = array_values(array_filter($db['schedules'], function($s) use ($replaceMonth, $replaceLoc) {
                    $matchMonth = strpos($s['date'] ?? '', $replaceMonth) === 0;
                    $matchLoc = $replaceLoc ? (($s['location'] ?? '') === $replaceLoc) : true;
                    return !($matchMonth && $matchLoc);
                }));
            } else {
                foreach ($body['batch'] as $item) {
                    $itemDate = $item['date'] ?? '';
                    $itemLoc = $item['location'] ?? '';
                    $itemEmp = $item['employeeId'] ?? '';
                    $db['schedules'] = array_values(array_filter($db['schedules'], function($s) use ($itemDate, $itemLoc, $itemEmp) {
                        return !(($s['date'] ?? '') === $itemDate && ($s['location'] ?? '') === $itemLoc && ($s['employeeId'] ?? '') === $itemEmp);
                    }));
                }
            }

            $defLoc = $db['locations'][0]['code'] ?? '';
            foreach ($body['batch'] as $item) {
                $bDate = $item['date'] ?? '';
                $bLoc = $item['location'] ?? $defLoc;
                $bEmp = $item['employeeId'] ?? '';
                // Enforce rule: never allow an employee to have 2 shifts on the same date at different PVZs
                $hasConflict = false;
                foreach ($db['schedules'] as $existingSch) {
                    if (($existingSch['employeeId'] ?? '') === $bEmp && ($existingSch['date'] ?? '') === $bDate && ($existingSch['location'] ?? '') !== $bLoc) {
                        $hasConflict = true;
                        break;
                    }
                }
                if (!$hasConflict) {
                    $db['schedules'][] = [
                        'id' => $item['id'] ?? ('sch-' . generateToken('', 8)),
                        'date' => $bDate,
                        'location' => $bLoc,
                        'employeeId' => $bEmp,
                        'employeeName' => $item['employeeName'] ?? 'Сотрудник',
                        'shiftType' => $item['shiftType'] ?? 'standard',
                        'note' => $item['note'] ?? ''
                    ];
                }
            }

            saveDb($dbFile, $db);
            echo json_encode(['success' => true, 'schedules' => $db['schedules']]);
            exit(0);
        }

        if (strpos($route, 'schedules/slot') !== false || isset($body['shifts'])) {
            $date = $body['date'] ?? '';
            $loc = $body['location'] ?? ($db['locations'][0]['code'] ?? '');
            $shifts = is_array($body['shifts'] ?? null) ? $body['shifts'] : [];

            // Check conflicts
            foreach ($shifts as $sh) {
                $shEmp = $sh['employeeId'] ?? '';
                if (empty($shEmp)) continue;
                foreach ($db['schedules'] as $existingSch) {
                    if (($existingSch['employeeId'] ?? '') === $shEmp && ($existingSch['date'] ?? '') === $date && ($existingSch['location'] ?? '') !== $loc) {
                        $shEmpName = $sh['employeeName'] ?? 'Сотрудник';
                        $otherLoc = $existingSch['location'] ?? 'другой ПВЗ';
                        echo json_encode([
                            'success' => false,
                            'error' => "Сотрудник {$shEmpName} уже назначен на смену в ПВЗ \"{$otherLoc}\" на {$date}. Один сотрудник не может работать в двух ПВЗ одновременно."
                        ]);
                        exit(0);
                    }
                }
            }

            // Remove existing for this date & loc
            $db['schedules'] = array_values(array_filter($db['schedules'], function($s) use ($date, $loc) {
                return !(($s['date'] ?? '') === $date && ($s['location'] ?? '') === $loc);
            }));

            // Add new shifts
            foreach ($shifts as $sh) {
                $shEmp = $sh['employeeId'] ?? '';
                if (empty($shEmp)) continue;
                $db['schedules'][] = [
                    'id' => $sh['id'] ?? ('sch-' . generateToken('', 8)),
                    'date' => $date,
                    'location' => $loc,
                    'employeeId' => $shEmp,
                    'employeeName' => $sh['employeeName'] ?? 'Сотрудник',
                    'shiftType' => $sh['shiftType'] ?? 'standard',
                    'note' => $sh['note'] ?? ''
                ];
            }

            saveDb($dbFile, $db);
            echo json_encode(['success' => true, 'schedules' => $db['schedules']]);
            exit(0);
        }

        $date = $body['date'] ?? '';
        $loc = $body['location'] ?? ($db['locations'][0]['code'] ?? '');
        $empId = $body['employeeId'] ?? '';
        $empName = $body['employeeName'] ?? 'Сотрудник';
        $shiftType = $body['shiftType'] ?? 'standard';
        $note = trim($body['note'] ?? '');

        // Enforce rule: an employee cannot be added to another PVZ if they already have a shift on this date
        if (!empty($empId) && !empty($date)) {
            foreach ($db['schedules'] as $existingSch) {
                if (($existingSch['employeeId'] ?? '') === $empId && ($existingSch['date'] ?? '') === $date && ($existingSch['location'] ?? '') !== $loc) {
                    $otherLocName = $existingSch['location'] ?? 'другой ПВЗ';
                    echo json_encode([
                        'success' => false,
                        'error' => "Сотрудник $empName уже назначен на смену в ПВЗ \"$otherLocName\" на $date. Один сотрудник не может работать в двух ПВЗ одновременно."
                    ]);
                    exit(0);
                }
            }
        }

        // Remove existing planned shift for same date + location + employee
        $db['schedules'] = array_values(array_filter($db['schedules'], function($s) use ($date, $loc, $empId) {
            return !(($s['date'] ?? '') === $date && ($s['location'] ?? '') === $loc && ($s['employeeId'] ?? '') === $empId);
        }));

        if (!empty($empId)) {
            $schId = 'sch-' . generateToken('', 8);
            $db['schedules'][] = [
                'id' => $schId,
                'date' => $date,
                'location' => $loc,
                'employeeId' => $empId,
                'employeeName' => $empName,
                'shiftType' => $shiftType,
                'note' => $note
            ];
        }

        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'schedules' => $db['schedules']]);
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#schedules/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['schedules'] = array_values(array_filter($db['schedules'], function($s) use ($targetId) {
            return ($s['id'] ?? '') !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 14. Availability / Time-off requests (Пожелания по графику и отпускам)
if (strpos($route, 'availability') !== false) {
    if (!isset($db['availability']) || !is_array($db['availability'])) {
        $db['availability'] = [];
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'availability' => $db['availability']]);
        exit(0);
    }

    if ($method === 'POST') {
        $empId = $body['employeeId'] ?? ($currentUser['id'] ?? 'usr-unknown');
        $empName = 'Сотрудник';
        foreach ($db['users'] as $u) {
            if ($u['id'] === $empId) {
                $empName = $u['name'];
                break;
            }
        }

        $date = $body['date'] ?? '';
        $type = $body['type'] ?? 'unavailable';
        $comment = trim($body['comment'] ?? '');

        // Remove existing availability for same employee + date
        $db['availability'] = array_values(array_filter($db['availability'], function($a) use ($empId, $date) {
            return !($a['employeeId'] === $empId && $a['date'] === $date);
        }));

        if ($type !== 'clear') {
            $avId = 'av-' . generateToken('', 8);
            $db['availability'][] = [
                'id' => $avId,
                'employeeId' => $empId,
                'employeeName' => $empName,
                'date' => $date,
                'type' => $type,
                'comment' => $comment,
                'createdAt' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c'),
                'status' => (string)($body['status'] ?? 'pending')
            ];
        }

        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'availability' => $db['availability']]);
        exit(0);
    }

    if ($method === 'PATCH' || ($method === 'POST' && isset($body['status']))) {
        preg_match('#availability/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $newStatus = (string)($body['status'] ?? 'approved');
        $updated = false;
        foreach ($db['availability'] as &$a) {
            if (($a['id'] ?? '') === $targetId) {
                $a['status'] = $newStatus;
                $updated = true;
                break;
            }
        }
        unset($a);
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'updated' => $updated, 'availability' => $db['availability']]);
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#availability/([^/?]+)#', $route, $m);
        $targetId = $m[1] ?? '';
        $db['availability'] = array_values(array_filter($db['availability'], function($a) use ($targetId) {
            return ($a['id'] ?? '') !== $targetId;
        }));
        saveDb($dbFile, $db);
        echo json_encode(['success' => true]);
        exit(0);
    }
}

// 14b. Income Goals Management (Цели и прогноз заработка)
if (strpos($route, 'income-goals') !== false || strpos($route, 'goals') !== false) {
    if (!isset($db['income_goals']) || !is_array($db['income_goals'])) {
        $db['income_goals'] = [];
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'goals' => $db['income_goals']]);
        exit(0);
    }

    if ($method === 'POST') {
        $empId = $body['employeeId'] ?? ($currentUser['id'] ?? '');
        $month = $body['month'] ?? date('Y-m');
        $targetAmount = isset($body['targetAmount']) ? intval($body['targetAmount']) : 50000;

        if (empty($empId)) {
            echo json_encode(['success' => false, 'error' => 'employeeId не указан']);
            exit(0);
        }

        // Remove existing goal for this employeeId + month
        $db['income_goals'] = array_values(array_filter($db['income_goals'], function($g) use ($empId, $month) {
            return !(($g['employeeId'] ?? '') === $empId && ($g['month'] ?? '') === $month);
        }));

        $newGoal = [
            'employeeId' => $empId,
            'month' => $month,
            'targetAmount' => $targetAmount,
            'updatedAt' => date('c')
        ];

        $db['income_goals'][] = $newGoal;
        saveDb($dbFile, $db);

        echo json_encode(['success' => true, 'goal' => $newGoal, 'goals' => $db['income_goals']]);
        exit(0);
    }
}

// 14c. Payback PVZ Engine (Окупаемость ПВЗ)
if (strpos($route, 'payback') !== false) {
    if (!isset($db['payback_records']) || !is_array($db['payback_records'])) {
        $db['payback_records'] = [];
    }
    $defaultIncomes = ['Агентское вознаграждение', 'Продажи за смену (выручка)'];
    $defaultExpenses = [
        'Аренда помещения',
        'Фонд оплаты труда (ФОТ)',
        'Коммунальные услуги и интернет',
        'Эквайринг и банковское обслуживание',
        'Расходники (лента, скотч, пакетирование)',
        'Налоги'
    ];

    if (!isset($db['payback_article_templates']) || !is_array($db['payback_article_templates'])) {
        $db['payback_article_templates'] = [
            'incomeArticles' => $defaultIncomes,
            'expenseArticles' => $defaultExpenses,
            'customIncomeArticles' => [],
            'customExpenseArticles' => []
        ];
    } else {
        if (!isset($db['payback_article_templates']['incomeArticles']) || !is_array($db['payback_article_templates']['incomeArticles'])) {
            $db['payback_article_templates']['incomeArticles'] = array_values(array_unique(array_merge($defaultIncomes, $db['payback_article_templates']['customIncomeArticles'] ?? [])));
        }
        if (!isset($db['payback_article_templates']['expenseArticles']) || !is_array($db['payback_article_templates']['expenseArticles'])) {
            $db['payback_article_templates']['expenseArticles'] = array_values(array_unique(array_merge($defaultExpenses, $db['payback_article_templates']['customExpenseArticles'] ?? [])));
        }
    }

    if ($method === 'GET') {
        echo json_encode([
            'success' => true,
            'records' => $db['payback_records'],
            'templates' => $db['payback_article_templates']
        ]);
        exit(0);
    }

    $isManager = ($currentUser && ($currentUser['role'] ?? '') === 'manager');
    if (!$isManager) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Действие разрешено только руководителю']);
        exit(0);
    }

    if ($method === 'POST') {
        if (strpos($route, 'article') !== false) {
            $type = $body['type'] ?? '';
            $action = $body['action'] ?? '';
            $name = trim($body['name'] ?? '');
            $oldName = trim($body['oldName'] ?? '');

            if (empty($type) || empty($action) || empty($name)) {
                echo json_encode(['success' => false, 'error' => 'Некорректные параметры статьи']);
                exit(0);
            }

            $key = ($type === 'income') ? 'incomeArticles' : 'expenseArticles';
            if (!isset($db['payback_article_templates'][$key]) || !is_array($db['payback_article_templates'][$key])) {
                $db['payback_article_templates'][$key] = ($type === 'income') ? $defaultIncomes : $defaultExpenses;
            }

            if ($action === 'add') {
                if (!in_array($name, $db['payback_article_templates'][$key], true)) {
                    $db['payback_article_templates'][$key][] = $name;
                }
            } else if ($action === 'edit' && !empty($oldName)) {
                $idx = array_search($oldName, $db['payback_article_templates'][$key], true);
                if ($idx !== false) {
                    $db['payback_article_templates'][$key][$idx] = $name;
                } else if (!in_array($name, $db['payback_article_templates'][$key], true)) {
                    $db['payback_article_templates'][$key][] = $name;
                }
                foreach ($db['payback_records'] as &$rec) {
                    $subKey = ($type === 'income') ? 'incomes' : 'expenses';
                    if (isset($rec[$subKey]) && is_array($rec[$subKey])) {
                        foreach ($rec[$subKey] as &$item) {
                            if (($item['name'] ?? '') === $oldName) {
                                $item['name'] = $name;
                            }
                        }
                    }
                }
                unset($rec);
            } else if ($action === 'delete') {
                $db['payback_article_templates'][$key] = array_values(array_filter($db['payback_article_templates'][$key], function($n) use ($name) {
                    return $n !== $name;
                }));
                foreach ($db['payback_records'] as &$rec) {
                    $subKey = ($type === 'income') ? 'incomes' : 'expenses';
                    if (isset($rec[$subKey]) && is_array($rec[$subKey])) {
                        $rec[$subKey] = array_values(array_filter($rec[$subKey], function($item) use ($name) {
                            return ($item['name'] ?? '') !== $name;
                        }));
                    }
                }
                unset($rec);
            }

            saveDb($dbFile, $db);
            echo json_encode([
                'success' => true,
                'templates' => $db['payback_article_templates'],
                'records' => $db['payback_records']
            ]);
            exit(0);
        }

        // Standard save of a PVZ record
        $record = $body['record'] ?? null;
        if (!$record || empty($record['pvzCode']) || empty($record['month'])) {
            echo json_encode(['success' => false, 'error' => 'Не указан ПВЗ или месяц']);
            exit(0);
        }

        $targetPvz = trim($record['pvzCode']);
        $targetMonth = trim($record['month']);

        $db['payback_records'] = array_values(array_filter($db['payback_records'], function($r) use ($targetPvz, $targetMonth) {
            return !(($r['pvzCode'] ?? '') === $targetPvz && ($r['month'] ?? '') === $targetMonth);
        }));

        $newRec = [
            'pvzCode' => $targetPvz,
            'month' => $targetMonth,
            'incomes' => isset($record['incomes']) && is_array($record['incomes']) ? $record['incomes'] : [],
            'expenses' => isset($record['expenses']) && is_array($record['expenses']) ? $record['expenses'] : [],
            'updatedAt' => date('c')
        ];

        $db['payback_records'][] = $newRec;

        // Sync template lists with the active articles
        $currentIncomes = [];
        foreach ($newRec['incomes'] as $inc) {
            $nm = trim($inc['name'] ?? '');
            if (!empty($nm) && !in_array($nm, $currentIncomes, true)) {
                $currentIncomes[] = $nm;
            }
        }
        if (!empty($currentIncomes)) {
            $db['payback_article_templates']['incomeArticles'] = $currentIncomes;
        }

        $currentExpenses = [];
        foreach ($newRec['expenses'] as $exp) {
            $nm = trim($exp['name'] ?? '');
            if (!empty($nm) && !in_array($nm, $currentExpenses, true)) {
                $currentExpenses[] = $nm;
            }
        }
        if (!empty($currentExpenses)) {
            $db['payback_article_templates']['expenseArticles'] = $currentExpenses;
        }

        saveDb($dbFile, $db);
        echo json_encode([
            'success' => true,
            'records' => $db['payback_records'],
            'templates' => $db['payback_article_templates']
        ]);
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#/payback/([^/]+)/([^/]+)#', $route, $matches);
        if (!empty($matches[1]) && !empty($matches[2])) {
            $targetPvz = urldecode($matches[1]);
            $targetMonth = urldecode($matches[2]);
            $db['payback_records'] = array_values(array_filter($db['payback_records'], function($r) use ($targetPvz, $targetMonth) {
                return !(($r['pvzCode'] ?? '') === $targetPvz && ($r['month'] ?? '') === $targetMonth);
            }));
            saveDb($dbFile, $db);
        }
        echo json_encode(['success' => true, 'records' => $db['payback_records']]);
        exit(0);
    }
}

// 15. Pickup Points / Locations Management (Up to 30 ПВЗ)
if (strpos($route, 'locations') !== false) {
    if (!isset($db['locations']) || !is_array($db['locations'])) {
        $db['locations'] = [];
        saveDb($dbFile, $db);
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'locations' => $db['locations']]);
        exit(0);
    }

    $isManager = ($currentUser && ($currentUser['role'] ?? '') === 'manager');
    if (!$isManager) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Действие разрешено только руководителю']);
        exit(0);
    }

    if ($method === 'POST') {
        if (count($db['locations']) >= 30) {
            echo json_encode(['success' => false, 'error' => 'Достигнут лимит: максимально допустимо 30 пунктов выдачи (ПВЗ).']);
            exit(0);
        }
        $name = trim((string)($body['name'] ?? ''));
        if (empty($name)) {
            echo json_encode(['success' => false, 'error' => 'Укажите название пункта выдачи.']);
            exit(0);
        }

        // Check unique name constraint (case-insensitive)
        $lowerName = mb_strtolower($name, 'UTF-8');
        foreach ($db['locations'] as $existingLoc) {
            if (mb_strtolower(trim((string)($existingLoc['name'] ?? '')), 'UTF-8') === $lowerName) {
                echo json_encode(['success' => false, 'error' => "Пункт выдачи с названием «{$name}» уже существует. Названия ПВЗ должны быть уникальными."]);
                exit(0);
            }
        }

        $code = trim((string)($body['code'] ?? ''));
        if (empty($code)) {
            $code = 'ПВЗ-' . (count($db['locations']) + 1);
        }
        $finalCode = mb_strtoupper($code, 'UTF-8');

        $isArchived = isset($body['isArchived']) ? (bool)$body['isArchived'] : false;
        $archivedAt = $isArchived ? (isset($body['archivedAt']) ? (string)$body['archivedAt'] : date('c')) : null;
        $active = isset($body['active']) ? (bool)$body['active'] : ($isArchived ? false : true);

        $newLoc = [
            'id' => 'pvz-' . generateToken('', 8),
            'code' => $finalCode,
            'name' => $name,
            'address' => trim((string)($body['address'] ?? '')),
            'active' => $active,
            'isArchived' => $isArchived,
            'archivedAt' => $archivedAt,
            'assignedStaffIds' => is_array($body['assignedStaffIds'] ?? null) ? $body['assignedStaffIds'] : [],
            'contactPhone' => trim((string)($body['contactPhone'] ?? '')),
            'notes' => trim((string)($body['notes'] ?? '')),
            'createdAt' => date('c'),
            'updatedAt' => date('c')
        ];
        $db['locations'][] = $newLoc;
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'location' => $newLoc, 'locations' => $db['locations']]);
        exit(0);
    }

    if ($method === 'PUT' || $method === 'PATCH') {
        preg_match('#locations/([^/?]+)#', $route, $m);
        $rawLocId = (string)($m[1] ?? ($body['id'] ?? ($body['code'] ?? '')));
        $locId = urldecode($rawLocId);
        $found = false;

        foreach ($db['locations'] as &$loc) {
            $lid = (string)($loc['id'] ?? '');
            $lcode = (string)($loc['code'] ?? '');

            $isMatch = (
                $lid === $rawLocId || $lid === $locId ||
                strcasecmp($lid, $rawLocId) === 0 || strcasecmp($lid, $locId) === 0 ||
                $lcode === $rawLocId || $lcode === $locId ||
                strcasecmp($lcode, $rawLocId) === 0 || strcasecmp($lcode, $locId) === 0
            );

            if ($isMatch) {
                if (isset($body['name'])) {
                    $cleanName = trim((string)$body['name']);
                    if (!empty($cleanName)) {
                        // Check uniqueness among other points
                        $lowerClean = mb_strtolower($cleanName, 'UTF-8');
                        foreach ($db['locations'] as $otherLoc) {
                            $otherId = (string)($otherLoc['id'] ?? '');
                            if ($otherId !== $lid && mb_strtolower(trim((string)($otherLoc['name'] ?? '')), 'UTF-8') === $lowerClean) {
                                echo json_encode(['success' => false, 'error' => "Пункт выдачи с названием «{$cleanName}» уже существует. Названия ПВЗ должны быть уникальными."]);
                                exit(0);
                            }
                        }
                        $loc['name'] = $cleanName;
                    }
                }

                if (isset($body['code'])) {
                    $cleanCode = mb_strtoupper(trim((string)$body['code']), 'UTF-8');
                    if (!empty($cleanCode)) {
                        $loc['code'] = $cleanCode;
                    }
                }

                if (isset($body['address'])) $loc['address'] = trim((string)$body['address']);
                if (isset($body['active'])) $loc['active'] = (bool)$body['active'];

                if (isset($body['isArchived'])) {
                    $loc['isArchived'] = (bool)$body['isArchived'];
                    if ($loc['isArchived']) {
                        $loc['archivedAt'] = isset($body['archivedAt']) ? (string)$body['archivedAt'] : date('c');
                        $loc['active'] = false;
                    } else {
                        $loc['archivedAt'] = null;
                        $loc['active'] = true;
                    }
                } elseif (isset($body['archivedAt'])) {
                    $loc['archivedAt'] = $body['archivedAt'] ? (string)$body['archivedAt'] : null;
                }

                if (isset($body['assignedStaffIds']) && is_array($body['assignedStaffIds'])) {
                    $loc['assignedStaffIds'] = $body['assignedStaffIds'];
                }
                if (isset($body['contactPhone'])) $loc['contactPhone'] = trim((string)$body['contactPhone']);
                if (isset($body['notes'])) $loc['notes'] = trim((string)$body['notes']);
                $loc['updatedAt'] = date('c');

                $found = true;
                break;
            }
        }
        unset($loc);

        if ($found) {
            saveDb($dbFile, $db);
            echo json_encode(['success' => true, 'locations' => $db['locations']]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Пункт выдачи не найден.']);
        }
        exit(0);
    }

    if ($method === 'DELETE') {
        preg_match('#locations/([^/?]+)#', $route, $m);
        $rawLocId = (string)($m[1] ?? '');
        $locId = urldecode($rawLocId);

        $db['locations'] = array_values(array_filter($db['locations'], function($l) use ($rawLocId, $locId) {
            $lid = (string)($l['id'] ?? '');
            $lcode = (string)($l['code'] ?? '');
            $isMatch = (
                $lid === $rawLocId || $lid === $locId ||
                strcasecmp($lid, $rawLocId) === 0 || strcasecmp($lid, $locId) === 0 ||
                $lcode === $rawLocId || $lcode === $locId ||
                strcasecmp($lcode, $rawLocId) === 0 || strcasecmp($lcode, $locId) === 0
            );
            return !$isMatch;
        }));

        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'locations' => $db['locations']]);
        exit(0);
    }
}

// 15. Checkin Alerts (Оповещения о невыходе на смену)
if (strpos($route, 'checkin-alerts') !== false && $method === 'POST') {
    $now = new DateTime('now', new DateTimeZone('Europe/Moscow'));
    $todayStr = $now->format('Y-m-d');
    $timeStr = $now->format('H:i');

    $activePoints = [];
    if (isset($db['locations']) && is_array($db['locations'])) {
        foreach ($db['locations'] as $loc) {
            if (empty($loc['isArchived']) && (!isset($loc['active']) || $loc['active'] !== false)) {
                $code = $loc['code'] ?? ($loc['name'] ?? '');
                if (!empty($code)) {
                    $activePoints[] = $code;
                }
            }
        }
    }

    $checkedLocations = [];
    if (isset($db['checkins']) && is_array($db['checkins'])) {
        foreach ($db['checkins'] as $c) {
            if (($c['date'] ?? '') === $todayStr && !empty($c['location'])) {
                $checkedLocations[] = $c['location'];
            }
        }
    }

    $missing = [];
    foreach ($activePoints as $ptCode) {
        if (!in_array($ptCode, $checkedLocations)) {
            $missing[] = $ptCode;
        }
    }

    if (!empty($missing)) {
        $missingText = implode(', ', $missing);
        $tgText = "⚠️ *ВНИМАНИЕ: Смена не открыта!*\n"
                . "📍 Пункты без Check-in: *{$missingText}*\n"
                . "⏰ Время проверки: *{$timeStr}* (МСК)\n"
                . "📅 Дата: *{$todayStr}*\n"
                . "Сотрудники еще не отметили выход на работу.";
        sendTelegramMessage($telegramToken, $managerChatId, $tgText);
    }

    echo json_encode([
        'success' => true,
        'missing' => $missing,
        'checkedLocations' => $checkedLocations,
        'time' => $timeStr
    ]);
    exit(0);
}

// 16. Salary Rates & Shift Types Settings
if (strpos($route, 'rates') !== false) {
    if (!isset($db['rates']) || !is_array($db['rates'])) {
        $db['rates'] = [
            'standard' => 2000,
            '400+' => 2200,
            '500+' => 2500,
            '8h' => 1500,
            '4h' => 800,
            'partTimeShiftRate' => 1800,
            'seniorBonus' => 200,
            'partTimeBonus' => 0,
            'shiftTypes' => [
                ['code' => 'standard', 'name' => 'Обычная смена', 'baseRate' => 2000, 'isArchived' => false],
                ['code' => '400+', 'name' => 'Смена 400+', 'baseRate' => 2200, 'isArchived' => false],
                ['code' => '500+', 'name' => 'Смена 500+', 'baseRate' => 2500, 'isArchived' => false],
                ['code' => '8h', 'name' => 'Смена 8 часов', 'baseRate' => 1500, 'isArchived' => false],
                ['code' => '4h', 'name' => 'Смена 4 часа', 'baseRate' => 800, 'isArchived' => false],
            ],
            'partTimeShiftTypes' => [
                ['code' => '4h', 'name' => 'Смена 4 часа', 'baseRate' => 800, 'isArchived' => false],
                ['code' => 'pt_standard', 'name' => 'Смена подработчика (полная)', 'baseRate' => 1800, 'isArchived' => false],
            ],
            'bonuses' => [
                ['code' => 'seniorBonus', 'name' => 'Доплата Старшему (Ст.С.)', 'value' => 200, 'isArchived' => false, 'target' => 'senior'],
                ['code' => 'partTimeBonus', 'name' => 'Доплата Подработчику', 'value' => 0, 'isArchived' => false, 'target' => 'part_time'],
            ]
        ];
        saveDb($dbFile, $db);
    }

    if ($method === 'GET') {
        echo json_encode(['success' => true, 'rates' => $db['rates']]);
        exit(0);
    }

    if ($method === 'POST') {
        $isManager = ($currentUser && ($currentUser['role'] ?? '') === 'manager');
        if (!$isManager) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Действие разрешено только руководителю']);
            exit(0);
        }
        $db['rates'] = $body;
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'rates' => $db['rates']]);
        exit(0);
    }
}

// 17. Telegram Settings & Integration
if (strpos($route, 'telegram') !== false) {
    // GET /api/v1/telegram/settings
    if (strpos($route, 'settings') !== false && $method === 'GET') {
        if ($currentUserRole !== 'manager') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Доступ только для руководителя']]);
            exit(0);
        }
        $isConfigured = !empty($telegramToken) && !empty($managerChatId);
        echo json_encode([
            'success' => true,
            'settings' => [
                'isConfigured' => $isConfigured,
                'botToken' => $telegramToken,
                'managerChatId' => $managerChatId,
                'botUsername' => $db['telegram_settings']['botUsername'] ?? '',
                'updatedAt' => $db['telegram_settings']['updatedAt'] ?? null
            ]
        ]);
        exit(0);
    }

    // POST /api/v1/telegram/settings (Save credentials to server db)
    if (strpos($route, 'settings') !== false && $method === 'POST') {
        if ($currentUserRole !== 'manager') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Доступ только для руководителя']]);
            exit(0);
        }
        $newBotToken = trim($body['botToken'] ?? '');
        $newChatId = trim($body['managerChatId'] ?? '');

        if (empty($newBotToken) || empty($newChatId)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => ['message' => 'Укажите токен бота и ID чата руководителя']]);
            exit(0);
        }

        // Verify token with Telegram getMe API
        $botUsername = '';
        if (function_exists('curl_init')) {
            $ch = curl_init("https://api.telegram.org/bot{$newBotToken}/getMe");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 8);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $res = curl_exec($ch);
            curl_close($ch);
            if ($res) {
                $check = json_decode($res, true);
                if (empty($check['ok'])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => ['message' => 'Неверный токен бота. Telegram отклонил авторизацию бота. Проверьте правильность токена от @BotFather.']]);
                    exit(0);
                }
                $botUsername = $check['result']['username'] ?? '';
            }
        }

        // Save into pvz_database.json
        $db['telegram_settings'] = [
            'botToken' => $newBotToken,
            'managerChatId' => $newChatId,
            'botUsername' => $botUsername,
            'updatedAt' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('c')
        ];
        saveDb($dbFile, $db);

        // Also update config.php if writable
        if (file_exists($configFile) && is_writable($configFile)) {
            $config['telegram_bot_token'] = $newBotToken;
            $config['telegram_manager_chat_id'] = $newChatId;
            $exported = "<?php\nif (!defined('PVZ_APP')) { http_response_code(403); exit('Direct access prohibited.'); }\nreturn " . var_export($config, true) . ";\n";
            @file_put_contents($configFile, $exported, LOCK_EX);
        }

        echo json_encode([
            'success' => true,
            'settings' => [
                'isConfigured' => true,
                'botToken' => $newBotToken,
                'managerChatId' => $newChatId,
                'botUsername' => $botUsername,
                'updatedAt' => $db['telegram_settings']['updatedAt']
            ]
        ]);
        exit(0);
    }

    // DELETE /api/v1/telegram/settings (Disconnect integration)
    if (strpos($route, 'settings') !== false && $method === 'DELETE') {
        if ($currentUserRole !== 'manager') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Доступ только для руководителя']]);
            exit(0);
        }
        $db['telegram_settings'] = null;
        saveDb($dbFile, $db);

        if (file_exists($configFile) && is_writable($configFile)) {
            $config['telegram_bot_token'] = '';
            $config['telegram_manager_chat_id'] = '';
            $exported = "<?php\nif (!defined('PVZ_APP')) { http_response_code(403); exit('Direct access prohibited.'); }\nreturn " . var_export($config, true) . ";\n";
            @file_put_contents($configFile, $exported, LOCK_EX);
        }

        echo json_encode(['success' => true]);
        exit(0);
    }

    // POST /api/v1/telegram/test (Test message)
    if (strpos($route, 'test') !== false && $method === 'POST') {
        if ($currentUserRole !== 'manager') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Доступ только для руководителя']]);
            exit(0);
        }
        $targetToken = !empty($body['botToken']) ? trim($body['botToken']) : $telegramToken;
        $targetChat = !empty($body['managerChatId']) ? trim($body['managerChatId']) : $managerChatId;

        if (empty($targetToken) || empty($targetChat)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => ['message' => 'Сначала заполните токен бота и ID чата руководителя']]);
            exit(0);
        }

        $nowStr = (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('d.m.Y H:i');
        $testMsg = "🟢 *Тестовое сообщение из панели управления ПВЗ*\n\n"
                 . "Интеграция с Telegram успешно подключена!\n"
                 . "⏰ Время отправки: *{$nowStr}* (МСК)\n\n"
                 . "Сюда будут приходить уведомления о выходах на смену, вечерней кассе, заявках и бирже смен.";

        $ch = curl_init("https://api.telegram.org/bot{$targetToken}/sendMessage");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'chat_id' => $targetChat,
            'text' => $testMsg,
            'parse_mode' => 'Markdown'
        ]));
        curl_setopt($ch, CURLOPT_TIMEOUT, 8);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $res = curl_exec($ch);
        curl_close($ch);

        $tgRes = $res ? json_decode($res, true) : null;
        if (!empty($tgRes['ok'])) {
            echo json_encode(['success' => true, 'message' => 'Тестовое сообщение успешно доставлено в Telegram!']);
        } else {
            http_response_code(400);
            $desc = $tgRes['description'] ?? 'Не удалось отправить сообщение в Telegram.';
            if (stripos($desc, 'chat not found') !== false) {
                $desc = 'Чат не найден (' . $desc . '). Важно: перейдите в диалог с ботом в Telegram, нажмите СТАРТ (/start), и проверьте правильность числового Chat ID (узнать ID можно у @userinfobot).';
            } elseif (stripos($desc, 'blocked by the user') !== false) {
                $desc = 'Бот заблокирован пользователем. Откройте диалог с ботом в Telegram и нажмите «Запустить» / отправьте команду /start.';
            } elseif (stripos($desc, 'Unauthorized') !== false) {
                $desc = 'Неверный токен бота. Проверьте токен, полученный от @BotFather.';
            }
            echo json_encode(['success' => false, 'error' => ['message' => $desc]]);
        }
        exit(0);
    }

    // GET /api/v1/telegram/templates (Manager only)
    if (strpos($route, 'templates') !== false && $method === 'GET') {
        if ($currentUserRole !== 'manager') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Доступ только для руководителя']]);
            exit(0);
        }
        $tpls = $db['telegram_templates'] ?? [];
        if (empty($tpls) || !is_array($tpls)) {
            $tpls = getDefaultTelegramTemplates();
        }
        echo json_encode(['success' => true, 'templates' => $tpls]);
        exit(0);
    }

    // POST /api/v1/telegram/templates (Manager only)
    if (strpos($route, 'templates') !== false && $method === 'POST') {
        if ($currentUserRole !== 'manager') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Доступ только для руководителя']]);
            exit(0);
        }
        $incoming = $body['templates'] ?? [];
        if (!is_array($incoming)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => ['message' => 'Неверный формат данных шаблонов']]);
            exit(0);
        }
        if (!isset($db['telegram_templates']) || !is_array($db['telegram_templates'])) {
            $db['telegram_templates'] = getDefaultTelegramTemplates();
        }
        foreach ($incoming as $k => $item) {
            if (isset($db['telegram_templates'][$k])) {
                $db['telegram_templates'][$k] = array_merge($db['telegram_templates'][$k], $item);
            } else {
                $db['telegram_templates'][$k] = $item;
            }
        }
        saveDb($dbFile, $db);
        echo json_encode(['success' => true, 'templates' => $db['telegram_templates']]);
        exit(0);
    }

    // POST /api/v1/telegram/report (Manual report trigger)
    if (strpos($route, 'report') !== false && $method === 'POST') {
        if ($currentUserRole !== 'manager') {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => ['code' => 'FORBIDDEN', 'message' => 'Доступ только для руководителя']]);
            exit(0);
        }
        if (empty($telegramToken) || empty($managerChatId)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => ['message' => 'Telegram-бот еще не привязан. Перейдите в раздел «Telegram-бот» и укажите токен и Chat ID.']]);
            exit(0);
        }

        $todayStr = (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('Y-m-d');
        $todayShifts = array_filter($db['checkins'] ?? [], function($c) use ($todayStr) {
            return ($c['date'] ?? '') === $todayStr;
        });

        $totalRev = 0; $totalCash = 0; $totalCard = 0;
        foreach ($todayShifts as $s) {
            if (!empty($s['sales'])) {
                $totalCash += ($s['sales']['photo']['cash'] ?? 0) + ($s['sales']['print']['cash'] ?? 0) + ($s['sales']['lamination']['cash'] ?? 0);
                $totalCard += ($s['sales']['photo']['card'] ?? 0) + ($s['sales']['print']['card'] ?? 0) + ($s['sales']['lamination']['card'] ?? 0);
            }
        }
        $totalRev = $totalCash + $totalCard;
        $shiftsCount = count($todayShifts);

        $reportText = "📊 *Сводный отчет по сети ПВЗ за {$todayStr}*\n\n"
                    . "👥 Активных смен: *{$shiftsCount}*\n"
                    . "💵 Наличные: *" . number_format($totalCash, 0, '.', ' ') . " ₽*\n"
                    . "💳 Безнал: *" . number_format($totalCard, 0, '.', ' ') . " ₽*\n"
                    . "🔥 Итого выручка: *" . number_format($totalRev, 0, '.', ' ') . " ₽*";

        $sent = sendTelegramMessage($telegramToken, $managerChatId, $reportText);
        if ($sent) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(502);
            echo json_encode(['success' => false, 'error' => ['message' => 'Ошибка отправки отчета в Telegram']]);
        }
        exit(0);
    }

    // Fallback direct notify / message
    if ($method === 'POST') {
        $msg = $body['message'] ?? 'Уведомление из панели ПВЗ';
        if (!empty($telegramToken) && !empty($managerChatId)) {
            sendTelegramMessage($telegramToken, $managerChatId, $msg);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => ['message' => 'Telegram не настроен']]);
        }
        exit(0);
    }
}

// 17. Cron Trigger (for Beget Cron / Webcron)
if (strpos($route, 'cron') !== false) {
    $executed = executeCronJobs($db, $dbFile, $telegramToken, $managerChatId);
    echo json_encode([
        'success' => true,
        'executedTasks' => $executed,
        'serverTime' => (new DateTime('now', new DateTimeZone('Europe/Moscow')))->format('Y-m-d H:i:s'),
        'timezone' => 'Europe/Moscow'
    ]);
    exit(0);
}

// 18. Health
if (strpos($route, 'health') !== false) {
    echo json_encode(['status' => 'ok', 'uptime' => time()]);
    exit(0);
}

// If completely unknown route, return 404 with error message (never return fake success)
http_response_code(404);
echo json_encode([
    'success' => false,
    'error' => [
        'code' => 'NOT_FOUND',
        'message' => "Маршрут API не найден: $route"
    ]
]);
exit(0);
