import express, { Request, Response, NextFunction } from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { db } from './server/db/index';
import { authenticate, csrfProtection } from './server/middleware/auth';
import { authRouter } from './server/routes/auth';
import { staffRouter } from './server/routes/staff';
import { checkinsRouter } from './server/routes/checkins';
import { salesRouter } from './server/routes/sales';
import { messagesRouter } from './server/routes/messages';
import { notificationsRouter } from './server/routes/notifications';
import { applicationsRouter } from './server/routes/applications';
import { ratesRouter } from './server/routes/rates';
import { locationsRouter } from './server/routes/locations';
import { botRouter } from './server/routes/bot';
import { telegramRouter } from './server/routes/telegram';
import { auditRouter } from './server/routes/audit';
import { healthRouter } from './server/routes/health';
import { swapsRouter } from './server/routes/swaps';
import { availabilityRouter } from './server/routes/availability';
import { schedulesRouter } from './server/routes/schedules';
import { goalsRouter } from './server/routes/goals';
import { paybackRouter } from './server/routes/payback';
import { schedulerService } from './server/services/scheduler';

dotenv.config();

const app = express();
const port = Number(process.env.PORT) || 3000;
const isDev = process.env.NODE_ENV !== 'production';

// Trust reverse proxies (Google Cloud Run, Nginx, AI Studio proxy)
app.set('trust proxy', 1);

// Disable X-Powered-By
app.disable('x-powered-by');

// Security Headers (Compatible with AI Studio preview iframe and web embedding)
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), camera=(), microphone=()');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self' https: data: blob: 'unsafe-inline' 'unsafe-eval'; frame-ancestors *;"
  );

  if (!isDev) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  next();
});

// Limit request body sizes to 1MB
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());

// Universal CORS with full credentials support for AI Studio & Cloud Run preview
app.use(
  cors({
    origin: true,
    credentials: true,
  })
);

// Auth session extractor
app.use(authenticate);

// CSRF protection on state-changing API endpoints
app.use('/api', csrfProtection);

// API v1 Routes
app.use('/api/v1/auth', authRouter);
app.use('/api/v1/staff', staffRouter);
app.use('/api/v1/checkins', checkinsRouter);
app.use(['/api/v1/checkin-alerts', '/api/checkin-alerts'], checkinsRouter);
app.use('/api/v1/sales', salesRouter);
app.use('/api/v1/messages', messagesRouter);
app.use('/api/v1/notifications', notificationsRouter);
app.use('/api/v1/applications', applicationsRouter);
app.use('/api/v1/rates', ratesRouter);
app.use('/api/v1/locations', locationsRouter);
app.use('/api/v1/swaps', swapsRouter);
app.use('/api/v1/availability', availabilityRouter);
app.use('/api/v1/schedules', schedulesRouter);
app.use(['/api/v1/income-goals', '/api/v1/goals'], goalsRouter);
app.use('/api/v1/payback', paybackRouter);
app.use('/api/v1/bot', botRouter);
app.use('/api/v1/telegram', telegramRouter);
app.use('/api/v1/audit-logs', auditRouter);
app.use('/api/v1/health', healthRouter);

// Fallback aliases for /api/* without /v1/
app.use('/api/auth', authRouter);
app.use('/api/staff', staffRouter);
app.use('/api/checkins', checkinsRouter);
app.use('/api/sales', salesRouter);
app.use('/api/messages', messagesRouter);
app.use('/api/notifications', notificationsRouter);
app.use('/api/applications', applicationsRouter);
app.use('/api/rates', ratesRouter);
app.use('/api/locations', locationsRouter);
app.use('/api/swaps', swapsRouter);
app.use('/api/availability', availabilityRouter);
app.use('/api/schedules', schedulesRouter);
app.use('/api/payback', paybackRouter);
app.use('/api/bot', botRouter);
app.use('/api/telegram', telegramRouter);
app.use('/api/audit-logs', auditRouter);
app.use('/api/health', healthRouter);
app.use('/health', healthRouter);

// Serve downloadable archive for hosting (e.g. Beget)
app.get(['/site_beget.zip', '/app_bundle.zip', '/download'], (_req: Request, res: Response) => {
  const zipPath = path.resolve(process.cwd(), 'site_beget.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', 'attachment; filename="site_beget.zip"');
    return res.download(zipPath, 'site_beget.zip');
  }
  res.status(404).send('Archive file not found');
});

// Initialize database and start background scheduler
async function bootstrap() {
  try {
    await db.init();
    schedulerService.start();

    if (isDev) {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);

      // Dev SPA Fallback (Prevents 404 on direct page navigation or refreshes like /lk, /dashboard, etc.)
      app.use('*', async (req: Request, res: Response, next: NextFunction) => {
        if (req.originalUrl.startsWith('/api')) {
          return next();
        }
        try {
          const indexHtmlPath = path.resolve(process.cwd(), 'index.html');
          if (!fs.existsSync(indexHtmlPath)) {
            return next();
          }
          let template = fs.readFileSync(indexHtmlPath, 'utf-8');
          template = await vite.transformIndexHtml(req.originalUrl, template);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
        } catch (e) {
          next(e);
        }
      });
    } else {
      const distDir = path.resolve(process.cwd(), 'dist');
      app.use(express.static(distDir));
      app.get('*', (req: Request, res: Response, next: NextFunction) => {
        if (req.originalUrl.startsWith('/api')) {
          return next();
        }
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }

    // Centralized Global Express Error Handler
    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      console.error('[Global Error Handler]:', err);
      const status = err.status || 500;
      const message = isDev ? err.message || 'Internal Server Error' : 'Внутренняя ошибка сервера';
      res.status(status).json({
        success: false,
        error: {
          code: err.code || 'INTERNAL_ERROR',
          message,
        },
      });
    });

    const server = app.listen(port, '0.0.0.0', () => {
      console.log(`[Server] PVZ CheckBot Full-Stack server running on http://0.0.0.0:${port}`);
    });

    const shutdown = () => {
      console.log('[Server] Gracefully shutting down...');
      schedulerService.stop();
      server.close(() => {
        console.log('[Server] HTTP server closed.');
        process.exit(0);
      });
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  } catch (err) {
    console.error('[Bootstrap Error]:', err);
    process.exit(1);
  }
}

bootstrap();
