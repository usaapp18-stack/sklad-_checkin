import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import { DatabaseSync } from 'node:sqlite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class DatabaseService {
  private pgPool: pg.Pool | null = null;
  private sqliteDb: DatabaseSync | null = null;
  private isPostgres = false;
  private initialized = false;

  async init(): Promise<void> {
    if (this.initialized) return;

    const isProd = process.env.NODE_ENV === 'production';
    const explicitDriver = process.env.DB_DRIVER?.toLowerCase();
    const dbUrl = process.env.DATABASE_URL;

    // Requirement 1: In production or when DB_DRIVER=postgres, PostgreSQL is MANDATORY.
    // If PostgreSQL fails, the application MUST exit and NEVER silently fall back to SQLite.
    const mustUsePostgres = explicitDriver === 'postgres' || (isProd && explicitDriver !== 'sqlite');

    if (mustUsePostgres || (dbUrl && (dbUrl.startsWith('postgres://') || dbUrl.startsWith('postgresql://')))) {
      if (!dbUrl) {
        console.error('[DB] APPLICATION STARTUP FAILED: PostgreSQL is required (DB_DRIVER=postgres or production), but DATABASE_URL is not set.');
        console.error('[DB] HINT: If you are deploying on Beget or hosting without PostgreSQL, set DB_DRIVER=sqlite in your .env file or environment variables.');
        process.exit(1);
      }

      try {
        console.log('[DB] Connecting to PostgreSQL database...');
        this.pgPool = new pg.Pool({
          connectionString: dbUrl,
          max: 20,
          idleTimeoutMillis: 30000,
          connectionTimeoutMillis: 5000,
          ssl: isProd && !dbUrl.includes('localhost') ? { rejectUnauthorized: false } : undefined,
        });

        // Test connection
        const client = await this.pgPool.connect();
        client.release();
        this.isPostgres = true;
        this.initialized = true;
        console.log('[DB] Connected to PostgreSQL successfully.');

        await this.runPgMigrations();
        await this.seedInitialData();
        return;
      } catch (err) {
        console.error('[DB] APPLICATION STARTUP FAILED: PostgreSQL connection unavailable:', (err as Error).message);
        if (mustUsePostgres) {
          console.error('[DB] Fatal: Silent fallback to SQLite is prohibited in production or when DB_DRIVER=postgres.');
          process.exit(1);
        }
        console.warn('[DB] Development mode fallback: Starting local SQLite database...');
      }
    }

    // SQLite engine: ONLY allowed when explicitly requested (DB_DRIVER=sqlite) or in non-production local dev
    if (isProd && explicitDriver !== 'sqlite') {
      console.error('[DB] APPLICATION STARTUP FAILED: SQLite is not allowed in production without explicit DB_DRIVER=sqlite.');
      process.exit(1);
    }

    console.log('[DB] Initializing local relational database (SQLite 3.51 engine)...');
    const dataDir = path.resolve(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    const dbPath = path.join(dataDir, 'pvz_relational.sqlite');
    this.sqliteDb = new DatabaseSync(dbPath);
    this.sqliteDb.exec('PRAGMA foreign_keys = ON;');
    this.sqliteDb.exec('PRAGMA journal_mode = WAL;');
    this.isPostgres = false;
    this.initialized = true;

    await this.runSqliteMigrations();
    await this.seedInitialData();
    console.log('[DB] Relational SQLite database initialized at:', dbPath);
  }

  // Versioned PostgreSQL migrations (Requirement 2 & 40)
  private async runPgMigrations(): Promise<void> {
    if (!this.pgPool) return;

    // 1. Ensure migrations tracking table exists
    await this.pgPool.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        id SERIAL PRIMARY KEY,
        version VARCHAR(50) UNIQUE NOT NULL,
        applied_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 2. Discover migration files
    const migrationsDir = path.resolve(process.cwd(), 'migrations');
    if (!fs.existsSync(migrationsDir)) return;

    const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();

    for (const file of files) {
      const version = file.replace(/\.sql$/, '');
      const checkRes = await this.pgPool.query('SELECT 1 FROM schema_migrations WHERE version = $1', [version]);
      if (checkRes.rows.length === 0) {
        console.log(`[DB Migration] Applying PostgreSQL migration: ${file}...`);
        const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
        const client = await this.pgPool.connect();
        try {
          await client.query('BEGIN');
          await client.query(sql);
          await client.query('INSERT INTO schema_migrations (version) VALUES ($1)', [version]);
          await client.query('COMMIT');
          console.log(`[DB Migration] Migration ${file} successfully applied.`);
        } catch (mErr) {
          await client.query('ROLLBACK');
          console.error(`[DB Migration] Failed applying migration ${file}:`, mErr);
          throw mErr;
        } finally {
          client.release();
        }
      }
    }

    // Ensure is_senior and password_plain columns exist if Postgres table was created earlier
    try {
      await this.pgPool.query('ALTER TABLE users ADD COLUMN is_senior BOOLEAN DEFAULT FALSE;');
    } catch {
      // Column already exists
    }
    try {
      await this.pgPool.query('ALTER TABLE users ADD COLUMN password_plain TEXT;');
    } catch {
      // Column already exists
    }

    // Ensure push_subscriptions and scheduled_notifications tables exist in Postgres
    try {
      await this.pgPool.query(`
        CREATE TABLE IF NOT EXISTS push_subscriptions (
          id VARCHAR(64) PRIMARY KEY,
          user_id VARCHAR(64) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          endpoint TEXT UNIQUE NOT NULL,
          keys_p256dh TEXT NOT NULL,
          keys_auth TEXT NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);
      await this.pgPool.query(`
        CREATE TABLE IF NOT EXISTS scheduled_notifications (
          id VARCHAR(64) PRIMARY KEY,
          title VARCHAR(255) NOT NULL,
          text TEXT NOT NULL,
          schedule_type VARCHAR(20) NOT NULL,
          time_of_day VARCHAR(5) NOT NULL,
          target_role VARCHAR(50) NOT NULL,
          is_active BOOLEAN NOT NULL DEFAULT TRUE,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS shift_swaps (
          id VARCHAR(64) PRIMARY KEY,
          date VARCHAR(10) NOT NULL,
          shift_type VARCHAR(30) NOT NULL DEFAULT 'standard',
          location VARCHAR(30) NOT NULL,
          requester_id VARCHAR(64) NOT NULL,
          requester_name VARCHAR(100) NOT NULL,
          candidate_id VARCHAR(64),
          candidate_name VARCHAR(100),
          reason TEXT,
          status VARCHAR(30) NOT NULL DEFAULT 'open',
          resolved_at TIMESTAMP WITH TIME ZONE,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);
    } catch (dbErr) {
      console.error('[DB] Error creating Postgres push/schedule tables:', dbErr);
    }
  }

  // Relational SQLite migrations matching PostgreSQL structure
  private async runSqliteMigrations(): Promise<void> {
    if (!this.sqliteDb) return;

    this.sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        version TEXT UNIQUE NOT NULL,
        applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS locations (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        address TEXT,
        active INTEGER DEFAULT 1,
        is_archived INTEGER DEFAULT 0,
        archived_at DATETIME,
        contact_phone TEXT,
        notes TEXT,
        assigned_staff_ids TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        login TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'employee',
        status TEXT NOT NULL DEFAULT 'active',
        is_part_time INTEGER DEFAULT 0,
        is_senior INTEGER DEFAULT 0,
        telegram_username TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS user_locations (
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        location_id TEXT NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
        PRIMARY KEY (user_id, location_id)
      );

      CREATE TABLE IF NOT EXISTS checkins (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
        location_code TEXT NOT NULL,
        shift_type TEXT NOT NULL DEFAULT 'standard',
        date TEXT NOT NULL,
        checked_in_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        notes TEXT,
        edit_count INTEGER DEFAULT 0,
        base_rate REAL,
        UNIQUE(user_id, date)
      );

      CREATE TABLE IF NOT EXISTS sales (
        id TEXT PRIMARY KEY,
        checkin_id TEXT UNIQUE NOT NULL REFERENCES checkins(id) ON DELETE RESTRICT,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
        date TEXT NOT NULL,
        photo_cash REAL DEFAULT 0.00,
        photo_card REAL DEFAULT 0.00,
        print_cash REAL DEFAULT 0.00,
        print_card REAL DEFAULT 0.00,
        lamination_cash REAL DEFAULT 0.00,
        lamination_card REAL DEFAULT 0.00,
        total REAL NOT NULL DEFAULT 0.00,
        bonus REAL NOT NULL DEFAULT 0.00,
        submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        from_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        message TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS notifications (
        id TEXT PRIMARY KEY,
        user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
        to_all INTEGER DEFAULT 0,
        title TEXT NOT NULL,
        text TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'system',
        location TEXT,
        source TEXT,
        is_read INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS applications (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        telegram_username TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        note TEXT,
        assigned_login TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS bot_logs (
        id TEXT PRIMARY KEY,
        action TEXT NOT NULL,
        initiated_by TEXT NOT NULL,
        status TEXT NOT NULL,
        details TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
        action TEXT NOT NULL,
        entity TEXT NOT NULL,
        entity_id TEXT,
        ip TEXT,
        user_agent TEXT,
        details TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token_hash TEXT UNIQUE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL
      );

      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS push_subscriptions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        endpoint TEXT UNIQUE NOT NULL,
        keys_p256dh TEXT NOT NULL,
        keys_auth TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS scheduled_notifications (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        text TEXT NOT NULL,
        schedule_type TEXT NOT NULL,
        time_of_day TEXT NOT NULL,
        target_role TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS checkin_cancellations (
        id VARCHAR(64) PRIMARY KEY,
        user_id VARCHAR(64) NOT NULL,
        date VARCHAR(10) NOT NULL,
        cancelled_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS shift_swaps (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        shift_type TEXT NOT NULL DEFAULT 'standard',
        location TEXT NOT NULL,
        requester_id TEXT NOT NULL,
        requester_name TEXT NOT NULL,
        candidate_id TEXT,
        candidate_name TEXT,
        reason TEXT,
        status TEXT NOT NULL DEFAULT 'open',
        resolved_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE INDEX IF NOT EXISTS idx_users_login ON users(login);
      CREATE INDEX IF NOT EXISTS idx_checkins_date ON checkins(date);
      CREATE INDEX IF NOT EXISTS idx_checkins_user ON checkins(user_id);
      CREATE INDEX IF NOT EXISTS idx_cancellations_user_date ON checkin_cancellations(user_id, date);
      CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(date);
      CREATE INDEX IF NOT EXISTS idx_sessions_hash ON sessions(token_hash);
      CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
    `);

    // Ensure is_senior and password_plain columns exist if table was created earlier
    try {
      this.sqliteDb.exec('ALTER TABLE users ADD COLUMN is_senior INTEGER DEFAULT 0;');
    } catch {
      // column already exists
    }

    try {
      this.sqliteDb.exec('ALTER TABLE users ADD COLUMN password_plain TEXT;');
    } catch {
      // column already exists
    }

    // Ensure edit_count column exists on checkins
    try {
      this.sqliteDb.exec('ALTER TABLE checkins ADD COLUMN edit_count INTEGER DEFAULT 0;');
    } catch {
      // column already exists
    }

    // Ensure base_rate column exists on checkins
    try {
      this.sqliteDb.exec('ALTER TABLE checkins ADD COLUMN base_rate REAL;');
    } catch {
      // column already exists
    }

    // Ensure locations table has all archive and metadata columns in SQLite
    try {
      const existingCols = new Set<string>();
      const rows = this.sqliteDb.prepare("PRAGMA table_info(locations)").all() as any[];
      rows.forEach(r => existingCols.add(r.name));

      const locColsToAdd: { name: string; type: string }[] = [
        { name: 'address', type: 'TEXT' },
        { name: 'active', type: 'INTEGER DEFAULT 1' },
        { name: 'is_archived', type: 'INTEGER DEFAULT 0' },
        { name: 'archived_at', type: 'TEXT' },
        { name: 'contact_phone', type: 'TEXT' },
        { name: 'notes', type: 'TEXT' },
        { name: 'assigned_staff_ids', type: 'TEXT' },
        { name: 'created_at', type: 'TEXT' },
        { name: 'updated_at', type: 'TEXT' },
      ];

      for (const col of locColsToAdd) {
        if (!existingCols.has(col.name)) {
          this.sqliteDb.exec(`ALTER TABLE locations ADD COLUMN ${col.name} ${col.type};`);
        }
      }
    } catch (colErr) {
      console.warn('[DB] Notice ensuring locations columns:', colErr);
    }
  }

  // Seed default data if tables are empty
  private async seedInitialData(): Promise<void> {
    // 1. Do not seed any default locations (manager adds and manages their own custom PVZs)

    // 2. Seed Default Manager (Admin) with secure bcrypt password hash
    // Requirement 4: INITIAL_ADMIN_PASSWORD from env, never hardcoded in source without env option.
    const adminRows = await this.query<{ id: string }>('SELECT id FROM users WHERE role = $1', ['manager']);
    if (adminRows.rows.length === 0) {
      console.log('[DB] Seeding default manager with secure bcrypt password hash...');
      const adminId = 'usr-admin-manager';
      const initialPassword = process.env.INITIAL_ADMIN_PASSWORD || '7222';
      const salt = bcrypt.genSaltSync(10);
      const passwordHash = bcrypt.hashSync(initialPassword, salt);

      await this.query(
        `INSERT INTO users (id, login, password_hash, name, role, status, is_part_time, telegram_username)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [adminId, '+79266137222', passwordHash, 'Руководитель ПВЗ (Admin)', 'manager', 'active', false, 'David_Sha']
      );
    }
  }

  async query<T = any>(sql: string, params: any[] = []): Promise<{ rows: T[] }> {
    if (!this.initialized) {
      await this.init();
    }

    if (this.isPostgres && this.pgPool) {
      const res = await this.pgPool.query(sql, params);
      return { rows: res.rows as T[] };
    }

    if (this.sqliteDb) {
      let sqliteSql = sql;
      if (params.length > 0) {
        sqliteSql = sql.replace(/\$(\d+)/g, (match, num) => {
          const idx = parseInt(num, 10);
          return idx >= 1 && idx <= params.length ? '?' : match;
        });
      }
      const cleanParams = params.map(p => (typeof p === 'boolean' ? (p ? 1 : 0) : p));

      const trimmed = sqliteSql.trim().toUpperCase();
      const isSelect = trimmed.startsWith('SELECT') || trimmed.startsWith('PRAGMA');

      if (isSelect) {
        const stmt = this.sqliteDb.prepare(sqliteSql);
        const rows = stmt.all(...cleanParams) as T[];
        return { rows };
      } else {
        const stmt = this.sqliteDb.prepare(sqliteSql);
        stmt.run(...cleanParams);
        return { rows: [] };
      }
    }

    throw new Error('[DB] No database engine available');
  }

  async transaction<T>(callback: (client: { query: <R = any>(sql: string, params?: any[]) => Promise<{ rows: R[] }> }) => Promise<T>): Promise<T> {
    if (!this.initialized) {
      await this.init();
    }

    if (this.isPostgres && this.pgPool) {
      const client = await this.pgPool.connect();
      try {
        await client.query('BEGIN');
        const res = await callback({
          query: async <R = any>(sql: string, params: any[] = []): Promise<{ rows: R[] }> => {
            const result = await client.query(sql, params);
            return { rows: result.rows as unknown as R[] };
          },
        });
        await client.query('COMMIT');
        return res;
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
    }

    if (this.sqliteDb) {
      this.sqliteDb.exec('BEGIN IMMEDIATE');
      try {
        const res = await callback({
          query: async <R = any>(sql: string, params: any[] = []): Promise<{ rows: R[] }> => {
            return this.query<R>(sql, params);
          },
        });
        this.sqliteDb.exec('COMMIT');
        return res;
      } catch (err) {
        this.sqliteDb.exec('ROLLBACK');
        throw err;
      }
    }

    throw new Error('[DB] No database engine available for transaction');
  }

  isUsingPostgres(): boolean {
    return this.isPostgres;
  }
}

export const db = new DatabaseService();
