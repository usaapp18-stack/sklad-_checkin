import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { db } from '../db/index';

export interface AuthUser {
  id: string;
  login: string;
  name: string;
  role: 'employee' | 'manager';
  status: string;
  isPartTime: boolean;
  isSenior: boolean;
  telegramUsername?: string;
  locations: string[];
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      sessionToken?: string;
    }
  }
}

// Requirement 56: SHA-256 Hashing helper for session tokens
export function hashSessionToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// Requirement 9: Double Submit CSRF Cookie Helper
export function setCsrfCookie(res: Response, req?: Request): string {
  const token = crypto.randomBytes(32).toString('hex');
  const isHttps = Boolean(req?.secure) || req?.headers?.['x-forwarded-proto'] === 'https' || process.env.NODE_ENV === 'production';
  res.cookie('pvz_csrf', token, {
    httpOnly: false,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    maxAge: 30 * 24 * 60 * 60 * 1000,
    ...(isHttps ? { partitioned: true } : {}),
  } as any);
  return token;
}

// Auth token extractor from cookies or headers
export const authenticate = async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
  try {
    let token = req.headers.authorization?.startsWith('Bearer ')
      ? req.headers.authorization.slice(7).trim()
      : req.cookies?.pvz_session;

    if (!token) {
      req.user = undefined;
      return next();
    }

    req.sessionToken = token;
    const tokenHash = hashSessionToken(token);

    // Look up session by SHA-256 hash
    const sessionRes = await db.query<{
      user_id: string;
      expires_at: string;
      login: string;
      name: string;
      role: 'employee' | 'manager';
      status: string;
      is_part_time: number | boolean;
      is_senior: number | boolean;
      telegram_username?: string;
    }>(
      `SELECT s.user_id, s.expires_at, u.login, u.name, u.role, u.status, u.is_part_time, u.is_senior, u.telegram_username
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = $1`,
      [tokenHash]
    );

    if (sessionRes.rows.length === 0) {
      req.user = undefined;
      return next();
    }

    const session = sessionRes.rows[0];

    // Check expiry
    if (new Date(session.expires_at) < new Date()) {
      await db.query('DELETE FROM sessions WHERE token_hash = $1', [tokenHash]);
      req.user = undefined;
      return next();
    }

    // Check user status
    if (session.status === 'blocked' || session.status === 'archived') {
      req.user = undefined;
      return next();
    }

    // Fetch user location codes
    const locRes = await db.query<{ code: string }>(
      `SELECT l.code FROM locations l
       JOIN user_locations ul ON ul.location_id = l.id
       WHERE ul.user_id = $1`,
      [session.user_id]
    );

    req.user = {
      id: session.user_id,
      login: session.login,
      name: session.name,
      role: session.role,
      status: session.status,
      isPartTime: Boolean(session.is_part_time),
      isSenior: Boolean(session.is_senior),
      telegramUsername: session.telegram_username,
      locations: locRes.rows.map(r => r.code),
    };

    next();
  } catch (err) {
    console.error('[Auth Middleware] Authentication error:', err);
    req.user = undefined;
    next();
  }
};

// Middleware: Require logged in user
export const requireAuth = (req: Request, res: Response, next: NextFunction): void => {
  if (!req.user) {
    res.status(401).json({
      success: false,
      error: { code: 'UNAUTHORIZED', message: 'Требуется авторизация в системе' },
    });
    return;
  }
  next();
};

// Middleware: Require Manager / Admin role
export const requireManager = (req: Request, res: Response, next: NextFunction): void => {
  if (!req.user) {
    res.status(401).json({
      success: false,
      error: { code: 'UNAUTHORIZED', message: 'Требуется авторизация в системе' },
    });
    return;
  }
  if (req.user.role !== 'manager') {
    res.status(403).json({
      success: false,
      error: { code: 'FORBIDDEN', message: 'Доступ разрешен только руководителю' },
    });
    return;
  }
  next();
};

// Rate limiter for login / auth attempts (5 requests per 15 mins per IP)
interface RateLimitEntry {
  count: number;
  resetAt: number;
}
const ipRateLimits = new Map<string, RateLimitEntry>();

export const loginRateLimiter = (req: Request, res: Response, next: NextFunction): void => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 15 * 60 * 1000;
  const maxAttempts = 15;

  const current = ipRateLimits.get(ip);
  if (!current || now > current.resetAt) {
    ipRateLimits.set(ip, { count: 1, resetAt: now + windowMs });
    return next();
  }

  if (current.count >= maxAttempts) {
    const retryAfterSec = Math.ceil((current.resetAt - now) / 1000);
    res.setHeader('Retry-After', retryAfterSec);
    res.status(429).json({
      success: false,
      error: {
        code: 'RATE_LIMIT_EXCEEDED',
        message: `Слишком много попыток входа. Попробуйте через ${Math.ceil(retryAfterSec / 60)} мин.`,
      },
    });
    return;
  }

  current.count++;
  next();
};

// Rate limiter for public applications (3 requests per 10 mins per IP)
const appRateLimits = new Map<string, RateLimitEntry>();

export const applicationRateLimiter = (req: Request, res: Response, next: NextFunction): void => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 10 * 60 * 1000;
  const maxAttempts = 5;

  const current = appRateLimits.get(ip);
  if (!current || now > current.resetAt) {
    appRateLimits.set(ip, { count: 1, resetAt: now + windowMs });
    return next();
  }

  if (current.count >= maxAttempts) {
    const retryAfterSec = Math.ceil((current.resetAt - now) / 1000);
    res.setHeader('Retry-After', retryAfterSec);
    res.status(429).json({
      success: false,
      error: {
        code: 'RATE_LIMIT_EXCEEDED',
        message: `Слишком много заявок. Попробуйте через ${Math.ceil(retryAfterSec / 60)} мин.`,
      },
    });
    return;
  }

  current.count++;
  next();
};

// Requirement 9: Double Submit CSRF Protection with support for iframe & Same-Origin requests
export const csrfProtection = (req: Request, res: Response, next: NextFunction): void => {
  const safeMethods = ['GET', 'HEAD', 'OPTIONS'];
  if (safeMethods.includes(req.method)) {
    return next();
  }

  // Exempt public auth & registration paths
  const originalUrl = req.originalUrl || req.url;
  if (
    originalUrl.startsWith('/api/v1/auth/login') ||
    originalUrl.startsWith('/api/auth/login') ||
    originalUrl === '/api/v1/applications' ||
    originalUrl === '/api/applications' ||
    originalUrl.startsWith('/api/v1/auth/csrf-token') ||
    originalUrl.startsWith('/api/auth/csrf-token')
  ) {
    return next();
  }

  // If requested using Bearer token (CLI, scripts, tests, iframe clients), exempt from CSRF
  if (req.headers.authorization?.startsWith('Bearer ')) {
    return next();
  }

  const cookieToken = req.cookies?.pvz_csrf;
  const headerToken = req.headers['x-csrf-token'] as string;

  // Valid CSRF header match
  if (cookieToken && headerToken && cookieToken === headerToken) {
    return next();
  }

  // Valid session with matching token or authenticated user session
  if (req.user) {
    if (headerToken && cookieToken && headerToken !== cookieToken) {
      res.status(403).json({
        success: false,
        error: {
          code: 'CSRF_INVALID',
          message: 'Ошибка CSRF-валидации запроса',
        },
      });
      return;
    }
    return next();
  }

  if (!cookieToken || !headerToken || cookieToken !== headerToken) {
    res.status(403).json({
      success: false,
      error: {
        code: 'CSRF_INVALID',
        message: 'Ошибка CSRF-валидации запроса',
      },
    });
    return;
  }

  next();
};
