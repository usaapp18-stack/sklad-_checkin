import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { db } from '../db/index';
import { requireManager, applicationRateLimiter } from '../middleware/auth';
import { logAudit } from '../services/audit';

export const applicationsRouter = Router();

// GET /api/v1/applications (Manager only)
applicationsRouter.get('/', requireManager, async (_req: Request, res: Response): Promise<void> => {
  try {
    const result = await db.query(
      'SELECT id, name, telegram_username, status, note, assigned_login, created_at, updated_at FROM applications ORDER BY created_at DESC'
    );

    const applications = result.rows.map(r => ({
      id: r.id,
      name: r.name,
      telegramUsername: r.telegram_username,
      status: r.status,
      note: r.note,
      generatedLogin: r.assigned_login,
      submittedAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
      createdAt: r.created_at ? new Date(r.created_at).toISOString() : new Date().toISOString(),
      decidedAt: r.updated_at ? new Date(r.updated_at).toISOString() : undefined,
    }));

    res.json({ success: true, applications });
  } catch (err) {
    console.error('[Applications] Get applications error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка получения заявок' } });
  }
});

const submitAppSchema = z.object({
  name: z.string().min(1, 'Имя обязательно'),
  telegramUsername: z.string().optional(),
});

// POST /api/v1/applications (Public registration request)
applicationsRouter.post('/', applicationRateLimiter, async (req: Request, res: Response): Promise<void> => {
  try {
    const parse = submitAppSchema.safeParse(req.body);
    if (!parse.success) {
      res.status(400).json({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: parse.error.issues?.[0]?.message || 'Неверные данные' },
      });
      return;
    }

    const { name, telegramUsername } = parse.data;
    const appId = `app-${uuidv4()}`;

    await db.query(
      'INSERT INTO applications (id, name, telegram_username, status) VALUES ($1, $2, $3, $4)',
      [appId, name.trim(), telegramUsername?.trim() || null, 'pending']
    );

    res.status(201).json({
      success: true,
      applicationId: appId,
      message: 'Заявка успешно отправлена на рассмотрение руководителю',
    });
  } catch (err) {
    console.error('[Applications] Submit application error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка при отправке заявки' } });
  }
});

const handleAppSchema = z.object({
  action: z.enum(['accept', 'reject']),
  note: z.string().optional(),
  generatedLogin: z.string().optional(),
  generatedPassword: z.string().optional(),
  assignedLocations: z.array(z.string()).default([]),
  isSenior: z.boolean().default(false),
});

// PATCH /api/v1/applications/:id (Manager only)
applicationsRouter.patch('/:id', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const parse = handleAppSchema.safeParse(req.body);
    if (!parse.success) {
      res.status(400).json({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: parse.error.issues?.[0]?.message || 'Неверные данные' },
      });
      return;
    }

    const { action, note, generatedLogin, generatedPassword, assignedLocations, isSenior } = parse.data;

    const appRes = await db.query<{ id: string; name: string; telegram_username?: string; status: string }>(
      'SELECT id, name, telegram_username, status FROM applications WHERE id = $1',
      [id]
    );

    if (appRes.rows.length === 0) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Заявка не найдена' } });
      return;
    }

    const app = appRes.rows[0];

    if (action === 'accept') {
      if (!generatedLogin || !generatedPassword) {
        res.status(400).json({
          success: false,
          error: { code: 'CREDENTIALS_REQUIRED', message: 'Для одобрения требуется логин и пароль' },
        });
        return;
      }

      const cleanLogin = generatedLogin.trim();
      const existingUser = await db.query('SELECT id FROM users WHERE LOWER(login) = LOWER($1)', [cleanLogin]);
      if (existingUser.rows.length > 0) {
        res.status(409).json({
          success: false,
          error: { code: 'LOGIN_EXISTS', message: `Логин «${cleanLogin}» уже занят` },
        });
        return;
      }

      const newUserId = `emp-${uuidv4()}`;
      const salt = bcrypt.genSaltSync(10);
      const hash = bcrypt.hashSync(generatedPassword.trim(), salt);

      await db.transaction(async client => {
        // Create user
        await client.query(
          `INSERT INTO users (id, login, password_hash, name, role, status, is_part_time, is_senior, telegram_username)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
          [newUserId, cleanLogin, hash, app.name, 'employee', 'active', false, isSenior, app.telegram_username]
        );

        // Assign locations
        for (const locCode of assignedLocations) {
          const locRes = await client.query<{ id: string }>('SELECT id FROM locations WHERE code = $1', [locCode]);
          if (locRes.rows.length > 0) {
            await client.query('INSERT INTO user_locations (user_id, location_id) VALUES ($1, $2)', [
              newUserId,
              locRes.rows[0].id,
            ]);
          }
        }

        // Update application
        await client.query(
          "UPDATE applications SET status = 'approved', note = $1, assigned_login = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3",
          [note?.trim() || null, cleanLogin, id]
        );

        // Welcome notification
        await client.query(
          `INSERT INTO notifications (id, user_id, title, text, type, source)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [
            `notif-${uuidv4()}`,
            newUserId,
            'Заявка одобрена!',
            `Ваша заявка на регистрацию одобрена. Ваш логин: "${cleanLogin}".`,
            'system',
            'manager',
          ]
        );
      });

      await logAudit(req, req.user!.id, 'APPROVE_APPLICATION', 'application', id, { newUserId, login: cleanLogin });
    } else {
      // Reject
      await db.query(
        "UPDATE applications SET status = 'rejected', note = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2",
        [note?.trim() || null, id]
      );
      await logAudit(req, req.user!.id, 'REJECT_APPLICATION', 'application', id, { note });
    }

    res.json({ success: true });
  } catch (err) {
    console.error('[Applications] Handle application error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка обработки заявки' } });
  }
});
