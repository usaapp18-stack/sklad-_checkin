import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { db } from '../db/index';
import { loginRateLimiter, requireAuth, hashSessionToken, setCsrfCookie } from '../middleware/auth';
import { logAudit } from '../services/audit';

export const authRouter = Router();

const loginSchema = z.object({
  login: z.string().min(1, 'Логин не может быть пустым'),
  password: z.string().min(1, 'Пароль не может быть пустым'),
});

// Helper: Canonical phone normalization without any hardcoded numbers (Requirement 5)
function normalizePhone(input: string): string {
  const digits = input.replace(/\D/g, '');
  if (digits.length === 11 && (digits.startsWith('7') || digits.startsWith('8'))) {
    return '+7' + digits.slice(1);
  }
  if (digits.length === 10) {
    return '+7' + digits;
  }
  return input.trim();
}

// GET /api/v1/auth/csrf-token
authRouter.get('/csrf-token', (req: Request, res: Response): void => {
  const csrfToken = setCsrfCookie(res, req);
  res.json({ success: true, csrfToken });
});

// POST /api/v1/auth/login
authRouter.post('/login', loginRateLimiter, async (req: Request, res: Response): Promise<void> => {
  try {
    const parseResult = loginSchema.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: parseResult.error.issues?.[0]?.message || 'Неверные данные' },
      });
      return;
    }

    const { login, password } = parseResult.data;
    const cleanLogin = login.trim();
    const normalizedPhone = normalizePhone(cleanLogin);

    // Look up user by canonical login or normalized phone in database (no hardcoded aliases!)
    const userRes = await db.query<{
      id: string;
      login: string;
      password_hash: string;
      name: string;
      role: 'manager' | 'employee';
      status: 'active' | 'blocked' | 'archived';
      is_part_time: boolean;
      is_senior: boolean;
      telegram_username?: string;
    }>(
      'SELECT id, login, password_hash, name, role, status, is_part_time, is_senior, telegram_username FROM users WHERE LOWER(login) = LOWER($1) OR login = $2',
      [cleanLogin, normalizedPhone]
    );

    if (userRes.rows.length === 0) {
      res.status(401).json({
        success: false,
        error: { code: 'INVALID_CREDENTIALS', message: 'Неверный логин или пароль' },
      });
      return;
    }

    const user = userRes.rows[0];

    // Check password hash
    const isPasswordValid = await bcrypt.compare(password, user.password_hash);
    if (!isPasswordValid) {
      res.status(401).json({
        success: false,
        error: { code: 'INVALID_CREDENTIALS', message: 'Неверный логин или пароль' },
      });
      return;
    }

    // Check account status (Requirement 39)
    if (user.status === 'blocked' || user.status === 'archived') {
      res.status(403).json({
        success: false,
        error: { code: 'ACCOUNT_BLOCKED', message: 'Учетная запись заблокирована или архивирована' },
      });
      return;
    }

    // Create session (valid for 30 days) and hash token before saving to DB (Requirement 56)
    const sessionToken = uuidv4();
    const tokenHash = hashSessionToken(sessionToken);
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

    await db.query(
      'INSERT INTO sessions (id, user_id, token_hash, expires_at) VALUES ($1, $2, $3, $4)',
      [`sess-${uuidv4()}`, user.id, tokenHash, expiresAt]
    );

    // Fetch user locations
    const locRes = await db.query<{ code: string }>(
      `SELECT l.code FROM locations l
       JOIN user_locations ul ON ul.location_id = l.id
       WHERE ul.user_id = $1`,
      [user.id]
    );
    const locations = locRes.rows.map(r => r.code);

    const isHttps = Boolean(req.secure) || req.headers['x-forwarded-proto'] === 'https' || process.env.NODE_ENV === 'production';

    // Set HttpOnly session cookie
    res.cookie('pvz_session', sessionToken, {
      httpOnly: true,
      secure: isHttps,
      sameSite: isHttps ? 'none' : 'lax',
      maxAge: 30 * 24 * 60 * 60 * 1000,
      ...(isHttps ? { partitioned: true } : {}),
    } as any);

    // Set CSRF cookie (Requirement 9)
    const csrfToken = setCsrfCookie(res, req);

    await logAudit(req, user.id, 'LOGIN', 'user', user.id, { role: user.role, login: user.login });

    // Return token to support Bearer auth in iframe previews alongside cookies
    res.json({
      success: true,
      token: sessionToken,
      csrfToken,
      user: {
        id: user.id,
        login: user.login,
        name: user.name,
        role: user.role,
        status: user.status,
        is_part_time: Boolean(user.is_part_time),
        is_senior: Boolean(user.is_senior),
        telegram_username: user.telegram_username,
        locations,
      },
    });
  } catch (err) {
    console.error('[Auth] Login error:', err);
    res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: 'Внутренняя ошибка сервера при входе' },
    });
  }
});

// POST /api/v1/auth/logout
authRouter.post('/logout', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    let token = req.cookies?.pvz_session;
    if (!token && req.headers.authorization?.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (token) {
      const tokenHash = hashSessionToken(token);
      await db.query('DELETE FROM sessions WHERE token_hash = $1', [tokenHash]);
    }

    res.clearCookie('pvz_session');
    res.clearCookie('pvz_csrf');

    if (req.user) {
      await logAudit(req, req.user.id, 'LOGOUT', 'user', req.user.id);
    }

    res.json({ success: true, message: 'Успешный выход из системы' });
  } catch (err) {
    console.error('[Auth] Logout error:', err);
    res.status(500).json({
      success: false,
      error: { code: 'SERVER_ERROR', message: 'Ошибка при выходе из системы' },
    });
  }
});

// GET /api/v1/auth/me (Requirement 23 & 57: Backend as Single Source of Truth)
authRouter.get('/me', requireAuth, (req: Request, res: Response): void => {
  const csrfToken = req.cookies?.pvz_csrf || setCsrfCookie(res, req);

  res.json({
    success: true,
    csrfToken,
    user: {
      id: req.user!.id,
      login: req.user!.login,
      name: req.user!.name,
      role: req.user!.role,
      status: req.user!.status,
      is_part_time: req.user!.isPartTime,
      is_senior: req.user!.isSenior,
      telegram_username: req.user!.telegramUsername,
      locations: req.user!.locations,
    },
  });
});
