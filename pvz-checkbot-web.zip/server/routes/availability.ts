import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/index';
import { requireAuth } from '../middleware/auth';
import { AvailabilityRequest } from '../../src/types';

export const availabilityRouter = Router();

async function getStoredAvailability(): Promise<AvailabilityRequest[]> {
  try {
    const res = await db.query('SELECT value FROM settings WHERE key = $1', ['staff_availability']);
    if (res.rows.length > 0 && res.rows[0].value) {
      return JSON.parse(res.rows[0].value);
    }
  } catch (e) {
    console.error('[Availability] Read error:', e);
  }
  return [];
}

async function saveStoredAvailability(list: AvailabilityRequest[]): Promise<void> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
    ['staff_availability', JSON.stringify(list)]
  );
}

// GET /api/v1/availability
availabilityRouter.get('/', requireAuth, async (_req: Request, res: Response): Promise<void> => {
  try {
    const list = await getStoredAvailability();
    res.json({ success: true, availability: list });
  } catch (err) {
    console.error('[Availability] Get error:', err);
    res.status(500).json({ success: false, error: 'Ошибка получения пожеланий' });
  }
});

// POST /api/v1/availability (Add or update availability)
availabilityRouter.post('/', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { date, type, comment } = req.body;
    const user = req.user!;

    if (!date || !type) {
      res.status(400).json({ success: false, error: 'Укажите дату и категорию пожелания' });
      return;
    }

    let list = await getStoredAvailability();
    // Remove existing preference for this user on this date if any
    list = list.filter(a => !(a.employeeId === user.id && a.date === date));

    const newReq: AvailabilityRequest = {
      id: `avail-${uuidv4()}`,
      employeeId: user.id,
      employeeName: user.name,
      date,
      type,
      comment: comment ? String(comment).trim() : '',
      createdAt: new Date().toISOString(),
      status: 'pending',
    };

    list.push(newReq);
    await saveStoredAvailability(list);

    res.json({ success: true, availability: list, item: newReq });
  } catch (err) {
    console.error('[Availability] Post error:', err);
    res.status(500).json({ success: false, error: 'Ошибка сохранения пожелания' });
  }
});

// PATCH /api/v1/availability/:id (Update status: approved | rejected | pending)
availabilityRouter.patch('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const availId = req.params.id;
    const { status } = req.body;
    let list = await getStoredAvailability();
    list = list.map(a => a.id === availId ? { ...a, status: status || 'approved' } : a);
    await saveStoredAvailability(list);
    res.json({ success: true, availability: list });
  } catch (err) {
    console.error('[Availability] Patch error:', err);
    res.status(500).json({ success: false, error: 'Ошибка обновления статуса пожелания' });
  }
});

// DELETE /api/v1/availability/:id
availabilityRouter.delete('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const availId = req.params.id;
    let list = await getStoredAvailability();
    list = list.filter(a => a.id !== availId);
    await saveStoredAvailability(list);
    res.json({ success: true, availability: list });
  } catch (err) {
    console.error('[Availability] Delete error:', err);
    res.status(500).json({ success: false, error: 'Ошибка удаления пожелания' });
  }
});
