import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { db } from '../db/index';
import { requireAuth } from '../middleware/auth';
import { telegramService } from '../services/telegram';
import { logAudit } from '../services/audit';

export const checkinsRouter = Router();

// POST /api/v1/checkin-alerts or /api/v1/checkins/checkin-alerts
checkinsRouter.post(['/alerts', '/checkin-alerts'], requireAuth, async (_req: Request, res: Response): Promise<void> => {
  try {
    const today = getTodayMoscowDate();

    // Fetch all active locations
    const locRes = await db.query<{ code: string; name: string }>(
      "SELECT code, name FROM locations WHERE active = TRUE AND is_archived = FALSE"
    );

    const activeLocs = locRes.rows;

    // Fetch checkins for today
    const checkinsRes = await db.query<{ location_code: string }>(
      'SELECT DISTINCT location_code FROM checkins WHERE date = $1',
      [today]
    );

    const checkedLocations = new Set(checkinsRes.rows.map(c => c.location_code));
    const missing = activeLocs
      .filter(loc => !checkedLocations.has(loc.code))
      .map(loc => loc.code);

    res.json({
      success: true,
      missing,
      checkedCount: checkedLocations.size,
      totalCount: activeLocs.length,
    });
  } catch (err) {
    console.error('[Checkins Alert Error]:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка проверки открытий смен' } });
  }
});

// Strict date format validator (YYYY-MM-DD)
const dateRegex = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;

function isValidCalendarDate(dateStr: string): boolean {
  if (!dateRegex.test(dateStr)) return false;
  const d = new Date(dateStr + 'T00:00:00Z');
  return !isNaN(d.getTime()) && d.toISOString().slice(0, 10) === dateStr;
}

function getTodayMoscowDate(): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Moscow',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());

  const year = parts.find(p => p.type === 'year')?.value;
  const month = parts.find(p => p.type === 'month')?.value;
  const day = parts.find(p => p.type === 'day')?.value;
  return `${year}-${month}-${day}`;
}

const checkinSchema = z.object({
  employeeId: z.string().optional(),
  location: z.string().min(1, 'Локация обязательна'),
  shiftType: z.string().min(1, 'Тип смены обязателен'),
  date: z
    .string()
    .refine(val => !val || isValidCalendarDate(val), { message: 'Некорректная дата (требуется ГГГГ-ММ-ДД)' })
    .optional(),
});

async function getActiveShiftRate(userId: string, shiftType: string, client: any): Promise<number> {
  try {
    // 1. Get user details
    const userRes = await client.query('SELECT is_part_time, is_senior FROM users WHERE id = $1', [userId]);
    if (userRes.rows.length === 0) return 2000;
    const user = userRes.rows[0];
    const isPartTime = Boolean(user.is_part_time || user.is_part_time === 1 || user.is_part_time === '1' || user.is_part_time === true);
    
    // 2. Get rates setting
    const ratesRes = await client.query("SELECT value FROM settings WHERE key = 'rates'");
    let rates: any = {
      standard: 2000,
      '400+': 2200,
      '500+': 2500,
      '8h': 1500,
      '4h': 800,
      partTimeShiftRate: 1800,
    };
    if (ratesRes.rows.length > 0) {
      try {
        rates = { ...rates, ...JSON.parse(ratesRes.rows[0].value) };
      } catch {}
    }
    
    // 3. Find base rate
    const shiftTypes = rates.shiftTypes || [];
    const foundType = shiftTypes.find((t: any) => t.code === shiftType);
    
    let baseRate = 2000;
    if (foundType) {
      baseRate = Number(foundType.baseRate);
    } else {
      baseRate = Number(rates[shiftType]) || 2000;
    }
    
    // Special rule for part-time standard shifts
    if (isPartTime && shiftType === 'standard') {
      baseRate = Number(rates.partTimeShiftRate) || 1800;
    }
    
    return baseRate;
  } catch (err) {
    console.error('[Rates History Helper] Error getting active rate:', err);
    return 2000;
  }
}

// GET /api/v1/checkins (Requirement 13: Strict isolation for employee)
checkinsRouter.get('/', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { date } = req.query;
    const isManager = req.user!.role === 'manager';

    let query = `
      SELECT 
        c.id,
        c.user_id,
        u.name as employee_name,
        c.location_code as location,
        c.shift_type,
        c.date,
        c.checked_in_at,
        c.edit_count,
        c.base_rate,
        (SELECT COUNT(*) FROM checkin_cancellations cc WHERE cc.user_id = c.user_id AND cc.date = c.date) as cancel_count,
        s.id as sales_id,
        s.photo_cash,
        s.photo_card,
        s.print_cash,
        s.print_card,
        s.lamination_cash,
        s.lamination_card,
        s.total as sales_total,
        s.bonus as sales_bonus,
        s.submitted_at as sales_submitted_at
      FROM checkins c
      JOIN users u ON u.id = c.user_id
      LEFT JOIN sales s ON s.checkin_id = c.id
    `;
    const params: any[] = [];
    const whereClauses: string[] = [];

    // Requirement 13: Employee strictly sees ONLY their own checkins
    if (!isManager) {
      params.push(req.user!.id);
      whereClauses.push(`c.user_id = $${params.length}`);
    }

    if (date && typeof date === 'string') {
      if (!isValidCalendarDate(date)) {
        res.status(400).json({ success: false, error: { code: 'INVALID_DATE', message: 'Некорректный формат даты' } });
        return;
      }
      params.push(date);
      whereClauses.push(`c.date = $${params.length}`);
    }

    if (whereClauses.length > 0) {
      query += ' WHERE ' + whereClauses.join(' AND ');
    }

    query += ' ORDER BY c.date DESC, c.checked_in_at DESC';

    const result = await db.query(query, params);

    const records = result.rows.map(r => ({
      id: r.id,
      employeeId: r.user_id,
      employeeName: r.employee_name,
      location: r.location,
      shiftType: r.shift_type,
      date: r.date,
      checkedInAt: r.checked_in_at,
      editCount: Number(r.edit_count || 0),
      cancelCount: Number(r.cancel_count || 0),
      baseRate: r.base_rate !== null && r.base_rate !== undefined ? Number(r.base_rate) : undefined,
      sales: r.sales_id
        ? {
            cash: Number(r.photo_cash || 0) + Number(r.print_cash || 0) + Number(r.lamination_cash || 0),
            card: Number(r.photo_card || 0) + Number(r.print_card || 0) + Number(r.lamination_card || 0),
            photo: { cash: Number(r.photo_cash || 0), card: Number(r.photo_card || 0) },
            print: { cash: Number(r.print_cash || 0), card: Number(r.print_card || 0) },
            lamination: { cash: Number(r.lamination_cash || 0), card: Number(r.lamination_card || 0) },
            total: Number(r.sales_total || 0),
            bonus: Number(r.sales_bonus || 0),
          }
        : null,
      salesSubmittedAt: r.sales_submitted_at,
    }));

    let cancelledDates: string[] = [];
    if (!isManager) {
      const cancelRes = await db.query<{ date: string }>(
        'SELECT date FROM checkin_cancellations WHERE user_id = $1',
        [req.user!.id]
      );
      cancelledDates = cancelRes.rows.map(row => row.date);
    }

    res.json({ success: true, records, cancelledDates });
  } catch (err) {
    console.error('[Checkins] Get checkins error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка получения записей смен' } });
  }
});

// POST /api/v1/checkins (Requirements 15, 17, 19: Strict employeeId and date isolation)
checkinsRouter.post('/', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const parse = checkinSchema.safeParse(req.body);
    if (!parse.success) {
      res.status(400).json({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: parse.error.issues?.[0]?.message || 'Неверные данные' },
      });
      return;
    }

    const { location, shiftType, date } = parse.data;
    const today = getTodayMoscowDate();

    // Requirement 15: For employee, employeeId is strictly req.user.id (body employeeId is ignored)
    const isManager = req.user!.role === 'manager';
    const targetUserId = isManager && parse.data.employeeId ? parse.data.employeeId : req.user!.id;

    // Requirement 17: Employee can only check in for TODAY's date
    let targetDate = today;
    if (date) {
      if (!isManager && date !== today) {
        res.status(403).json({
          success: false,
          error: { code: 'FORBIDDEN_DATE', message: 'Сотрудники могут отмечать явку только за текущий день' },
        });
        return;
      }
      targetDate = date;
    }

    // Load target user
    const userRes = await db.query<{ id: string; name: string; status: string; role: string }>(
      'SELECT id, name, status, role FROM users WHERE id = $1',
      [targetUserId]
    );

    if (userRes.rows.length === 0) {
      res.status(404).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'Сотрудник не найден' } });
      return;
    }

    const targetUser = userRes.rows[0];
    if (targetUser.status === 'blocked' || targetUser.status === 'archived') {
      res.status(403).json({
        success: false,
        error: { code: 'USER_INACTIVE', message: 'Сотрудник заблокирован или архивирован' },
      });
      return;
    }

    // Verify employee location assignment
    if (!isManager) {
      const locCheck = await db.query<{ id: string }>(
        `SELECT l.id FROM locations l
         JOIN user_locations ul ON ul.location_id = l.id
         WHERE ul.user_id = $1 AND l.code = $2`,
        [targetUserId, location]
      );

      if (locCheck.rows.length === 0) {
        res.status(403).json({
          success: false,
          error: {
            code: 'FORBIDDEN_LOCATION',
            message: `Сотрудник не имеет доступа к локации «${location}». Обратитесь к руководителю.`,
          },
        });
        return;
      }
    } else {
      // For manager, ensure location exists in locations table and associate with employee
      const locRes = await db.query<{ id: string }>('SELECT id FROM locations WHERE code = $1', [location]);
      let locId = locRes.rows[0]?.id;
      if (!locId) {
        locId = `loc-${uuidv4()}`;
        await db.query(
          'INSERT INTO locations (id, code, name) VALUES ($1, $2, $3)',
          [locId, location, `ПВЗ ${location}`]
        );
      }
      // Associate with user so future checks pass
      await db.query(
        'INSERT INTO user_locations (user_id, location_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [targetUserId, locId]
      );
    }

    // Normalize shift type to standard canonical identifiers
    let cleanShiftType = shiftType;
    if (shiftType === 'rate400') cleanShiftType = '400+';
    else if (shiftType === 'rate500') cleanShiftType = '500+';
    else if (shiftType === 'shift8h') cleanShiftType = '8h';
    else if (shiftType === 'shift4h') cleanShiftType = '4h';

    // Record check-in atomically
    let checkinId = `rec-${uuidv4()}`;

    await db.transaction(async client => {
      // Get the correct base rate active for the user at this moment
      let baseRate: number | null = null;
      try {
        baseRate = await getActiveShiftRate(targetUserId, cleanShiftType, client);
      } catch (rateErr) {
        console.error('Error fetching active shift rate inside transaction:', rateErr);
      }

      // Check existing check-in for this user on targetDate
      const existing = await client.query<{ id: string; edit_count?: number }>(
        'SELECT id, edit_count FROM checkins WHERE user_id = $1 AND date = $2',
        [targetUserId, targetDate]
      );

      if (existing.rows.length > 0) {
        checkinId = existing.rows[0].id;
        const currentEditCount = Number(existing.rows[0].edit_count || 0);

        // Employee can edit their checked-in shift ONLY ONCE!
        // Manager can edit shifts unlimited times.
        if (!isManager && currentEditCount >= 1) {
          const limitErr = new Error('EDIT_LIMIT_EXCEEDED');
          (limitErr as any).code = 'EDIT_LIMIT_EXCEEDED';
          throw limitErr;
        }

        const newEditCount = isManager ? currentEditCount : currentEditCount + 1;
        await client.query(
          `UPDATE checkins
           SET location_code = $1, shift_type = $2, edit_count = $3, base_rate = $4
           WHERE id = $5`,
          [location, cleanShiftType, newEditCount, baseRate, checkinId]
        );
      } else {
        // If past date and added by manager, set checked_in_at to that date at 09:00:00 MSK
        const checkinTime = isManager && targetDate !== today
          ? `${targetDate} 09:00:00`
          : new Date().toISOString().replace('T', ' ').slice(0, 19);

        await client.query(
          `INSERT INTO checkins (id, user_id, location_code, shift_type, date, checked_in_at, edit_count, base_rate)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [checkinId, targetUserId, location, cleanShiftType, targetDate, checkinTime, 0, baseRate]
        );
      }
    });

    // Notify Telegram asynchronously
    const isOnline = cleanShiftType !== 'standard';
    const shiftLabel = cleanShiftType;
    telegramService
      .sendMessage(
        `🟢 *Check-in зафиксирован!*\n` +
          `👤 Сотрудник: *${targetUser.name}*\n` +
          `📍 Пункт: *${location}*\n` +
          `⏱ Смена: *${shiftLabel}*\n` +
          `📅 Дата: *${targetDate}*\n` +
          `⏰ Время: *${new Date().toLocaleTimeString('ru-RU', { timeZone: 'Europe/Moscow' })} (МСК)*`
      )
      .catch(err => console.error('[Checkins] Telegram notification error:', err));

    await logAudit(req, req.user!.id, 'CHECKIN', 'checkin', checkinId, {
      userId: targetUserId,
      location,
      shiftType: cleanShiftType,
      date: targetDate,
    });

    res.json({
      success: true,
      checkin: {
        id: checkinId,
        employeeId: targetUserId,
        employeeName: targetUser.name,
        location,
        shiftType: cleanShiftType,
        date: targetDate,
        checkedInAt: new Date().toISOString(),
        sales: null,
      },
    });
  } catch (err: any) {
    if (err?.code === 'EDIT_LIMIT_EXCEEDED' || err?.message === 'EDIT_LIMIT_EXCEEDED') {
      res.status(403).json({
        success: false,
        error: {
          code: 'EDIT_LIMIT_EXCEEDED',
          message: 'Работник может изменять свою отмеченную смену только один раз. В случае необходимости обратитесь к руководителю, чтобы руководитель сам внёс изменение.',
        },
      });
      return;
    }
    console.error('[Checkins] Post checkin error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка при выполнении Check-in' } });
  }
});

// PATCH /api/v1/checkins/:id (Manager can edit shift details unlimited times)
checkinsRouter.patch('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const isManager = req.user!.role === 'manager';
    if (!isManager) {
      res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Только руководитель может изменять смены' } });
      return;
    }

    const { shiftType, location, date } = req.body;
    const updates: string[] = [];
    const params: any[] = [];

    if (shiftType) {
      let cleanShiftType = shiftType;
      if (shiftType === 'rate400') cleanShiftType = '400+';
      else if (shiftType === 'rate500') cleanShiftType = '500+';
      else if (shiftType === 'shift8h') cleanShiftType = '8h';
      else if (shiftType === 'shift4h') cleanShiftType = '4h';
      params.push(cleanShiftType);
      updates.push(`shift_type = $${params.length}`);
    }
    if (location) {
      params.push(location);
      updates.push(`location_code = $${params.length}`);
    }
    if (date) {
      params.push(date);
      updates.push(`date = $${params.length}`);
    }

    if (updates.length > 0) {
      params.push(id);
      await db.query(`UPDATE checkins SET ${updates.join(', ')} WHERE id = $${params.length}`, params);
    }

    res.json({ success: true });
  } catch (err) {
    console.error('[Checkins] Patch checkin error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка обновления смены' } });
  }
});

// DELETE /api/v1/checkins/:id (Requirement 16: Employee can only delete today's checkin)
checkinsRouter.delete('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const isManager = req.user!.role === 'manager';
    const today = getTodayMoscowDate();

    const checkinRes = await db.query<{ id: string; user_id: string; date: string; edit_count?: number }>(
      'SELECT id, user_id, date, edit_count FROM checkins WHERE id = $1',
      [id]
    );

    if (checkinRes.rows.length === 0) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Запись Check-in не найдена' } });
      return;
    }

    const checkin = checkinRes.rows[0];

    // If employee: must own the record AND must be today's date AND must not have exceeded edit limit
    if (!isManager) {
      if (checkin.user_id !== req.user!.id) {
        res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Нельзя отменить чужую смену' } });
        return;
      }
      if (checkin.date !== today) {
        res.status(403).json({
          success: false,
          error: {
            code: 'FORBIDDEN_PAST_DATE',
            message: 'Сотрудник может отменить check-in только за сегодняшний день',
          },
        });
        return;
      }
      if (Number(checkin.edit_count || 0) >= 1) {
        res.status(403).json({
          success: false,
          error: {
            code: 'EDIT_LIMIT_EXCEEDED',
            message: 'Работник может изменять или отменять смену только один раз. Для дальнейших изменений обратитесь к руководителю.',
          },
        });
        return;
      }

      // Check if employee already cancelled check-in today (allowed only 1 time)
      const cancelCheck = await db.query<{ count: string | number }>(
        'SELECT COUNT(*) as count FROM checkin_cancellations WHERE user_id = $1 AND date = $2',
        [req.user!.id, checkin.date]
      );
      if (Number(cancelCheck.rows[0]?.count || 0) >= 1) {
        res.status(403).json({
          success: false,
          error: {
            code: 'CANCEL_LIMIT_EXCEEDED',
            message: 'Работник может отменить Check-in только один раз. В случае необходимости обратитесь к руководителю, чтобы руководитель сам внёс изменение.',
          },
        });
        return;
      }
    }

    await db.transaction(async client => {
      if (!isManager) {
        await client.query(
          'INSERT INTO checkin_cancellations (id, user_id, date) VALUES ($1, $2, $3)',
          [`canc-${uuidv4()}`, req.user!.id, checkin.date]
        );
      } else {
        // Manager deleting/cancelling clears any cancellation locks for this employee and date
        await client.query(
          'DELETE FROM checkin_cancellations WHERE user_id = $1 AND date = $2',
          [checkin.user_id, checkin.date]
        );
      }
      await client.query('DELETE FROM sales WHERE checkin_id = $1', [id]);
      await client.query('DELETE FROM checkins WHERE id = $1', [id]);
    });
    await logAudit(req, req.user!.id, 'CANCEL_CHECKIN', 'checkin', id);

    res.json({ success: true });
  } catch (err) {
    console.error('[Checkins] Delete checkin error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка отмены Check-in' } });
  }
});
