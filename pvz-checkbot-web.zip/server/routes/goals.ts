import { Router, Request, Response } from 'express';
import { db } from '../db/index';
import { requireAuth } from '../middleware/auth';
import { IncomeGoal } from '../../src/types';

export const goalsRouter = Router();

async function getStoredGoals(): Promise<IncomeGoal[]> {
  try {
    const res = await db.query('SELECT value FROM settings WHERE key = $1', ['income_goals']);
    if (res.rows.length > 0 && res.rows[0].value) {
      return JSON.parse(res.rows[0].value);
    }
  } catch (e) {
    console.error('[Goals] Read error:', e);
  }
  return [];
}

async function saveStoredGoals(goals: IncomeGoal[]): Promise<void> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
    ['income_goals', JSON.stringify(goals)]
  );
}

// GET /api/v1/income-goals
goalsRouter.get('/', requireAuth, async (_req: Request, res: Response): Promise<void> => {
  try {
    const goals = await getStoredGoals();
    res.json({ success: true, goals });
  } catch (err) {
    console.error('[Goals] Get error:', err);
    res.status(500).json({ success: false, error: 'Ошибка загрузки целей заработка' });
  }
});

// POST /api/v1/income-goals
goalsRouter.post('/', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { employeeId, month, targetAmount } = req.body;
    const user = req.user!;
    const targetEmpId = employeeId || user.id;

    if (!month || typeof targetAmount !== 'number') {
      res.status(400).json({ success: false, error: 'Укажите месяц и финансовую цель' });
      return;
    }

    let goals = await getStoredGoals();
    // Remove existing goal for this employee and month
    goals = goals.filter(g => !(g.employeeId === targetEmpId && g.month === month));

    const newGoal: IncomeGoal = {
      employeeId: targetEmpId,
      month,
      targetAmount,
    };

    goals.push(newGoal);
    await saveStoredGoals(goals);

    res.json({ success: true, goals, goal: newGoal });
  } catch (err) {
    console.error('[Goals] Post error:', err);
    res.status(500).json({ success: false, error: 'Ошибка сохранения цели' });
  }
});
