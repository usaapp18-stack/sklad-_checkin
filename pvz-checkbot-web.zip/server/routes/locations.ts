import { Router, Request, Response } from 'express';
import { db } from '../db/index';
import { requireManager } from '../middleware/auth';
import { logAudit } from '../services/audit';

export const locationsRouter = Router();

export interface LocationItem {
  id: string;
  code: string;
  name: string;
  address?: string;
  active: boolean;
  isArchived?: boolean;
  archivedAt?: string;
  assignedStaffIds?: string[];
  contactPhone?: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

const DEFAULT_LOCATIONS: LocationItem[] = [];

// Helper to map DB row to LocationItem
function mapRowToLocation(row: any): LocationItem {
  let assignedStaff: string[] = [];
  if (row.assigned_staff_ids) {
    try {
      assignedStaff = JSON.parse(row.assigned_staff_ids);
    } catch {
      assignedStaff = typeof row.assigned_staff_ids === 'string' ? row.assigned_staff_ids.split(',').map((s: string) => s.trim()).filter(Boolean) : [];
    }
  }

  return {
    id: row.id,
    code: row.code,
    name: row.name,
    address: row.address || '',
    active: Boolean(row.active ?? true),
    isArchived: Boolean(row.is_archived ?? false),
    archivedAt: row.archived_at ? new Date(row.archived_at).toISOString() : undefined,
    assignedStaffIds: Array.isArray(assignedStaff) ? assignedStaff : [],
    contactPhone: row.contact_phone || '',
    notes: row.notes || '',
    createdAt: row.created_at ? new Date(row.created_at).toISOString() : new Date().toISOString(),
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : undefined,
  };
}

/**
 * Get all locations (both active and archived) directly from the persistent database table `locations`.
 */
export async function getStoredLocations(): Promise<LocationItem[]> {
  try {
    // Query directly from relational `locations` table (single source of truth)
    const res = await db.query(
      `SELECT id, code, name, address, active, is_archived, archived_at, contact_phone, notes, assigned_staff_ids, created_at, updated_at
       FROM locations
       ORDER BY created_at ASC, name ASC`
    );

    const list = res.rows.map(mapRowToLocation);
    // Mirror to settings table for backup only
    try {
      await db.query(
        `INSERT INTO settings (key, value) VALUES ($1, $2)
         ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
        ['locations', JSON.stringify(list)]
      );
    } catch {}

    return list;
  } catch (err) {
    console.error('[Locations] Read error from DB:', err);
    try {
      const fallback = await db.query('SELECT value FROM settings WHERE key = $1', ['locations']);
      if (fallback.rows.length > 0 && fallback.rows[0].value) {
        return JSON.parse(fallback.rows[0].value);
      }
    } catch {}
    return [];
  }
}

/**
 * Persists a single location to the relational database `locations` table.
 */
export async function saveSingleLocationToDb(loc: LocationItem): Promise<void> {
  const assignedJson = JSON.stringify(loc.assignedStaffIds || []);
  await db.query(
    `INSERT INTO locations (id, code, name, address, active, is_archived, archived_at, contact_phone, notes, assigned_staff_ids, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, CURRENT_TIMESTAMP)
     ON CONFLICT (id) DO UPDATE SET
       code = EXCLUDED.code,
       name = EXCLUDED.name,
       address = EXCLUDED.address,
       active = EXCLUDED.active,
       is_archived = EXCLUDED.is_archived,
       archived_at = EXCLUDED.archived_at,
       contact_phone = EXCLUDED.contact_phone,
       notes = EXCLUDED.notes,
       assigned_staff_ids = EXCLUDED.assigned_staff_ids,
       updated_at = CURRENT_TIMESTAMP`,
    [
      loc.id,
      loc.code,
      loc.name,
      loc.address || '',
      loc.active ? 1 : 0,
      loc.isArchived ? 1 : 0,
      loc.archivedAt || null,
      loc.contactPhone || '',
      loc.notes || '',
      assignedJson,
      loc.createdAt || new Date().toISOString(),
    ]
  );
}

// GET /api/v1/locations
locationsRouter.get('/', async (_req: Request, res: Response): Promise<void> => {
  try {
    const locations = await getStoredLocations();
    res.json({ success: true, locations });
  } catch (err) {
    console.error('[Locations] Get error:', err);
    res.json({ success: true, locations: DEFAULT_LOCATIONS });
  }
});

// POST /api/v1/locations (Add new ПВЗ - max 30)
locationsRouter.post('/', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const currentLocs = await getStoredLocations();

    if (currentLocs.length >= 30) {
      res.status(400).json({ success: false, error: 'Достигнут лимит: максимально допустимо 30 пунктов выдачи (ПВЗ).' });
      return;
    }

    const { name, code, address, active = true, assignedStaffIds = [], contactPhone = '', notes = '' } = req.body;
    const cleanName = typeof name === 'string' ? name.trim().slice(0, 30) : '';
    if (!cleanName) {
      res.status(400).json({ success: false, error: 'Укажите название пункта выдачи.' });
      return;
    }

    const duplicateName = currentLocs.find(l => l.name.trim().toLowerCase() === cleanName.toLowerCase());
    if (duplicateName) {
      res.status(400).json({ success: false, error: `Пункт выдачи с названием «${cleanName}» уже существует. Названия ПВЗ должны быть уникальными.` });
      return;
    }

    const finalCode = (typeof code === 'string' && code.trim().length > 0 ? code.trim().slice(0, 18) : `ПВЗ-${currentLocs.length + 1}`).toUpperCase();

    const newLoc: LocationItem = {
      id: `pvz-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      code: finalCode,
      name: cleanName,
      address: address ? String(address).trim() : '',
      active: Boolean(active),
      isArchived: false,
      assignedStaffIds: Array.isArray(assignedStaffIds) ? assignedStaffIds : [],
      contactPhone: contactPhone ? String(contactPhone).trim() : '',
      notes: notes ? String(notes).trim() : '',
      createdAt: new Date().toISOString(),
    };

    await saveSingleLocationToDb(newLoc);
    const updatedList = await getStoredLocations();

    await logAudit(req, req.user!.id, 'CREATE_LOCATION', 'location', newLoc.id, {
      code: newLoc.code,
      name: newLoc.name,
    });

    res.json({ success: true, location: newLoc, locations: updatedList });
  } catch (err: any) {
    console.error('[Locations] Create error:', err);
    res.status(500).json({ success: false, error: { message: 'Ошибка сохранения пункта выдачи' } });
  }
});

// PUT /api/v1/locations/:id (Update existing ПВЗ / Archive / Restore)
locationsRouter.put('/:id', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const locId = req.params.id;
    const currentLocs = await getStoredLocations();

    const locIdDecoded = decodeURIComponent(locId);
    const idx = currentLocs.findIndex(
      l =>
        l.id === locId ||
        l.id === locIdDecoded ||
        l.code === locId ||
        l.code === locIdDecoded ||
        l.code.toUpperCase() === locId.toUpperCase() ||
        l.code.toUpperCase() === locIdDecoded.toUpperCase() ||
        l.id.toLowerCase() === locId.toLowerCase()
    );

    if (idx === -1) {
      res.status(404).json({ success: false, error: 'Пункт выдачи не найден.' });
      return;
    }

    const target = currentLocs[idx];
    const body = req.body;

    if (body.name !== undefined) {
      const cleanName = String(body.name).trim().slice(0, 30);
      if (!cleanName) {
        res.status(400).json({ success: false, error: 'Укажите название пункта выдачи.' });
        return;
      }
      const duplicateName = currentLocs.find((l, i) => i !== idx && l.name.trim().toLowerCase() === cleanName.toLowerCase());
      if (duplicateName) {
        res.status(400).json({ success: false, error: `Пункт выдачи с названием «${cleanName}» уже существует. Названия ПВЗ должны быть уникальными.` });
        return;
      }
      target.name = cleanName;
    }
    if (body.code !== undefined) {
      const cleanCode = String(body.code).trim().slice(0, 18).toUpperCase();
      if (cleanCode) {
        target.code = cleanCode;
      }
    }
    if (body.address !== undefined) target.address = String(body.address).trim();
    if (body.active !== undefined) target.active = Boolean(body.active);
    
    // Archiving and Restoring logic
    if (body.isArchived !== undefined) {
      target.isArchived = Boolean(body.isArchived);
      if (body.isArchived) {
        target.archivedAt = body.archivedAt || new Date().toISOString();
        target.active = false;
      } else {
        target.archivedAt = undefined;
        target.active = true;
      }
    }
    
    if (Array.isArray(body.assignedStaffIds)) target.assignedStaffIds = body.assignedStaffIds;
    if (body.contactPhone !== undefined) target.contactPhone = String(body.contactPhone).trim();
    if (body.notes !== undefined) target.notes = String(body.notes).trim();

    await saveSingleLocationToDb(target);
    const updatedList = await getStoredLocations();

    await logAudit(req, req.user!.id, target.isArchived ? 'ARCHIVE_LOCATION' : 'UPDATE_LOCATION', 'location', target.id, {
      code: target.code,
      name: target.name,
      isArchived: target.isArchived,
    });

    res.json({ success: true, locations: updatedList });
  } catch (err) {
    console.error('[Locations] Update error:', err);
    res.status(500).json({ success: false, error: 'Ошибка обновления пункта выдачи' });
  }
});

// DELETE /api/v1/locations/:id
locationsRouter.delete('/:id', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const locId = req.params.id;
    const currentLocs = await getStoredLocations();

    const locIdDecoded = decodeURIComponent(locId);
    const targetLoc = currentLocs.find(
      l =>
        l.id === locId ||
        l.id === locIdDecoded ||
        l.code === locId ||
        l.code === locIdDecoded ||
        l.code.toUpperCase() === locId.toUpperCase() ||
        l.code.toUpperCase() === locIdDecoded.toUpperCase() ||
        l.id.toLowerCase() === locId.toLowerCase()
    );

    const targetCode = targetLoc?.code || locId;
    const targetId = targetLoc?.id || locId;

    // Delete directly from locations table (cascades user_locations)
    try {
      await db.query('DELETE FROM locations WHERE id = $1 OR code = $2', [targetId, targetCode]);
    } catch (e) {
      console.warn('[Locations] Cleanup in locations table notice:', e);
    }

    const updatedList = await getStoredLocations();

    await logAudit(req, req.user!.id, 'DELETE_LOCATION', 'location', targetId, {
      code: targetCode,
      name: targetLoc?.name,
    });

    res.json({ success: true, locations: updatedList });
  } catch (err) {
    console.error('[Locations] Delete error:', err);
    res.status(500).json({ success: false, error: 'Ошибка удаления пункта выдачи' });
  }
});
