import { Router, Request, Response } from 'express';
import { db } from '../db/index';
import { requireAuth } from '../middleware/auth';
import { PaybackPvzRecord, PaybackArticleTemplates } from '../../src/types';

export const paybackRouter = Router();

const DEFAULT_INCOME_NAMES = [
  'Агентское вознаграждение',
  'Продажи за смену (выручка)',
];

const DEFAULT_EXPENSE_NAMES = [
  'Аренда помещения',
  'Фонд оплаты труда (ФОТ)',
  'Коммунальные услуги и интернет',
  'Эквайринг и банковское обслуживание',
  'Расходники (лента, скотч, пакетирование)',
  'Налоги',
];

const DEFAULT_TEMPLATES: PaybackArticleTemplates = {
  incomeArticles: [...DEFAULT_INCOME_NAMES],
  expenseArticles: [...DEFAULT_EXPENSE_NAMES],
  customIncomeArticles: [],
  customExpenseArticles: [],
};

async function getStoredRecords(): Promise<PaybackPvzRecord[]> {
  try {
    const res = await db.query('SELECT value FROM settings WHERE key = $1', ['payback_records']);
    if (res.rows.length > 0 && res.rows[0].value) {
      return JSON.parse(res.rows[0].value);
    }
  } catch (e) {
    console.error('[Payback] Read records error:', e);
  }
  return [];
}

async function saveStoredRecords(records: PaybackPvzRecord[]): Promise<void> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
    ['payback_records', JSON.stringify(records)]
  );
}

async function getStoredTemplates(): Promise<PaybackArticleTemplates> {
  try {
    const res = await db.query('SELECT value FROM settings WHERE key = $1', ['payback_article_templates']);
    if (res.rows.length > 0 && res.rows[0].value) {
      const parsed = JSON.parse(res.rows[0].value);
      const inc = Array.isArray(parsed.incomeArticles)
        ? parsed.incomeArticles
        : Array.from(new Set([...DEFAULT_INCOME_NAMES, ...(parsed.customIncomeArticles || [])]));
      const exp = Array.isArray(parsed.expenseArticles)
        ? parsed.expenseArticles
        : Array.from(new Set([...DEFAULT_EXPENSE_NAMES, ...(parsed.customExpenseArticles || [])]));
      return {
        incomeArticles: inc,
        expenseArticles: exp,
        customIncomeArticles: parsed.customIncomeArticles || [],
        customExpenseArticles: parsed.customExpenseArticles || [],
      };
    }
  } catch (e) {
    console.error('[Payback] Read templates error:', e);
  }
  return {
    incomeArticles: [...DEFAULT_INCOME_NAMES],
    expenseArticles: [...DEFAULT_EXPENSE_NAMES],
    customIncomeArticles: [],
    customExpenseArticles: [],
  };
}

async function saveStoredTemplates(templates: PaybackArticleTemplates): Promise<void> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
    ['payback_article_templates', JSON.stringify(templates)]
  );
}

// GET /api/v1/payback
paybackRouter.get('/', requireAuth, async (_req: Request, res: Response): Promise<void> => {
  try {
    const [records, templates] = await Promise.all([
      getStoredRecords(),
      getStoredTemplates(),
    ]);
    res.json({ success: true, records, templates });
  } catch (err) {
    console.error('[Payback] Get error:', err);
    res.status(500).json({ success: false, error: 'Ошибка загрузки данных окупаемости' });
  }
});

// POST /api/v1/payback (Save or update record for a PVZ and Month)
paybackRouter.post('/', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { record } = req.body;
    if (!record || !record.pvzCode || !record.month) {
      res.status(400).json({ success: false, error: 'Не указан ПВЗ или месяц' });
      return;
    }

    const targetPvz = String(record.pvzCode).trim();
    const targetMonth = String(record.month).trim();

    const [recordsRaw, templates] = await Promise.all([
      getStoredRecords(),
      getStoredTemplates(),
    ]);

    // Filter out existing record for this pvz + month
    const records = recordsRaw.filter(r => !(r.pvzCode === targetPvz && r.month === targetMonth));

    const newRecord: PaybackPvzRecord = {
      pvzCode: targetPvz,
      month: targetMonth,
      incomes: Array.isArray(record.incomes) ? record.incomes : [],
      expenses: Array.isArray(record.expenses) ? record.expenses : [],
      updatedAt: new Date().toISOString(),
    };

    records.push(newRecord);

    // Sync updated article names into templates so all future months have this exact configuration
    const currentIncomeNames = (newRecord.incomes || []).map(i => i.name.trim()).filter(Boolean);
    const currentExpenseNames = (newRecord.expenses || []).map(e => e.name.trim()).filter(Boolean);

    if (currentIncomeNames.length > 0) {
      templates.incomeArticles = currentIncomeNames;
    }
    if (currentExpenseNames.length > 0) {
      templates.expenseArticles = currentExpenseNames;
    }

    await Promise.all([
      saveStoredRecords(records),
      saveStoredTemplates(templates),
    ]);

    res.json({ success: true, records, templates });
  } catch (err) {
    console.error('[Payback] Save error:', err);
    res.status(500).json({ success: false, error: 'Ошибка сохранения данных окупаемости' });
  }
});

// POST /api/v1/payback/article (Add, edit or delete article template)
paybackRouter.post('/article', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { type, action, name, oldName } = req.body;
    if (!type || !action || !name) {
      res.status(400).json({ success: false, error: 'Некорректные параметры статьи' });
      return;
    }

    const templates = await getStoredTemplates();
    let records = await getStoredRecords();

    const isIncome = type === 'income';
    let list = isIncome ? (templates.incomeArticles || []) : (templates.expenseArticles || []);

    if (action === 'add') {
      const cleanName = name.trim();
      if (cleanName && !list.includes(cleanName)) {
        list.push(cleanName);
      }
    } else if (action === 'edit' && oldName) {
      const cleanOld = oldName.trim();
      const cleanNew = name.trim();
      const idx = list.indexOf(cleanOld);
      if (idx !== -1) {
        list[idx] = cleanNew;
      } else if (!list.includes(cleanNew)) {
        list.push(cleanNew);
      }
      // Also update in existing records
      records = records.map(r => {
        const arr = isIncome ? r.incomes : r.expenses;
        const updatedArr = (arr || []).map(item => item.name === cleanOld ? { ...item, name: cleanNew } : item);
        return isIncome ? { ...r, incomes: updatedArr } : { ...r, expenses: updatedArr };
      });
      await saveStoredRecords(records);
    } else if (action === 'delete') {
      const cleanName = name.trim();
      list = list.filter(n => n !== cleanName);
      // Also remove from records
      records = records.map(r => {
        const arr = isIncome ? r.incomes : r.expenses;
        const filtered = (arr || []).filter(item => item.name !== cleanName);
        return isIncome ? { ...r, incomes: filtered } : { ...r, expenses: filtered };
      });
      await saveStoredRecords(records);
    }

    if (isIncome) {
      templates.incomeArticles = list;
    } else {
      templates.expenseArticles = list;
    }

    await saveStoredTemplates(templates);
    res.json({ success: true, templates, records });
  } catch (err) {
    console.error('[Payback] Article action error:', err);
    res.status(500).json({ success: false, error: 'Ошибка изменения статьи' });
  }
});

// DELETE /api/v1/payback/:pvzCode/:month
paybackRouter.delete('/:pvzCode/:month', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { pvzCode, month } = req.params;
    let records = await getStoredRecords();
    records = records.filter(r => !(r.pvzCode === pvzCode && r.month === month));
    await saveStoredRecords(records);
    res.json({ success: true, records });
  } catch (err) {
    console.error('[Payback] Delete error:', err);
    res.status(500).json({ success: false, error: 'Ошибка удаления данных окупаемости' });
  }
});
