import { Router, Request, Response } from 'express';
import { db } from '../db/index';
import { requireManager } from '../middleware/auth';

export const ratesRouter = Router();

const DEFAULT_RATES = {
  standard: 2000,
  '400+': 2200,
  '500+': 2500,
  '8h': 1500,
  '4h': 800,
  partTimeShiftRate: 1800,
  seniorBonus: 200,
  partTimeBonus: 0,
  shiftTypes: [
    { code: 'standard', name: 'Обычная смена', baseRate: 2000, isArchived: false },
    { code: '400+', name: 'Смена 400+', baseRate: 2200, isArchived: false },
    { code: '500+', name: 'Смена 500+', baseRate: 2500, isArchived: false },
    { code: '8h', name: 'Смена 8 часов', baseRate: 1500, isArchived: false },
    { code: '4h', name: 'Смена 4 часа', baseRate: 800, isArchived: false },
  ],
  partTimeShiftTypes: [
    { code: '4h', name: 'Смена 4 часа', baseRate: 800, isArchived: false },
    { code: 'pt_standard', name: 'Смена подработчика (полная)', baseRate: 1800, isArchived: false },
  ],
  bonuses: [
    { code: 'seniorBonus', name: 'Доплата Старшему (Ст.С.)', value: 200, isArchived: false, target: 'senior' },
    { code: 'partTimeBonus', name: 'Доплата Подработчику', value: 0, isArchived: false, target: 'part_time' },
  ],
};

// GET /api/v1/rates
ratesRouter.get('/', async (_req: Request, res: Response): Promise<void> => {
  try {
    const result = await db.query('SELECT value FROM settings WHERE key = $1', ['rates']);
    if (result.rows.length === 0) {
      res.json({ success: true, rates: DEFAULT_RATES });
      return;
    }

    try {
      const parsed = JSON.parse(result.rows[0].value);
      res.json({ success: true, rates: { ...DEFAULT_RATES, ...parsed } });
    } catch {
      res.json({ success: true, rates: DEFAULT_RATES });
    }
  } catch (err) {
    console.error('[Rates] Get rates error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка получения ставок' } });
  }
});

// POST /api/v1/rates (Manager only)
ratesRouter.post('/', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const ratesString = JSON.stringify(req.body);
    
    await db.query(
      `INSERT INTO settings (key, value) VALUES ($1, $2)
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
      ['rates', ratesString]
    );

    res.json({ success: true, rates: req.body });
  } catch (err) {
    console.error('[Rates] Save rates error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка сохранения ставок' } });
  }
});
