import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/index';
import { requireAuth } from '../middleware/auth';
import { PlannedShift, ScheduleTemplate } from '../../src/types';

export const schedulesRouter = Router();

async function getStoredSchedules(): Promise<PlannedShift[]> {
  try {
    const res = await db.query('SELECT value FROM settings WHERE key = $1', ['planned_schedules']);
    if (res.rows.length > 0 && res.rows[0].value) {
      return JSON.parse(res.rows[0].value);
    }
  } catch (e) {
    console.error('[Schedules] Read error:', e);
  }
  return [];
}

async function saveStoredSchedules(schedules: PlannedShift[]): Promise<void> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
    ['planned_schedules', JSON.stringify(schedules)]
  );
}

async function getStoredTemplates(): Promise<ScheduleTemplate[]> {
  try {
    const res = await db.query('SELECT value FROM settings WHERE key = $1', ['schedule_templates']);
    if (res.rows.length > 0 && res.rows[0].value) {
      return JSON.parse(res.rows[0].value);
    }
  } catch (e) {
    console.error('[Schedule Templates] Read error:', e);
  }
  return [];
}

async function saveStoredTemplates(templates: ScheduleTemplate[]): Promise<void> {
  await db.query(
    `INSERT INTO settings (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
    ['schedule_templates', JSON.stringify(templates)]
  );
}

// GET /api/v1/schedules
schedulesRouter.get('/', requireAuth, async (_req: Request, res: Response): Promise<void> => {
  try {
    const schedules = await getStoredSchedules();
    res.json({ success: true, schedules });
  } catch (err) {
    console.error('[Schedules] Get error:', err);
    res.status(500).json({ success: false, error: 'Ошибка получения графика смен' });
  }
});

// GET /api/v1/schedules/templates
schedulesRouter.get('/templates', requireAuth, async (_req: Request, res: Response): Promise<void> => {
  try {
    const templates = await getStoredTemplates();
    res.json({ success: true, templates });
  } catch (err) {
    console.error('[Schedule Templates] Get error:', err);
    res.status(500).json({ success: false, error: 'Ошибка получения шаблонов' });
  }
});

// POST /api/v1/schedules/templates
schedulesRouter.post('/templates', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id, name, location, scenarioType, mainStaffIds, partTimeStaffIds, defaultShiftType, notes } = req.body;
    if (!name || !location || !scenarioType) {
      res.status(400).json({ success: false, error: 'Заполните обязательные поля шаблона' });
      return;
    }

    let templates = await getStoredTemplates();
    const templateId = id || `tpl-${uuidv4()}`;

    const newTemplate: ScheduleTemplate = {
      id: templateId,
      name: String(name).trim(),
      location: String(location).trim(),
      scenarioType,
      mainStaffIds: Array.isArray(mainStaffIds) ? mainStaffIds : [],
      partTimeStaffIds: Array.isArray(partTimeStaffIds) ? partTimeStaffIds : [],
      defaultShiftType: defaultShiftType || 'standard',
      notes: notes ? String(notes).trim() : '',
      createdAt: new Date().toISOString(),
    };

    templates = templates.filter(t => t.id !== templateId);
    templates.push(newTemplate);
    await saveStoredTemplates(templates);

    res.json({ success: true, templates, template: newTemplate });
  } catch (err) {
    console.error('[Schedule Templates] Save error:', err);
    res.status(500).json({ success: false, error: 'Ошибка сохранения шаблона' });
  }
});

// DELETE /api/v1/schedules/templates/:id
schedulesRouter.delete('/templates/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const templateId = req.params.id;
    let templates = await getStoredTemplates();
    templates = templates.filter(t => t.id !== templateId);
    await saveStoredTemplates(templates);
    res.json({ success: true, templates });
  } catch (err) {
    console.error('[Schedule Templates] Delete error:', err);
    res.status(500).json({ success: false, error: 'Ошибка удаления шаблона' });
  }
});

// POST /api/v1/schedules (Single shift, Batch, or Replace month/location)
schedulesRouter.post('/', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { batch, replaceMonth, replaceLocation, date, location, employeeId, employeeName, shiftType, note } = req.body;
    let schedules = await getStoredSchedules();

    if (Array.isArray(batch)) {
      if (replaceMonth) {
        // Remove shifts in that month and optionally location
        schedules = schedules.filter(s => {
          const matchMonth = s.date.startsWith(replaceMonth);
          const matchLoc = replaceLocation ? s.location === replaceLocation : true;
          return !(matchMonth && matchLoc);
        });
      } else {
        // Remove collision shifts
        for (const item of batch) {
          schedules = schedules.filter(s => !(s.date === item.date && s.location === item.location && s.employeeId === item.employeeId));
        }
      }

      for (const item of batch) {
        // Enforce rule: never allow an employee to have 2 shifts on the same date at different PVZs
        const conflict = schedules.find(
          s => s.employeeId === item.employeeId && s.date === item.date && s.location !== item.location
        );
        if (!conflict) {
          schedules.push({
            ...item,
            id: item.id || `sch-${uuidv4()}`,
            createdAt: item.createdAt || new Date().toISOString(),
          });
        }
      }
      await saveStoredSchedules(schedules);
      res.json({ success: true, schedules });
      return;
    }

    if (!date || !location || !employeeId) {
      res.status(400).json({ success: false, error: 'Укажите дату, пункт и сотрудника' });
      return;
    }

    // Enforce rule: an employee cannot be added to another PVZ if they already have a shift on this date
    const conflictShift = schedules.find(
      s => s.employeeId === employeeId && s.date === date && s.location !== location
    );
    if (conflictShift) {
      res.status(400).json({
        success: false,
        error: `Сотрудник ${employeeName || 'Сотрудник'} уже назначен на смену в ПВЗ "${conflictShift.location}" на ${date}. Один сотрудник не может работать в двух ПВЗ одновременно.`,
      });
      return;
    }

    // Remove existing for this date & location
    schedules = schedules.filter(s => !(s.date === date && s.location === location && s.employeeId === employeeId));

    const newShift: PlannedShift = {
      id: `sch-${uuidv4()}`,
      date,
      location,
      employeeId,
      employeeName: employeeName || 'Сотрудник',
      shiftType: shiftType || 'standard',
      note: note ? String(note).trim() : '',
      createdAt: new Date().toISOString(),
    };

    schedules.push(newShift);
    await saveStoredSchedules(schedules);

    res.json({ success: true, schedules, item: newShift });
  } catch (err) {
    console.error('[Schedules] Post error:', err);
    res.status(500).json({ success: false, error: 'Ошибка сохранения плановой смены' });
  }
});

// POST /api/v1/schedules/slot (Atomic replace shifts for a single date & location)
schedulesRouter.post('/slot', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { date, location, shifts } = req.body;
    if (!date || !location) {
      res.status(400).json({ success: false, error: 'Укажите дату и пункт' });
      return;
    }

    const shiftList = Array.isArray(shifts) ? shifts : [];
    let schedules = await getStoredSchedules();

    // Check for conflicts: none of the employees in shiftList should have a shift at a different PVZ on this date
    for (const sh of shiftList) {
      if (!sh.employeeId) continue;
      const conflict = schedules.find(
        s => s.employeeId === sh.employeeId && s.date === date && s.location !== location
      );
      if (conflict) {
        res.status(400).json({
          success: false,
          error: `Сотрудник ${sh.employeeName || 'Сотрудник'} уже назначен на смену в ПВЗ "${conflict.location}" на ${date}. Один сотрудник не может работать в двух ПВЗ одновременно.`,
        });
        return;
      }
    }

    // Filter out all existing shifts for this date and location
    schedules = schedules.filter(s => !(s.date === date && s.location === location));

    // Append new shifts
    for (const sh of shiftList) {
      if (!sh.employeeId) continue;
      schedules.push({
        id: sh.id || `sch-${uuidv4()}`,
        date,
        location,
        employeeId: sh.employeeId,
        employeeName: sh.employeeName || 'Сотрудник',
        shiftType: sh.shiftType || 'standard',
        note: sh.note ? String(sh.note).trim() : '',
        createdAt: new Date().toISOString(),
      });
    }

    await saveStoredSchedules(schedules);
    res.json({ success: true, schedules });
  } catch (err) {
    console.error('[Schedules] Slot save error:', err);
    res.status(500).json({ success: false, error: 'Ошибка сохранения смен слота' });
  }
});

// POST /api/v1/schedules/publish (Publish to staff & send notifications)
schedulesRouter.post('/publish', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { month, location, count } = req.body;
    const publishedAt = new Date().toISOString();

    // Create a staff notification broadcast
    try {
      const notifRes = await db.query('SELECT value FROM settings WHERE key = $1', ['staff_notifications']);
      let notifications: any[] = [];
      if (notifRes.rows.length > 0 && notifRes.rows[0].value) {
        notifications = JSON.parse(notifRes.rows[0].value);
      }

      const newNotif = {
        id: `notif-${uuidv4()}`,
        toEmployeeId: 'all',
        title: `📅 Опубликован график смен ${month ? `на ${month}` : ''}`,
        text: `Руководитель утвердил и разослал график смен${location ? ` для пункта ${location}` : ''}. Проверьте свои запланированные смены в календаре!`,
        type: 'status_update',
        timestamp: publishedAt,
        read: false,
      };

      notifications.unshift(newNotif);
      if (notifications.length > 200) notifications = notifications.slice(0, 200);

      await db.query(
        `INSERT INTO settings (key, value) VALUES ($1, $2)
         ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
        ['staff_notifications', JSON.stringify(notifications)]
      );
    } catch (ne) {
      console.warn('[Schedules] Notification broadcast warning:', ne);
    }

    res.json({ success: true, publishedAt, count });
  } catch (err) {
    console.error('[Schedules] Publish error:', err);
    res.status(500).json({ success: false, error: 'Ошибка публикации графика' });
  }
});

// DELETE /api/v1/schedules/:id
schedulesRouter.delete('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const scheduleId = req.params.id;
    let schedules = await getStoredSchedules();
    schedules = schedules.filter(s => s.id !== scheduleId);
    await saveStoredSchedules(schedules);
    res.json({ success: true, schedules });
  } catch (err) {
    console.error('[Schedules] Delete error:', err);
    res.status(500).json({ success: false, error: 'Ошибка удаления смены из графика' });
  }
});
