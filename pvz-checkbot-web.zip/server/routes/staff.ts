import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { db } from '../db/index';
import { requireAuth, requireManager } from '../middleware/auth';
import { logAudit } from '../services/audit';

export const staffRouter = Router();

// GET /api/v1/staff
staffRouter.get('/', async (req: Request, res: Response): Promise<void> => {
  try {
    const isManager = req.user?.role === 'manager';

    const usersQuery = isManager
      ? "SELECT id, login, password_plain, name, role, status, is_part_time, is_senior, telegram_username, created_at, updated_at FROM users WHERE role = 'employee' ORDER BY name ASC"
      : "SELECT id, name, role, status, is_part_time, is_senior, telegram_username FROM users WHERE role = 'employee' AND status = 'active' ORDER BY name ASC";

    const usersRes = await db.query(usersQuery);

    // Fetch locations for these users
    const userLocsRes = await db.query<{ user_id: string; code: string }>(
      `SELECT ul.user_id, l.code
       FROM user_locations ul
       JOIN locations l ON l.id = ul.location_id`
    );

    const locMap = new Map<string, string[]>();
    for (const row of userLocsRes.rows) {
      if (!locMap.has(row.user_id)) {
        locMap.set(row.user_id, []);
      }
      locMap.get(row.user_id)!.push(row.code);
    }

    const staffList = usersRes.rows.map(u => ({
      id: u.id,
      name: u.name,
      login: isManager ? u.login : undefined,
      password: isManager ? (u.password_plain || undefined) : undefined,
      role: u.role,
      status: u.status,
      isPartTime: Boolean(u.is_part_time),
      isSenior: Boolean(u.is_senior),
      hasAccess: u.status === 'active',
      telegramUsername: u.telegram_username,
      locations: locMap.get(u.id) || [],
      registeredAt: u.created_at,
    }));

    res.json({ success: true, staff: staffList });
  } catch (err) {
    console.error('[Staff] Get staff error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка получения сотрудников' } });
  }
});

const staffCreateSchema = z.object({
  name: z.string().min(1, 'Имя обязательно'),
  login: z.string().min(1, 'Логин обязателен'),
  password: z.string().min(1, 'Пароль обязателен'),
  locations: z.array(z.string()).min(1, 'Необходимо выбрать хотя бы одно место работы'),
  isPartTime: z.boolean().default(false),
  isSenior: z.boolean().default(false),
  telegramUsername: z.string().optional(),
});

// POST /api/v1/staff (Manager only)
staffRouter.post('/', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const parse = staffCreateSchema.safeParse(req.body);
    if (!parse.success) {
      res.status(400).json({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: parse.error.issues?.[0]?.message || 'Неверные данные' },
      });
      return;
    }

    const { name, login, password, locations, isPartTime, isSenior, telegramUsername } = parse.data;
    const cleanLogin = login.trim();

    // Validate location codes
    if (!locations || locations.length === 0) {
      res.status(400).json({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: 'Необходимо указать хотя бы одну локацию' },
      });
      return;
    }

    // Check employee count limit (max 150)
    const countRes = await db.query<{ count: string | number }>(
      "SELECT COUNT(*) as count FROM users WHERE role = 'employee' AND status != 'deleted'"
    );
    const currentCount = Number(countRes.rows[0]?.count || 0);
    if (currentCount >= 150) {
      res.status(400).json({
        success: false,
        error: { code: 'LIMIT_EXCEEDED', message: 'Достигнут лимит: максимально допустимо 150 сотрудников.' },
      });
      return;
    }

    // Check if login already exists
    const existing = await db.query('SELECT id FROM users WHERE LOWER(login) = LOWER($1)', [cleanLogin]);
    if (existing.rows.length > 0) {
      res.status(409).json({
        success: false,
        error: { code: 'LOGIN_EXISTS', message: 'Сотрудник с таким логином уже зарегистрирован' },
      });
      return;
    }

    const userId = `emp-${uuidv4()}`;
    const salt = bcrypt.genSaltSync(10);
    const cleanPassword = password.trim();
    const passwordHash = bcrypt.hashSync(cleanPassword, salt);

    await db.transaction(async client => {
      // 1. Insert user
      await client.query(
        `INSERT INTO users (id, login, password_hash, password_plain, name, role, status, is_part_time, is_senior, telegram_username)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [userId, cleanLogin, passwordHash, cleanPassword, name.trim(), 'employee', 'active', isPartTime, isSenior, telegramUsername?.trim() || null]
      );

      // 2. Insert user_locations
      for (const locCode of locations) {
        let locRes = await client.query<{ id: string }>('SELECT id FROM locations WHERE code = $1', [locCode]);
        let locId = locRes.rows[0]?.id;
        if (!locId) {
          locId = `loc-${uuidv4()}`;
          await client.query('INSERT INTO locations (id, code, name) VALUES ($1, $2, $3)', [locId, locCode, `ПВЗ ${locCode}`]);
        }
        await client.query('INSERT INTO user_locations (user_id, location_id) VALUES ($1, $2)', [userId, locId]);
      }

      // 3. Welcome notification
      await client.query(
        `INSERT INTO notifications (id, user_id, title, text, type, source)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          `notif-${uuidv4()}`,
          userId,
          'Добро пожаловать в команду!',
          `Ваша учетная запись активирована. Логин: "${cleanLogin}". Доступные локации: ${locations.join(', ')}.`,
          'system',
          'manager',
        ]
      );
    });

    await logAudit(req, req.user!.id, 'CREATE_STAFF', 'user', userId, { name, login: cleanLogin, locations, isSenior });

    res.status(201).json({
      success: true,
      staff: {
        id: userId,
        name: name.trim(),
        login: cleanLogin,
        password: cleanPassword,
        role: 'employee',
        status: 'active',
        isPartTime,
        isSenior,
        hasAccess: true,
        locations,
      },
    });
  } catch (err) {
    console.error('[Staff] Create staff error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка при создании сотрудника' } });
  }
});

const staffUpdateSchema = z.object({
  name: z.string().optional(),
  login: z.string().optional(),
  password: z.string().optional(),
  locations: z.array(z.string()).optional(),
  isPartTime: z.boolean().optional(),
  isSenior: z.boolean().optional(),
  status: z.enum(['active', 'blocked', 'archived', 'deactivated']).optional(),
  telegramUsername: z.string().optional(),
});

// PATCH /api/v1/staff/:id (Manager only)
staffRouter.patch('/:id', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const parse = staffUpdateSchema.safeParse(req.body);
    if (!parse.success) {
      res.status(400).json({
        success: false,
        error: { code: 'VALIDATION_ERROR', message: parse.error.issues?.[0]?.message || 'Неверные данные' },
      });
      return;
    }

    const { name, login, password, locations, isPartTime, isSenior, status, telegramUsername } = parse.data;

    if (locations) {
      if (locations.length === 0) {
        res.status(400).json({
          success: false,
          error: { code: 'VALIDATION_ERROR', message: 'Необходимо указать хотя бы одну локацию' },
        });
        return;
      }
    }

    // Verify user exists
    const userRes = await db.query<{ id: string }>('SELECT id FROM users WHERE id = $1', [id]);
    if (userRes.rows.length === 0) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Сотрудник не найден' } });
      return;
    }

    // Check login conflict if changing login
    if (login) {
      const conflictRes = await db.query('SELECT id FROM users WHERE LOWER(login) = LOWER($1) AND id != $2', [
        login.trim(),
        id,
      ]);
      if (conflictRes.rows.length > 0) {
        res.status(409).json({ success: false, error: { code: 'LOGIN_EXISTS', message: 'Такой логин уже занят' } });
        return;
      }
    }

    await db.transaction(async client => {
      // Build dynamic update for user
      const updates: string[] = ['updated_at = CURRENT_TIMESTAMP'];
      const params: any[] = [];

      if (name) {
        params.push(name.trim());
        updates.push(`name = $${params.length}`);
      }
      if (login) {
        params.push(login.trim());
        updates.push(`login = $${params.length}`);
      }
      if (password && password.trim().length > 0) {
        const cleanPassword = password.trim();
        const salt = bcrypt.genSaltSync(10);
        const hash = bcrypt.hashSync(cleanPassword, salt);
        params.push(hash);
        updates.push(`password_hash = $${params.length}`);
        params.push(cleanPassword);
        updates.push(`password_plain = $${params.length}`);
      }
      if (isPartTime !== undefined) {
        params.push(isPartTime);
        updates.push(`is_part_time = $${params.length}`);
      }
      if (isSenior !== undefined) {
        params.push(isSenior);
        updates.push(`is_senior = $${params.length}`);
      }
      if (status) {
        const canonicalStatus = status === 'deactivated' ? 'blocked' : status;
        params.push(canonicalStatus);
        updates.push(`status = $${params.length}`);

        if (canonicalStatus === 'blocked' || canonicalStatus === 'archived') {
          // Immediately revoke all active sessions
          await client.query('DELETE FROM sessions WHERE user_id = $1', [id]);
        }
      }
      if (telegramUsername !== undefined) {
        params.push(telegramUsername.trim() || null);
        updates.push(`telegram_username = $${params.length}`);
      }

      params.push(id);
      await client.query(`UPDATE users SET ${updates.join(', ')} WHERE id = $${params.length}`, params);

      // Update locations if specified
      if (locations) {
        await client.query('DELETE FROM user_locations WHERE user_id = $1', [id]);
        for (const locCode of locations) {
          let locRes = await client.query<{ id: string }>('SELECT id FROM locations WHERE code = $1', [locCode]);
          let locId = locRes.rows[0]?.id;
          if (!locId) {
            locId = `loc-${uuidv4()}`;
            await client.query('INSERT INTO locations (id, code, name) VALUES ($1, $2, $3)', [locId, locCode, `ПВЗ ${locCode}`]);
          }
          await client.query('INSERT INTO user_locations (user_id, location_id) VALUES ($1, $2)', [id, locId]);
        }
      }
    });

    await logAudit(req, req.user!.id, 'UPDATE_STAFF', 'user', id, { name, login, status, locations });

    res.json({ success: true });
  } catch (err) {
    console.error('[Staff] Update staff error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка при обновлении сотрудника' } });
  }
});

// DELETE /api/v1/staff/:id (Requirements 27 & 28: Soft delete by default, Hard delete requires explicit confirmation)
staffRouter.delete('/:id', requireManager, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const isHardDelete = req.query.hard === 'true';

    const userRes = await db.query<{ id: string; name: string }>('SELECT id, name FROM users WHERE id = $1', [id]);
    if (userRes.rows.length === 0) {
      res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Сотрудник не найден' } });
      return;
    }

    if (isHardDelete) {
      // Requirement 28: Backend confirmation check for hard delete
      const { confirmation } = req.body || {};
      if (confirmation !== 'DELETE USER') {
        res.status(400).json({
          success: false,
          error: {
            code: 'CONFIRMATION_REQUIRED',
            message: 'Для безвозвратного удаления требуется явное подтверждение: confirmation="DELETE USER"',
          },
        });
        return;
      }

      await db.transaction(async client => {
        await client.query('DELETE FROM sessions WHERE user_id = $1', [id]);
        await client.query('DELETE FROM user_locations WHERE user_id = $1', [id]);
        await client.query('DELETE FROM messages WHERE from_user_id = $1', [id]);
        await client.query('DELETE FROM notifications WHERE user_id = $1', [id]);
        await client.query('DELETE FROM sales WHERE user_id = $1', [id]);
        await client.query('DELETE FROM checkins WHERE user_id = $1', [id]);
        await client.query('DELETE FROM users WHERE id = $1', [id]);
      });
      await logAudit(req, req.user!.id, 'HARD_DELETE_STAFF', 'user', id, { name: userRes.rows[0].name });
    } else {
      // Soft delete: status = 'archived'
      await db.query("UPDATE users SET status = 'archived', updated_at = CURRENT_TIMESTAMP WHERE id = $1", [id]);
      await db.query('DELETE FROM sessions WHERE user_id = $1', [id]);
      await logAudit(req, req.user!.id, 'ARCHIVE_STAFF', 'user', id, { name: userRes.rows[0].name });
    }

    res.json({ success: true });
  } catch (err) {
    console.error('[Staff] Delete staff error:', err);
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Ошибка при удалении сотрудника' } });
  }
});
