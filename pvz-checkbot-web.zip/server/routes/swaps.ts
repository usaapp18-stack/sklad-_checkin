import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db/index';
import { requireAuth } from '../middleware/auth';
import { ShiftSwapRequest } from '../../src/types';
import { telegramService } from '../services/telegram';

export const swapsRouter = Router();

function formatDateDDMMYYYY(dateStr?: string | null): string {
  if (!dateStr) return '';
  const clean = dateStr.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length === 3) {
    return `${parts[2]}-${parts[1]}-${parts[0]}`;
  }
  return dateStr;
}

/**
 * Calculates the start date of the 3rd preceding month from the current Moscow date.
 * Example: If current month is 2026-10, 3 previous months are July (2026-07), August (2026-08), September (2026-09).
 * The cutoff date is 2026-07-01. Anything earlier than this is archived/pruned.
 */
export function getThreeMonthsCutoffDate(): string {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Moscow',
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(now);

  const year = parseInt(parts.find(p => p.type === 'year')?.value || `${now.getFullYear()}`, 10);
  const month = parseInt(parts.find(p => p.type === 'month')?.value || `${now.getMonth() + 1}`, 10);

  let targetYear = year;
  let targetMonth = month - 3;
  if (targetMonth < 1) {
    targetMonth += 12;
    targetYear -= 1;
  }
  const padMonth = String(targetMonth).padStart(2, '0');
  return `${targetYear}-${padMonth}-01`;
}

// Convert DB row to ShiftSwapRequest
function mapRowToSwap(row: any): ShiftSwapRequest {
  return {
    id: row.id,
    date: row.date,
    shiftType: row.shift_type || 'standard',
    location: row.location,
    requesterId: row.requester_id,
    requesterName: row.requester_name,
    candidateId: row.candidate_id || undefined,
    candidateName: row.candidate_name || undefined,
    reason: row.reason || '',
    status: row.status || 'open',
    resolvedAt: row.resolved_at ? new Date(row.resolved_at).toISOString() : undefined,
    createdAt: row.created_at ? new Date(row.created_at).toISOString() : new Date().toISOString(),
  };
}

// Helper to get stored swaps from shift_swaps database table with 3-month retention
export async function getStoredSwaps(): Promise<ShiftSwapRequest[]> {
  const cutoffDate = getThreeMonthsCutoffDate();

  try {
    // 1. One-time migration: only if shift_swaps table is empty, seed from legacy settings table
    const countCheck = await db.query('SELECT COUNT(*) as count FROM shift_swaps');
    const rowCount = Number(countCheck.rows[0]?.count || 0);

    if (rowCount === 0) {
      const legacyCheck = await db.query('SELECT value FROM settings WHERE key = $1', ['shift_swaps']);
      if (legacyCheck.rows.length > 0 && legacyCheck.rows[0].value) {
        try {
          const legacyList: ShiftSwapRequest[] = JSON.parse(legacyCheck.rows[0].value);
          if (Array.isArray(legacyList) && legacyList.length > 0) {
            for (const s of legacyList) {
              if (s && s.id && s.date && s.date >= cutoffDate) {
                await db.query(
                  `INSERT INTO shift_swaps (id, date, shift_type, location, requester_id, requester_name, candidate_id, candidate_name, reason, status, resolved_at, created_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
                   ON CONFLICT (id) DO NOTHING`,
                  [
                    s.id,
                    s.date,
                    s.shiftType || 'standard',
                    s.location,
                    s.requesterId,
                    s.requesterName,
                    s.candidateId || null,
                    s.candidateName || null,
                    s.reason || null,
                    s.status || 'open',
                    s.resolvedAt || null,
                    s.createdAt || new Date().toISOString(),
                  ]
                );
              }
            }
          }
        } catch (mErr) {
          console.warn('[Swaps Migration] Legacy parse warning:', mErr);
        }
      }
    }

    // 2. Prune records older than 3 previous months from the archive
    try {
      await db.query('DELETE FROM shift_swaps WHERE date < $1', [cutoffDate]);
    } catch (pruneErr) {
      console.warn('[Swaps Retention] Prune warning:', pruneErr);
    }

    // 3. Query all swaps for current month + 3 previous months
    const res = await db.query(
      `SELECT id, date, shift_type, location, requester_id, requester_name, 
              candidate_id, candidate_name, reason, status, resolved_at, created_at
       FROM shift_swaps
       WHERE date >= $1
       ORDER BY date DESC, created_at DESC`,
      [cutoffDate]
    );

    const swaps = res.rows.map(mapRowToSwap);

    // Sync mirrored cache to settings table for backup
    await db.query(
      `INSERT INTO settings (key, value) VALUES ($1, $2)
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP`,
      ['shift_swaps', JSON.stringify(swaps)]
    );

    return swaps;
  } catch (e) {
    console.error('[Swaps] Read error from database, attempting fallback:', e);
    // Fallback read from settings table if database table query fails
    try {
      const fallback = await db.query('SELECT value FROM settings WHERE key = $1', ['shift_swaps']);
      if (fallback.rows.length > 0 && fallback.rows[0].value) {
        const parsed: ShiftSwapRequest[] = JSON.parse(fallback.rows[0].value);
        return parsed.filter(s => s && s.date && s.date >= cutoffDate);
      }
    } catch {}
  }
  return [];
}

// Helper to save a swap into the persistent archive
export async function saveSingleSwap(swap: ShiftSwapRequest): Promise<void> {
  try {
    await db.query(
      `INSERT INTO shift_swaps (id, date, shift_type, location, requester_id, requester_name, candidate_id, candidate_name, reason, status, resolved_at, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       ON CONFLICT (id) DO UPDATE SET
         date = EXCLUDED.date,
         shift_type = EXCLUDED.shift_type,
         location = EXCLUDED.location,
         requester_id = EXCLUDED.requester_id,
         requester_name = EXCLUDED.requester_name,
         candidate_id = EXCLUDED.candidate_id,
         candidate_name = EXCLUDED.candidate_name,
         reason = EXCLUDED.reason,
         status = EXCLUDED.status,
         resolved_at = EXCLUDED.resolved_at,
         updated_at = CURRENT_TIMESTAMP`,
      [
        swap.id,
        swap.date,
        swap.shiftType || 'standard',
        swap.location,
        swap.requesterId,
        swap.requesterName,
        swap.candidateId || null,
        swap.candidateName || null,
        swap.reason || null,
        swap.status || 'open',
        swap.resolvedAt || null,
        swap.createdAt || new Date().toISOString(),
      ]
    );
  } catch (err) {
    console.error('[Swaps DB Save] Error:', err);
  }
}

// Helper to delete a single swap from archive
export async function deleteSingleSwap(swapId: string): Promise<void> {
  try {
    await db.query('DELETE FROM shift_swaps WHERE id = $1', [swapId]);
  } catch (err) {
    console.error('[Swaps DB Delete] Error:', err);
  }
}

// GET /api/v1/swaps
swapsRouter.get('/', requireAuth, async (_req: Request, res: Response): Promise<void> => {
  try {
    const swaps = await getStoredSwaps();
    res.json({ success: true, swaps });
  } catch (err) {
    console.error('[Swaps] Get error:', err);
    res.status(500).json({ success: false, error: 'Ошибка получения биржи смен' });
  }
});

// POST /api/v1/swaps (Create or Claim)
swapsRouter.post('/', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { action, swapId, date, shiftType, location, reason } = req.body;
    const user = req.user!;
    const swaps = await getStoredSwaps();

    if (action === 'claim' && swapId) {
      // Employee claims a shift
      const idx = swaps.findIndex(s => s.id === swapId);
      if (idx === -1) {
        res.status(404).json({ success: false, error: 'Заявка на смену не найдена' });
        return;
      }
      if (swaps[idx].status !== 'open') {
        res.status(400).json({ success: false, error: 'Эта смена уже забрана другим сотрудником' });
        return;
      }

      swaps[idx].status = 'claimed';
      swaps[idx].candidateId = user.id;
      swaps[idx].candidateName = user.name;
      
      await saveSingleSwap(swaps[idx]);
      const updatedList = await getStoredSwaps();

      const formattedDate = formatDateDDMMYYYY(swaps[idx].date);

      // 1. Notify initiator in-app
      try {
        await db.query(
          `INSERT INTO notifications (id, user_id, title, text, type, source)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [
            `notif-${uuidv4()}`,
            swaps[idx].requesterId,
            '🙋 Отклик на вашу смену!',
            `${user.name} откликнулся на вашу смену ${formattedDate} (${swaps[idx].location}). Зайдите на Биржу смен, чтобы подтвердить договоренность.`,
            'system',
            'system',
          ]
        );
      } catch (nErr) {
        console.error('[Swaps] In-app notification error:', nErr);
      }

      // 2. Telegram notification
      telegramService.sendMessage(
        `🙋 Отклик на Бирже смен!\n\n${user.name} откликнулся на смену ${formattedDate} (${swaps[idx].location}).`
      ).catch(err => console.warn('[Swaps] Telegram notify error:', err));

      res.json({ success: true, swap: swaps[idx], swaps: updatedList });
      return;
    }

    // Otherwise create a new swap request
    if (!date || !location) {
      res.status(400).json({ success: false, error: 'Укажите дату и пункт смены' });
      return;
    }

    // Check if employee already has an active swap on this date
    const existingActive = swaps.find(
      s => s.requesterId === user.id && s.date === date && s.status !== 'rejected' && s.status !== 'cancelled'
    );
    if (existingActive) {
      const formattedDate = formatDateDDMMYYYY(date);
      res.status(400).json({
        success: false,
        error: `У вас уже есть активная заявка на бирже на дату ${formattedDate}. Можно выставлять не более одной смены на одну дату.`,
      });
      return;
    }

    const newSwap: ShiftSwapRequest = {
      id: `swp-${uuidv4()}`,
      date,
      shiftType: shiftType || 'standard',
      location,
      requesterId: user.id,
      requesterName: user.name,
      reason: reason ? String(reason).trim() : '',
      status: 'open',
      createdAt: new Date().toISOString(),
    };

    await saveSingleSwap(newSwap);
    const updatedList = await getStoredSwaps();

    const formattedDate = formatDateDDMMYYYY(date);

    // 1. In-app broadcast notification for all employees and manager
    try {
      await db.query(
        `INSERT INTO notifications (id, to_all, title, text, type, source)
         VALUES ($1, 1, $2, $3, $4, $5)`,
        [
          `notif-${uuidv4()}`,
          '🔄 Новая открытая смена на Бирже!',
          `${user.name} ищет замену на ${formattedDate} (пункт ${location}). Кто готов выйти — откройте Биржу смен!`,
          'system',
          'system',
        ]
      );
    } catch (nErr) {
      console.error('[Swaps] Broadcast notification error:', nErr);
    }

    // 2. Telegram Notification
    telegramService.sendMessage(
      `🔄 *Новая смена на Бирже смен!*\n\n${user.name} ищет замену на ${formattedDate} (${location}).`
    ).catch(err => console.warn('[Swaps] Telegram notify error:', err));

    res.json({ success: true, swap: newSwap, swaps: updatedList });
  } catch (err) {
    console.error('[Swaps] Post error:', err);
    res.status(500).json({ success: false, error: 'Ошибка обработки биржи смен' });
  }
});

// PATCH /api/v1/swaps/:id (Approve / Confirm / Reject / Release)
swapsRouter.patch('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const swapId = req.params.id;
    const { action } = req.body;
    const user = req.user!;
    const isManager = user.role === 'manager';

    const swaps = await getStoredSwaps();
    const idx = swaps.findIndex(s => s.id === swapId);

    if (idx === -1) {
      res.status(404).json({ success: false, error: 'Заявка не найдена' });
      return;
    }

    const swap = swaps[idx];
    const isInitiator = swap.requesterId === user.id;

    if (!isManager && !isInitiator) {
      res.status(403).json({ success: false, error: 'Только автор заявки или руководитель могут подтверждать замену' });
      return;
    }

    const formattedDate = formatDateDDMMYYYY(swap.date);

    if (action === 'approve' || action === 'confirm') {
      swap.status = 'approved';
      swap.resolvedAt = new Date().toISOString();

      // Notify candidate that replacement is confirmed
      if (swap.candidateId) {
        try {
          await db.query(
            `INSERT INTO notifications (id, user_id, title, text, type, source)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [
              `notif-${uuidv4()}`,
              swap.candidateId,
              '✅ Замена утверждена! (Договорились)',
              `Подмена на смену ${formattedDate} (${swap.location}) подтверждена. Смена закреплена за вами.`,
              'system',
              'system',
            ]
          );
        } catch (nErr) {
          console.error('[Swaps] Candidate notification error:', nErr);
        }

        telegramService.sendMessage(
          `✅ *Замена утверждена!*\n\nСмена на ${formattedDate} (${swap.location}) закреплена за сотрудником.`
        ).catch(err => console.warn('[Swaps] Telegram notify error:', err));
      }
    } else if (action === 'reject') {
      // Reopen shift for other candidates
      const previousCandidateId = swap.candidateId;
      swap.candidateId = undefined;
      swap.candidateName = undefined;
      swap.status = 'open';

      if (previousCandidateId) {
        telegramService.sendMessage(
          `Замена на ${formattedDate} (${swap.location}) отклонена. Смена снова открыта на бирже.`
        ).catch(err => console.warn('[Swaps] Telegram notify error:', err));
      }
    }

    await saveSingleSwap(swap);
    const updatedList = await getStoredSwaps();
    res.json({ success: true, swap, swaps: updatedList });
  } catch (err) {
    console.error('[Swaps] Patch error:', err);
    res.status(500).json({ success: false, error: 'Ошибка обновления заявки' });
  }
});

// PUT /api/v1/swaps/:id (Update swap request details by manager or requester)
swapsRouter.put('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const swapId = req.params.id;
    const { date, shiftType, location, reason, status, candidateId, candidateName, requesterId, requesterName } = req.body;
    const user = req.user!;
    const isManager = user.role === 'manager';

    const swaps = await getStoredSwaps();
    const idx = swaps.findIndex(s => s.id === swapId);

    if (idx === -1) {
      res.status(404).json({ success: false, error: 'Заявка не найдена' });
      return;
    }

    if (!isManager && swaps[idx].requesterId !== user.id) {
      res.status(403).json({ success: false, error: 'Редактировать заявку может только руководитель или её создатель' });
      return;
    }

    if (date !== undefined) swaps[idx].date = date;
    if (shiftType !== undefined) swaps[idx].shiftType = shiftType;
    if (location !== undefined) swaps[idx].location = location;
    if (reason !== undefined) swaps[idx].reason = String(reason).trim();
    if (status !== undefined) swaps[idx].status = status;
    if (candidateId !== undefined) swaps[idx].candidateId = candidateId || undefined;
    if (candidateName !== undefined) swaps[idx].candidateName = candidateName || undefined;
    if (requesterId !== undefined) swaps[idx].requesterId = requesterId;
    if (requesterName !== undefined) swaps[idx].requesterName = requesterName;

    if (req.body.clearCandidate || status === 'open') {
      swaps[idx].candidateId = undefined;
      swaps[idx].candidateName = undefined;
    }

    await saveSingleSwap(swaps[idx]);
    const updatedList = await getStoredSwaps();
    res.json({ success: true, swap: swaps[idx], swaps: updatedList });
  } catch (err) {
    console.error('[Swaps] Put error:', err);
    res.status(500).json({ success: false, error: 'Ошибка редактирования заявки' });
  }
});

// DELETE /api/v1/swaps/:id (Cancel or delete)
swapsRouter.delete('/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const swapId = req.params.id;
    const user = req.user!;
    const isManager = user.role === 'manager';

    const swaps = await getStoredSwaps();
    const target = swaps.find(s => s.id === swapId);

    if (target && !isManager && target.requesterId !== user.id) {
      res.status(403).json({ success: false, error: 'Вы можете отменять только свои заявки' });
      return;
    }

    await deleteSingleSwap(swapId);
    const updatedList = await getStoredSwaps();
    res.json({ success: true, swaps: updatedList });
  } catch (err) {
    console.error('[Swaps] Delete error:', err);
    res.status(500).json({ success: false, error: 'Ошибка отмены заявки' });
  }
});
