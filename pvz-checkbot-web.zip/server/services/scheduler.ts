import { db } from '../db/index';
import { telegramService } from './telegram';
import { v4 as uuidv4 } from 'uuid';

interface ScheduledJobStatus {
  name: string;
  time: string;
  lastRun?: string;
  status: 'idle' | 'running' | 'completed' | 'error';
}

export class SchedulerService {
  private timer: NodeJS.Timeout | null = null;
  private cleanupTimer: NodeJS.Timeout | null = null;
  private isRunning = false;
  private startTime: number = Date.now();
  private lastHeartbeat: string = new Date().toISOString();
  // Requirement 35: Idempotency set to prevent duplicate execution upon restarts
  private executedJobs = new Set<string>();

  private jobs: Record<string, ScheduledJobStatus> = {
    '20:00': { name: 'Напоминание о Check-in', time: '20:00', status: 'idle' },
    '20:50': { name: 'Напоминание о вводе выручки', time: '20:50', status: 'idle' },
    '21:10': { name: 'Срочное предупреждение (выручка)', time: '21:10', status: 'idle' },
    '21:15': { name: 'Ежедневный сводный отчет в Telegram', time: '21:15', status: 'idle' },
  };

  start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.startTime = Date.now();
    this.lastHeartbeat = new Date().toISOString();
    console.log('[Scheduler] Authoritative Node.js scheduler started (Timezone: Europe/Moscow).');

    // Main tick every 30 seconds
    this.timer = setInterval(() => {
      this.lastHeartbeat = new Date().toISOString();
      this.tick();
    }, 30 * 1000);

    // Requirement 50: Periodic expired sessions cleanup every 60 minutes
    this.cleanupTimer = setInterval(() => {
      this.cleanupExpiredSessions();
    }, 60 * 60 * 1000);

    // Run initial cleanup once on startup
    this.cleanupExpiredSessions();

    this.recordBotLog('start', 'Система', 'success', 'Планировщик запущен успешно.');
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = null;
    }
    this.isRunning = false;
    console.log('[Scheduler] Node.js scheduler stopped.');
  }

  async restart(initiatedBy = 'Руководитель'): Promise<void> {
    this.stop();
    this.start();
    await this.recordBotLog(
      'restart',
      initiatedBy,
      'success',
      `Планировщик и Telegram-сервис перезапущены успешно (pid=${process.pid}).`
    );
  }

  // Requirement 34: Clear breakdown of Scheduler status vs Telegram configuration
  getStatus() {
    return {
      scheduler: {
        running: this.isRunning,
        pid: process.pid,
        uptimeSeconds: Math.floor((Date.now() - this.startTime) / 1000),
        timezone: 'Europe/Moscow',
        lastHeartbeat: this.lastHeartbeat,
        jobs: Object.values(this.jobs),
      },
      telegram: {
        configured: Boolean(process.env.TELEGRAM_BOT_TOKEN),
        managerId: telegramService.getManagerChatId(),
      },
    };
  }

  // Requirement 50: Expired sessions and 3-month archive retention cleanup
  private async cleanupExpiredSessions(): Promise<void> {
    try {
      await db.query('DELETE FROM sessions WHERE expires_at < CURRENT_TIMESTAMP');
      
      // Prune shift swaps older than 3 previous months
      const now = new Date();
      const parts = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Europe/Moscow',
        year: 'numeric',
        month: 'numeric',
      }).formatToParts(now);

      const year = parseInt(parts.find(p => p.type === 'year')?.value || `${now.getFullYear()}`, 10);
      const month = parseInt(parts.find(p => p.type === 'month')?.value || `${now.getMonth() + 1}`, 10);

      let targetYear = year;
      let targetMonth = month - 3;
      if (targetMonth < 1) {
        targetMonth += 12;
        targetYear -= 1;
      }
      const cutoffDate = `${targetYear}-${String(targetMonth).padStart(2, '0')}-01`;
      await db.query('DELETE FROM shift_swaps WHERE date < $1', [cutoffDate]);
    } catch (err) {
      console.warn('[Scheduler] Periodic retention cleanup warning:', err);
    }
  }

  private async recordBotLog(action: string, initiatedBy: string, status: string, details: string): Promise<void> {
    try {
      const id = `rst-${uuidv4()}`;
      await db.query(
        'INSERT INTO bot_logs (id, action, initiated_by, status, details) VALUES ($1, $2, $3, $4, $5)',
        [id, action, initiatedBy, status, details]
      );
    } catch (err) {
      console.error('[Scheduler] Failed to write bot log:', err);
    }
  }

  private getMoscowTime(): { timeStr: string; dateStr: string; hour: number; minute: number } {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('ru-RU', {
      timeZone: 'Europe/Moscow',
      hour: '2-digit',
      minute: '2-digit',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour12: false,
    });
    const parts = formatter.formatToParts(now);
    const hour = parseInt(parts.find(p => p.type === 'hour')?.value || '0', 10);
    const minute = parseInt(parts.find(p => p.type === 'minute')?.value || '0', 10);
    const day = parts.find(p => p.type === 'day')?.value || '01';
    const month = parts.find(p => p.type === 'month')?.value || '01';
    const year = parts.find(p => p.type === 'year')?.value || '2026';

    const hourStr = String(hour).padStart(2, '0');
    const minuteStr = String(minute).padStart(2, '0');

    return {
      timeStr: `${hourStr}:${minuteStr}`,
      dateStr: `${year}-${month}-${day}`,
      hour,
      minute,
    };
  }

  private async tick(): Promise<void> {
    const { timeStr, dateStr } = this.getMoscowTime();

    // Requirement 35: Idempotency keys prevent double execution
    if (timeStr === '20:00') {
      const key = `checkin-reminder-${dateStr}`;
      if (!this.executedJobs.has(key)) {
        this.executedJobs.add(key);
        await this.runCheckInReminder(dateStr);
      }
    } else if (timeStr === '20:50') {
      const key = `sales-reminder-normal-${dateStr}`;
      if (!this.executedJobs.has(key)) {
        this.executedJobs.add(key);
        await this.runSalesReminder(dateStr, false);
      }
    } else if (timeStr === '21:10') {
      const key = `sales-reminder-urgent-${dateStr}`;
      if (!this.executedJobs.has(key)) {
        this.executedJobs.add(key);
        await this.runSalesReminder(dateStr, true);
      }
    } else if (timeStr === '21:15') {
      const key = `daily-report-${dateStr}`;
      if (!this.executedJobs.has(key)) {
        this.executedJobs.add(key);
        await this.runDailyReport(dateStr);
      }
    }

    // Call custom scheduled notifications
    await this.processCustomScheduledNotifications(timeStr, dateStr);
  }

  // 20:00 In-app Check-in Reminder (Requirement 31)
  private async runCheckInReminder(dateStr: string): Promise<void> {
    try {
      this.jobs['20:00'].status = 'running';
      const staffRes = await db.query<{ id: string; name: string }>(
        "SELECT id, name FROM users WHERE role = 'employee' AND status = 'active'"
      );
      const checkinsRes = await db.query<{ user_id: string }>(
        'SELECT user_id FROM checkins WHERE date = $1',
        [dateStr]
      );
      const checkedIds = new Set(checkinsRes.rows.map(c => c.user_id));
      const missingStaff = staffRes.rows.filter(s => !checkedIds.has(s.id));

      if (missingStaff.length > 0) {
        for (const emp of missingStaff) {
          await db.query(
            `INSERT INTO notifications (id, user_id, title, text, type, source)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [
              `notif-${uuidv4()}`,
              emp.id,
              'Напоминание о смене',
              'Пожалуйста, не забудьте отметиться (Check-in) в системе.',
              'system',
              'scheduler',
            ]
          );
        }
      }
      this.jobs['20:00'].lastRun = new Date().toISOString();
      this.jobs['20:00'].status = 'completed';
    } catch (err) {
      console.error('[Scheduler] Error in 20:00 job:', err);
      this.jobs['20:00'].status = 'error';
    }
  }

  // 20:50 and 21:10 Reminders (Requirement 31)
  private async runSalesReminder(dateStr: string, isUrgent: boolean): Promise<void> {
    const jobKey = isUrgent ? '21:10' : '20:50';
    try {
      this.jobs[jobKey].status = 'running';
      const pendingRes = await db.query<{ user_id: string; name: string }>(
        `SELECT c.user_id, u.name
         FROM checkins c
         JOIN users u ON u.id = c.user_id
         LEFT JOIN sales s ON s.checkin_id = c.id
         WHERE c.date = $1 AND s.id IS NULL AND u.status = 'active'`,
        [dateStr]
      );

      for (const row of pendingRes.rows) {
        const title = isUrgent ? '⚠️ СРОЧНО: Внесите выручку!' : '📊 Напоминание о выручке';
        const text = isUrgent
          ? 'До 21:15 необходимо закрыть смену и внести данные по фото, печати и ламинации!'
          : 'Смена подходит к концу. Пожалуйста, внесите данные по кассе в раздел «Выручка».';

        await db.query(
          `INSERT INTO notifications (id, user_id, title, text, type, source)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [`notif-${uuidv4()}`, row.user_id, title, text, 'system', 'scheduler']
        );
      }

      this.jobs[jobKey].lastRun = new Date().toISOString();
      this.jobs[jobKey].status = 'completed';
    } catch (err) {
      console.error(`[Scheduler] Error in ${jobKey} job:`, err);
      this.jobs[jobKey].status = 'error';
    }
  }

  // 21:15 Daily Sales Report (Requirement 30 & 35)
  private async runDailyReport(dateStr: string): Promise<void> {
    try {
      this.jobs['21:15'].status = 'running';
      console.log(`[Scheduler] 21:15 MSK reached. Generating and dispatching daily sales report for ${dateStr}...`);
      const res = await telegramService.sendDailySalesReport(dateStr);
      if (res.success) {
        await this.recordBotLog('daily_report', 'Планировщик', 'success', `Ежедневный отчет за ${dateStr} успешно отправлен в Telegram.`);
        this.jobs['21:15'].status = 'completed';
      } else {
        await this.recordBotLog('daily_report', 'Планировщик', 'error', `Ошибка отправки отчета: ${res.error}`);
        this.jobs['21:15'].status = 'error';
      }
      this.jobs['21:15'].lastRun = new Date().toISOString();
    } catch (err) {
      console.error('[Scheduler] Error in 21:15 daily report job:', err);
      this.jobs['21:15'].status = 'error';
    }
  }

  // Process custom manager-defined scheduled notifications and trigger system logs + Web Push notifications
  private async processCustomScheduledNotifications(timeStr: string, dateStr: string): Promise<void> {
    try {
      // Find active rules matching current timeOfDay
      const rules = await db.query<{
        id: string;
        title: string;
        text: string;
        schedule_type: string;
        time_of_day: string;
        target_role: string;
      }>(
        `SELECT id, title, text, schedule_type, time_of_day, target_role 
         FROM scheduled_notifications 
         WHERE time_of_day = $1 AND is_active = 1`,
        [timeStr]
      );

      for (const rule of rules.rows) {
        const idempotencyKey = `custom-notif-${rule.id}-${dateStr}`;
        if (this.executedJobs.has(idempotencyKey)) {
          continue;
        }
        this.executedJobs.add(idempotencyKey);

        console.log(`[Scheduler] Processing scheduled notification "${rule.title}" for ${timeStr} MSK.`);

        // Determine target users
        let usersQuery = "SELECT id FROM users WHERE role = 'employee' AND status = 'active'";
        let params: any[] = [];

        if (rule.target_role === 'standard') {
          usersQuery = "SELECT id FROM users WHERE role = 'employee' AND status = 'active' AND is_part_time = FALSE";
        } else if (rule.target_role === 'part_time') {
          usersQuery = "SELECT id FROM users WHERE role = 'employee' AND status = 'active' AND is_part_time = TRUE";
        }

        const employees = await db.query<{ id: string }>(usersQuery, params);

        for (const emp of employees.rows) {
          // 1. Insert into in-app notifications
          const notifId = `notif-${uuidv4()}`;
          await db.query(
            `INSERT INTO notifications (id, user_id, title, text, type, source)
             VALUES ($1, $2, $3, $4, 'system', 'scheduler')`,
            [notifId, emp.id, rule.title, rule.text]
          );

        }

        // 2. Deliver via Telegram to all staff matching targetRole who have Telegram username + manager:
        const targetLabel = rule.target_role === 'all' ? 'Все сотрудники' : rule.target_role === 'standard' ? 'Штатный персонал' : 'Подработчики';
        const telegramMessage = `*${rule.title}*\n\n${rule.text}\n\n─────────────────\nПолучатели: ${targetLabel}\nВремя: ${rule.time_of_day} МСК`;
        const broadcastRes = await telegramService.sendBroadcastToStaff(telegramMessage, rule.target_role as any);

        await this.recordBotLog(
          'scheduled_broadcast',
          'Планировщик',
          broadcastRes.success ? 'success' : 'error',
          `Рассылка "${rule.title}" отправлена в Telegram (${targetLabel}, доставлено: ${broadcastRes.deliveredCount} сотрудн.).`
        );

        console.log(`[Scheduler] Dispatched "${rule.title}" to Telegram (delivered: ${broadcastRes.deliveredCount} staff).`);
      }
    } catch (err) {
      console.error('[Scheduler] Error processing custom scheduled notifications:', err);
    }
  }
}

export const schedulerService = new SchedulerService();
