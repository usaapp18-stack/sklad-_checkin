import { db } from '../db/index';

const SHIFT_LABELS: Record<string, string> = {
  standard: 'Обычная смена',
  '400+': '400+',
  '500+': '500+',
  '8h': '8 часов',
  '4h': '4 часа',
};

// Requirement 33: Escape user-controlled Markdown characters to prevent formatting breakage / injection
export function escapeMarkdown(text: string): string {
  return text.replace(/([_*[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
}

export interface TelegramTemplateItem {
  id: string;
  name: string;
  description: string;
  variables: string[];
  template: string;
}

export const DEFAULT_TELEGRAM_TEMPLATES: Record<string, TelegramTemplateItem> = {
  checkin: {
    id: 'checkin',
    name: 'Отметка Check-in',
    description: 'Уведомление руководителю о начале смены сотрудником',
    variables: ['{employeeName}', '{location}', '{shiftType}', '{date}'],
    template: '🔔 *Новая отметка Check-in!*\n\n👤 *Сотрудник:* {employeeName}\n📍 *Пункт:* {location}\n🕒 *Смена:* {shiftType}\n📅 *Дата:* {date}',
  },
  daily_report: {
    id: 'daily_report',
    name: 'Ежедневный сводный отчет (21:15)',
    description: 'Вечерняя сводка по продажам, выручке и премиям',
    variables: ['{date}', '{staffList}', '{totalRevenue}', '{totalBonus}', '{totalCash}', '{totalCard}'],
    template: '💰 *Отчёт по продажам на {date}*\n\n{staffList}\n\n─────────────────\n💵 Итог дня: *{totalRevenue} ₽*\n🎁 Премия: *{totalBonus} ₽*\n💵 Наличные: *{totalCash} ₽*\n💳 Безналичные: *{totalCard} ₽*',
  },
  swap_status: {
    id: 'swap_status',
    name: 'Решение по замене смены',
    description: 'Уведомление при согласовании или отклонении заявки биржи',
    variables: ['{status}', '{date}', '{location}', '{requesterName}', '{candidateName}'],
    template: '📋 *Решение по замене смены: {status}*\n📅 Дата: *{date}* ({location})\n👤 Передал: *{requesterName}*\n👤 Принял: *{candidateName}*',
  },
  thank_you: {
    id: 'thank_you',
    name: 'Благодарность сотруднику',
    description: 'Отправка благодарности сотруднику смены от руководителя',
    variables: ['{location}'],
    template: '❤️ *Благодарность от руководителя*\nРуководитель выражает огромную благодарность за отличную работу на пункте {location}! Так держать!',
  },
};

let customTelegramSettings: {
  botToken: string;
  managerChatId: string;
  botUsername: string;
  updatedAt?: string;
} | null = null;

export class TelegramService {
  setSettings(settings: { botToken: string; managerChatId: string; botUsername?: string; updatedAt?: string }) {
    customTelegramSettings = {
      botToken: settings.botToken,
      managerChatId: settings.managerChatId,
      botUsername: settings.botUsername || '',
      updatedAt: settings.updatedAt || new Date().toISOString(),
    };
  }

  getSettings() {
    return customTelegramSettings || {
      botToken: process.env.TELEGRAM_BOT_TOKEN || '',
      managerChatId: process.env.MANAGER_TELEGRAM_ID || '',
      botUsername: '',
      updatedAt: undefined,
    };
  }

  clearSettings() {
    customTelegramSettings = null;
  }

  isConfigured(): boolean {
    const s = this.getSettings();
    return Boolean(s.botToken && s.managerChatId);
  }

  private getBotToken(): string {
    return customTelegramSettings?.botToken || process.env.TELEGRAM_BOT_TOKEN || '';
  }

  getManagerChatId(): string {
    return customTelegramSettings?.managerChatId || process.env.MANAGER_TELEGRAM_ID || '';
  }

  async sendMessage(text: string, chatId?: string): Promise<{ success: boolean; simulated?: boolean; error?: string }> {
    const token = this.getBotToken();
    const targetChatId = chatId || this.getManagerChatId();

    if (!token) {
      console.log(`[Telegram Simulation] (Token not configured in .env)\nTarget Chat ID: ${targetChatId}\nMessage Content:\n${text}`);
      return { success: true, simulated: true };
    }

    try {
      // 1. Attempt sending with Markdown formatting
      let response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: targetChatId,
          text,
          parse_mode: 'Markdown',
        }),
      });

      let resData = await response.json();

      // 2. Fallback to plain text if Markdown parsing failed
      if (!response.ok || !resData.ok) {
        response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: targetChatId,
            text,
          }),
        });
        resData = await response.json();
      }

      if (!response.ok || !resData.ok) {
        console.error('[Telegram] Telegram API error:', resData);
        return { success: false, error: resData.description || 'Ошибка Telegram API' };
      }

      return { success: true };
    } catch (err) {
      console.error('[Telegram] Network error sending message to Telegram:', err);
      return { success: false, error: (err as Error).message };
    }
  }

  async sendCheckInNotification(
    employeeName: string,
    location: string,
    shiftType: string,
    date: string
  ): Promise<boolean> {
    const shiftLabel = SHIFT_LABELS[shiftType] || shiftType;
    const safeName = escapeMarkdown(employeeName);
    const msg = `🔔 *Новая отметка Check-in!*\n\n👤 *Сотрудник:* ${safeName}\n📍 *Пункт:* ${location}\n🕒 *Смена:* ${shiftLabel}\n📅 *Дата:* ${date}`;
    const res = await this.sendMessage(msg);
    return res.success;
  }

  async generateDailySalesReportText(targetDate?: string): Promise<string> {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('ru-RU', {
      timeZone: 'Europe/Moscow',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    const parts = formatter.formatToParts(now);
    const day = parts.find(p => p.type === 'day')?.value || '01';
    const month = parts.find(p => p.type === 'month')?.value || '01';
    const year = parts.find(p => p.type === 'year')?.value || '2026';
    const dateFormatted = `${year}-${month}-${day}`;
    const displayDate = `${day}.${month}.${year}`;

    const dateToQuery = targetDate || dateFormatted;

    // Fetch all active employees
    const staffRes = await db.query<{ id: string; name: string }>(
      "SELECT id, name FROM users WHERE role = 'employee' AND status = 'active' ORDER BY name ASC"
    );

    // Fetch checkins for today
    const checkinsRes = await db.query<{
      user_id: string;
      location_code: string;
      shift_type: string;
    }>('SELECT user_id, location_code, shift_type FROM checkins WHERE date = $1', [dateToQuery]);

    // Fetch sales for today
    const salesRes = await db.query<{
      user_id: string;
      total: number;
      photo_cash: number;
      photo_card: number;
      print_cash: number;
      print_card: number;
      lamination_cash: number;
      lamination_card: number;
      bonus: number;
    }>('SELECT user_id, total, photo_cash, photo_card, print_cash, print_card, lamination_cash, lamination_card, bonus FROM sales WHERE date = $1', [dateToQuery]);

    const checkinMap = new Map(checkinsRes.rows.map(c => [c.user_id, c]));
    const salesMap = new Map(salesRes.rows.map(s => [s.user_id, s]));

    let totalRevenue = 0;
    let totalCash = 0;
    let totalCard = 0;
    let totalBonus = 0;

    const lines: string[] = [`💰 *Отчёт по продажам на ${displayDate}*\n`];

    if (staffRes.rows.length === 0) {
      lines.push('_(Активных сотрудников в системе нет)_');
    } else {
      for (const emp of staffRes.rows) {
        const safeName = escapeMarkdown(emp.name);
        const checkin = checkinMap.get(emp.id);
        if (!checkin) {
          lines.push(`🔴 ${safeName} — нет check-in`);
        } else {
          const shiftLabel = SHIFT_LABELS[checkin.shift_type] || checkin.shift_type;
          const sale = salesMap.get(emp.id);
          if (sale) {
            const empTotal = Number(sale.total || 0);
            const empCash = Number(sale.photo_cash || 0) + Number(sale.print_cash || 0) + Number(sale.lamination_cash || 0);
            const empCard = Number(sale.photo_card || 0) + Number(sale.print_card || 0) + Number(sale.lamination_card || 0);
            const empBonus = Number(sale.bonus || 0);

            totalRevenue += empTotal;
            totalCash += empCash;
            totalCard += empCard;
            totalBonus += empBonus;

            lines.push(
              `🟢 ${safeName} (${shiftLabel}, ${checkin.location_code}): *${empTotal.toLocaleString('ru-RU')} ₽* (нал: ${empCash.toLocaleString('ru-RU')} / б/нал: ${empCard.toLocaleString('ru-RU')})`
            );
          } else {
            lines.push(`🟡 ${safeName} (${shiftLabel}, ${checkin.location_code}) — нет продаж`);
          }
        }
      }
    }

    lines.push('\n─────────────────');
    lines.push(`💵 Итог дня: *${totalRevenue.toLocaleString('ru-RU')} ₽*`);
    lines.push(`🎁 Премия: *${totalBonus.toLocaleString('ru-RU')} ₽*`);
    lines.push(`💵 Наличные: *${totalCash.toLocaleString('ru-RU')} ₽*`);
    lines.push(`💳 Безналичные: *${totalCard.toLocaleString('ru-RU')} ₽*`);

    return lines.join('\n');
  }

  async sendDailySalesReport(targetDate?: string): Promise<{ success: boolean; simulated?: boolean; text?: string; error?: string }> {
    const text = await this.generateDailySalesReportText(targetDate);
    const sendResult = await this.sendMessage(text);
    return {
      success: sendResult.success,
      simulated: sendResult.simulated,
      text,
      error: sendResult.error,
    };
  }

  private customTemplates: Record<string, TelegramTemplateItem> = { ...DEFAULT_TELEGRAM_TEMPLATES };
  private knownUserChats = new Map<string, string>();

  getTemplates(): Record<string, TelegramTemplateItem> {
    return this.customTemplates;
  }

  setTemplates(templates: Record<string, Partial<TelegramTemplateItem>>) {
    for (const [key, tpl] of Object.entries(templates)) {
      if (this.customTemplates[key]) {
        this.customTemplates[key] = {
          ...this.customTemplates[key],
          ...tpl,
        };
      }
    }
  }

  async syncUpdates(): Promise<void> {
    const token = this.getBotToken();
    if (!token) return;

    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/getUpdates?timeout=1`);
      const data = await res.json();
      if (data.ok && Array.isArray(data.result)) {
        for (const update of data.result) {
          const msg = update.message || update.edited_message || update.channel_post;
          if (!msg) continue;
          const chatId = msg.chat?.id;
          if (!chatId) continue;

          if (msg.from?.username) {
            const clean = msg.from.username.trim().replace(/^@/, '').toLowerCase();
            this.knownUserChats.set(clean, String(chatId));
          }
          if (msg.chat?.username) {
            const clean = msg.chat.username.trim().replace(/^@/, '').toLowerCase();
            this.knownUserChats.set(clean, String(chatId));
          }
        }
      }
    } catch (e) {
      console.warn('[Telegram] syncUpdates error:', e);
    }
  }

  async resolveChatIdForUsername(usernameOrId: string): Promise<string> {
    const trimmed = (usernameOrId || '').trim();
    if (!trimmed) return '';

    // If already numeric ID (or negative for group)
    if (/^-?\d+$/.test(trimmed)) {
      return trimmed;
    }

    const clean = trimmed.replace(/^@/, '').toLowerCase();
    if (this.knownUserChats.has(clean)) {
      return this.knownUserChats.get(clean)!;
    }

    // Try fetching updates to see if user recently interacted with the bot
    await this.syncUpdates();
    if (this.knownUserChats.has(clean)) {
      return this.knownUserChats.get(clean)!;
    }

    // Fallback: return @username
    return `@${clean}`;
  }

  async sendBroadcastToStaff(
    text: string,
    targetRole: 'all' | 'standard' | 'part_time' = 'all'
  ): Promise<{ success: boolean; deliveredCount: number; staffCount: number; error?: string }> {
    const token = this.getBotToken();
    if (!token) {
      return { success: true, deliveredCount: 0, staffCount: 0 };
    }

    // 1. Sync updates to learn employee chat IDs
    await this.syncUpdates();

    // 2. Query matching employees who have telegram_username specified
    let query = `SELECT id, name, telegram_username FROM users WHERE role = 'employee' AND status = 'active' AND telegram_username IS NOT NULL AND TRIM(telegram_username) != ''`;
    if (targetRole === 'standard') {
      query += ' AND is_part_time = 0';
    } else if (targetRole === 'part_time') {
      query += ' AND is_part_time = 1';
    }

    let staffMembers: { id: string; name: string; telegram_username: string }[] = [];
    try {
      const res = await db.query<{ id: string; name: string; telegram_username: string }>(query);
      staffMembers = res.rows;
    } catch (err) {
      console.warn('[Telegram] Broadcast staff query warning:', err);
    }

    let deliveredCount = 0;
    const sentChatIds = new Set<string>();

    for (const emp of staffMembers) {
      const target = await this.resolveChatIdForUsername(emp.telegram_username);
      if (!target || sentChatIds.has(target)) continue;
      sentChatIds.add(target);

      const sendRes = await this.sendMessage(text, target);
      if (sendRes.success) {
        deliveredCount++;
      } else {
        console.warn(`[Telegram] Broadcast failed for ${emp.name} (${emp.telegram_username}): ${sendRes.error}`);
      }
    }

    // Also send to manager chat ID if not already sent
    const managerChat = this.getManagerChatId();
    if (managerChat && !sentChatIds.has(managerChat)) {
      await this.sendMessage(text, managerChat);
    }

    return {
      success: true,
      deliveredCount,
      staffCount: staffMembers.length,
    };
  }
}

export const telegramService = new TelegramService();
