/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { ThemeProvider } from './context/ThemeContext';
import { Header } from './components/Header';
import { UserSwitcher } from './components/UserSwitcher';
import { NotificationModal } from './components/NotificationModal';
import { RegistrationView } from './components/employee/RegistrationView';
import { EmployeeDashboard } from './components/employee/EmployeeDashboard';
import { ManagerDashboard } from './components/manager/ManagerDashboard';
import { LoginScreen } from './components/auth/LoginScreen';
import { OfflineIndicator } from './components/OfflineIndicator';

const AppContent: React.FC = () => {
  const { authStatus, authSession, currentRole } = useApp();

  const [isUserSwitcherOpen, setIsUserSwitcherOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);

  // Loading state (Requirement 57: Never assume employee or flash screens while validating session)
  if (authStatus === 'LOADING') {
    return (
      <div className="min-h-screen min-h-[100dvh] bg-slate-950 dark:bg-slate-950 light:bg-slate-50 flex flex-col items-center justify-center text-slate-400 gap-3 selection:bg-emerald-500 p-4">
        <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Проверка сессии...</span>
        <button
          onClick={() => {
            if (typeof window !== 'undefined') {
              localStorage.removeItem('pvz_session_token');
              localStorage.removeItem('pvz_csrf');
              window.location.reload();
            }
          }}
          className="mt-4 px-3 py-1.5 text-[11px] text-slate-500 hover:text-slate-300 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors cursor-pointer"
        >
          Перейти к окну входа
        </button>
      </div>
    );
  }

  // 1. Locked starting screen until authentication
  if (!authSession) {
    return (
      <div className="min-h-screen min-h-[100dvh] flex flex-col justify-between">
        <LoginScreen onOpenRegistration={() => setIsRegistrationOpen(true)} />
        <RegistrationView
          isOpen={isRegistrationOpen}
          onClose={() => setIsRegistrationOpen(false)}
        />
        <OfflineIndicator />
      </div>
    );
  }

  // 2. Authenticated workspace (Manager Admin or Employee Admin)
  return (
    <div className="min-h-screen min-h-[100dvh] bg-slate-950 dark:bg-slate-950 light:bg-slate-50 text-slate-100 dark:text-slate-100 light:text-slate-900 flex flex-col overflow-x-hidden max-w-full selection:bg-emerald-500 selection:text-slate-950">
      
      {/* Top Bar Header */}
      <Header
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenUserSwitcher={() => setIsUserSwitcherOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-16">
        {currentRole === 'manager' ? (
          <ManagerDashboard />
        ) : (
          <EmployeeDashboard />
        )}
      </main>

      {/* Modals */}
      <UserSwitcher
        isOpen={isUserSwitcherOpen}
        onClose={() => setIsUserSwitcherOpen(false)}
        onOpenRegistration={() => setIsRegistrationOpen(true)}
      />

      <NotificationModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
      />

      <RegistrationView
        isOpen={isRegistrationOpen}
        onClose={() => setIsRegistrationOpen(false)}
      />

      <OfflineIndicator />

    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </ThemeProvider>
  );
}
