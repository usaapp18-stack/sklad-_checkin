import React from 'react';
import { useApp } from '../context/AppContext';
import { Clock, Bell, User, ShieldCheck, LogOut } from 'lucide-react';
import { formatDisplayDate } from '../utils/time';
import { PWAInstallButton } from './PWAInstallButton';
import { ThemeToggle } from './ThemeToggle';
import { useAppBadge } from '../hooks/useAppBadge';

interface HeaderProps {
  onOpenNotifications: () => void;
  onOpenUserSwitcher: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNotifications,
  onOpenUserSwitcher,
}) => {
  const { authSession, currentRole, currentStaffId, currentStaff, mskTime, todayDate, notifications, messages, logout } = useApp();

  // Calculate unread notifications specifically for the current role / user
  const relevantUnreadNotifs = notifications.filter(n => {
    if (n.read) return false;
    if (currentRole === 'manager') {
      return n.type === 'report' || n.type === 'system' || n.toEmployeeId === 'manager';
    } else {
      const isTargeted = n.toEmployeeId === currentStaffId || n.toEmployeeId === 'all';
      if (!isTargeted) return false;
      if (n.location && currentStaff) {
        const staffLocs = currentStaff.locations || (currentStaff.location ? [currentStaff.location] : []);
        return staffLocs.includes(n.location);
      }
      return true;
    }
  }).length;

  const unreadMessages = currentRole === 'manager' ? messages.filter(m => !m.read).length : 0;
  const totalAlerts = relevantUnreadNotifs + unreadMessages;

  // Sync unread notifications count with the home screen app icon (App Badging API)
  useAppBadge(totalAlerts);

  return (
    <header className="sticky top-0 z-30 bg-slate-900 dark:bg-slate-900 light:bg-[#183B2E] border-b border-slate-800 dark:border-slate-800 light:border-[#143227] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-15">
          
          {/* Wordmark */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <span className="text-sm sm:text-base font-semibold tracking-tight text-slate-100 flex items-center gap-2 shrink-0 whitespace-nowrap">
              <img src="/favicon.svg" alt="Логотип ПВЗ" className="w-6 h-6 object-contain rounded-lg shrink-0" />
              <span>PVZ Check-in</span>
            </span>
          </div>

          {/* Clock & Local browser time */}
          <div className="hidden md:flex items-center gap-2 text-xs">
            <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 border border-slate-800 rounded-lg header-clock-pill">
              <span className="text-slate-400">Время:</span>
              <span className="font-mono tabular-nums font-medium text-slate-100">{mskTime.slice(0, 5)}</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-300">{formatDisplayDate(todayDate)}</span>
            </div>
          </div>

          {/* Action buttons & User info */}
          <div className="flex items-center gap-1.5 sm:gap-3">

            {/* Theme Toggle (Light / Dark / System) */}
            <ThemeToggle />

            {/* Add to home screen / PWA Install (arrow icon on mobile, label on desktop) */}
            <PWAInstallButton isHeader />

            {/* Notifications Button with quiet static badge */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 text-slate-300 hover:text-slate-100 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer border border-slate-800"
              aria-label="Уведомления"
              title="Уведомления и сообщения"
            >
              <Bell className="w-4 h-4" />
              {totalAlerts > 0 && (
                <span className="notification-badge absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-emerald-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-xs">
                  {totalAlerts}
                </span>
              )}
            </button>

            {/* User Badge / Persona Selector (Manager only or Profile) */}
            <button
              onClick={onOpenUserSwitcher}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-lg transition-all shadow-sm cursor-pointer border border-slate-800"
              title="Информация об аккаунте"
            >
              {currentRole === 'manager' ? (
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              ) : (
                <User className="w-4 h-4 text-emerald-400 shrink-0" />
              )}
              <div className="text-left hidden sm:block">
                <span className="font-semibold block truncate max-w-[130px] text-slate-100">
                  {authSession?.name || (currentRole === 'manager' ? 'Руководитель' : currentStaff?.name)}
                </span>
              </div>
            </button>

            {/* Logout Button */}
            <button
              onClick={logout}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-slate-100 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer border border-slate-800"
              title="Выйти из админки (закрыть сессию)"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Выйти</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};

