import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { parseDateSafe } from '../utils/time';
import { Bell, X, CheckCheck, Heart, AlertTriangle, FileText, MessageSquare, Clock, CornerDownLeft, Send, Check, User } from 'lucide-react';
import { useBottomSheetGesture } from '../hooks/useBottomSheetGesture';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  const {
    currentRole,
    currentStaffId,
    currentStaff,
    notifications,
    messages,
    markNotificationRead,
    markMessageRead,
    markAllNotificationsRead,
    markAllMessagesRead,
    replyToMessage,
  } = useApp();

  const [replyingMsgId, setReplyingMsgId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState<string>('');
  const [isSendingReply, setIsSendingReply] = useState<boolean>(false);
  const [replySuccessMsgId, setReplySuccessMsgId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSendReply = async (msgId: string) => {
    if (!replyText.trim()) return;
    setIsSendingReply(true);
    const res = await replyToMessage(msgId, replyText.trim());
    setIsSendingReply(false);
    if (res.success) {
      setReplySuccessMsgId(msgId);
      setReplyText('');
      setTimeout(() => {
        setReplySuccessMsgId(null);
        setReplyingMsgId(null);
      }, 2000);
    }
  };

  const staffLocs = currentStaff?.locations || (currentStaff?.location ? [currentStaff.location] : []);

  // Filter notifications relevant to current user
  const relevantNotifs = notifications.filter(n => {
    if (currentRole === 'manager') {
      return n.type === 'report' || n.type === 'system' || n.toEmployeeId === 'manager';
    } else {
      const isTargeted = n.toEmployeeId === currentStaffId || n.toEmployeeId === 'all';
      if (!isTargeted) return false;
      if (n.location) {
        return staffLocs.includes(n.location);
      }
      return true;
    }
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'thank_you':
        return <Heart className="w-4 h-4 text-rose-400" />;
      case 'reminder':
        return <Clock className="w-4 h-4 text-amber-400" />;
      case 'report':
        return <FileText className="w-4 h-4 text-sky-400" />;
      default:
        return <Bell className="w-4 h-4 text-emerald-400" />;
    }
  };

  const handleMarkAllRead = () => {
    markAllNotificationsRead();
    if (currentRole === 'manager') {
      markAllMessagesRead();
    }
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 light:bg-white border-t sm:border border-slate-800 light:border-slate-200 rounded-t-2xl sm:rounded-2xl w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl text-white light:text-slate-900"
      >
        
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1.5 bg-slate-700/80 rounded-full pointer-events-none" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 light:border-slate-200 shrink-0">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-semibold text-white light:text-slate-900">Уведомления и сообщения</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllRead}
              className="text-xs text-slate-400 light:text-slate-600 hover:text-white light:hover:text-slate-900 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-slate-800 light:hover:bg-slate-100 transition-colors cursor-pointer"
              title="Отметить всё как прочитанное"
            >
              <CheckCheck className="w-3.5 h-3.5 text-emerald-400 light:text-emerald-600" />
              <span>Прочитать всё</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 light:text-slate-500 hover:text-white light:hover:text-slate-900 rounded-lg hover:bg-slate-800 light:hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-4 space-y-4 flex-1 overflow-y-auto overscroll-contain touch-pan-y">
          
          {/* Manager Incoming Staff Messages */}
          {currentRole === 'manager' && (
            <div className="space-y-2">
              <div className="text-xs font-semibold text-slate-400 light:text-slate-500 uppercase tracking-wider">
                Сообщения от сотрудников
              </div>
              {messages.length === 0 ? (
                <div className="text-xs text-slate-500 light:text-slate-400 py-2">Нет сообщений от сотрудников</div>
              ) : (
                messages.map(msg => {
                  const isReplying = replyingMsgId === msg.id;
                  const isSuccess = replySuccessMsgId === msg.id;

                  // Gather complete dialog history context between this employee and manager
                  const employeeId = msg.fromEmployeeId;
                  const employeeMessages = messages.filter(m => m.fromEmployeeId === employeeId);
                  const managerReplies = notifications.filter(n => n.toEmployeeId === employeeId && ((n as any).source === 'manager' || n.title.includes('Ответ')));

                  const threadItems = [
                    ...employeeMessages.map(m => ({
                      id: m.id,
                      type: 'employee' as const,
                      text: m.message,
                      timestamp: m.timestamp,
                      senderName: m.fromEmployeeName,
                    })),
                    ...managerReplies.map(n => ({
                      id: n.id,
                      type: 'manager' as const,
                      text: n.text,
                      timestamp: n.timestamp,
                      senderName: 'Руководитель',
                    })),
                  ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

                  return (
                    <div
                      key={msg.id}
                      onClick={() => { if (!msg.read) markMessageRead(msg.id); }}
                      className={`p-3 rounded-xl border transition-all ${
                        !msg.read
                          ? 'bg-sky-500/10 light:bg-sky-50 border-sky-500/40 light:border-sky-300 text-slate-100 light:text-slate-900'
                          : 'bg-slate-800/40 light:bg-slate-50 border-slate-800 light:border-slate-200 text-slate-300 light:text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-sky-400 light:text-sky-700">
                          <User className="w-3.5 h-3.5 text-sky-400 light:text-sky-700 shrink-0" />
                          <span>Сотрудник: <strong className="text-white light:text-slate-900 font-bold">{msg.fromEmployeeName}</strong></span>
                          {!msg.read && (
                            <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse"></span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 light:text-slate-400 font-mono">
                          {parseDateSafe(msg.timestamp).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      {/* Full Thread Conversation History */}
                      <div className="space-y-2 mb-2 max-h-48 overflow-y-auto pr-1">
                        {threadItems.map(item => (
                          <div
                            key={item.id}
                            className={`p-2 rounded-lg text-xs border ${
                              item.type === 'employee'
                                ? 'bg-sky-500/10 light:bg-sky-50 border-sky-500/20 light:border-sky-200 text-slate-200 light:text-slate-800 mr-4'
                                : 'bg-emerald-500/10 light:bg-emerald-50 border-emerald-500/20 light:border-emerald-200 text-slate-200 light:text-slate-800 ml-4'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2 text-[10px] text-slate-400 light:text-slate-500 mb-1">
                              <span className="font-semibold text-slate-300 light:text-slate-700">
                                {item.senderName}
                              </span>
                              <span>
                                {parseDateSafe(item.timestamp).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="leading-relaxed whitespace-pre-wrap">{item.text}</p>
                          </div>
                        ))}
                      </div>

                      {/* Reply Action & Inline Form */}
                      {isSuccess ? (
                        <div className="flex items-center gap-1.5 text-xs text-emerald-400 light:text-emerald-700 font-medium py-1 px-2 bg-emerald-500/10 light:bg-emerald-50 rounded-lg border border-emerald-500/30 light:border-emerald-200">
                          <Check className="w-3.5 h-3.5" />
                          <span>Ответ успешно отправлен сотруднику!</span>
                        </div>
                      ) : isReplying ? (
                        <div className="mt-2 space-y-2 pt-2 border-t border-slate-800/80 light:border-slate-200" onClick={e => e.stopPropagation()}>
                          <textarea
                            rows={2}
                            autoFocus
                            placeholder={`Ответ сотруднику ${msg.fromEmployeeName}...`}
                            value={replyText}
                            onChange={e => setReplyText(e.target.value)}
                            className="w-full p-2 bg-slate-950 light:bg-white border border-slate-700 light:border-slate-300 rounded-lg text-xs text-white light:text-slate-900 placeholder-slate-500 light:placeholder-slate-400 focus:outline-none focus:border-sky-500 resize-none"
                          />
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => { setReplyingMsgId(null); setReplyText(''); }}
                              className="px-2.5 py-1 text-xs text-slate-400 light:text-slate-600 hover:text-white light:hover:text-slate-900 rounded-lg transition-colors cursor-pointer"
                            >
                              Отмена
                            </button>
                            <button
                              type="button"
                              disabled={isSendingReply || !replyText.trim()}
                              onClick={() => handleSendReply(msg.id)}
                              className="px-3 py-1 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 text-xs font-semibold rounded-lg flex items-center gap-1 transition-all cursor-pointer shadow-sm"
                            >
                              <Send className="w-3 h-3" />
                              <span>{isSendingReply ? 'Отправка...' : 'Отправить'}</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center justify-end pt-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setReplyingMsgId(msg.id);
                              setReplyText('');
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-sky-400 light:text-sky-700 hover:text-sky-300 light:hover:text-sky-800 bg-sky-500/10 light:bg-sky-50 hover:bg-sky-500/20 light:hover:bg-sky-100 border border-sky-500/30 light:border-sky-200 rounded-lg transition-all cursor-pointer"
                          >
                            <CornerDownLeft className="w-3 h-3" />
                            <span>Ответить</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* System Notifications & Bot Broadcasts */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-400 light:text-slate-500 uppercase tracking-wider">
              Оповещения бота и рассылки
            </div>
            {relevantNotifs.length === 0 ? (
              <div className="text-xs text-slate-500 light:text-slate-400 py-2">Уведомлений нет</div>
            ) : (
              relevantNotifs.map(n => (
                <div
                  key={n.id}
                  onClick={() => markNotificationRead(n.id)}
                  className={`p-3 rounded-xl border transition-colors cursor-pointer ${
                    !n.read
                      ? 'bg-slate-800/90 light:bg-white border-slate-700 light:border-slate-300 text-slate-100 light:text-slate-900 shadow-sm'
                      : 'bg-slate-800/30 light:bg-slate-50 border-slate-800/80 light:border-slate-200 text-slate-400 light:text-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-white light:text-slate-900">
                      {getIcon(n.type)}
                      <span>{n.title}</span>
                      {n.location && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-700 light:bg-slate-200 text-slate-300 light:text-slate-700">
                          {n.location}
                        </span>
                      )}
                      {!n.read && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-500 light:text-slate-400">
                      {parseDateSafe(n.timestamp).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 light:text-slate-600 leading-relaxed">{n.text}</p>
                </div>
              ))
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
