import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { ArrowDownToLine, X, Share } from 'lucide-react';

interface PWAInstallButtonProps {
  isHeader?: boolean;
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ isHeader = false, className = '' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  const handleClick = () => {
    if (isInstallable) {
      install();
    } else {
      setShowIOSGuide(true);
    }
  };

  // Header Mode: Icon button on mobile, compact labeled button on desktop
  if (isHeader) {
    return (
      <>
        {/* Mobile: Arrow icon button */}
        <button
          onClick={handleClick}
          className={`inline-flex sm:hidden p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer ${className}`}
          title="Добавить на экран"
          aria-label="Добавить на экран"
        >
          <ArrowDownToLine className="w-4 h-4 text-emerald-400" />
        </button>

        {/* Desktop: Compact button with text */}
        <button
          onClick={handleClick}
          className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer ${className}`}
          title="Добавить на экран (установить как приложение)"
        >
          <ArrowDownToLine className="w-3.5 h-3.5 text-emerald-400" />
          <span>На экран</span>
        </button>

        {/* Instruction modal for manual/iOS installation */}
        {showIOSGuide && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 p-4">
            <div className="w-full max-w-sm rounded-lg bg-slate-900 border border-slate-800 p-5 shadow-2xl relative">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <span className="text-xs font-semibold text-white">Добавить на экран устройства</span>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                  title="Закрыть"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-slate-300">
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {isIOS
                    ? 'Для установки веб-приложения на рабочий стол iOS выполните 3 шага в Safari:'
                    : 'Для добавления страницы на экран рабочего стола используйте меню браузера:'}
                </p>

                <div className="space-y-2 bg-slate-950 p-3 rounded border border-slate-850 text-xs">
                  <div className="flex items-start gap-2">
                    <span className="text-slate-500 font-mono text-[11px]">1.</span>
                    <p className="text-[11px]">
                      Нажмите кнопку «Поделиться» (<Share className="w-3 h-3 inline text-slate-300 mx-0.5" /> в Safari).
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-slate-500 font-mono text-[11px]">2.</span>
                    <p className="text-[11px]">
                      Выберите пункт «На экран "Домой"» (Add to Home Screen).
                    </p>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-slate-500 font-mono text-[11px]">3.</span>
                    <p className="text-[11px]">
                      Подтвердите нажатием «Добавить».
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors border border-slate-700"
                >
                  Закрыть
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // Standard standalone button mode (e.g. inside employee dashboard)
  return (
    <>
      <button
        onClick={handleClick}
        className={`flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-3 py-1.5 text-xs font-medium transition-colors ${className}`}
      >
        <ArrowDownToLine className="w-3.5 h-3.5 text-emerald-400" />
        <span>Добавить на экран</span>
      </button>

      {showIOSGuide && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 p-4">
          <div className="w-full max-w-sm rounded-lg bg-slate-900 border border-slate-800 p-5 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <span className="text-xs font-semibold text-white">Добавить на экран устройства</span>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
                title="Закрыть"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Инструкция по установке веб-приложения на рабочий стол:
              </p>

              <div className="space-y-2 bg-slate-950 p-3 rounded border border-slate-850 text-xs">
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 font-mono text-[11px]">1.</span>
                  <p className="text-[11px]">
                    В меню браузера нажмите кнопку «Поделиться» (<Share className="w-3 h-3 inline text-slate-300 mx-0.5" />).
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 font-mono text-[11px]">2.</span>
                  <p className="text-[11px]">
                    Выберите «На экран "Домой"».
                  </p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-slate-500 font-mono text-[11px]">3.</span>
                  <p className="text-[11px]">
                    Нажмите «Добавить».
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                onClick={() => setShowIOSGuide(false)}
                className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors border border-slate-700"
              >
                Закрыть
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
