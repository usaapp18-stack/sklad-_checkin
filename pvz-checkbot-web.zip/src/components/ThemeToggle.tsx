import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { Sun, Moon, Monitor } from 'lucide-react';

interface ThemeToggleProps {
  className?: string;
  showLabels?: boolean;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ className = '', showLabels = false }) => {
  const { theme, setTheme } = useTheme();

  const handleCycleTheme = () => {
    if (theme === 'light') setTheme('dark');
    else if (theme === 'dark') setTheme('system');
    else setTheme('light');
  };

  const getThemeTitle = () => {
    if (theme === 'light') return 'Тема: Светлая (нажмите для смены)';
    if (theme === 'dark') return 'Тема: Тёмная (нажмите для смены)';
    return 'Тема: Системная (нажмите для смены)';
  };

  return (
    <div className={`inline-flex items-center ${className}`}>
      {/* Mobile Compact View: Single Icon Button */}
      <button
        type="button"
        onClick={handleCycleTheme}
        className="sm:hidden p-2 text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-800 flex items-center justify-center cursor-pointer shrink-0"
        title={getThemeTitle()}
        aria-label={getThemeTitle()}
      >
        {theme === 'light' && <Sun className="w-4 h-4 text-white shrink-0" />}
        {theme === 'dark' && <Moon className="w-4 h-4 text-white shrink-0" />}
        {theme === 'system' && <Monitor className="w-4 h-4 text-white shrink-0" />}
      </button>

      {/* Desktop View: Segmented Control */}
      <div
        className="hidden sm:inline-flex items-center p-0.5 rounded-lg border bg-slate-800 border-slate-800 transition-colors theme-toggle-container"
        role="group"
        aria-label="Переключение темы оформления"
      >
        <button
          type="button"
          onClick={() => setTheme('light')}
          className={`px-2 py-1 rounded-md text-xs font-medium flex items-center gap-1 transition-all cursor-pointer ${
            theme === 'light'
              ? 'bg-slate-700 text-white font-semibold shadow-xs theme-toggle-btn-active'
              : 'text-slate-400 hover:text-white theme-toggle-btn-inactive'
          }`}
          title="Светлая тема"
          aria-pressed={theme === 'light'}
        >
          <Sun className="w-3.5 h-3.5 text-white shrink-0" />
          {showLabels && <span>Светлая</span>}
        </button>

        <button
          type="button"
          onClick={() => setTheme('dark')}
          className={`px-2 py-1 rounded-md text-xs font-medium flex items-center gap-1 transition-all cursor-pointer ${
            theme === 'dark'
              ? 'bg-slate-700 text-white font-semibold shadow-xs theme-toggle-btn-active'
              : 'text-slate-400 hover:text-white theme-toggle-btn-inactive'
          }`}
          title="Тёмная тема"
          aria-pressed={theme === 'dark'}
        >
          <Moon className="w-3.5 h-3.5 text-white shrink-0" />
          {showLabels && <span>Тёмная</span>}
        </button>

        <button
          type="button"
          onClick={() => setTheme('system')}
          className={`px-2 py-1 rounded-md text-xs font-medium flex items-center gap-1 transition-all cursor-pointer ${
            theme === 'system'
              ? 'bg-slate-700 text-white font-semibold shadow-xs theme-toggle-btn-active'
              : 'text-slate-400 hover:text-white theme-toggle-btn-inactive'
          }`}
          title="Системная тема"
          aria-pressed={theme === 'system'}
        >
          <Monitor className="w-3.5 h-3.5 text-white shrink-0" />
          {showLabels && <span>Авто</span>}
        </button>
      </div>
    </div>
  );
};
