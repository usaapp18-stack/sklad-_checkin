import React from 'react';
import { useApp } from '../context/AppContext';
import { Shield, UserCheck, X, Check, RefreshCw, AlertCircle, Lock, LogOut } from 'lucide-react';
import { useBottomSheetGesture } from '../hooks/useBottomSheetGesture';

interface UserSwitcherProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenRegistration: () => void;
}

export const UserSwitcher: React.FC<UserSwitcherProps> = ({
  isOpen,
  onClose,
}) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  const {
    authSession,
    currentRole,
    currentStaff,
    staffList,
    logout,
    resetLocalUIState,
  } = useApp();

  if (!isOpen) return null;

  const activeStaff = staffList.filter(s => s.status === 'active' && s.hasAccess);
  const otherStaff = staffList.filter(s => s.status !== 'active' || !s.hasAccess);
  const staffLocs = currentStaff?.locations || (currentStaff?.location ? [currentStaff.location] : []);

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl"
      >
        
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1.5 bg-slate-700/80 rounded-full pointer-events-none" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 shrink-0">
          <div>
            <h3 className="text-base font-semibold text-white">
              {currentRole === 'manager' ? 'Профиль руководителя' : 'Профиль сотрудника'}
            </h3>
            <p className="text-xs text-slate-400">
              {currentRole === 'manager' ? 'Управление доступом' : 'Данные учетной записи'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4 flex-1 overflow-y-auto overscroll-contain touch-pan-y">
          
          {/* If Employee is logged in */}
          {currentRole === 'employee' ? (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                      <UserCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="font-semibold text-white text-sm flex items-center gap-1.5">
                        <span>{currentStaff?.name}</span>
                        {currentStaff?.isSenior && (
                          <span className="text-xs $2font-medium px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300">
                            Ст.С.
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                        <span>Место работы:</span>
                        <span className="text-emerald-400 font-semibold">{staffLocs.join(', ')}</span>
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                    Доступ активен
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-850 text-xs space-y-1.5 font-mono">
                  <div className="flex justify-between text-slate-400">
                    <span>Логин:</span>
                    <span className="text-white font-semibold">{currentStaff?.login}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Telegram:</span>
                    <span className="text-slate-300 font-sans">{currentStaff?.telegramUsername || 'Не указан'}</span>
                  </div>
                </div>
              </div>

              {/* Strict Notice */}
              <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-start gap-2.5 leading-relaxed">
                <Lock className="w-4 h-4 text-white shrink-0 mt-0.5" />
                <span>
                  Работник не может менять логин и пароль. Изменение учетных данных или отзыв доступа производится только руководителем.
                </span>
              </div>

              <button
                onClick={() => {
                  onClose();
                  logout();
                }}
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Выйти из системы</span>
              </button>
            </div>
          ) : (
            /* If Manager is logged in */
            <>
              <div>
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Текущая сессия руководителя
                </div>
                <div className="p-3 rounded-xl bg-amber-500/10 text-white flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                      <Shield className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold">{authSession?.name || 'Руководитель (Admin)'}</div>
                      <div className="text-xs text-slate-400">Логин: {authSession?.login || '+79266137222'}</div>
                    </div>
                  </div>
                  <Check className="w-5 h-5 text-amber-400 shrink-0" />
                </div>
              </div>

              {/* Active Employees List (Requirements 3 & 22: No passwords displayed, no role spoofing) */}
              <div>
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Работники с выданным доступом
                </div>
                <div className="space-y-2">
                  {activeStaff.length === 0 ? (
                    <div className="p-3 text-center text-xs text-slate-500 bg-slate-950 rounded-xl border border-slate-800">
                      Работники еще не добавлены
                    </div>
                  ) : (
                    activeStaff.map(staff => {
                      const locs = staff.locations && staff.locations.length > 0 ? staff.locations : (staff.location ? [staff.location] : []);
                      return (
                        <div
                          key={staff.id}
                          className="flex items-center justify-between p-2.5 rounded-xl border bg-slate-800/40 border-slate-800 text-slate-200"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                              <UserCheck className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="text-xs font-semibold text-white flex items-center gap-1.5 flex-wrap">
                                <span>{staff.name}</span>
                                {locs.map(loc => (
                                  <span key={loc} className="text-[9px] px-1 rounded bg-slate-800 text-emerald-400">
                                    {loc}
                                  </span>
                                ))}
                              </div>
                              <div className="text-[11px] font-mono text-slate-400">
                                Логин: {staff.login}
                              </div>
                            </div>
                          </div>

                          <span className="text-[10px] text-emerald-400 font-semibold px-2 py-0.5 rounded bg-emerald-950">
                            Активен
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Inactive Staff */}
              {otherStaff.length > 0 && (
                <div>
                  <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                    Без доступа / Архив
                  </div>
                  <div className="space-y-1.5">
                    {otherStaff.map(staff => (
                      <div
                        key={staff.id}
                        className="flex items-center justify-between p-2 rounded-lg bg-slate-800/20 border border-slate-800 text-slate-400 text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <AlertCircle className="w-3.5 h-3.5 text-slate-500" />
                          <span>{staff.name}</span>
                        </div>
                        <span className="text-[10px] text-slate-500">
                          {staff.status === 'blocked' || staff.status === 'deactivated' ? 'Заблокирован' : 'В архиве'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Reset Local UI State (Requirement 25) */}
              <div className="pt-2 border-t border-slate-800/80 space-y-2">
                <button
                  onClick={() => {
                    resetLocalUIState();
                    onClose();
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 text-slate-400 hover:text-slate-200 text-xs transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Обновить данные с сервера</span>
                </button>

                <button
                  onClick={() => {
                    onClose();
                    logout();
                  }}
                  className="w-full py-2 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Выйти из учетной записи</span>
                </button>
              </div>
            </>
          )}

        </div>

      </div>
    </div>
  );
};
