import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getBrowserTimeZoneLabel } from '../../utils/time';
import { ThemeToggle } from '../ThemeToggle';
import {
  Eye,
  EyeOff,
  AlertCircle,
  UserPlus,
} from 'lucide-react';

interface LoginScreenProps {
  onOpenRegistration: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onOpenRegistration }) => {
  const { login, mskTime } = useApp();

  const [loginInput, setLoginInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const result = await login(loginInput, passwordInput);
      if (!result.success) {
        setError(result.error || 'Ошибка авторизации. Проверьте правильность логина и пароля.');
      }
    } catch (err: any) {
      setError(err?.message || 'Ошибка подключения к серверу');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 dark:bg-slate-950 light:bg-slate-50 flex flex-col justify-center items-center p-4 selection:bg-emerald-500 selection:text-slate-950 relative transition-colors">
      
      {/* Top Right Theme Selector */}
      <div className="absolute top-4 right-4 z-20">
        <ThemeToggle />
      </div>

      <div className="w-full max-w-sm relative z-10 space-y-6">
        
        {/* Brand Header */}
        <div className="text-center space-y-1.5">
          <div className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-slate-900 dark:bg-slate-900 light:bg-white border border-slate-800 dark:border-slate-800 light:border-slate-200 shadow-sm mb-1">
            <img src="/favicon.svg" alt="Логотип ПВЗ" className="w-6 h-6 object-contain" />
          </div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight text-white dark:text-white light:text-slate-900">
            Вход в систему
          </h1>
          <p className="text-xs text-slate-400 dark:text-slate-400 light:text-slate-500">
            Управление сменами и показателями ПВЗ
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-slate-900 dark:bg-slate-900 light:bg-white border border-slate-800 dark:border-slate-800 light:border-slate-200 rounded-lg p-6 sm:p-7 shadow-xl space-y-5">

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-rose-950/60 dark:bg-rose-950/60 light:bg-rose-50 border border-rose-800/80 dark:border-rose-800/80 light:border-rose-200 rounded-md text-xs text-rose-200 dark:text-rose-200 light:text-rose-700 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            
            <div>
              <label className="block text-xs font-medium text-slate-300 dark:text-slate-300 light:text-slate-700 mb-1.5">
                Логин или телефон
              </label>
              <input
                type="text"
                required
                autoFocus
                placeholder="Логин или номер телефона"
                value={loginInput}
                onChange={e => {
                  setLoginInput(e.target.value);
                  if (error) setError(null);
                }}
                className="w-full px-3.5 py-2.5 bg-slate-950 dark:bg-slate-950 light:bg-slate-50 border border-slate-700/80 dark:border-slate-700/80 light:border-slate-300 rounded-md text-sm text-white dark:text-white light:text-slate-900 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 transition-colors font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 dark:text-slate-300 light:text-slate-700 mb-1.5">
                Пароль
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Введите пароль"
                  value={passwordInput}
                  onChange={e => {
                    setPasswordInput(e.target.value);
                    if (error) setError(null);
                  }}
                  className="w-full px-3.5 pr-10 py-2.5 bg-slate-950 dark:bg-slate-950 light:bg-slate-50 border border-slate-700/80 dark:border-slate-700/80 light:border-slate-300 rounded-md text-sm text-white dark:text-white light:text-slate-900 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500 transition-colors font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 dark:hover:text-slate-300 light:hover:text-slate-700 transition-colors p-1"
                  aria-label={showPassword ? 'Скрыть пароль' : 'Показать пароль'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || !loginInput.trim() || !passwordInput.trim()}
              className={`w-full py-2.5 px-4 rounded-md text-xs font-semibold flex items-center justify-center transition-colors shadow-sm mt-3 ${
                loginInput.trim() && passwordInput.trim() && !isLoading
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 cursor-pointer active:scale-[0.99]'
                  : 'bg-slate-800 dark:bg-slate-800 light:bg-slate-200 text-slate-500 cursor-not-allowed'
              }`}
            >
              <span>{isLoading ? 'Проверка...' : 'Войти в систему'}</span>
            </button>

          </form>

          {/* Registration Trigger */}
          <div className="pt-2 text-center border-t border-slate-800/80 dark:border-slate-800/80 light:border-slate-200">
            <button
              type="button"
              onClick={onOpenRegistration}
              className="text-xs text-emerald-400 dark:text-emerald-400 light:text-emerald-600 hover:text-emerald-300 font-medium inline-flex items-center gap-1.5 transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Подать заявку на выдачу доступа</span>
            </button>
          </div>

        </div>

        {/* Footer */}
        <div className="text-center text-xs text-slate-500 dark:text-slate-500 light:text-slate-600">
          <span>Время ({getBrowserTimeZoneLabel()}): <span className="font-mono text-slate-400 dark:text-slate-400 light:text-slate-700 tabular-nums">{mskTime.slice(0, 5)}</span></span>
        </div>

      </div>

    </div>
  );
};
