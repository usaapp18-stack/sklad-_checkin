import React, { useState, useRef, useEffect } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, X, Check } from 'lucide-react';
import { formatDateDDMMYYYY } from '../../utils/time';

interface CustomDatePickerProps {
  value: string; // YYYY-MM-DD
  onChange: (value: string) => void;
  min?: string;
  max?: string;
  required?: boolean;
  className?: string;
  align?: 'left' | 'right';
  placeholder?: string;
}

export const CustomDatePicker: React.FC<CustomDatePickerProps> = ({
  value,
  onChange,
  min,
  max,
  className = '',
  align = 'left',
  placeholder = 'Выберите дату',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Parse initial view year and month from value or today
  const initialDate = value ? new Date(value) : new Date();
  const validInitial = !isNaN(initialDate.getTime()) ? initialDate : new Date();

  const [viewYear, setViewYear] = useState(validInitial.getFullYear());
  const [viewMonth, setViewMonth] = useState(validInitial.getMonth()); // 0-11

  // Update view when value changes
  useEffect(() => {
    if (value) {
      const d = new Date(value);
      if (!isNaN(d.getTime())) {
        setViewYear(d.getFullYear());
        setViewMonth(d.getMonth());
      }
    }
  }, [value]);

  // Click outside and escape handler
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('touchstart', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const monthNames = [
    'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
  ];

  const daysOfWeek = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

  const prevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear(prev => prev - 1);
    } else {
      setViewMonth(prev => prev - 1);
    }
  };

  const nextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear(prev => prev + 1);
    } else {
      setViewMonth(prev => prev + 1);
    }
  };

  // Generate calendar days matrix for viewMonth/viewYear
  const getCalendarCells = () => {
    const firstDayOfMonth = new Date(viewYear, viewMonth, 1);
    const lastDayOfMonth = new Date(viewYear, viewMonth + 1, 0);

    // Day of week for 1st day (0 = Sunday, convert to Monday = 0)
    let startDay = firstDayOfMonth.getDay() - 1;
    if (startDay === -1) startDay = 6;

    const totalDays = lastDayOfMonth.getDate();
    const cells: (number | null)[] = [];

    // Empty cells before start of month
    for (let i = 0; i < startDay; i++) {
      cells.push(null);
    }

    // Days of current month
    for (let d = 1; d <= totalDays; d++) {
      cells.push(d);
    }

    return cells;
  };

  const handleSelectDay = (dayNum: number) => {
    const formattedMonth = String(viewMonth + 1).padStart(2, '0');
    const formattedDay = String(dayNum).padStart(2, '0');
    const selectedDateStr = `${viewYear}-${formattedMonth}-${formattedDay}`;

    if (min && selectedDateStr < min) return;
    if (max && selectedDateStr > max) return;

    onChange(selectedDateStr);
    setIsOpen(false);
  };

  const handleSetToday = () => {
    const now = new Date();
    const formattedMonth = String(now.getMonth() + 1).padStart(2, '0');
    const formattedDay = String(now.getDate()).padStart(2, '0');
    const todayStr = `${now.getFullYear()}-${formattedMonth}-${formattedDay}`;

    setViewYear(now.getFullYear());
    setViewMonth(now.getMonth());

    if (min && todayStr < min) return;
    if (max && todayStr > max) return;

    onChange(todayStr);
    setIsOpen(false);
  };

  const handleClear = () => {
    onChange('');
    setIsOpen(false);
  };

  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  const cells = getCalendarCells();

  return (
    <div ref={containerRef} className={`relative inline-block text-left w-full ${className}`}>
      {/* Input Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full h-10 min-h-[40px] px-3 py-2 bg-slate-950/90 border border-slate-700/80 hover:border-slate-600 focus:border-emerald-500/80 focus:ring-1 focus:ring-emerald-500/30 rounded-xl text-white font-mono text-xs flex items-center justify-between gap-2 transition-all cursor-pointer shadow-sm select-none"
      >
        <div className="flex items-center gap-2 truncate">
          <CalendarIcon className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className={value ? 'text-white font-semibold' : 'text-slate-500'}>
            {value ? formatDateDDMMYYYY(value) : placeholder}
          </span>
        </div>
        <span className="p-1 rounded-md bg-slate-900 text-slate-400 shrink-0 text-[10px]">
          ▼
        </span>
      </button>

      {/* Branded In-DOM Calendar Popover (Reduced by 20-25%) */}
      {isOpen && (
        <div
          role="dialog"
          aria-label="Календарь"
          className={`absolute z-50 mt-1.5 w-[235px] sm:w-[245px] p-2.5 bg-slate-900 rounded-2xl shadow-2xl shadow-black/90 space-y-2 animate-in fade-in zoom-in-95 duration-150 ${
            align === 'right' ? 'right-0' : 'left-0'
          }`}
        >
          {/* Header Month / Year controls */}
          <div className="flex items-center justify-between pb-1.5">
            <button
              type="button"
              onClick={prevMonth}
              className="p-1 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Предыдущий месяц"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>

            <div className="text-xs font-semibold text-white font-mono flex items-center gap-1.5">
              <span>{monthNames[viewMonth]}</span>
              <span className="text-emerald-400">{viewYear}</span>
            </div>

            <button
              type="button"
              onClick={nextMonth}
              className="p-1 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Следующий месяц"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Days of week header (Сб and Вс are soft red, not too bright) */}
          <div className="grid grid-cols-7 gap-0.5 text-center">
            {daysOfWeek.map((day, idx) => (
              <div
                key={day}
                className={`text-xs $2font-medium py-0.5 select-none ${
                  idx >= 5 ? 'text-rose-400/80' : 'text-slate-400'
                }`}
              >
                {day}
              </div>
            ))}
          </div>

          {/* Grid of days */}
          <div className="grid grid-cols-7 gap-0.5 text-[11px]">
            {cells.map((dayNum, idx) => {
              if (dayNum === null) {
                return <div key={`empty-${idx}`} className="aspect-square"></div>;
              }

              const formattedMonth = String(viewMonth + 1).padStart(2, '0');
              const formattedDay = String(dayNum).padStart(2, '0');
              const cellDateStr = `${viewYear}-${formattedMonth}-${formattedDay}`;

              const isSelected = value === cellDateStr;
              const isCellToday = todayStr === cellDateStr;
              const isDisabled = (min && cellDateStr < min) || (max && cellDateStr > max);

              // Calculate whether it's Saturday (6) or Sunday (0)
              const cellDate = new Date(viewYear, viewMonth, dayNum);
              const dayOfWeek = cellDate.getDay();
              const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

              let dayStyle = 'bg-slate-950/80 text-slate-300 hover:bg-slate-800';
              if (isWeekend && !isSelected && !isCellToday) {
                dayStyle = 'bg-slate-950/80 text-rose-300/80 hover:bg-rose-950/30';
              }
              if (isSelected) {
                dayStyle = 'bg-emerald-500 text-white font-bold shadow-sm scale-105';
              } else if (isCellToday) {
                dayStyle = 'bg-slate-800 text-sky-300 font-semibold ring-1 ring-sky-500/80';
              }

              if (isDisabled) {
                dayStyle = 'bg-slate-950/20 text-slate-600 cursor-not-allowed';
              }

              return (
                <button
                  key={`day-${dayNum}`}
                  type="button"
                  disabled={Boolean(isDisabled)}
                  onClick={() => handleSelectDay(dayNum)}
                  className={`aspect-square rounded-lg flex items-center justify-center font-mono text-[11px] transition-all select-none cursor-pointer ${dayStyle}`}
                >
                  {dayNum}
                </button>
              );
            })}
          </div>

          {/* Footer Quick Actions */}
          <div className="flex items-center justify-between pt-1.5 text-[10px]">
            <button
              type="button"
              onClick={handleClear}
              className="text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
            >
              Очистить
            </button>
            <button
              type="button"
              onClick={handleSetToday}
              className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors cursor-pointer"
            >
              Сегодня
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
