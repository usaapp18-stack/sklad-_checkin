import React, { useState, useRef, useEffect } from 'react';
import { Calendar, ChevronDown, Check } from 'lucide-react';

export interface PeriodOption {
  key: string;
  label: string;
  isCurrent?: boolean;
}

interface CustomPeriodSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: PeriodOption[];
  labelPrefix?: string;
  showIcon?: boolean;
  align?: 'left' | 'right';
  className?: string;
}

export const CustomPeriodSelect: React.FC<CustomPeriodSelectProps> = ({
  value,
  onChange,
  options,
  labelPrefix = 'Период:',
  showIcon = true,
  align = 'right',
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find(o => o.key === value) || {
    key: value,
    label: value,
    isCurrent: false,
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('touchstart', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleSelect = (key: string) => {
    onChange(key);
    setIsOpen(false);
  };

  return (
    <div ref={containerRef} className={`relative inline-block text-left ${className}`}>
      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="h-9 flex items-center gap-2 bg-slate-950/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 px-3 rounded-xl text-xs text-white transition-all cursor-pointer select-none focus:outline-none focus:border-emerald-500/50 shadow-sm"
        aria-haspopup="listbox"
        aria-expanded={isOpen}
      >
        {showIcon && <Calendar className="w-4 h-4 text-emerald-400 shrink-0" />}
        {labelPrefix && (
          <span className="text-slate-300 font-semibold whitespace-nowrap">{labelPrefix}</span>
        )}
        <span className="text-emerald-400 font-semibold whitespace-nowrap">
          {selectedOption.label}
          {selectedOption.isCurrent ? ' (Тек.)' : ''}
        </span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 shrink-0 ${
            isOpen ? 'rotate-180 text-emerald-400' : ''
          }`}
        />
      </button>

      {/* Styled Dropdown Menu (In-DOM, no OS gray borders) */}
      {isOpen && (
        <div
          role="listbox"
          className={`absolute z-50 mt-1.5 w-64 max-w-[calc(100vw-32px)] bg-slate-900 border border-slate-700/90 rounded-2xl shadow-2xl shadow-black/80 py-1.5 overflow-hidden animate-in fade-in zoom-in-95 duration-150 ${
            align === 'left' ? 'left-0' : 'right-0'
          }`}
        >
          <div className="px-3 py-1.5 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span>Выберите период</span>
            <span className="text-emerald-400 font-mono text-[10px] lowercase">({options.length})</span>
          </div>

          <div className="max-h-64 overflow-y-auto py-1 divide-y divide-slate-800/40">
            {options.map(option => {
              const isSelected = option.key === value;
              return (
                <button
                  key={option.key}
                  type="button"
                  onClick={() => handleSelect(option.key)}
                  className={`w-full px-3.5 py-2 text-left text-xs flex items-center justify-between transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-500/15 text-emerald-300 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                  role="option"
                  aria-selected={isSelected}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="truncate">{option.label}</span>
                    {option.isCurrent && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 font-semibold shrink-0">
                        Текущий
                      </span>
                    )}
                  </div>

                  {isSelected && (
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
