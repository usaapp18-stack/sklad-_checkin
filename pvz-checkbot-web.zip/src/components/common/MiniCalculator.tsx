import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Calculator, X, Copy, Check, CornerDownLeft, RotateCcw } from 'lucide-react';

interface MiniCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertValue?: (val: number) => void;
}

export const MiniCalculator: React.FC<MiniCalculatorProps> = ({
  isOpen,
  onClose,
  onInsertValue,
}) => {
  const [display, setDisplay] = useState<string>('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [expression, setExpression] = useState<string>('');
  const [waitingForOperand, setWaitingForOperand] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);

  // Clear all
  const handleClear = useCallback(() => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setExpression('');
    setWaitingForOperand(false);
  }, []);

  // Backspace / Delete last character
  const handleBackspace = useCallback(() => {
    if (waitingForOperand) return;
    setDisplay(prev => {
      if (prev.length <= 1 || (prev.length === 2 && prev.startsWith('-'))) {
        return '0';
      }
      return prev.slice(0, -1);
    });
  }, [waitingForOperand]);

  // Input single digit or decimal
  const handleDigit = useCallback((digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit === '.' ? '0.' : digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(prev => {
        if (digit === '.') {
          if (prev.includes('.')) return prev;
          return prev + '.';
        }
        if (prev === '0') return digit;
        // Limit max digits for clean display
        if (prev.replace(/[^0-9]/g, '').length >= 14) return prev;
        return prev + digit;
      });
    }
  }, [waitingForOperand]);

  // Negate sign (+/-)
  const handleToggleSign = useCallback(() => {
    setDisplay(prev => {
      const num = parseFloat(prev);
      if (num === 0 || isNaN(num)) return '0';
      return (num * -1).toString();
    });
  }, []);

  // Execute binary calculation
  const executeCalculation = (first: number, second: number, op: string): number => {
    switch (op) {
      case '+':
        return first + second;
      case '−':
      case '-':
        return first - second;
      case '×':
      case '*':
        return first * second;
      case '÷':
      case '/':
        return second === 0 ? 0 : first / second;
      default:
        return second;
    }
  };

  // Perform operator action
  const handleOperator = useCallback((nextOp: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
      setExpression(`${formatDisplayNumber(inputValue)} ${nextOp}`);
    } else if (operation) {
      if (waitingForOperand) {
        setOperation(nextOp);
        setExpression(`${formatDisplayNumber(previousValue)} ${nextOp}`);
        return;
      }
      const result = executeCalculation(previousValue, inputValue, operation);
      const rounded = Math.round((result + Number.EPSILON) * 10000) / 10000;
      setPreviousValue(rounded);
      setDisplay(rounded.toString());
      setExpression(`${formatDisplayNumber(rounded)} ${nextOp}`);
    }

    setWaitingForOperand(true);
    setOperation(nextOp);
  }, [display, previousValue, operation, waitingForOperand]);

  // Percentage calculation
  const handlePercent = useCallback(() => {
    const current = parseFloat(display);
    if (isNaN(current)) return;

    if (previousValue !== null && operation) {
      // In context of operation: e.g. 100000 * 6% = 6000, 100000 - 10% = 10000
      let pctVal = 0;
      if (operation === '×' || operation === '*' || operation === '÷' || operation === '/') {
        pctVal = current / 100;
      } else {
        pctVal = (previousValue * current) / 100;
      }
      const rounded = Math.round((pctVal + Number.EPSILON) * 10000) / 10000;
      setDisplay(rounded.toString());
    } else {
      // Standalone percent: e.g. 25% = 0.25
      const result = current / 100;
      setDisplay(result.toString());
      setExpression(`${formatDisplayNumber(current)}%`);
    }
  }, [display, previousValue, operation]);

  // Equals (=)
  const handleEquals = useCallback(() => {
    const inputValue = parseFloat(display);

    if (previousValue !== null && operation) {
      const result = executeCalculation(previousValue, inputValue, operation);
      const rounded = Math.round((result + Number.EPSILON) * 10000) / 10000;
      setExpression(`${formatDisplayNumber(previousValue)} ${operation} ${formatDisplayNumber(inputValue)} =`);
      setDisplay(rounded.toString());
      setPreviousValue(null);
      setOperation(null);
      setWaitingForOperand(true);
    }
  }, [display, previousValue, operation]);

  // Copy result to clipboard
  const handleCopy = useCallback(() => {
    const val = display;
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(val);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [display]);

  // Keyboard shortcut listener
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // If user is typing in an external input field, don't intercept unless Esc
      const activeEl = document.activeElement;
      const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');
      if (isInput && !containerRef.current?.contains(activeEl)) {
        if (e.key === 'Escape') {
          onClose();
        }
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === '.' || e.key === ',') {
        e.preventDefault();
        handleDigit('.');
      } else if (e.key === '+') {
        e.preventDefault();
        handleOperator('+');
      } else if (e.key === '-') {
        e.preventDefault();
        handleOperator('−');
      } else if (e.key === '*') {
        e.preventDefault();
        handleOperator('×');
      } else if (e.key === '/') {
        e.preventDefault();
        handleOperator('÷');
      } else if (e.key === '%') {
        e.preventDefault();
        handlePercent();
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        handleEquals();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleDigit, handleOperator, handlePercent, handleEquals, handleBackspace, onClose]);

  if (!isOpen) return null;

  const currentNumeric = parseFloat(display);

  return (
    <div
      ref={containerRef}
      className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 w-72 bg-slate-900 border border-slate-800 rounded-lg shadow-2xl p-3.5 space-y-2.5 animate-in fade-in slide-in-from-bottom-2 duration-150"
      role="dialog"
      aria-label="Калькулятор"
    >
      {/* Header bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-1.5 text-xs font-medium text-white">
          <Calculator className="w-3.5 h-3.5 text-emerald-400" />
          <span>Калькулятор</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handleClear}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Очистить всё (C)"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Закрыть"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Screen / Display */}
      <div className="bg-slate-950 border border-slate-800 rounded-md p-2.5 text-right font-mono">
        <div className="text-[11px] text-slate-400 h-4 truncate">
          {expression || '\u00A0'}
        </div>
        <div
          className="text-xl sm:text-2xl font-semibold text-white tracking-tight tabular-nums truncate select-all cursor-text"
          title="Нажмите для выделения"
        >
          {formatDisplayNumber(display)}
        </div>
      </div>

      {/* Quick Actions (Copy / Insert) */}
      <div className="flex items-center justify-between text-xs pt-0.5">
        <button
          type="button"
          onClick={handleCopy}
          className="px-2 py-1 rounded bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-medium flex items-center gap-1 transition-colors border border-slate-700/60"
        >
          {copied ? (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-emerald-400">Скопировано!</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3 text-slate-400" />
              <span>Копировать</span>
            </>
          )}
        </button>

        {onInsertValue && (
          <button
            type="button"
            onClick={() => onInsertValue(isNaN(currentNumeric) ? 0 : currentNumeric)}
            className="px-2 py-1 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-[11px] font-medium flex items-center gap-1 transition-colors border border-emerald-500/30"
          >
            <CornerDownLeft className="w-3 h-3" />
            <span>Вставить в статью</span>
          </button>
        )}
      </div>

      {/* Calculator Keypad */}
      <div className="grid grid-cols-4 gap-1.5 pt-1 text-xs font-mono font-medium">
        {/* Row 1 */}
        <button
          type="button"
          onClick={handleClear}
          className="h-9 rounded-md bg-slate-800/90 hover:bg-slate-700 text-rose-400 border border-slate-700/60 transition-colors"
          title="Сброс"
        >
          C
        </button>
        <button
          type="button"
          onClick={handleBackspace}
          className="h-9 rounded-md bg-slate-800/90 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors"
          title="Удалить последний символ"
        >
          ⌫
        </button>
        <button
          type="button"
          onClick={handlePercent}
          className="h-9 rounded-md bg-slate-800/90 hover:bg-slate-700 text-sky-400 border border-slate-700/60 transition-colors"
          title="Процент"
        >
          %
        </button>
        <button
          type="button"
          onClick={() => handleOperator('÷')}
          className={`h-9 rounded-md border transition-colors ${
            operation === '÷'
              ? 'bg-sky-500 text-slate-950 border-sky-400 font-semibold'
              : 'bg-slate-800/90 hover:bg-slate-700 text-sky-400 border-slate-700/60'
          }`}
          title="Разделить"
        >
          ÷
        </button>

        {/* Row 2 */}
        <button
          type="button"
          onClick={() => handleDigit('7')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          7
        </button>
        <button
          type="button"
          onClick={() => handleDigit('8')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          8
        </button>
        <button
          type="button"
          onClick={() => handleDigit('9')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          9
        </button>
        <button
          type="button"
          onClick={() => handleOperator('×')}
          className={`h-9 rounded-md border transition-colors ${
            operation === '×'
              ? 'bg-sky-500 text-slate-950 border-sky-400 font-semibold'
              : 'bg-slate-800/90 hover:bg-slate-700 text-sky-400 border-slate-700/60'
          }`}
          title="Умножить"
        >
          ×
        </button>

        {/* Row 3 */}
        <button
          type="button"
          onClick={() => handleDigit('4')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          4
        </button>
        <button
          type="button"
          onClick={() => handleDigit('5')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          5
        </button>
        <button
          type="button"
          onClick={() => handleDigit('6')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          6
        </button>
        <button
          type="button"
          onClick={() => handleOperator('−')}
          className={`h-9 rounded-md border transition-colors ${
            operation === '−'
              ? 'bg-sky-500 text-slate-950 border-sky-400 font-semibold'
              : 'bg-slate-800/90 hover:bg-slate-700 text-sky-400 border-slate-700/60'
          }`}
          title="Вычесть"
        >
          −
        </button>

        {/* Row 4 */}
        <button
          type="button"
          onClick={() => handleDigit('1')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          1
        </button>
        <button
          type="button"
          onClick={() => handleDigit('2')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          2
        </button>
        <button
          type="button"
          onClick={() => handleDigit('3')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          3
        </button>
        <button
          type="button"
          onClick={() => handleOperator('+')}
          className={`h-9 rounded-md border transition-colors ${
            operation === '+'
              ? 'bg-sky-500 text-slate-950 border-sky-400 font-semibold'
              : 'bg-slate-800/90 hover:bg-slate-700 text-sky-400 border-slate-700/60'
          }`}
          title="Сложить"
        >
          +
        </button>

        {/* Row 5 */}
        <button
          type="button"
          onClick={handleToggleSign}
          className="h-9 rounded-md bg-slate-800/90 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors"
          title="Смена знака (+/-)"
        >
          ±
        </button>
        <button
          type="button"
          onClick={() => handleDigit('0')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          0
        </button>
        <button
          type="button"
          onClick={() => handleDigit('.')}
          className="h-9 rounded-md bg-slate-950 hover:bg-slate-800 text-white border border-slate-800 hover:border-slate-700 transition-colors"
        >
          ,
        </button>
        <button
          type="button"
          onClick={handleEquals}
          className="h-9 rounded-md bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold shadow-xs transition-colors"
          title="Рассчитать (=)"
        >
          =
        </button>
      </div>
    </div>
  );
};

// Formats number with thousands separation
function formatDisplayNumber(val: number | string): string {
  if (val === undefined || val === null || val === '') return '0';
  const str = String(val);
  const parts = str.split('.');
  const integerPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  if (parts.length > 1) {
    return `${integerPart}.${parts[1]}`;
  }
  return integerPart;
}
