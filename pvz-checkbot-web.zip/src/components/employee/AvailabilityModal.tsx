import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CustomSelect } from '../common/CustomSelect';
import { CustomDatePicker } from '../common/CustomDatePicker';
import { formatDateDDMMYYYY } from '../../utils/time';
import {
  Calendar,
  X,
  Check,
  AlertTriangle,
  GraduationCap,
  Palmtree,
  Stethoscope,
  CalendarCheck,
  Trash2,
  CheckCircle2
} from 'lucide-react';
import { useBottomSheetGesture } from '../../hooks/useBottomSheetGesture';

interface AvailabilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultDate?: string;
}

export const AvailabilityModal: React.FC<AvailabilityModalProps> = ({
  isOpen,
  onClose,
  defaultDate,
}) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  const { availability, currentStaffId, setAvailability, deleteAvailability } = useApp();

  const [date, setDate] = useState(defaultDate || new Date().toISOString().slice(0, 10));
  const [type, setType] = useState<'unavailable' | 'vacation' | 'study' | 'sick' | 'preferred'>('study');
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const myAvailabilities = availability
    .filter(a => a.employeeId === currentStaffId)
    .sort((a, b) => a.date.localeCompare(b.date));

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setActionSuccess(null);
    const res = await setAvailability(date, type, comment);
    setLoading(false);
    if (!res || res.success) {
      setActionSuccess('Пожелание успешно сохранено и отправлено руководителю!');
      setComment('');
      setTimeout(() => setActionSuccess(null), 3500);
    }
  };

  const handleDelete = async (id: string) => {
    setLoading(true);
    await deleteAvailability(id);
    setLoading(false);
  };

  const typeOptions = [
    { value: 'study' as const, label: 'Учёба / Сессия', icon: GraduationCap, color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' },
    { value: 'vacation' as const, label: 'Отпуск / Отгул', icon: Palmtree, color: 'text-sky-400 bg-sky-500/10 border-sky-500/30' },
    { value: 'sick' as const, label: 'Больничный', icon: Stethoscope, color: 'text-rose-400 bg-rose-500/10 border-rose-500/30' },
    { value: 'unavailable' as const, label: 'Личные дела (не могу)', icon: AlertTriangle, color: 'text-orange-400 bg-orange-500/10 border-orange-500/30' },
    { value: 'preferred' as const, label: 'Желаемый день (хочу смену)', icon: CalendarCheck, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' },
  ];

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl"
      >
        
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1.5 bg-slate-700/80 rounded-full pointer-events-none" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800/80 shrink-0">
          <div className="text-white font-semibold text-base">
            <span>Пожелания по графику и отпускам</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4 flex-1 overflow-y-auto overscroll-contain touch-pan-y">
          
          <form onSubmit={handleSave} className="p-4 bg-slate-950/80 rounded-xl space-y-3.5 text-xs shadow-sm">
            <div className="font-medium text-white uppercase text-[11px] tracking-wider text-slate-300">
              Добавить пожелание для руководителя:
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Дата:</label>
                <CustomDatePicker
                  value={date}
                  onChange={v => setDate(v)}
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Категория:</label>
                <CustomSelect<'unavailable' | 'vacation' | 'study' | 'sick' | 'preferred'>
                  value={type}
                  onChange={v => setType(v)}
                  align="right"
                  menuHeaderTitle="Категория пожелания"
                  options={typeOptions.map(opt => ({
                    value: opt.value,
                    label: opt.label,
                    icon: opt.icon,
                  }))}
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Комментарий (опционально):</label>
              <input
                type="text"
                placeholder="Например: экзамен до 15:00"
                value={comment}
                onChange={e => setComment(e.target.value)}
                className="w-full h-10 min-h-[40px] px-3 py-2 bg-slate-950/90 hover:bg-slate-900 focus:ring-1 focus:ring-amber-500/50 rounded-xl text-white text-xs focus:outline-none transition-all shadow-sm"
              />
            </div>

            <div className="pt-1 flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-xl shadow-sm transition-colors disabled:opacity-50"
              >
                {loading ? 'Сохранение...' : 'Отправить пожелание'}
              </button>
            </div>
          </form>

          {/* List of current availability requests */}
          <div className="space-y-2">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Мои отправленные пожелания ({myAvailabilities.length})
            </div>

            {myAvailabilities.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-500 bg-slate-950/40 rounded-xl">
                У вас пока нет сохранённых пожеланий. Руководитель видит вас доступным во все дни.
              </div>
            ) : (
              <div className="space-y-2">
                {myAvailabilities.map(a => {
                  const opt = typeOptions.find(o => o.value === a.type);
                  const Icon = opt?.icon || Calendar;

                  return (
                    <div
                      key={a.id}
                      className="p-3 bg-slate-950/70 rounded-xl flex items-center justify-between text-xs gap-3 shadow-sm"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${opt?.color?.replace(/border[^\s]*/g, '') || 'text-slate-400 bg-slate-800'}`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="font-semibold text-white font-mono flex items-center gap-2 flex-wrap">
                            <span>{formatDateDDMMYYYY(a.date)}</span>
                            <span className="text-[10px] text-slate-400 font-sans font-normal">
                              ({opt?.label || a.type})
                            </span>
                            {a.status === 'approved' ? (
                              <span className="px-1.5 py-0.5 rounded-md text-[ bg-emerald-500/20 text-emerald-300 font-sans px]$2font-medium">
                                Одобрено
                              </span>
                            ) : a.status === 'rejected' ? (
                              <span className="px-1.5 py-0.5 rounded-md text-[ bg-rose-500/20 text-rose-300 font-sans px]$2font-medium">
                                Отклонено
                              </span>
                            ) : (
                              <span className="px-1.5 py-0.5 rounded-md text-[9px] bg-amber-500/20 text-amber-300 font-sans font-medium">
                                На рассмотрении
                              </span>
                            )}
                          </div>
                          {a.comment && (
                            <div className="text-[11px] text-slate-400 italic">
                              &ldquo;{a.comment}&rdquo;
                            </div>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleDelete(a.id)}
                        disabled={loading}
                        className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                        title="Удалить пожелание"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors"
          >
            Закрыть
          </button>
        </div>

      </div>
    </div>
  );
};
