import React, { useState, useEffect } from 'react';
import { ShiftType, SHIFT_LABELS, LocationType } from '../../types';
import { CheckCircle, X, Sun, Zap, Clock, ShieldAlert, Building2, MapPin, Check, Banknote, AlertTriangle, AlertCircle, MessageSquare, Lock, ArrowLeftRight } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { getShiftLabel } from '../../utils/calculations';
import { useBottomSheetGesture } from '../../hooks/useBottomSheetGesture';

interface CheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckIn: (shiftType: ShiftType, location: LocationType, initialCash?: number, cashNotes?: string) => Promise<{ success: boolean; error?: string }> | void;
  onCancelCheckIn?: () => Promise<{ success: boolean; error?: string }> | void;
  currentShift: ShiftType | null;
  currentLocation?: LocationType | null;
  availableLocations: LocationType[];
  initialCashVal?: number;
  editCount?: number;
  cancelCount?: number;
  hasCancelledToday?: boolean;
  onContactManager?: () => void;
}

export const CheckInModal: React.FC<CheckInModalProps> = ({
  isOpen,
  onClose,
  onCheckIn,
  onCancelCheckIn,
  currentShift,
  currentLocation,
  availableLocations,
  initialCashVal,
  editCount = 0,
  cancelCount = 0,
  hasCancelledToday = false,
  onContactManager,
}) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  const { currentStaff, authSession, pickupPoints = [], rates, swaps = [], currentStaffId, todayDate } = useApp();
  const isPartTime = !!currentStaff?.isPartTime;
  const hasExceededEditLimit = !!currentShift && editCount >= 1;
  const hasExceededCancelLimit = cancelCount >= 1 || hasCancelledToday;

  // Active shift types configured for regular staff
  const activeShiftTypes = (rates?.shiftTypes || []).filter((t: any) => !t.isArchived);

  // Active shift types configured for part-time staff
  const activePartTimeTypes = (rates?.partTimeShiftTypes || []).filter((t: any) => !t.isArchived);

  // Check for any approved exchange shift taken by this staff member on today's date
  const targetDate = todayDate || new Date().toISOString().slice(0, 10);
  const approvedExchangeShiftsToday = swaps.filter(
    (s: any) =>
      (s.candidateId === currentStaffId ||
        (authSession?.staffId && s.candidateId === authSession.staffId) ||
        (currentStaff?.name && s.candidateName === currentStaff.name)) &&
      s.status === 'approved' &&
      s.date === targetDate
  );

  // Active/valid pickup point codes from network
  const activePickupPointCodes = new Set(
    (pickupPoints || [])
      .filter(p => p.active !== false && !p.isArchived)
      .map(p => p.code)
  );

  const rawLocations = Array.from(
    new Set([
      ...availableLocations,
      ...approvedExchangeShiftsToday.map((s: any) => s.location).filter(Boolean),
    ])
  );

  // Exclude deactivated, archived, or permanently deleted PVZs (unless it's the currently active shift's location)
  const effectiveAvailableLocations = rawLocations.filter(
    locCode => activePickupPointCodes.has(locCode) || locCode === currentLocation
  );

  // Fallback: If employee has no valid active assigned location, fallback to offering active network locations
  const displayLocations = effectiveAvailableLocations.length > 0
    ? effectiveAvailableLocations
    : Array.from(activePickupPointCodes);

  const hasMultipleLocations = displayLocations.length > 1;

  let shiftOptions: { type: ShiftType; label: string; desc: string; isExchange?: boolean }[] = [];

  if (isPartTime) {
    // 1. Shift(s) approved from Shift Exchange for this part-time worker
    const exchangeOptions = approvedExchangeShiftsToday.map((sw: any) => {
      const shiftName = getShiftLabel(sw.shiftType, rates);
      return {
        type: sw.shiftType as ShiftType,
        label: `${shiftName} (с Биржи смен)`,
        desc: `Подтвержденная смена (замена ${sw.requesterName}, пункт ${sw.location})`,
        isExchange: true,
      };
    });

    // 2. Base shift types configured for part-time worker
    const basePtOptions = activePartTimeTypes.length > 0
      ? activePartTimeTypes.map((t: any) => ({
          type: t.code as ShiftType,
          label: t.name,
          desc: t.name === '4 часа' ? 'Сокращенный график смены (4 ч)' : 'Смена подработчика',
        }))
      : [
          {
            type: '4h' as ShiftType,
            label: '4 часа',
            desc: 'Сокращенный график смены (4 ч)',
          },
          {
            type: 'pt_standard' as ShiftType,
            label: 'Смена подработчика (полная)',
            desc: 'Полный рабочий день подработчика',
          },
        ];

    shiftOptions = [...exchangeOptions, ...basePtOptions];
  } else {
    // Regular employees
    shiftOptions = activeShiftTypes.length > 0
      ? activeShiftTypes.map((t: any) => {
          let desc = t.name;
          if (t.code === 'standard') desc = 'Стандартный полный рабочий день ПВЗ';
          else if (t.code === '400+') desc = 'Интенсивная смена (400+ операций/посылок)';
          else if (t.code === '500+') desc = 'Пиковая смена высокой нагрузки (500+ операций)';
          else if (t.code === '8h') desc = 'Смена 8 часов';
          else if (t.code === '4h') desc = 'Сокращенный график смены (4 ч)';

          return {
            type: t.code as ShiftType,
            label: t.name,
            desc,
          };
        })
      : [
          {
            type: 'standard' as ShiftType,
            label: 'Обычная смена',
            desc: 'Стандартный полный рабочий день ПВЗ',
          },
          {
            type: '400+' as ShiftType,
            label: '400+',
            desc: 'Интенсивная смена (400+ операций/посылок)',
          },
          {
            type: '500+' as ShiftType,
            label: '500+',
            desc: 'Пиковая смена высокой нагрузки (500+ операций)',
          },
          {
            type: '8h' as ShiftType,
            label: '8 часов',
            desc: 'Смена 8 часов',
          },
          {
            type: '4h' as ShiftType,
            label: '4 часа',
            desc: 'Сокращенный график смены (4 ч)',
          },
        ];
  }

  const [selectedShift, setSelectedShift] = useState<ShiftType | null>(() => {
    if (currentShift) return currentShift;
    if (isPartTime && approvedExchangeShiftsToday.length > 0) {
      return approvedExchangeShiftsToday[0].shiftType as ShiftType;
    }
    if (shiftOptions.length > 0) {
      return shiftOptions[0].type;
    }
    return null;
  });

  const [selectedLocation, setSelectedLocation] = useState<LocationType | null>(() => {
    if (currentLocation) return currentLocation;
    if (isPartTime && approvedExchangeShiftsToday.length > 0 && approvedExchangeShiftsToday[0].location) {
      return approvedExchangeShiftsToday[0].location;
    }
    if (displayLocations.length === 1) return displayLocations[0];
    return null;
  });

  const [initialCash, setInitialCash] = useState<string>(initialCashVal ? String(initialCashVal) : '');
  const [cashNotes, setCashNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [isConfirmingCancel, setIsConfirmingCancel] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Keep state synchronized when modal opens
  useEffect(() => {
    if (isOpen) {
      if (currentShift) {
        setSelectedShift(currentShift);
      } else if (isPartTime && approvedExchangeShiftsToday.length > 0) {
        setSelectedShift(approvedExchangeShiftsToday[0].shiftType as ShiftType);
      } else if (shiftOptions.length > 0) {
        setSelectedShift(shiftOptions[0].type);
      } else {
        setSelectedShift(null);
      }

      if (currentLocation) {
        setSelectedLocation(currentLocation);
      } else if (isPartTime && approvedExchangeShiftsToday.length > 0 && approvedExchangeShiftsToday[0].location) {
        setSelectedLocation(approvedExchangeShiftsToday[0].location);
      } else if (displayLocations.length > 0) {
        setSelectedLocation(displayLocations[0]);
      } else {
        setSelectedLocation(null);
      }

      setInitialCash(initialCashVal ? String(initialCashVal) : '');
      setErrorMsg(null);
      setIsSubmitting(false);
      setIsCancelling(false);
      setIsConfirmingCancel(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const canConfirm = !hasExceededEditLimit && !!selectedShift && !!selectedLocation && !isSubmitting;

  const handleExecuteCancel = async () => {
    if (!onCancelCheckIn) return;
    setIsCancelling(true);
    setErrorMsg(null);
    const res = await onCancelCheckIn();
    setIsCancelling(false);
    setIsConfirmingCancel(false);
    if (res && typeof res === 'object' && res.success === false) {
      setErrorMsg(res.error || 'Ошибка при отмене Check-in');
      return;
    }
    onClose();
  };

  const handleConfirm = async () => {
    if (hasExceededEditLimit) {
      setErrorMsg('Работник может изменять свою смену только один раз. Для изменения смены обратитесь к руководителю.');
      return;
    }
    if (selectedShift && selectedLocation) {
      setIsSubmitting(true);
      setErrorMsg(null);
      const cashNum = initialCash ? parseFloat(initialCash) : undefined;
      const res = await onCheckIn(selectedShift, selectedLocation, cashNum, cashNotes);
      setIsSubmitting(false);
      if (res && typeof res === 'object' && res.success === false) {
        setErrorMsg(res.error || 'Ошибка при изменении смены');
        return;
      }
      onClose();
    }
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl"
      >
        
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1.5 bg-slate-700/80 rounded-full pointer-events-none" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800/80 shrink-0">
          <div className="text-slate-100 font-semibold text-base">
            <span>{currentShift ? 'Изменение параметров смены' : 'Отметка о выходе на смену'}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 space-y-4 flex-1 overflow-y-auto overscroll-contain touch-pan-y">

          {/* API Error Notification */}
          {errorMsg && (
            <div className="p-3 bg-red-950/50 rounded-xl text-xs text-red-200 flex items-start gap-2 animate-fade-in">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold">{errorMsg}</p>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onContactManager?.();
                  }}
                  className="mt-1 inline-flex items-center gap-1 text-[11px] text-amber-300 hover:text-amber-200 underline font-medium"
                >
                  <MessageSquare className="w-3 h-3" />
                  <span>Написать руководителю</span>
                </button>
              </div>
            </div>
          )}

          {/* Limit Exceeded Notice */}
          {hasExceededEditLimit ? (
            <div className="p-4 bg-amber-950/40 rounded-xl space-y-3 animate-fade-in">
              <div className="flex items-start gap-2.5">
                <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="font-semibold text-slate-100 text-xs sm:text-sm">Лимит изменений исчерпан (1/1)</h4>
                  <p className="text-xs text-amber-200/90 leading-relaxed">
                    Работник может менять свою отмеченную смену <strong>только один раз</strong>. Вы уже использовали эту возможность.
                  </p>
                  <p className="text-xs text-slate-300 leading-relaxed mt-1">
                    В случае необходимости изменить смену можно <strong>только написав руководителю</strong>, чтобы руководитель сам внёс изменение в систему.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onContactManager?.();
                }}
                className="w-full py-2 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Написать руководителю</span>
              </button>
            </div>
          ) : currentShift ? (
            /* Warning Banner when editing shift for the allowed 1 time */
            <div className="p-3.5 bg-amber-950/30 rounded-xl text-xs space-y-1.5 animate-fade-in">
              <div className="flex items-center gap-2 font-semibold text-amber-300">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Уведомление: смену можно изменить только один раз!</span>
              </div>
              <p className="text-slate-200 text-xs leading-relaxed">
                Работник может менять свою отмеченную смену <strong>только один раз</strong>.
              </p>
              <p className="text-[11px] text-amber-200/80 leading-relaxed">
                В случае необходимости повторного изменения поменять смену можно будет <strong>только написав руководителю</strong>, чтобы руководитель сам внёс изменение.
              </p>
            </div>
          ) : null}

          {/* Step 1: Location Selection */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-medium">1</span>
                <span>Место работы (Пункт) *</span>
              </label>
              {selectedLocation && (
                <span className="text-[11px] font-semibold text-emerald-400">
                  Выбран пункт {selectedLocation}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-full">
              {displayLocations.map(loc => {
                const isSelected = selectedLocation === loc;
                const matchedPoint = pickupPoints.find(p => p.code === loc || p.id === loc || p.name === loc);
                const locName = matchedPoint ? matchedPoint.name : `Пункт ${loc}`;
                const locAddress = matchedPoint?.address || 'Пункт выдачи';

                return (
                  <button
                    key={loc}
                    type="button"
                    onClick={() => setSelectedLocation(loc)}
                    className={`w-full p-3 rounded-xl text-left transition-all flex items-center justify-between gap-2.5 min-w-0 overflow-hidden border cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-500/15 border-emerald-500 ring-1 ring-emerald-500/40 text-slate-100 shadow-sm'
                        : 'bg-slate-800/40 dark:bg-slate-800/60 border-slate-700/80 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' : 'bg-slate-900 text-slate-400'
                      }`}>
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1 overflow-hidden">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 font-mono text-xs font-bold shrink-0">
                            {loc}
                          </span>
                          <span className="font-semibold text-xs sm:text-sm text-slate-100 truncate block">
                            {locName}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 truncate mt-0.5" title={locAddress}>
                          {locAddress}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-900 border border-slate-700'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Shift Type Selection */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-medium">2</span>
                <span>Тип смены *</span>
              </label>
              {selectedShift && (
                <span className="text-[11px] font-semibold text-emerald-400">
                  {getShiftLabel(selectedShift, rates)}
                </span>
              )}
            </div>

            <div className="space-y-2">
              {shiftOptions.map((opt: any) => {
                const isChosen = selectedShift === opt.type;
                return (
                  <button
                    key={opt.type}
                    type="button"
                    onClick={() => setSelectedShift(opt.type)}
                    className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-all border cursor-pointer ${
                      isChosen
                        ? 'bg-emerald-500/15 border-emerald-500 ring-1 ring-emerald-500/40 text-slate-100 shadow-sm'
                        : 'bg-slate-800/40 dark:bg-slate-800/60 border-slate-700/80 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <div>
                      <div className="text-xs sm:text-sm font-semibold text-slate-100">{opt.label}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{opt.desc}</div>
                    </div>
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center transition-all shrink-0 ml-2 ${
                        isChosen
                          ? 'bg-emerald-600 border-2 border-emerald-600 text-white shadow-sm'
                          : 'bg-slate-900 border-2 border-slate-600 dark:border-slate-700'
                      }`}
                    >
                      {isChosen && <div className="w-2.5 h-2.5 rounded-full bg-white"></div>}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Action buttons */}
        <div className="p-4 bg-slate-900/60 flex items-center justify-between gap-3">
          {hasExceededEditLimit ? (
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl transition-colors ml-auto"
            >
              Закрыть
            </button>
          ) : (
            <>
              {currentShift && onCancelCheckIn ? (
                hasExceededCancelLimit ? (
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg('Работник может отменить Check-in только один раз. В случае необходимости обратитесь к руководителю, чтобы руководитель сам внёс изменение.');
                    }}
                    className="px-3.5 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800/80 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                    title="Лимит отмены исчерпан (1/1)"
                  >
                    <Lock className="w-3.5 h-3.5 text-slate-500" />
                    <span>Отмена исчерпана (1/1)</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setIsConfirmingCancel(true)}
                    disabled={isSubmitting || isCancelling}
                    className="px-3.5 py-2 text-xs font-medium text-rose-400 hover:bg-rose-950/40 rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    Отменить Check-in
                  </button>
                )
              ) : (
                <button
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-xl transition-colors"
                >
                  Отмена
                </button>
              )}

              <button
                disabled={!canConfirm}
                onClick={handleConfirm}
                className={`px-5 py-2 text-xs font-semibold rounded-xl transition-all shadow-sm flex items-center gap-1.5 ${
                  canConfirm
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20 cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>
                  {isSubmitting
                    ? 'Сохранение...'
                    : !selectedLocation && hasMultipleLocations
                    ? 'Выберите место работы'
                    : !selectedShift
                    ? 'Выберите тип смены'
                    : currentShift
                    ? `Сохранить смену (${selectedLocation})`
                    : `Подтвердить Check-in (${selectedLocation})`}
                </span>
              </button>
            </>
          )}
        </div>

      </div>

      {/* Cancel Check-in Confirmation Modal */}
      {isConfirmingCancel && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md max-h-[90dvh] flex flex-col p-5 space-y-4 shadow-2xl overflow-y-auto my-auto">
            <div className="flex items-center gap-3 shrink-0">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Подтверждение отмены Check-in</h4>
                <p className="text-xs text-slate-400">Правило однократной отмены</p>
              </div>
            </div>

            <div className="p-3.5 bg-amber-950/30 rounded-xl text-xs space-y-2">
              <p className="font-semibold text-amber-300 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Отменить Check-in можно только 1 раз!</span>
              </p>
              <p className="text-slate-200 leading-relaxed text-xs">
                Работник может отменить Check-in <strong>только один раз</strong>.
              </p>
              <p className="text-amber-200/80 leading-relaxed text-[11px]">
                В случае необходимости повторной отметки или корректировки, повторно отменить смену самостоятельно будет нельзя — только написав руководителю, чтобы руководитель сам внёс изменение.
              </p>
            </div>

            <p className="text-xs text-slate-300">
              Вы точно хотите отменить текущий выход на смену?
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsConfirmingCancel(false)}
                disabled={isCancelling}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
              >
                Вернуться
              </button>
              <button
                type="button"
                onClick={handleExecuteCancel}
                disabled={isCancelling}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-xl transition-colors shadow-sm disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
              >
                {isCancelling ? 'Отмена...' : 'Да, точно отменить Check-in'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
