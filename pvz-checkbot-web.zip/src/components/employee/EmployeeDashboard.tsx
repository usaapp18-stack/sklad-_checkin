import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SHIFT_LABELS, ShiftType, LocationType } from '../../types';
import { calculateDailySales, formatCurrency, formatDateDDMMYYYY, getBaseShiftPay, normalizeShiftType, calculateShiftTotalSalary, getShiftLabel } from '../../utils/calculations';
import { formatDisplayDate, parseDateSafe } from '../../utils/time';
import { CheckInModal } from './CheckInModal';
import { SalesEntryModal } from './SalesEntryModal';
import { MessageManagerModal } from './MessageManagerModal';
import { ShiftStatsView } from './ShiftStatsView';
import { IncomeGoalCalculatorWidget } from './IncomeGoalCalculatorWidget';
import { PWAInstallButton } from '../PWAInstallButton';
import { AvailabilityModal } from './AvailabilityModal';
import { EmployeeSwapModal } from './EmployeeSwapModal';
import {
  CheckCircle2,
  Clock,
  TrendingUp,
  DollarSign,
  MessageSquare,
  BarChart3,
  Edit3,
  Calendar,
  Lock,
  Camera,
  Award,
  Printer,
  Layers,
  ArrowRight,
  ShieldAlert,
  X,
  Check,
  Building2,
  ChevronLeft,
  ChevronRight,
  Coins,
  Briefcase,
  ArrowLeftRight,
  Target,
  GraduationCap,
  Palmtree,
  Stethoscope,
  AlertTriangle,
} from 'lucide-react';

export const EmployeeDashboard: React.FC = () => {
  const {
    currentStaff,
    currentStaffId,
    records,
    cancelledDates = [],
    availability,
    swaps,
    schedules = [],
    todayDate,
    performCheckIn,
    cancelCheckIn,
    submitSales,
    notifications,
    markNotificationRead,
    rates,
    pickupPoints = [],
  } = useApp();

  const [isCheckInOpen, setIsCheckInOpen] = useState(false);
  const [isSalesOpen, setIsSalesOpen] = useState(false);
  const [isMessageOpen, setIsMessageOpen] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [isAvailOpen, setIsAvailOpen] = useState(false);
  const [isSwapOpen, setIsSwapOpen] = useState(false);


  // Premium Calendar state and logic
  const [calendarYear, setCalendarYear] = useState<number>(new Date().getFullYear());
  const [calendarMonth, setCalendarMonth] = useState<number>(new Date().getMonth()); // 0-11
  const [selectedDayNum, setSelectedDayNum] = useState<number | null>(new Date().getDate());

  const handlePrevMonth = () => {
    if (calendarMonth === 0) {
      setCalendarMonth(11);
      setCalendarYear(prev => prev - 1);
    } else {
      setCalendarMonth(prev => prev - 1);
    }
    setSelectedDayNum(null);
  };

  const handleNextMonth = () => {
    if (calendarMonth === 11) {
      setCalendarMonth(0);
      setCalendarYear(prev => prev + 1);
    } else {
      setCalendarMonth(prev => prev + 1);
    }
    setSelectedDayNum(null);
  };

  const monthNamesRu = [
    'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
  ];

  const getShiftBaseSalaryForRecord = (rec: any) => {
    return calculateShiftTotalSalary(rec, currentStaff, rates);
  };

  if (!currentStaff || currentStaff.status !== 'active') {
    return (
      <div className="max-w-2xl mx-auto py-12 px-4 text-center">
        <div className="p-8 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
          <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-semibold text-white">Доступ к учетной записи ограничен</h2>
          <p className="text-xs text-slate-400 leading-relaxed max-w-md mx-auto">
            Ваш аккаунт находится в статусе «{currentStaff?.status || 'Ожидает'}». Обратитесь к руководителю для открытия доступа.
          </p>
        </div>
      </div>
    );
  }

  const todayRecords = records.filter(r => r.employeeId === currentStaffId && r.date === todayDate);
  const todayRecord = todayRecords.length > 0 ? todayRecords[todayRecords.length - 1] : undefined;
  const hasCheckedIn = !!todayRecord?.shiftType;
  const hasSubmittedSales = !!todayRecord?.sales;
  const isPartTime = !!currentStaff?.isPartTime;
  const editCount = Number(todayRecord?.editCount || 0);
  const hasUsedEdit = editCount >= 1;
  const cancelCount = Number(todayRecord?.cancelCount || 0) + (cancelledDates.includes(todayDate) ? 1 : 0);
  const hasUsedCancel = cancelCount >= 1;
  const salesSummary = calculateDailySales(todayRecord?.sales);

  // Premium Calendar calculations
  const calendarMonthStr = `${calendarYear}-${String(calendarMonth + 1).padStart(2, '0')}`;
  const empMonthRecords = records.filter(r => 
    r.employeeId === currentStaffId && 
    r.date.startsWith(calendarMonthStr)
  );

  // Map to check if worked
  const empMonthRecordsMap = new Map<string, any>();
  empMonthRecords.forEach(r => {
    empMonthRecordsMap.set(r.date, r);
  });

  // Planned shifts for employee in this month
  const empMonthPlannedShifts = schedules.filter(s =>
    String(s.employeeId) === String(currentStaffId) &&
    s.date.startsWith(calendarMonthStr)
  );

  const formatShiftCountRu = (cnt: number) => {
    const mod10 = cnt % 10;
    const mod100 = cnt % 100;
    if (mod100 >= 11 && mod100 <= 19) return `${cnt} смен`;
    if (mod10 === 1) return `${cnt} смена`;
    if (mod10 >= 2 && mod10 <= 4) return `${cnt} смены`;
    return `${cnt} смен`;
  };

  const calendarDaysCount = new Date(calendarYear, calendarMonth + 1, 0).getDate();
  let firstDayIdx = new Date(calendarYear, calendarMonth, 1).getDay();
  firstDayIdx = firstDayIdx === 0 ? 6 : firstDayIdx - 1; // Mon-indexed

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstDayIdx; i++) {
    cells.push(null);
  }
  for (let d = 1; d <= calendarDaysCount; d++) {
    cells.push(d);
  }

  // Robust date comparison helper (handles ISO, YYYY-MM-DD, DD-MM-YYYY)
  const isSameDate = (d1?: string, d2?: string) => {
    if (!d1 || !d2) return false;
    const clean1 = d1.split('T')[0].trim();
    const clean2 = d2.split('T')[0].trim();
    if (clean1 === clean2) return true;
    const p1 = clean1.split(/[-.]/);
    const p2 = clean2.split(/[-.]/);
    if (p1.length === 3 && p2.length === 3) {
      const y1 = p1[0].length === 4 ? p1[0] : p1[2];
      const m1 = p1[1].padStart(2, '0');
      const day1 = p1[0].length === 4 ? p1[2].padStart(2, '0') : p1[0].padStart(2, '0');

      const y2 = p2[0].length === 4 ? p2[0] : p2[2];
      const m2 = p2[1].padStart(2, '0');
      const day2 = p2[0].length === 4 ? p2[2].padStart(2, '0') : p2[0].padStart(2, '0');

      return y1 === y2 && m1 === m2 && day1 === day2;
    }
    return false;
  };

  // Selected date details
  const selectedDateString = selectedDayNum
    ? `${calendarYear}-${String(calendarMonth + 1).padStart(2, '0')}-${String(selectedDayNum).padStart(2, '0')}`
    : '';
  const selectedDayRecord = empMonthRecordsMap.get(selectedDateString);

  // My availability for selected day
  const selectedDayAvail = availability.find(
    a => String(a.employeeId) === String(currentStaffId) && isSameDate(a.date, selectedDateString)
  );

  const activePickupPointCodes = new Set<string>(
    (pickupPoints || [])
      .filter((p: any) => p.active !== false && !p.isArchived)
      .map((p: any) => p.code)
  );

  const rawStaffLocations = currentStaff.locations || (currentStaff.location ? [currentStaff.location] : []);
  const staffLocations = rawStaffLocations.filter(locCode => activePickupPointCodes.has(locCode));
  const effectiveStaffLocations: LocationType[] = staffLocations.length > 0 ? staffLocations : Array.from(activePickupPointCodes);

  // Open swaps available on market
  const openMarketSwapsCount = swaps.filter(s => s.status === 'open' && s.requesterId !== currentStaffId).length;

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 sm:px-6 space-y-6">
      
      {/* Welcome & Profile Header (ERP standard) */}
      <div className="p-4 sm:p-5 bg-slate-900 border border-slate-800 rounded-lg shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs text-slate-400 font-normal">
              Рабочее место сотрудника {staffLocations.length > 0 ? `· Пункт ${staffLocations.join(', ')}` : ''}
            </div>
            <h1 className="text-lg sm:text-xl font-medium text-white mt-0.5 flex items-center gap-1.5 flex-wrap">
              <span>{currentStaff.name}</span>
              {currentStaff.isSenior && (
                <span className="text-emerald-700 dark:text-purple-400 text-xs font-medium">· Старший смены</span>
              )}
              {currentStaff.isPartTime && (
                <span className="text-amber-400 text-xs font-normal">· Подработчик</span>
              )}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Сегодня: {formatDisplayDate(todayDate)}
            </p>
          </div>

          {/* Quick Toolbar */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setIsAvailOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/80 rounded-md text-xs font-medium transition-colors cursor-pointer"
              title="Пожелания по графику и отпускам"
            >
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Пожелания</span>
            </button>

            <button
              onClick={() => setIsSwapOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/80 rounded-md text-xs font-medium transition-colors relative cursor-pointer"
              title="Биржа смен и подмен"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-slate-400" />
              <span>Биржа смен</span>
              {openMarketSwapsCount > 0 && (
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              )}
            </button>

            <button
              onClick={() => setIsStatsOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/80 rounded-md text-xs font-medium transition-colors cursor-pointer"
            >
              <BarChart3 className="w-3.5 h-3.5 text-slate-400" />
              <span>Показатели</span>
            </button>

            <button
              onClick={() => setIsMessageOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/80 rounded-md text-xs font-medium transition-colors cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
              <span>Сообщение</span>
            </button>
          </div>
        </div>
      </div>

      {/* Feature 1: Income Goal & Forecast Widget */}
      <IncomeGoalCalculatorWidget />

      {/* Worked Days Calendar */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-lg space-y-5 shadow-sm">
        {/* Calendar Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-sm font-medium text-white">Календарь смен</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Начисления, плановые и отработанные смены по дням
            </p>
          </div>

          {/* Controls & Mini Counter */}
          <div className="flex items-center justify-between sm:justify-end gap-3 flex-wrap">
            <div className="px-3 py-1 rounded-md bg-slate-850 border border-slate-800 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"></div>
              <span className="text-xs font-medium text-slate-200 font-mono">
                Смен: {empMonthRecordsMap.size}
              </span>
            </div>

            <div className="flex items-center bg-slate-950 p-0.5 rounded-md border border-slate-800">
              <button
                onClick={handlePrevMonth}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-900 rounded transition-colors cursor-pointer"
                title="Предыдущий месяц"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-xs font-medium text-slate-200 px-3 min-w-[100px] text-center font-mono">
                {monthNamesRu[calendarMonth]} {calendarYear}
              </span>
              <button
                onClick={handleNextMonth}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-900 rounded transition-colors cursor-pointer"
                title="Следующий месяц"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Calendar Grid & Details side-by-side */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
          
          {/* Left Column: Calendar Grid */}
          <div className="md:col-span-7">
            <div className="grid grid-cols-7 gap-1 text-center">
              {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map((day, idx) => (
                <div
                  key={day}
                  className={`text-[11px] font-medium py-1 font-mono ${
                    idx >= 5 ? 'text-rose-400/80 font-medium' : 'text-slate-400'
                  }`}
                >
                  {day}
                </div>
              ))}

              {cells.map((dayNum, idx) => {
                if (dayNum === null) {
                  return <div key={`empty-${idx}`} className="aspect-square"></div>;
                }

                const cellDateStr = `${calendarYear}-${String(calendarMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
                const hasShift = empMonthRecordsMap.has(cellDateStr);
                const isSelected = selectedDayNum === dayNum;
                const isToday =
                  new Date().getDate() === dayNum &&
                  new Date().getMonth() === calendarMonth &&
                  new Date().getFullYear() === calendarYear;

                // Check my availability on this cell
                const myAvail = availability.find(
                  a => String(a.employeeId) === String(currentStaffId) && isSameDate(a.date, cellDateStr)
                );
                const myApprovedSwap = swaps.find(s => s.candidateId === currentStaffId && s.status === 'approved' && s.date === cellDateStr);
                const myPlannedShift = schedules.find(s => s.employeeId === currentStaffId && s.date === cellDateStr);

                let cellStyle = 'bg-slate-950/40 border border-slate-900/60 text-slate-400';
                if (hasShift) {
                  cellStyle = 'bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 font-medium';
                } else if (myApprovedSwap) {
                  cellStyle = 'bg-sky-500/15 border border-sky-400/50 text-sky-300 font-medium';
                } else if (myPlannedShift) {
                  cellStyle = 'bg-indigo-500/15 border border-indigo-500/40 text-indigo-300 font-medium';
                } else if (myAvail) {
                  cellStyle = 'bg-amber-500/10 border border-amber-500/30 text-amber-300 font-medium';
                }

                // Actual date
                if (isToday) {
                  cellStyle += ' ring-1.5 ring-amber-400/90 relative';
                  if (!hasShift && !myApprovedSwap && !myPlannedShift && !myAvail) {
                    cellStyle += ' bg-amber-500/10 border-amber-400/40 text-amber-200 font-medium';
                  }
                }

                if (isSelected) {
                  cellStyle += ' ring-2 ring-emerald-400 ring-offset-1 ring-offset-slate-950';
                }

                return (
                  <button
                    key={`day-${dayNum}`}
                    onClick={() => setSelectedDayNum(dayNum)}
                    className={`aspect-square rounded-md flex flex-col items-center justify-center relative cursor-pointer transition-colors select-none ${cellStyle}`}
                  >
                    {/* Мягкий бейдж актуальной даты */}
                    {isToday && (
                      <span className="absolute -top-1 left-1/2 -translate-x-1/2 px-1 py-0.2 bg-amber-400 text-slate-950 font-medium text-[7px] uppercase tracking-wider rounded-sm pointer-events-none whitespace-nowrap z-10 leading-tight">
                        Сегодня
                      </span>
                    )}

                    <span className={`text-xs font-mono ${isToday ? 'font-semibold text-amber-300' : ''}`}>{dayNum}</span>

                    {/* Bottom dots wrapper */}
                    <div className="absolute bottom-1.5 flex items-center justify-center gap-1">
                      {myApprovedSwap && myAvail ? (
                        <>
                          <span className="w-1.5 h-1.5 rounded-full bg-sky-400" title="Смена с биржи" />
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" title="Пожелание" />
                        </>
                      ) : hasShift && myAvail ? (
                        <>
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Отработанная смена" />
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" title="Пожелание" />
                        </>
                      ) : myPlannedShift && myAvail ? (
                        <>
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" title="Запланированная смена" />
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" title="Пожелание" />
                        </>
                      ) : hasShift ? (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      ) : myApprovedSwap ? (
                        <span className="w-1.5 h-1.5 rounded-full bg-sky-400"></span>
                      ) : myPlannedShift ? (
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                      ) : myAvail ? (
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                      ) : null}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Calendar Legend Markers Bar */}
            <div className="flex items-center gap-3 text-[10px] sm:text-[11px] text-slate-400 flex-wrap pt-3 mt-3 border-t border-slate-800/80">
              <span className="flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.6)]"></span>
                <span>Отработана ({formatShiftCountRu(empMonthRecordsMap.size)})</span>
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 shadow-[0_0_6px_rgba(129,140,248,0.6)]"></span>
                <span>Запланирована ({formatShiftCountRu(empMonthPlannedShifts.length)})</span>
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-full ring-2 ring-amber-400 bg-amber-400/40"></span>
                <span>Сегодня (Текущая дата)</span>
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400"></span>
                <span>Смена с Биржи</span>
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                <span>Пожелание / Выходной</span>
              </span>
            </div>
          </div>

          {/* Right Column: Selected Day Details */}
          <div className="md:col-span-5 space-y-3">
            {selectedDayAvail && (
              <div className="p-3 bg-amber-950/40 border border-amber-500/40 rounded-2xl text-xs space-y-1 shadow-sm animate-fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-medium text-amber-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    <span>Пожелание на день:</span>
                  </span>
                  <strong className="font-semibold text-amber-300">
                    {
                      {
                        study: 'Учёба / Сессия',
                        vacation: 'Отпуск / Отгул',
                        sick: 'Больничный',
                        unavailable: 'Личные дела (не могу)',
                        preferred: 'Желаемый день (хочу смену)',
                      }[selectedDayAvail.type] || selectedDayAvail.type
                    }
                  </strong>
                </div>
                {selectedDayAvail.comment && (
                  <p className="text-[11px] text-slate-300 italic pt-0.5">&ldquo;{selectedDayAvail.comment}&rdquo;</p>
                )}
              </div>
            )}

            {selectedDayRecord ? (
              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl space-y-4 shadow-sm animate-fade-in">
                
                {/* Header info */}
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <div>
                    <div className="text-[10px] uppercase font-medium text-slate-400">Детали смены</div>
                    <div className="text-sm font-semibold text-white font-mono">{formatDateDDMMYYYY(selectedDayRecord.date)}</div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {selectedDayRecord.location && (
                      <span className="text-xs $2font-medium px-2 py-0.5 rounded bg-slate-800 text-emerald-400">
                        {selectedDayRecord.location}
                      </span>
                    )}
                    <span className="text-xs $2font-medium px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300">
                      {getShiftLabel(selectedDayRecord.shiftType, rates)}
                    </span>
                  </div>
                </div>

                {/* 3 Metrics */}
                <div className="space-y-2">
                  <div className="p-3 bg-slate-900 border border-slate-850 rounded-xl flex items-center justify-between gap-2">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1 text-[9px] text-slate-400 font-semibold uppercase tracking-wider">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        <span>Оклад за смену</span>
                      </div>
                      <div className="text-[10px] text-slate-500 leading-none">
                        Чекин: {selectedDayRecord.checkedInAt ? selectedDayRecord.checkedInAt.slice(11, 16) : '08:55'}
                      </div>
                    </div>
                    <div className="text-xs font-semibold font-mono text-sky-400">
                      {formatCurrency(getShiftBaseSalaryForRecord(selectedDayRecord))}
                    </div>
                  </div>

                  <div className="p-3 bg-slate-900 border border-slate-850 rounded-xl flex items-center justify-between gap-2">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1 text-[9px] text-slate-400 font-semibold uppercase tracking-wider">
                        <TrendingUp className="w-3.5 h-3.5 text-slate-500" />
                        <span>Премия (5% выручки)</span>
                      </div>
                      <div className="text-[10px] text-slate-500 leading-none">
                        Выручка: {formatCurrency(calculateDailySales(selectedDayRecord.sales).totalSales)}
                      </div>
                    </div>
                    <div className="text-xs font-semibold font-mono text-emerald-400">
                      +{formatCurrency(calculateDailySales(selectedDayRecord.sales).bonus)}
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-between gap-2 relative overflow-hidden">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1 text-[9px] text-emerald-400 font-medium uppercase tracking-wider">
                        <Coins className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Итого за день</span>
                      </div>
                      <div className="text-[9px] text-emerald-500/80 font-medium leading-none">
                        Зачислено на баланс
                      </div>
                    </div>
                    <div className="text-sm font-semibold font-mono text-emerald-400">
                      {formatCurrency(getShiftBaseSalaryForRecord(selectedDayRecord) + calculateDailySales(selectedDayRecord.sales).bonus)}
                    </div>
                  </div>
                </div>
              </div>
            ) : selectedDateString && swaps.find(s => s.candidateId === currentStaffId && s.status === 'approved' && s.date === selectedDateString) ? (() => {
              const approvedSwap = swaps.find(s => s.candidateId === currentStaffId && s.status === 'approved' && s.date === selectedDateString)!;
              return (
                <div className="p-4 bg-slate-950/80 border border-sky-500/40 rounded-2xl space-y-3.5 shadow-sm animate-fade-in">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <div className="text-[10px] uppercase font-medium text-sky-400 flex items-center gap-1">
                        <ArrowLeftRight className="w-3.5 h-3.5" />
                        <span>Смена с Биржи (Согласовано)</span>
                      </div>
                      <div className="text-sm font-semibold text-white font-mono">{formatDateDDMMYYYY(selectedDateString)}</div>
                    </div>
                    <span className="text-xs $2font-medium px-2 py-0.5 rounded bg-sky-500/20 text-sky-300">
                      Пункт {approvedSwap.location}
                    </span>
                  </div>

                  <div className="text-xs space-y-2 text-slate-300">
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                      <div className="text-slate-400 text-[11px]">Категория смены:</div>
                      <div className="font-semibold text-white text-xs">{getShiftLabel(approvedSwap.shiftType, rates)}</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                      <div className="text-slate-400 text-[11px]">Передал замену:</div>
                      <div className="font-semibold text-white text-xs">{approvedSwap.requesterName}</div>
                    </div>
                  </div>

                  <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Замена согласована! Выходите на смену в этот день на пункте {approvedSwap.location}.</span>
                  </div>
                </div>
              );
            })() : selectedDateString && schedules.find(s => s.employeeId === currentStaffId && s.date === selectedDateString) ? (() => {
              const planned = schedules.find(s => s.employeeId === currentStaffId && s.date === selectedDateString)!;
              return (
                <div className="p-4 bg-slate-950/80 border border-indigo-500/40 rounded-2xl space-y-3.5 shadow-sm animate-fade-in">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div>
                      <div className="text-[10px] uppercase font-medium text-indigo-400 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Плановая смена по графику</span>
                      </div>
                      <div className="text-sm font-semibold text-white font-mono">{formatDateDDMMYYYY(selectedDateString)}</div>
                    </div>
                    <span className="text-xs $2font-medium px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                      Пункт {planned.location}
                    </span>
                  </div>

                  <div className="text-xs space-y-2 text-slate-300">
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                      <div className="text-slate-400 text-[11px]">Категория смены:</div>
                      <div className="font-semibold text-white text-xs">{getShiftLabel(planned.shiftType, rates)}</div>
                    </div>
                  </div>
                </div>
              );
            })() : (
              <div className="p-5 bg-slate-950/40 rounded-2xl border border-slate-900/80 text-center text-[11px] text-slate-500 h-full flex flex-col justify-center min-h-[180px] space-y-2">
                {selectedDayNum ? (
                  <div>
                    <p className="font-semibold text-slate-400">
                      {selectedDayNum}.{String(calendarMonth + 1).padStart(2, '0')}.{calendarYear}
                    </p>
                    {!selectedDayAvail && (
                      <p className="text-[10px] text-slate-500 my-1">Смена не зафиксирована.</p>
                    )}
                    <button
                      onClick={() => setIsAvailOpen(true)}
                      className="mt-2 text-xs text-amber-400 hover:text-amber-300 underline font-medium cursor-pointer"
                    >
                      + Указать пожелание на этот день
                    </button>
                  </div>
                ) : (
                  <p>Выберите любой день на календаре для просмотра деталей смены</p>
                )}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Main Actions Grid (Check-in & Sales) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Step 1: Check-in Card */}
        <div className={`p-4 sm:p-5 rounded-lg border transition-colors shadow-sm ${
          hasCheckedIn
            ? 'bg-slate-900 border-slate-700/80'
            : 'bg-slate-900 border-slate-800'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-300">
              <span className="w-5 h-5 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-xs font-mono">1</span>
              <span>Дневной Check-in</span>
            </div>
            {hasCheckedIn ? (
              <span className="text-xs font-medium text-emerald-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>Пройден</span>
              </span>
            ) : (
              <span className="text-xs font-medium text-amber-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span>Ожидает отметки</span>
              </span>
            )}
          </div>

          <div className="space-y-3">
            {hasCheckedIn ? (
              <div className="p-3.5 bg-slate-950/70 rounded-md border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Выбранная смена:</span>
                  {todayRecord.location && (
                    <span className="font-mono text-slate-200">
                      Пункт {todayRecord.location}
                    </span>
                  )}
                </div>
                <div className="text-base font-medium text-white flex items-center gap-2">
                  <span>{getShiftLabel(todayRecord.shiftType, rates)}</span>
                  <span className="text-xs text-emerald-400 font-normal">
                    · Активна
                  </span>
                </div>
                <div className="text-xs text-slate-500 flex items-center gap-1.5 pt-0.5">
                  <Clock className="w-3.5 h-3.5 text-slate-500" />
                  <span>Отмечено в {parseDateSafe(todayRecord.checkedInAt || todayRecord.timestamp).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>

                {hasUsedEdit && (
                  <div className="p-2.5 bg-amber-950/30 border border-amber-500/25 rounded-md text-xs text-amber-300 flex items-start gap-2 mt-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <p className="font-medium text-xs text-amber-300">Лимит изменений исчерпан (1/1)</p>
                      <p className="text-[11px] text-amber-200/80 leading-relaxed">
                        Работник может менять смену только 1 раз. При необходимости изменений обратитесь к руководителю, чтобы он сам внёс правки.
                      </p>
                    </div>
                  </div>
                )}

                {hasUsedCancel && (
                  <div className="p-2 bg-slate-900 border border-slate-800 rounded-md text-xs text-slate-400 flex items-center gap-1.5 mt-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                    <span>Отмена Check-in использована (1/1). Повторная отмена — через руководителя.</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-3.5 bg-slate-950/40 rounded-md border border-slate-800/60 text-xs text-slate-400 leading-relaxed space-y-2">
                {hasUsedCancel && (
                  <div className="p-2.5 bg-amber-950/30 border border-amber-500/25 rounded-md text-xs text-amber-300 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <p className="font-medium text-xs text-amber-300">Check-in сегодня был отменён (1/1)</p>
                      <p className="text-[11px] text-amber-200/80 leading-relaxed">
                        Вы уже использовали право на одну отмену Check-in сегодня. Вы можете отметить смену снова, но повторно отменить её самостоятельно будет нельзя.
                      </p>
                    </div>
                  </div>
                )}
                {staffLocations.length > 1 ? (
                  <span>Вам присвоено несколько мест работы. При отметке Check-in выберите нужный пункт и категорию смены.</span>
                ) : (
                  <span>Нажмите кнопку ниже, чтобы отметить начало смены {staffLocations[0] ? `(Пункт ${staffLocations[0]})` : ''}.</span>
                )}
              </div>
            )}

            {hasCheckedIn && hasUsedEdit ? (
              <button
                onClick={() => setIsMessageOpen(true)}
                className="w-full py-2 px-3.5 rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-750 text-amber-300 border border-slate-700 cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
                <span>Написать руководителю для изменения смены</span>
              </button>
            ) : (
              <button
                onClick={() => setIsCheckInOpen(true)}
                className={`w-full py-2 px-3.5 rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                  hasCheckedIn
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-medium'
                }`}
              >
                <span>{hasCheckedIn ? 'Изменить смену или пункт (доступно 1 раз)' : 'Отметить Check-in'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Step 2: Sales Entry Card */}
        <div className={`p-4 sm:p-5 rounded-lg border transition-colors shadow-sm ${
          isPartTime
            ? 'bg-slate-900/40 border-slate-800/60 opacity-80'
            : !hasCheckedIn
            ? 'bg-slate-900/40 border-slate-800/60 opacity-75'
            : hasSubmittedSales
            ? 'bg-slate-900 border-slate-700/80'
            : 'bg-slate-900 border-slate-800'
        }`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-300">
              <span className="w-5 h-5 rounded bg-slate-800 text-slate-300 flex items-center justify-center text-xs font-mono">2</span>
              <span>Внесение продаж</span>
            </div>
            {isPartTime ? (
              <span className="text-xs font-normal text-slate-400 flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-slate-500" />
                <span>Не требуется</span>
              </span>
            ) : !hasCheckedIn ? (
              <span className="text-xs font-normal text-slate-500 flex items-center gap-1.5">
                <Lock className="w-3 h-3" />
                <span>Заблокировано</span>
              </span>
            ) : hasSubmittedSales ? (
              <span className="text-xs font-medium text-emerald-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>Внесены</span>
              </span>
            ) : (
              <span className="text-xs font-medium text-sky-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                <span>Готово к внесению</span>
              </span>
            )}
          </div>

          <div className="space-y-3">
            {isPartTime ? (
              <div className="p-3.5 bg-slate-950/40 rounded-md border border-slate-800/60 text-xs text-slate-400 leading-relaxed">
                Для сотрудников в статусе «Подработчик» внесение выручки не предусмотрено.
              </div>
            ) : !hasCheckedIn ? (
              <div className="p-3.5 bg-slate-950/40 rounded-md border border-slate-800/60 text-xs text-slate-500 leading-relaxed">
                Внесение продаж станет доступно сразу после отметки Check-in.
              </div>
            ) : hasSubmittedSales ? (
              <div className="p-3.5 bg-slate-950/70 rounded-md border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Общая выручка за сегодня:</span>
                  <span className="font-semibold text-white font-mono tabular-nums text-sm">
                    {formatCurrency(salesSummary.totalSales)}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-1.5 border-t border-slate-800">
                  <div className="text-slate-400">
                    Наличные: <span className="font-medium text-white font-mono">{formatCurrency(salesSummary.totalCash)}</span>
                  </div>
                  <div className="text-slate-400 text-right">
                    Безналичные: <span className="font-medium text-white font-mono">{formatCurrency(salesSummary.totalCard)}</span>
                  </div>
                </div>

                <div className="p-2 bg-slate-900 border border-slate-800 rounded-md flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-medium">Премия (5%):</span>
                  <span className="font-semibold text-emerald-400 font-mono tabular-nums">
                    +{formatCurrency(salesSummary.bonus)}
                  </span>
                </div>
              </div>
            ) : (
              <div className="p-3.5 bg-slate-950/60 rounded-md border border-slate-800 text-xs text-slate-400 leading-relaxed">
                Check-in успешно пройден! Внесите суммы продаж наличными и безналичными за смену.
              </div>
            )}

            <button
              disabled={!hasCheckedIn || isPartTime}
              onClick={() => setIsSalesOpen(true)}
              className={`w-full py-2 px-3.5 rounded-md text-xs font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                isPartTime || !hasCheckedIn
                  ? 'bg-slate-800/50 text-slate-500 cursor-not-allowed border border-slate-800'
                  : hasSubmittedSales
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-medium'
              }`}
            >
              {isPartTime ? <Lock className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5" />}
              <span>
                {isPartTime
                  ? 'Недоступно для подработчиков'
                  : hasSubmittedSales
                  ? 'Редактировать продажи'
                  : 'Внести продажи'}
              </span>
            </button>
          </div>
        </div>

      </div>

      {/* Modals */}
      <CheckInModal
        isOpen={isCheckInOpen}
        onClose={() => setIsCheckInOpen(false)}
        onCheckIn={(shiftType, location, initialCash, cashNotes) =>
          performCheckIn(currentStaffId, shiftType, location, undefined, initialCash, cashNotes)
        }
        onCancelCheckIn={() => cancelCheckIn(currentStaffId)}
        currentShift={todayRecord?.shiftType || null}
        currentLocation={todayRecord?.location || null}
        availableLocations={effectiveStaffLocations}
        initialCashVal={todayRecord?.initialCash}
        editCount={editCount}
        cancelCount={cancelCount}
        hasCancelledToday={hasUsedCancel}
        onContactManager={() => setIsMessageOpen(true)}
      />

      <SalesEntryModal
        isOpen={isSalesOpen}
        onClose={() => setIsSalesOpen(false)}
        onSave={(sales, finalCash, collectedCash, initialCash, cashNotes) =>
          submitSales(currentStaffId, sales, undefined, finalCash, collectedCash, initialCash, cashNotes)
        }
        initialSales={todayRecord?.sales}
        initialCashVal={todayRecord?.initialCash}
        finalCashVal={todayRecord?.finalCash}
        collectedCashVal={todayRecord?.collectedCash}
        cashNotesVal={todayRecord?.cashNotes}
      />

      <AvailabilityModal
        isOpen={isAvailOpen}
        onClose={() => setIsAvailOpen(false)}
        defaultDate={selectedDateString}
      />

      <EmployeeSwapModal
        isOpen={isSwapOpen}
        onClose={() => setIsSwapOpen(false)}
        defaultDate={selectedDateString}
      />

      <MessageManagerModal
        isOpen={isMessageOpen}
        onClose={() => setIsMessageOpen(false)}
      />

      <ShiftStatsView
        isOpen={isStatsOpen}
        onClose={() => setIsStatsOpen(false)}
      />

    </div>
  );
};
