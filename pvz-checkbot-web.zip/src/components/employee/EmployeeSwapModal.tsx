import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ShiftType, LocationType, ShiftSwapRequest, SHIFT_LABELS } from '../../types';
import { CustomSelect } from '../common/CustomSelect';
import { CustomDatePicker } from '../common/CustomDatePicker';
import { formatDateDDMMYYYY, getShiftLabel } from '../../utils/calculations';
import {
  ArrowLeftRight,
  X,
  Plus,
  CheckCircle,
  Clock,
  MapPin,
  Send,
  AlertCircle,
  HandMetal,
  Check,
  XCircle,
  Calendar
} from 'lucide-react';
import { useBottomSheetGesture } from '../../hooks/useBottomSheetGesture';

interface EmployeeSwapModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultDate?: string;
}

export const EmployeeSwapModal: React.FC<EmployeeSwapModalProps> = ({
  isOpen,
  onClose,
  defaultDate,
}) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  const {
    swaps,
    currentStaffId,
    currentStaff,
    authSession,
    pickupPoints = [],
    createSwapRequest,
    claimSwapRequest,
    approveSwapRequest,
    rejectSwapRequest,
    cancelSwapRequest,
    rates,
  } = useApp();

  const activePickupPointCodes = new Set(
    (pickupPoints || [])
      .filter(p => p.active !== false && !p.isArchived)
      .map(p => p.code)
  );

  const rawLocations = currentStaff?.locations && currentStaff.locations.length > 0
    ? currentStaff.locations
    : currentStaff?.location
    ? [currentStaff.location]
    : Array.from(activePickupPointCodes);

  const filteredLocations = rawLocations.filter(code => activePickupPointCodes.has(code));
  const userLocations = filteredLocations.length > 0 ? filteredLocations : Array.from(activePickupPointCodes);

  const [activeTab, setActiveTab] = useState<'open_market' | 'my_requests' | 'claimed_by_me'>('open_market');
  const [date, setDate] = useState(defaultDate || new Date().toISOString().slice(0, 10));
  const [shiftType, setShiftType] = useState<ShiftType>('standard');
  const [location, setLocation] = useState<LocationType>(userLocations[0] || (pickupPoints[0]?.code || ''));
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Open shifts from colleagues or shifts I claimed (pending or approved)
  const isCandidateMe = (s: ShiftSwapRequest) =>
    s.candidateId === currentStaffId ||
    (authSession?.staffId && s.candidateId === authSession.staffId) ||
    (currentStaff?.name && s.candidateName === currentStaff.name);

  const openMarketSwaps = swaps
    .filter(
      s =>
        s.requesterId !== currentStaffId &&
        (s.status === 'open' || (isCandidateMe(s) && s.status === 'claimed'))
    )
    .sort((a, b) => a.date.localeCompare(b.date));

  // My own swap requests (sorted from old to new)
  const mySwaps = swaps
    .filter(s => s.requesterId === currentStaffId)
    .sort((a, b) => a.date.localeCompare(b.date));

  // Shifts I claimed (both pending confirmation and approved)
  const myClaimedSwaps = swaps
    .filter(s => isCandidateMe(s) && (s.status === 'claimed' || s.status === 'approved'))
    .sort((a, b) => a.date.localeCompare(b.date));

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setActionSuccess(null);

    // Single shift request per date validation
    const existingOnDate = mySwaps.find(
      s => s.date === date && s.status !== 'rejected' && s.status !== 'cancelled'
    );
    if (existingOnDate) {
      setFormError(`У вас уже выведена смена на биржу на дату ${formatDateDDMMYYYY(date)}. Можно выставлять не более одной смены на одну дату.`);
      setTimeout(() => setFormError(null), 1700);
      return;
    }

    setLoading(true);
    const res = await createSwapRequest(date, shiftType, location, reason);
    setLoading(false);
    if (res.success) {
      setActionSuccess('Запрос на подмену опубликован на бирже смен! Все сотрудники получили push-уведомление.');
      setReason('');
      setTimeout(() => setActionSuccess(null), 3500);
    } else {
      setFormError(res.error || 'Ошибка при создании заявки');
      setTimeout(() => setFormError(null), 2000);
    }
  };

  const handleClaimShift = async (swapId: string) => {
    setLoading(true);
    setActionSuccess(null);
    setFormError(null);
    const res = await claimSwapRequest(swapId);
    setLoading(false);
    if (res.success) {
      setActionSuccess('Вы успешно откликнулись на смену! Автор смены получил уведомление для подтверждения.');
      setTimeout(() => setActionSuccess(null), 4000);
    } else {
      setFormError(res.error || 'Не удалось откликнуться на смену');
      setTimeout(() => setFormError(null), 4000);
    }
  };

  const handleApprove = async (swapId: string) => {
    setLoading(true);
    setActionSuccess(null);
    const res = await approveSwapRequest(swapId);
    setLoading(false);
    if (res.success) {
      setActionSuccess('Договорились! Смена успешно зафиксирована за откликнувшимся коллегой.');
      setTimeout(() => setActionSuccess(null), 4000);
    }
  };

  const handleReject = async (swapId: string) => {
    setLoading(true);
    setActionSuccess(null);
    const res = await rejectSwapRequest(swapId);
    setLoading(false);
    if (res.success) {
      setActionSuccess('Отклик отклонен. Смена снова открыта на бирже для других коллег.');
      setTimeout(() => setActionSuccess(null), 3500);
    }
  };

  const handleCancel = async (swapId: string) => {
    setLoading(true);
    await cancelSwapRequest(swapId);
    setLoading(false);
  };

  // Group swaps by date helper (sorted from old to new date)
  const groupSwapsByDate = (list: ShiftSwapRequest[]) => {
    const groups: { [date: string]: ShiftSwapRequest[] } = {};
    list.forEach(item => {
      if (!groups[item.date]) groups[item.date] = [];
      groups[item.date].push(item);
    });
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  };

  const openGroups = groupSwapsByDate(openMarketSwaps);
  const myGroups = groupSwapsByDate(mySwaps);
  const myClaimedGroups = groupSwapsByDate(myClaimedSwaps);

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-2xl max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl"
      >
        
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1.5 bg-slate-700/80 rounded-full pointer-events-none" />
        </div>

        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-center justify-between shrink-0">
          <div>
            <h3 className="text-base font-semibold text-white">
              Биржа смен и подмен
            </h3>
            <p className="text-xs text-slate-400">
              Обмен, передача и взятие смен
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="px-4 sm:px-5 pt-3 pb-2 bg-slate-900 border-b border-slate-800/50 shrink-0">
          <div className="flex bg-slate-950/60 p-1.5 gap-1.5 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setActiveTab('open_market')}
              className={`flex-1 py-2 px-2.5 rounded-lg transition-all cursor-pointer text-center truncate ${
                activeTab === 'open_market'
                  ? 'bg-sky-500 text-slate-950 shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
              }`}
            >
              Открытые смены ({openMarketSwaps.length})
            </button>
            <button
              onClick={() => setActiveTab('my_requests')}
              className={`flex-1 py-2 px-2.5 rounded-lg transition-all cursor-pointer text-center truncate ${
                activeTab === 'my_requests'
                  ? 'bg-sky-500 text-slate-950 shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
              }`}
            >
              Мои заявки ({mySwaps.length})
            </button>
            <button
              onClick={() => setActiveTab('claimed_by_me')}
              className={`flex-1 py-2 px-2.5 rounded-lg transition-all cursor-pointer text-center truncate ${
                activeTab === 'claimed_by_me'
                  ? 'bg-emerald-500 text-slate-950 shadow-sm font-semibold'
                  : 'text-emerald-400 hover:text-emerald-300 hover:bg-slate-900/50'
              }`}
            >
              Забранные смены ({myClaimedSwaps.length})
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-5 space-y-4 flex-1 overflow-y-auto overscroll-contain touch-pan-y">
          
          {actionSuccess && (
            <div className="p-3 bg-slate-900 border border-emerald-500/50 text-white rounded-xl text-xs flex items-center gap-2 animate-fade-in shadow-md">
              <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
              <span className="text-white font-medium">{actionSuccess}</span>
            </div>
          )}

          {formError && (
            <div className="p-3 bg-slate-900 border border-red-500/50 text-white rounded-xl text-xs flex items-center gap-2 animate-fade-in shadow-md">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span className="text-white font-medium">{formError}</span>
            </div>
          )}

          {activeTab === 'open_market' ? (
            <div className="space-y-4">
              <div className="text-xs text-slate-400">
                Коллеги, которые ищут замену на свои смены. Нажмите «Выйти на замену», чтобы забрать смену:
              </div>

              {openMarketSwaps.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/40 rounded-xl">
                  Сейчас нет открытых смен для подмены. Все смены закрыты!
                </div>
              ) : (
                <div className="space-y-4">
                  {openGroups.map(([grpDate, items]) => (
                    <div key={grpDate} className="space-y-2">
                      <div className="flex items-center gap-2 px-1 text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                        <Calendar className="w-3.5 h-3.5 text-sky-400" />
                        <span className="text-white font-mono">{formatDateDDMMYYYY(grpDate)}</span>
                        <span className="text-slate-500 font-normal">({items.length} смен)</span>
                      </div>

                      <div className="space-y-2">
                        {items.map(sw => {
                          const isMyClaim = isCandidateMe(sw) && sw.status === 'claimed';

                          return (
                            <div
                              key={sw.id}
                              className="p-3.5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-all shadow-sm bg-slate-950/80"
                            >
                              <div className="min-w-0 flex-1 space-y-1">
                                <div className="flex items-center gap-2 mb-1 flex-wrap">
                                  <span className="font-semibold text-white font-mono bg-slate-900 px-2.5 py-0.5 rounded-lg min-w-[85px] justify-center text-center inline-flex">
                                    {formatDateDDMMYYYY(sw.date)}
                                  </span>
                                  <span className="px-2.5 py-0.5 rounded-lg bg-slate-800 text-sky-300 font-semibold font-mono min-w-[85px] text-center inline-flex justify-center">
                                    {sw.location}
                                  </span>
                                  <span className="px-2.5 py-0.5 rounded-lg bg-slate-800 text-slate-300 min-w-[105px] text-center inline-flex justify-center">
                                    {getShiftLabel(sw.shiftType, rates)}
                                  </span>
                                  {isMyClaim ? (
                                    <span className="text-xs $2font-medium px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 min-w-[130px] text-center inline-flex justify-center">
                                      Ждёт подтверждения
                                    </span>
                                  ) : (
                                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-700 dark:text-amber-400 font-medium min-w-[120px] text-center inline-flex justify-center">
                                      Открыта на бирже
                                    </span>
                                  )}
                                </div>
                                <div className="text-slate-300 flex items-center gap-1.5 truncate text-xs">
                                  <span className="text-slate-500 min-w-[65px] shrink-0">Передает:</span>
                                  <strong className="text-white font-semibold truncate">{sw.requesterName}</strong>
                                </div>
                                <div className="flex items-center gap-1.5 truncate text-[11px]">
                                  <span className="text-slate-500 min-w-[65px] shrink-0">Причина:</span>
                                  <span className={`truncate ${sw.reason ? 'text-slate-300 italic' : 'text-slate-500'}`}>
                                    {sw.reason ? `«${sw.reason}»` : '—'}
                                  </span>
                                </div>
                              </div>

                              {isMyClaim ? (
                                <div className="py-1.5 px-3 bg-amber-500/20 text-amber-300 rounded-xl text-xs font-semibold shrink-0 text-center">
                                  Отклик отправлен
                                </div>
                              ) : (
                                <button
                                  onClick={() => handleClaimShift(sw.id)}
                                  disabled={loading}
                                  className="py-1.5 px-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl text-xs transition-colors self-start sm:self-auto shadow-sm cursor-pointer disabled:opacity-50"
                                >
                                  Выйти на замену
                                </button>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : activeTab === 'claimed_by_me' ? (
            /* My Claimed Shifts Tab */
            <div className="space-y-4">
              <div className="text-xs text-slate-400">
                Смены коллег, на которые вы откликнулись и выйдете на замену:
              </div>

              {myClaimedSwaps.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/40 rounded-xl">
                  У вас пока нет забранных смен с биржи. Вы можете забрать открытую смену коллеги на первой вкладке!
                </div>
              ) : (
                <div className="space-y-4">
                  {myClaimedGroups.map(([grpDate, items]) => (
                    <div key={grpDate} className="space-y-2">
                      <div className="flex items-center gap-2 px-1 text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                        <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-white font-mono">{formatDateDDMMYYYY(grpDate)}</span>
                      </div>

                      <div className="space-y-2">
                        {items.map(sw => {
                          const isPending = sw.status === 'claimed';

                          return (
                            <div
                              key={sw.id}
                              className="p-3.5 rounded-xl space-y-2 text-xs shadow-sm bg-slate-950/80"
                            >
                              <div className="flex items-center justify-between gap-2 flex-wrap">
                                <div className="flex items-center gap-2">
                                  <span className="font-semibold text-white font-mono bg-slate-900 px-2.5 py-0.5 rounded-lg min-w-[85px] justify-center text-center inline-flex">
                                    {formatDateDDMMYYYY(sw.date)}
                                  </span>
                                  <span className="text-sky-300 font-semibold font-mono px-2.5 py-0.5 rounded-lg bg-slate-800 min-w-[85px] justify-center text-center inline-flex">
                                    {sw.location}
                                  </span>
                                  <span className="text-slate-300 font-medium bg-slate-900 px-2.5 py-0.5 rounded-lg min-w-[105px] justify-center text-center inline-flex">
                                    {getShiftLabel(sw.shiftType, rates)}
                                  </span>
                                </div>

                                {isPending ? (
                                  <span className="text-xs $2font-medium px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 min-w-[140px] justify-center inline-flex">
                                    Ждёт подтверждения
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 flex items-center gap-1 min-w-[140px] justify-center">
                                    <Check className="w-3 h-3 text-emerald-400" />
                                    <span>Договорились (Утверждено)</span>
                                  </span>
                                )}
                              </div>

                              <div className="space-y-1 text-xs text-slate-300 pt-1">
                                <div className="flex items-center gap-1.5 truncate">
                                  <span className="text-slate-500 shrink-0 min-w-[125px]">Выходите вместо:</span>
                                  <strong className="text-white font-semibold truncate">{sw.requesterName}</strong>
                                </div>
                                <div className="flex items-center gap-1.5 truncate text-[11px]">
                                  <span className="text-slate-500 shrink-0 min-w-[125px]">Причина передачи:</span>
                                  <span className={`truncate ${sw.reason ? 'text-slate-300 italic' : 'text-slate-500'}`}>
                                    {sw.reason ? `«${sw.reason}»` : '—'}
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              
              <form onSubmit={handleCreateRequest} className="p-4 sm:p-5 bg-slate-950/80 rounded-xl space-y-3.5 text-xs shadow-sm">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Выставить мою смену на биржу:
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Дата смены:</label>
                    <CustomDatePicker
                      value={date}
                      onChange={v => setDate(v)}
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Пункт:</label>
                    <CustomSelect<LocationType>
                      value={location}
                      onChange={v => setLocation(v)}
                      menuHeaderTitle="Пункт выдачи"
                      options={userLocations.map(loc => {
                        const pt = pickupPoints.find(p => p.code === loc || p.id === loc);
                        return {
                          value: loc,
                          label: loc,
                          sublabel: pt?.name && pt.name !== loc ? pt.name : undefined,
                        };
                      })}
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Категория:</label>
                    <CustomSelect<ShiftType>
                      value={shiftType}
                      onChange={v => setShiftType(v)}
                      align="right"
                      menuHeaderTitle="Категория смены"
                      options={(rates?.shiftTypes || []).filter((t: any) => !t.isArchived).length > 0
                        ? (rates.shiftTypes || []).filter((t: any) => !t.isArchived).map((t: any) => ({
                            value: t.code as ShiftType,
                            label: t.name,
                          }))
                        : [
                            { value: 'standard', label: 'Обычная смена' },
                            { value: '400+', label: 'Смена 400+' },
                            { value: '500+', label: 'Смена 500+' },
                            { value: '8h', label: 'Смена 8 часов' },
                            { value: '4h', label: 'Смена 4 часа' },
                          ]}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Причина замены (для коллег):</label>
                  <input
                    type="text"
                    placeholder="Например, зачёт в университете / срочные дела"
                    value={reason}
                    onChange={e => setReason(e.target.value)}
                    required
                    className="w-full h-10 min-h-[40px] px-3 py-2 bg-slate-950/90 border border-slate-700/80 hover:border-slate-600 focus:border-sky-500/80 focus:ring-1 focus:ring-sky-500/30 rounded-xl text-white text-xs focus:outline-none transition-all shadow-sm"
                  />
                </div>

                <div className="pt-1 flex justify-end">
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-4 py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold rounded-xl shadow-sm transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    {loading ? 'Публикация...' : 'Опубликовать на бирже'}
                  </button>
                </div>
              </form>

              {/* My active requests */}
              <div className="space-y-3 pt-2">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                  <span>Мои запросы на подмену ({mySwaps.length})</span>
                </div>

                {mySwaps.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400 bg-slate-950/60 rounded-xl">
                    У вас нет активных запросов на бирже.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {myGroups.map(([grpDate, items]) => (
                      <div key={grpDate} className="space-y-2">
                        <div className="flex items-center gap-2 px-1 text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                          <Calendar className="w-3.5 h-3.5 text-amber-400" />
                          <span className="text-white font-mono">{formatDateDDMMYYYY(grpDate)}</span>
                        </div>

                        <div className="space-y-2.5">
                          {items.map(sw => {
                            const isClaimed = sw.status === 'claimed';
                            const isApproved = sw.status === 'approved';

                            return (
                              <div
                                key={sw.id}
                                className="p-3.5 rounded-xl text-xs space-y-2.5 transition-all shadow-sm bg-slate-950/80"
                              >
                                <div className="flex items-center justify-between gap-2 flex-wrap">
                                  <div className="flex items-center gap-2">
                                    <span className="font-semibold text-white font-mono bg-slate-900 px-2.5 py-0.5 rounded-lg min-w-[85px] justify-center text-center inline-flex">
                                      {formatDateDDMMYYYY(sw.date)}
                                    </span>
                                    <span className="text-sky-300 font-semibold font-mono px-2.5 py-0.5 rounded-lg bg-sky-950/80 min-w-[85px] justify-center text-center inline-flex">
                                      {sw.location}
                                    </span>
                                    <span className="text-slate-300 font-medium bg-slate-900 px-2.5 py-0.5 rounded-lg min-w-[105px] justify-center text-center inline-flex">
                                      {getShiftLabel(sw.shiftType, rates)}
                                    </span>
                                  </div>

                                  <span
                                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-md min-w-[120px] justify-center text-center inline-flex ${
                                      sw.status === 'open'
                                        ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400 font-medium'
                                        : isClaimed
                                        ? 'bg-amber-500 text-slate-950 font-semibold'
                                        : isApproved
                                        ? 'bg-emerald-500 text-slate-950 font-semibold'
                                        : 'bg-red-500/10 text-red-700 dark:text-red-400 font-medium'
                                    }`}
                                  >
                                    {sw.status === 'open'
                                      ? 'На бирже (ждёт отклика)'
                                      : isClaimed
                                      ? `Откликнулся: ${sw.candidateName}`
                                      : isApproved
                                      ? `Договорились: ${sw.candidateName || 'Утверждено'}`
                                      : 'Отклонено'}
                                  </span>
                                </div>

                                <div className="space-y-1 text-xs text-slate-300 pt-1">
                                  <div className="flex items-center gap-1.5 truncate">
                                    <span className="text-slate-500 shrink-0 min-w-[65px]">Передает:</span>
                                    <strong className="text-white font-semibold truncate">{sw.requesterName}</strong>
                                  </div>
                                  <div className="flex items-center gap-1.5 truncate">
                                    <span className="text-slate-500 shrink-0 min-w-[65px]">Забирает:</span>
                                    {sw.candidateName ? (
                                      <strong className="text-emerald-400 font-semibold truncate">{sw.candidateName}</strong>
                                    ) : (
                                      <span className="text-slate-500 italic truncate">— (ожидает отклика)</span>
                                    )}
                                  </div>
                                  <div className="flex items-center gap-1.5 truncate text-[11px]">
                                    <span className="text-slate-500 shrink-0 min-w-[65px]">Причина:</span>
                                    <span className={`truncate ${sw.reason ? 'text-slate-300 italic' : 'text-slate-500'}`}>
                                      {sw.reason ? `«${sw.reason}»` : '—'}
                                    </span>
                                  </div>
                                </div>

                                {/* When someone claimed, initiator confirms or rejects */}
                                {isClaimed && (
                                  <div className="p-3.5 bg-slate-950 rounded-xl space-y-2 mt-2 shadow-inner">
                                    <div className="text-xs text-amber-300 font-semibold flex items-center gap-1.5">
                                      <span>Коллега <strong className="text-white font-semibold">{sw.candidateName}</strong> готов выйти за вас на смену!</span>
                                    </div>
                                    <p className="text-[11px] text-slate-300">
                                      Зафиксируйте договоренность, чтобы закрыть заявку статусом «Договорились» и передать смену:
                                    </p>
                                    <div className="flex items-center justify-end gap-2 pt-1">
                                      <button
                                        type="button"
                                        onClick={() => handleReject(sw.id)}
                                        disabled={loading}
                                        className="py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-red-400 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                                      >
                                        Отклонить
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleApprove(sw.id)}
                                        disabled={loading}
                                        className="py-1.5 px-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
                                      >
                                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                                        <span>Подтвердить замену (Договорились)</span>
                                      </button>
                                    </div>
                                  </div>
                                )}

                                {sw.status === 'open' && (
                                  <div className="flex justify-end pt-1">
                                    <button
                                      type="button"
                                      onClick={() => handleCancel(sw.id)}
                                      disabled={loading}
                                      className="text-xs text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                                    >
                                      Снять с биржи
                                    </button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 bg-slate-950/70 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors cursor-pointer"
          >
            Закрыть
          </button>
        </div>

      </div>
    </div>
  );
};
