import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { aggregateMonthlyStats, formatCurrency, getBaseShiftPay, calculateShiftTotalSalary } from '../../utils/calculations';
import { getCurrentAndPreviousMonth } from '../../utils/time';
import { Target, TrendingUp, CheckCircle, Calculator, ChevronRight } from 'lucide-react';

export const IncomeGoalCalculatorWidget: React.FC = () => {
  const { currentStaffId, records, rates, currentStaff, incomeGoals, saveIncomeGoal } = useApp();
  const { current } = getCurrentAndPreviousMonth(); // e.g. "2026-10"

  const statsMap = aggregateMonthlyStats(records, current, currentStaffId);
  const myStat = statsMap.get(currentStaffId);

  // Compute earned so far in current month
  let shiftBaseSalary = 0;
  myStat?.records.forEach(rec => {
    if (rec.shiftType) {
      shiftBaseSalary += calculateShiftTotalSalary(rec, currentStaff, rates);
    }
  });

  const bonus = myStat?.sales?.totalBonus || 0;
  const currentEarned = shiftBaseSalary + bonus;

  // Server goal sync (synced across all devices for this employee and month)
  const serverGoal = incomeGoals.find(g => g.employeeId === currentStaffId && g.month === current);

  const [targetGoal, setTargetGoal] = useState<number>(() => {
    if (serverGoal?.targetAmount) return serverGoal.targetAmount;
    return 50000;
  });

  // Sync state when serverGoal updates from server
  useEffect(() => {
    if (serverGoal?.targetAmount) {
      setTargetGoal(serverGoal.targetAmount);
    }
  }, [serverGoal?.targetAmount]);

  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [tempGoalInput, setTempGoalInput] = useState(String(targetGoal));

  const handleSaveGoal = async () => {
    const val = parseInt(tempGoalInput, 10);
    if (val && val > 0) {
      setTargetGoal(val);
      // Save persistently to server database strictly
      await saveIncomeGoal(currentStaffId, current, val);
    }
    setIsEditingGoal(false);
  };

  const percentAchieved = Math.min(100, Math.round((currentEarned / (targetGoal || 1)) * 100));
  const remainingToEarn = Math.max(0, targetGoal - currentEarned);

  // Average payout per shift (base rate + average bonus)
  const avgShiftPay = currentStaff?.isPartTime ? 2000 : (Number(rates?.standard) || 2000) + 400;
  const shiftsNeeded = remainingToEarn > 0 ? Math.ceil(remainingToEarn / avgShiftPay) : 0;

  return (
    <div className={`p-3.5 sm:p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm ${isEditingGoal ? 'space-y-4' : 'space-y-2.5 sm:space-y-4'}`}>
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div>
            <div className="text-xs font-medium text-white uppercase tracking-wider flex items-center gap-1.5">
              <span>Цель и прогноз заработка</span>
            </div>
            <div className={`text-[11px] text-slate-400 ${isEditingGoal ? 'block' : 'hidden sm:block'}`}>
              Персональный финансовый прогресс за текущий месяц
            </div>
          </div>
        </div>

        {/* Goal editor button */}
        <div className="flex items-center gap-2">
          {isEditingGoal ? (
            <div className="flex items-center gap-1.5">
              <input
                type="number"
                min="5000"
                step="5000"
                value={tempGoalInput}
                onFocus={e => e.target.select()}
                onClick={e => (e.target as HTMLInputElement).select()}
                onChange={e => setTempGoalInput(e.target.value)}
                className="w-28 px-2.5 py-1 bg-slate-950 rounded-lg text-white font-mono text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500/50 shadow-inner"
              />
              <button
                onClick={handleSaveGoal}
                className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors cursor-pointer"
              >
                ОК
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                setTempGoalInput(String(targetGoal));
                setIsEditingGoal(true);
              }}
              className="text-[11px] font-semibold text-sky-400 hover:text-sky-300 px-2.5 py-1 bg-slate-950 rounded-lg flex items-center gap-1 cursor-pointer"
            >
              <span>Цель: {formatCurrency(targetGoal)}</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar & Key Numbers */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs">
          <div className="font-mono">
            <span className="text-slate-400">Заработано: </span>
            <strong className="text-emerald-400 text-sm">{formatCurrency(currentEarned)}</strong>
          </div>
          <div className="text-right font-mono">
            <span className="text-slate-400">Прогресс: </span>
            <strong className="text-white">{percentAchieved}%</strong>
          </div>
        </div>

        {/* Bar */}
        <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
          <div
            style={{ width: `${percentAchieved}%` }}
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-700"
          ></div>
        </div>
      </div>

      {/* Status calculation card */}
      <div className={`p-3 bg-slate-950/70 rounded-xl text-xs flex-col sm:flex-row sm:items-center justify-between gap-2 ${isEditingGoal ? 'flex' : 'hidden sm:flex'}`}>
        {percentAchieved >= 100 ? (
          <div className="text-emerald-300 font-semibold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Финансовая цель на текущий месяц выполнена (100%).</span>
          </div>
        ) : (
          <div className="text-slate-300 leading-relaxed">
            Осталось до цели: <strong className="text-white font-mono">{formatCurrency(remainingToEarn)}</strong>.
            {shiftsNeeded > 0 && (
              <span className="text-slate-400">
                {' '}Это всего около <strong className="text-emerald-400 font-semibold font-mono">~{shiftsNeeded} смен</strong> (при текущей ставке и премиях).
              </span>
            )}
          </div>
        )}
      </div>

    </div>
  );
};
