import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { parseDateSafe } from '../../utils/time';
import { MessageSquare, Send, X, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useBottomSheetGesture } from '../../hooks/useBottomSheetGesture';

interface MessageManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MessageManagerModal: React.FC<MessageManagerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  const { currentStaffId, sendMessageToManager, messages, notifications } = useApp();
  const [text, setText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    setIsSending(true);
    await sendMessageToManager(currentStaffId, text);
    setIsSending(false);
    setSentSuccess(true);

    setTimeout(() => {
      setSentSuccess(false);
      setText('');
      onClose();
    }, 1200);
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 light:bg-white border-t sm:border border-slate-800 light:border-slate-200 rounded-t-2xl sm:rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl text-white light:text-slate-900"
      >
        
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1.5 bg-slate-700/80 light:bg-slate-300 rounded-full pointer-events-none" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 light:border-slate-200 shrink-0">
          <div>
            <h3 className="text-base font-semibold text-white light:text-slate-900">Написать руководителю</h3>
            <p className="text-xs text-slate-400 light:text-slate-500">Сообщение руководителю ПВЗ</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 light:text-slate-500 hover:text-white light:hover:text-slate-900 rounded-lg hover:bg-slate-800 light:hover:bg-slate-100 transition-colors"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat History & Message Input */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 max-h-[60vh] overscroll-contain">
          {/* List previous messages & manager replies */}
          {(() => {
            const mySentMsgs = messages.filter(m => m.fromEmployeeId === currentStaffId);
            const myReplies = notifications.filter(
              n => (n.toEmployeeId === currentStaffId || n.toEmployeeId === 'all') && n.title.includes('Ответ')
            );

            // Combine and sort chronologically
            const threadItems = [
              ...mySentMsgs.map(m => ({ id: m.id, type: 'sent' as const, text: m.message, timestamp: m.timestamp, title: 'Вы' })),
              ...myReplies.map(r => ({ id: r.id, type: 'received' as const, text: r.text, timestamp: r.timestamp, title: r.title || 'Руководитель' })),
            ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

            if (threadItems.length === 0) {
              return (
                <div className="text-center py-6 text-xs text-slate-500 light:text-slate-500 bg-slate-950/40 light:bg-slate-50 rounded-xl p-4 border border-slate-800 light:border-slate-200">
                  История переписки пока пуста. Напишите ваше сообщение руководителю ниже.
                </div>
              );
            }

            return (
              <div className="space-y-2.5">
                <div className="text-[10px] uppercase font-medium tracking-wider text-slate-500 light:text-slate-500 text-center mb-1">
                  История обращений и ответов ({threadItems.length})
                </div>
                {threadItems.map(item => (
                  <div
                    key={item.id}
                    className={`p-3 rounded-xl text-xs space-y-1 border ${
                      item.type === 'sent'
                        ? 'bg-sky-500/10 light:bg-sky-50 border-sky-500/20 light:border-sky-200 text-slate-200 light:text-slate-800 ml-6'
                        : 'bg-emerald-500/10 light:bg-emerald-50 border-emerald-500/20 light:border-emerald-200 text-slate-200 light:text-slate-800 mr-6'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className={`font-semibold ${item.type === 'sent' ? 'text-sky-400 light:text-sky-700' : 'text-emerald-400 light:text-emerald-700'}`}>
                        {item.title}
                      </span>
                      <span className="text-[10px] text-slate-500 light:text-slate-400 font-mono">
                        {parseDateSafe(item.timestamp).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="leading-relaxed text-slate-100 light:text-slate-900 whitespace-pre-wrap">{item.text}</p>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>

        {/* Message Input Form */}
        <form onSubmit={handleSubmit} className="p-3.5 border-t border-slate-800 light:border-slate-200 bg-slate-900 light:bg-white shrink-0 space-y-2.5">
          {sentSuccess && (
            <div className="p-2.5 bg-emerald-500/10 light:bg-emerald-50 border border-emerald-500/30 light:border-emerald-200 text-emerald-400 light:text-emerald-700 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Сообщение успешно отправлено руководителю!</span>
            </div>
          )}

          <div className="flex gap-2 items-end">
            <textarea
              rows={2}
              required
              placeholder="Введите сообщение или ответ руководителю..."
              value={text}
              onChange={e => setText(e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-950 light:bg-slate-50 border border-slate-700 light:border-slate-300 rounded-xl text-xs text-white light:text-slate-900 focus:outline-none focus:border-sky-500 transition-colors resize-none placeholder:text-slate-600 light:placeholder:text-slate-400"
            />
            <button
              type="submit"
              disabled={isSending || !text.trim()}
              className={`px-4 py-2.5 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-all shadow-sm shrink-0 h-10 ${
                text.trim() && !isSending
                  ? 'bg-sky-500 hover:bg-sky-400 text-slate-950 cursor-pointer'
                  : 'bg-slate-800 light:bg-slate-200 text-slate-500 light:text-slate-400 cursor-not-allowed'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSending ? '...' : 'Отправить'}</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
