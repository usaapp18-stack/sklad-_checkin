import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserPlus, Clock, CheckCircle2, XCircle, ArrowRight, X, KeyRound, Lock } from 'lucide-react';

interface RegistrationViewProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RegistrationView: React.FC<RegistrationViewProps> = ({ isOpen, onClose }) => {
  const { submitRegistration, applications, staffList } = useApp();
  const [name, setName] = useState('');
  const [telegram, setTelegram] = useState('');
  const [submittedAppId, setSubmittedAppId] = useState<string | null>(null);
  const [localApp, setLocalApp] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentApp = localApp || applications.find(a => a.id === submittedAppId);
  const newlyCreatedStaff = currentApp?.status === 'accepted'
    ? staffList.find(s => s.name.toLowerCase() === currentApp.name.toLowerCase())
    : null;

  const handleClose = () => {
    setName('');
    setTelegram('');
    setSubmittedAppId(null);
    setLocalApp(null);
    setErrorMessage(null);
    setIsSubmitting(false);
    onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || isSubmitting) return;
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const result = await submitRegistration(name, telegram);
      if (result.success && result.id) {
        setSubmittedAppId(result.id);
        setLocalApp({
          id: result.id,
          name: name.trim(),
          telegram_username: telegram.trim(),
          status: 'pending',
        });
      } else {
        setErrorMessage(result.error || 'Не удалось отправить заявку. Попробуйте еще раз.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Ошибка сети при отправке заявки');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-sky-400" />
            <div>
              <h3 className="text-base font-semibold text-white">Заявка на доступ</h3>
              <p className="text-xs text-slate-400">Получение логина и пароля от руководителя</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submittedAppId && currentApp ? (
          <div className="p-6 text-center space-y-4">
            {currentApp.status === 'pending' && (
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/30">
                  <Clock className="w-6 h-6" />
                </div>
                <h4 className="text-base font-semibold text-white">Заявка отправлена руководителю</h4>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Статус: <span className="text-amber-400 font-semibold">«Ожидает решения»</span>. Руководитель создаст логин и пароль и откроет вам доступ.
                </p>
                <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-800 text-xs text-slate-300">
                  Кандидат: <span className="font-semibold text-white">{currentApp.name}</span>
                </div>
                <button
                  onClick={handleClose}
                  className="w-full mt-4 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Понятно, закрыть
                </button>
              </div>
            )}

            {currentApp.status === 'accepted' && (
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-base font-semibold text-white">Заявка одобрена!</h4>
                <p className="text-xs text-slate-300">
                  Руководитель выдал доступ к админке работника.
                </p>
                {newlyCreatedStaff && (
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono space-y-1 text-left">
                    <div className="text-slate-400">Ваш логин: <span className="text-white font-semibold">{newlyCreatedStaff.login}</span></div>
                    <div className="text-slate-400">Пароль: <span className="text-emerald-400 font-semibold">•••••••• (задан руководителем)</span></div>
                  </div>
                )}
                <button
                  onClick={handleClose}
                  className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-semibold transition-colors"
                >
                  Перейти на страницу авторизации
                </button>
              </div>
            )}

            {currentApp.status === 'rejected' && (
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto border border-rose-500/30">
                  <XCircle className="w-6 h-6" />
                </div>
                <h4 className="text-base font-semibold text-white">Заявка отклонена</h4>
                <p className="text-xs text-slate-400">
                  {currentApp.note ? `Причина: ${currentApp.note}` : 'Руководитель отклонил заявку на регистрацию.'}
                </p>
                <p className="text-[11px] text-slate-500">
                  Доступ к функциям работника не предоставлен.
                </p>
                <button
                  onClick={handleClose}
                  className="w-full mt-2 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium transition-colors"
                >
                  Закрыть
                </button>
              </div>
            )}
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="p-4 space-y-3.5">
              
              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-start gap-2 leading-relaxed">
                <Lock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  Доступ к админке выдает только руководитель. Логин и пароль будут созданы после рассмотрения заявки.
                </span>
              </div>

              {errorMessage && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300">
                  {errorMessage}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  ФИО работника *
                </label>
                <input
                  type="text"
                  required
                  placeholder="например, Екатерина Орлова"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Telegram Username (необязательно)
                </label>
                <input
                  type="text"
                  placeholder="@username"
                  value={telegram}
                  onChange={e => setTelegram(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 transition-colors"
                />
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={handleClose}
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-xl transition-colors"
              >
                Отмена
              </button>
              <button
                type="submit"
                disabled={!name.trim() || isSubmitting}
                className={`px-5 py-2 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-all shadow-sm ${
                  name.trim() && !isSubmitting
                    ? 'bg-sky-500 hover:bg-sky-400 text-slate-950 cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>Отправка...</span>
                  </>
                ) : (
                  <>
                    <span>Отправить заявку</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
