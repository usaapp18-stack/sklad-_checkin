import React, { useState } from 'react';
import { DailySales } from '../../types';
import { calculateDailySales, formatCurrency } from '../../utils/calculations';
import { X, ArrowLeft, Check, Banknote, CreditCard, Wallet } from 'lucide-react';
import { useBottomSheetGesture } from '../../hooks/useBottomSheetGesture';

interface SalesEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (sales: DailySales, finalCash?: number, collectedCash?: number, initialCash?: number, cashNotes?: string) => void;
  initialSales?: DailySales | null;
  initialCashVal?: number;
  finalCashVal?: number;
  collectedCashVal?: number;
  cashNotesVal?: string;
}

export const SalesEntryModal: React.FC<SalesEntryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialSales,
  initialCashVal,
  finalCashVal,
  collectedCashVal,
  cashNotesVal,
}) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  // Extract initial cash / card (support both direct cash/card and legacy photo/print/lamination sums)
  const initialCashSum = initialSales
    ? (initialSales.cash !== undefined
        ? initialSales.cash
        : ((initialSales.photo?.cash || 0) + (initialSales.print?.cash || 0) + (initialSales.lamination?.cash || 0)))
    : 0;

  const initialCardSum = initialSales
    ? (initialSales.card !== undefined
        ? initialSales.card
        : ((initialSales.photo?.card || 0) + (initialSales.print?.card || 0) + (initialSales.lamination?.card || 0)))
    : 0;

  const [cashSales, setCashSales] = useState<string>(initialCashSum > 0 ? String(initialCashSum) : '');
  const [cardSales, setCardSales] = useState<string>(initialCardSum > 0 ? String(initialCardSum) : '');

  // Cash management fields
  const [finalCash, setFinalCash] = useState<string>(finalCashVal ? String(finalCashVal) : '');
  const [collectedCash, setCollectedCash] = useState<string>(collectedCashVal ? String(collectedCashVal) : '');
  const [cashNotes, setCashNotes] = useState<string>(cashNotesVal || '');

  const [step, setStep] = useState<'input' | 'review'>('input');

  if (!isOpen) return null;

  const cashNum = Math.max(0, parseInt(cashSales, 10) || 0);
  const cardNum = Math.max(0, parseInt(cardSales, 10) || 0);

  const currentSalesData: DailySales = {
    cash: cashNum,
    card: cardNum,
    total: cashNum + cardNum,
  };

  const calc = calculateDailySales(currentSalesData);

  const handleSave = () => {
    const fCash = finalCash ? parseFloat(finalCash) : undefined;
    const colCash = collectedCash ? parseFloat(collectedCash) : undefined;
    onSave(currentSalesData, fCash, colCash, initialCashVal, cashNotes);
    onClose();
  };

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl"
      >
        
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1.5 bg-slate-700/80 rounded-full pointer-events-none" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800/80 shrink-0">
          <div>
            <h3 className="text-base font-semibold text-white">
              {step === 'input' ? 'Внесение продаж и кассы за смену' : 'Проверка и подтверждение'}
            </h3>
            <p className="text-xs text-slate-400">
              {step === 'input'
                ? 'Укажите выручку смены и остаток в кассе'
                : 'Проверьте итоговые суммы и расчет премии (5%)'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 space-y-4 flex-1 overflow-y-auto overscroll-contain touch-pan-y">
          {step === 'input' ? (
            <div className="space-y-4">
              
              {/* Sales inputs (Cash and Card) */}
              <div className="p-4 bg-slate-950/60 rounded-xl space-y-3 border border-slate-800">
                <div className="text-xs font-semibold text-slate-300">
                  Выручка за смену
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-300 mb-1.5 font-medium">
                      Наличные (₽)
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      placeholder="0"
                      value={cashSales}
                      onFocus={e => e.target.select()}
                      onClick={e => (e.target as HTMLInputElement).select()}
                      onChange={e => setCashSales(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-base focus:outline-none focus:border-emerald-500 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1.5 font-medium">
                      Безналичные / Карта (₽)
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      placeholder="0"
                      value={cardSales}
                      onFocus={e => e.target.select()}
                      onClick={e => (e.target as HTMLInputElement).select()}
                      onChange={e => setCardSales(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-base focus:outline-none focus:border-emerald-500 transition-colors"
                    />
                  </div>
                </div>
              </div>

              {/* Cash & Register Management */}
              <div className="p-3.5 bg-slate-950 rounded-xl space-y-2.5 shadow-sm border border-slate-800/80">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
                  <Banknote className="w-4 h-4 text-amber-400" />
                  <span>Касса и инкассация (на конец смены)</span>
                </div>

                <div className="grid grid-cols-2 gap-2.5 text-xs">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Остаток в кассе (₽):</label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      placeholder="Остаток наличных"
                      value={finalCash}
                      onFocus={e => e.target.select()}
                      onClick={e => (e.target as HTMLInputElement).select()}
                      onChange={e => setFinalCash(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-1.5 bg-slate-900 rounded-lg text-white font-mono focus:outline-none focus:ring-1 focus:ring-amber-500/50 shadow-inner border border-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Инкассация / передача (₽):</label>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      placeholder="Сумма сдачи"
                      value={collectedCash}
                      onFocus={e => e.target.select()}
                      onClick={e => (e.target as HTMLInputElement).select()}
                      onChange={e => setCollectedCash(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-1.5 bg-slate-900 rounded-lg text-white font-mono focus:outline-none focus:ring-1 focus:ring-amber-500/50 shadow-inner border border-slate-800"
                    />
                  </div>
                </div>
              </div>

              {/* Summary preview badge */}
              <div className="p-3.5 bg-slate-950 rounded-xl flex items-center justify-between shadow-sm border border-slate-850">
                <div>
                  <div className="text-xs text-slate-400">Общая выручка:</div>
                  <div className="text-base font-semibold text-white font-mono tabular-nums">
                    {formatCurrency(calc.totalSales)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-emerald-400 font-medium">Премия 5%:</div>
                  <div className="text-base font-semibold text-emerald-400 font-mono tabular-nums">
                    +{formatCurrency(calc.bonus)}
                  </div>
                </div>
              </div>

            </div>
          ) : (
            /* Review Step */
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 rounded-xl space-y-3 shadow-sm border border-slate-800">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  Сводка по продажам
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between py-2 bg-slate-900/60 px-3 rounded-lg text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <Banknote className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Наличные:</span>
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-white">
                      {formatCurrency(calc.totalCash)}
                    </span>
                  </div>

                  <div className="flex justify-between py-2 bg-slate-900/60 px-3 rounded-lg text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                      <span>Безналичные / Карта:</span>
                    </span>
                    <span className="font-mono tabular-nums font-semibold text-white">
                      {formatCurrency(calc.totalCard)}
                    </span>
                  </div>

                  {finalCash && (
                    <div className="flex justify-between py-1.5 bg-amber-950/20 px-3 rounded-lg text-amber-300">
                      <span>Остаток в кассе:</span>
                      <span className="font-mono font-semibold">{formatCurrency(parseFloat(finalCash))}</span>
                    </div>
                  )}

                  {collectedCash && (
                    <div className="flex justify-between py-1.5 bg-amber-950/20 px-3 rounded-lg text-amber-300">
                      <span>Инкассация:</span>
                      <span className="font-mono font-semibold">{formatCurrency(parseFloat(collectedCash))}</span>
                    </div>
                  )}
                </div>

                <div className="pt-2 flex items-center justify-between text-sm font-semibold border-t border-slate-850">
                  <span className="text-white">ОБЩАЯ ВЫРУЧКА:</span>
                  <span className="text-emerald-400 font-mono tabular-nums text-base">
                    {formatCurrency(calc.totalSales)}
                  </span>
                </div>

                <div className="p-2.5 bg-emerald-950/40 rounded-lg flex items-center justify-between text-xs border border-emerald-500/20">
                  <span className="text-emerald-200 font-medium">Ваша премия (5% от выручки):</span>
                  <span className="text-emerald-400 font-semibold font-mono tabular-nums text-sm">
                    +{formatCurrency(calc.bonus)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 bg-slate-900/60 flex items-center justify-between gap-3 border-t border-slate-800">
          {step === 'input' ? (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
              >
                Отмена
              </button>
              <button
                onClick={() => setStep('review')}
                className="px-5 py-2 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <span>Далее к проверке</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setStep('input')}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-750 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Назад к редактированию</span>
              </button>
              <button
                onClick={handleSave}
                className="px-5 py-2 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Сохранить продажи</span>
              </button>
            </>
          )}
        </div>

      </div>
    </div>
  );
};
