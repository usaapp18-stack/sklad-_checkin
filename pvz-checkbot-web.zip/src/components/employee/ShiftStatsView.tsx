import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getCurrentAndPreviousMonth, formatMonthName, formatDisplayDate, getAllAvailableMonths } from '../../utils/time';
import { aggregateMonthlyStats, formatCurrency, calculateDailySales, normalizeShiftType, getBaseShiftPay, calculateShiftBonuses, calculateShiftTotalSalary, getShiftLabel } from '../../utils/calculations';
import { SHIFT_LABELS, ShiftType } from '../../types';
import { Calendar, TrendingUp, DollarSign, Award, ChevronRight, X } from 'lucide-react';
import { CustomPeriodSelect } from '../common/CustomPeriodSelect';
import { useBottomSheetGesture } from '../../hooks/useBottomSheetGesture';

interface ShiftStatsViewProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShiftStatsView: React.FC<ShiftStatsViewProps> = ({ isOpen, onClose }) => {
  const { dragOffset, handleProps } = useBottomSheetGesture({ isOpen, onClose });
  const { currentStaffId, currentStaff, records, rates } = useApp();
  const { current, previous } = getCurrentAndPreviousMonth();
  const allAvailableMonths = getAllAvailableMonths(records, 12);
  const [selectedMonth, setSelectedMonth] = useState<string>(current);

  if (!isOpen) return null;

  const statsMap = aggregateMonthlyStats(records, selectedMonth, currentStaffId);
  const myStat = statsMap.get(currentStaffId);

  const monthRecords = (myStat?.records || [])
    .slice()
    .sort((a, b) => b.date.localeCompare(a.date));

  // Calculate salary details for the current employee
  let totalShiftSalary = 0;
  monthRecords.forEach(rec => {
    if (rec.shiftType) {
      totalShiftSalary += calculateShiftTotalSalary(rec, currentStaff, rates);
    }
  });

  const totalBonus = myStat?.sales.totalBonus || 0;
  const totalEarnings = totalShiftSalary + totalBonus;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      onTouchMove={(e) => { if (e.target === e.currentTarget) e.preventDefault(); }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-hidden"
    >
      <div
        style={{
          transform: dragOffset > 0 ? `translateY(${dragOffset}px)` : undefined,
          transition: dragOffset === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-lg sm:rounded-lg w-full max-w-2xl max-h-[90dvh] sm:max-h-[85vh] flex flex-col overflow-hidden shadow-2xl"
      >
        {/* Mobile Drag Handle */}
        <div
          {...handleProps}
          className="sm:hidden pt-3 pb-3 px-8 flex justify-center shrink-0 cursor-grab active:cursor-grabbing select-none touch-none"
          title="Потяните вниз, чтобы закрыть"
        >
          <div className="w-12 h-1 bg-slate-700 rounded-full pointer-events-none" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 sm:px-5 sm:py-3.5 border-b border-slate-800 bg-slate-900 shrink-0">
          <div>
            <h3 className="text-sm font-semibold text-white font-sans">Личные показатели и смены</h3>
            <p className="text-xs text-slate-400 mt-0.5">{currentStaff?.name || 'Сотрудник'}</p>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 flex items-center justify-center text-slate-400 hover:text-white rounded-md bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer shrink-0 border border-slate-700/60"
            aria-label="Закрыть"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Month Selector Tabs */}
        <div className="p-3 sm:px-5 border-b border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-2.5 shrink-0">
          <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800 max-w-sm">
            <button
              onClick={() => setSelectedMonth(current)}
              className={`py-1 px-2.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                selectedMonth === current
                  ? 'bg-emerald-500 text-slate-950 font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {formatMonthName(current)} (Текущий)
            </button>
            <button
              onClick={() => setSelectedMonth(previous)}
              className={`py-1 px-2.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                selectedMonth === previous
                  ? 'bg-emerald-500 text-slate-950 font-medium'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {formatMonthName(previous)} (Прошлый)
            </button>
          </div>

          <div className="relative w-full sm:w-auto">
            <CustomPeriodSelect
              value={selectedMonth}
              onChange={setSelectedMonth}
              options={allAvailableMonths}
              labelPrefix="Архив:"
              showIcon={false}
              align="left"
              className="w-full sm:w-auto"
            />
          </div>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 space-y-4 flex-1 overflow-y-auto overscroll-contain touch-pan-y">
          
          {/* Top KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            <div className="p-2.5 sm:p-3 bg-slate-950 border border-slate-800 rounded-lg text-center">
              <div className="text-[10px] uppercase font-medium tracking-wider text-slate-400 mb-0.5">Всего смен</div>
              <div className="text-sm sm:text-base font-semibold font-mono tabular-nums text-white">
                {myStat?.shiftsCount.total || 0}
              </div>
            </div>

            <div className="p-2.5 sm:p-3 bg-slate-950 border border-slate-800 rounded-lg text-center">
              <div className="text-[10px] uppercase font-medium tracking-wider text-slate-400 mb-0.5">Выручка</div>
              <div className="text-sm sm:text-base font-semibold font-mono tabular-nums text-sky-400">
                {formatCurrency(myStat?.sales.totalRevenue || 0)}
              </div>
            </div>

            <div className="p-2.5 sm:p-3 bg-slate-950 border border-slate-800 rounded-lg text-center">
              <div className="text-[10px] uppercase font-medium tracking-wider text-slate-400 mb-0.5">Премия (5%)</div>
              <div className="text-sm sm:text-base font-semibold font-mono tabular-nums text-emerald-400">
                +{formatCurrency(totalBonus)}
              </div>
            </div>

            <div className="p-2.5 sm:p-3 bg-slate-950 border border-slate-800 rounded-lg text-center">
              <div className="text-[10px] uppercase font-medium tracking-wider text-slate-400 mb-0.5">Оклад смен</div>
              <div className="text-sm sm:text-base font-semibold font-mono tabular-nums text-white">
                {formatCurrency(totalShiftSalary)}
              </div>
            </div>

            <div className="p-2.5 sm:p-3 bg-slate-950 border border-emerald-500/30 rounded-lg text-center col-span-2 sm:col-span-1">
              <div className="text-[10px] uppercase font-medium tracking-wider text-emerald-400 mb-0.5">Зарплата</div>
              <div className="text-sm sm:text-base font-semibold font-mono tabular-nums text-emerald-400">
                {formatCurrency(totalEarnings)}
              </div>
            </div>
          </div>

          {/* Breakdown by Shift Types */}
          {(() => {
            const shiftTypeCountsMap = new Map<string, number>();
            (myStat?.records || []).forEach(rec => {
              if (rec.shiftType) {
                shiftTypeCountsMap.set(rec.shiftType, (shiftTypeCountsMap.get(rec.shiftType) || 0) + 1);
              }
            });
            const workedShiftEntries = Array.from(shiftTypeCountsMap.entries());

            return (
              <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg space-y-2.5">
                <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Разбивка по типам смен
                </div>
                {workedShiftEntries.length > 0 ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {workedShiftEntries.map(([code, count]) => (
                      <div key={code} className="p-2 bg-slate-950 border border-slate-800 rounded-md text-center">
                        <div className="text-[11px] text-slate-300 font-medium truncate" title={getShiftLabel(code, rates)}>
                          {getShiftLabel(code, rates)}
                        </div>
                        <div className="text-xs font-semibold font-mono tabular-nums text-emerald-400 mt-0.5">
                          {count}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-slate-500 italic py-2 text-center">
                    Нет отмеченных смен за выбранный период
                  </div>
                )}
              </div>
            );
          })()}

          {/* Sales Breakdown by Payment Method */}
          <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg space-y-2.5">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Выручка от продаж по способам оплаты
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800">
                <span className="text-slate-300">Наличные:</span>
                <span className="font-mono tabular-nums font-semibold text-white">
                  {formatCurrency(myStat?.sales.totalCash || 0)}
                </span>
              </div>

              <div className="flex items-center justify-between py-1.5 border-b border-slate-800">
                <span className="text-slate-300">Безналичные / Карта:</span>
                <span className="font-mono tabular-nums font-semibold text-white">
                  {formatCurrency(myStat?.sales.totalCard || 0)}
                </span>
              </div>

              <div className="pt-1 flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-200">Общая выручка:</span>
                <span className="font-mono tabular-nums text-emerald-400">
                  {formatCurrency(myStat?.sales.totalRevenue || 0)}
                </span>
              </div>

              <div className="pt-0.5 flex items-center justify-between text-[11px] text-emerald-400 font-medium">
                <span>Премия 5% от выручки:</span>
                <span className="font-mono font-semibold">
                  +{formatCurrency(myStat?.sales.totalBonus || 0)}
                </span>
              </div>
            </div>
          </div>

          {/* Daily Shift Log */}
          <div className="space-y-2">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wider">
              Журнал смен за {formatMonthName(selectedMonth)}
            </div>
            {monthRecords.length === 0 ? (
              <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 text-center text-xs text-slate-500">
                Нет записей за выбранный месяц
              </div>
            ) : (
              <div className="rounded-lg bg-slate-900 border border-slate-800 divide-y divide-slate-800 overflow-hidden">
                {monthRecords.map(rec => {
                  const calc = calculateDailySales(rec.sales);
                  
                  // Calculate specific shift pay using standard unified formula
                  const shiftPay = rec.shiftType ? calculateShiftTotalSalary(rec, currentStaff, rates) : 0;
                  const shiftTotal = shiftPay + calc.bonus;

                  return (
                    <div
                      key={rec.id}
                      className="p-3 flex items-center justify-between text-xs hover:bg-slate-850/50 transition-colors"
                    >
                      <div className="space-y-0.5">
                        <div className="font-medium text-white">
                          {formatDisplayDate(rec.date)}
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                          <span>{rec.shiftType ? getShiftLabel(rec.shiftType, rates) : 'Без смены'}</span>
                          {rec.location && (
                            <span className="px-1.5 py-0.2 rounded bg-slate-950 font-mono text-[10px] text-emerald-400 border border-slate-800">
                              {rec.location}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right font-mono tabular-nums">
                        <div className="font-semibold text-emerald-400">
                          {formatCurrency(shiftTotal)}
                        </div>
                        <div className="text-[10px] text-slate-400 leading-normal">
                          оклад: {formatCurrency(shiftPay)} | премия: +{formatCurrency(calc.bonus)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
