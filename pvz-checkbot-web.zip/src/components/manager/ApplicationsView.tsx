import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ApplicationRequest, LocationType } from '../../types';
import { formatDisplayDate, parseDateSafe } from '../../utils/time';
import { copyToClipboard } from '../../utils/clipboard';
import { UserCheck, Check, X, Clock, CheckCircle2, XCircle, AlertCircle, KeyRound, Copy, ShieldCheck, MapPin } from 'lucide-react';

export const ApplicationsView: React.FC = () => {
  const { applications, handleApplication, pickupPoints = [] } = useApp();
  
  const [rejectModalApp, setRejectModalApp] = useState<ApplicationRequest | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  const [acceptModalApp, setAcceptModalApp] = useState<ApplicationRequest | null>(null);
  const [assignLogin, setAssignLogin] = useState('');
  const [assignPassword, setAssignPassword] = useState('');
  const [assignLocations, setAssignLocations] = useState<LocationType[]>([]);
  const [copied, setCopied] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const availableLocations: string[] = pickupPoints.filter(p => !p.isArchived).map(p => p.code);

  const pendingApps = (applications || []).filter(a => a.status === 'pending');
  const pastApps = (applications || []).filter(a => a.status !== 'pending');

  const toggleLocationSelection = (loc: LocationType) => {
    if (assignLocations.includes(loc)) {
      if (assignLocations.length === 1) return; // keep at least one
      setAssignLocations(assignLocations.filter(l => l !== loc));
    } else {
      setAssignLocations([...assignLocations, loc]);
    }
  };

  const openAcceptModal = (app: ApplicationRequest) => {
    setAcceptModalApp(app);
    // Generate suggested unique credentials based on name
    const randomSuffix = Math.floor(100 + Math.random() * 900);
    setAssignLogin(`emp_${randomSuffix}`);
    setAssignPassword(`pass${Math.floor(1000 + Math.random() * 9000)}`);
    setAssignLocations(availableLocations.length > 0 ? [availableLocations[0]] : []);
    setCopied(false);
  };

  const confirmAccept = async () => {
    if (acceptModalApp) {
      const res = await handleApplication(
        acceptModalApp.id,
        'accept',
        undefined,
        assignLogin.trim(),
        assignPassword.trim(),
        assignLocations
      );
      if (res.success) {
        setActionNotice(`Доступ для «${acceptModalApp.name}» успешно выдан! Логин: ${assignLogin}`);
        setTimeout(() => setActionNotice(null), 4000);
      }
      setAcceptModalApp(null);
    }
  };

  const confirmReject = async () => {
    if (rejectModalApp) {
      const res = await handleApplication(rejectModalApp.id, 'reject', rejectReason.trim());
      if (res.success) {
        setActionNotice(`Заявка кандидата «${rejectModalApp.name}» отклонена.`);
        setTimeout(() => setActionNotice(null), 3500);
      }
      setRejectModalApp(null);
      setRejectReason('');
    }
  };

  const handleCopy = async () => {
    const locsStr = assignLocations.join(', ');
    const text = `Логин: ${assignLogin}\nПароль: ${assignPassword}\nМесто работы: ${locsStr}\nВход: Админка @PVZchackbot`;
    await copyToClipboard(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const parseSafeDate = (isoStr?: string | null): { dateStr: string; timeStr: string } => {
    if (!isoStr) {
      const now = new Date();
      return {
        dateStr: formatDisplayDate(now.toISOString().slice(0, 10)),
        timeStr: now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
      };
    }
    try {
      const d = parseDateSafe(isoStr);
      return {
        dateStr: formatDisplayDate(d.toISOString().slice(0, 10)),
        timeStr: d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
      };
    } catch {
      return { dateStr: isoStr, timeStr: '' };
    }
  };

  return (
    <div className="space-y-6">

      {actionNotice && (
        <div className="p-3 bg-slate-900 text-white border border-emerald-500/50 rounded-xl text-xs flex items-center gap-2 animate-fade-in shadow-md">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <span className="text-white font-medium">{actionNotice}</span>
        </div>
      )}
      
      {/* Pending Applications Section */}
      <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-sm">
        <div className="p-4 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Новые заявки на выдачу доступа</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono font-medium">
            {pendingApps.length}
          </span>
        </div>

        {pendingApps.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/40">
            Нет активных заявок, ожидающих решения
          </div>
        ) : (
          <div className="divide-y divide-slate-800/40">
            {pendingApps.map(app => {
              const { dateStr, timeStr } = parseSafeDate(app.createdAt || app.submittedAt);

              return (
                <div key={app.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-950/80 hover:bg-slate-950 transition-colors">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm text-white">{app.name}</span>
                      <span className="text-xs text-slate-400 font-mono">
                        {app.telegramUsername ? `@${app.telegramUsername.replace('@', '')}` : 'Без Telegram'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 flex items-center gap-2 flex-wrap">
                      <span>Подана: {dateStr} {timeStr ? `в ${timeStr}` : ''}</span>
                      {app.note && <span>· {app.note}</span>}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openAcceptModal(app)}
                      className="flex-1 sm:flex-initial py-2 px-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
                    >
                      <KeyRound className="w-4 h-4" />
                      <span>Выдать логин и пароль</span>
                    </button>

                    <button
                      onClick={() => {
                        setRejectModalApp(app);
                        setRejectReason('');
                      }}
                      className="flex-1 sm:flex-initial py-2 px-3.5 bg-slate-800 hover:bg-slate-750 text-rose-400 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                      <span>Отклонить</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* History of Past Applications */}
      <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-sm">
        <div className="p-4 bg-slate-950/70 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white">История рассмотренных заявок</h3>
            <p className="text-xs text-slate-400">Ранее принятые и отклоненные заявки кандидатов</p>
          </div>
          <span className="text-xs text-slate-400 font-medium">
            Всего: {pastApps.length}
          </span>
        </div>

        {pastApps.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/40">
            История пуста
          </div>
        ) : (
          <div className="divide-y divide-slate-800/40">
            {pastApps.map(app => {
              const { dateStr } = parseSafeDate(app.createdAt || app.submittedAt);
              const isAccepted = app.status === 'accepted' || app.status === 'approved';

              return (
                <div key={app.id} className="p-4 flex items-center justify-between gap-4 text-xs bg-slate-950/80">
                  <div className="space-y-0.5">
                    <div className="font-semibold text-white flex items-center gap-2 flex-wrap">
                      <span>{app.name}</span>
                      <span className="text-slate-400 text-xs font-mono">{app.telegramUsername ? `@${app.telegramUsername.replace('@', '')}` : ''}</span>
                    </div>
                    <div className="text-xs text-slate-500">
                      Дата: {dateStr}
                      {app.note && ` · ${app.note}`}
                    </div>
                  </div>

                  <div>
                    {isAccepted ? (
                      <span className="flex items-center gap-1 text-emerald-400 font-semibold bg-emerald-950/40 px-2.5 py-1 rounded-lg text-xs">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Доступ выдан</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-rose-400 font-semibold bg-rose-950/40 px-2.5 py-1 rounded-lg text-xs">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Отклонена</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Accept & Assign Credentials & Locations Modal */}
      {acceptModalApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            
            <div className="flex items-center justify-between p-4 sm:p-5 bg-slate-950/70 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                  <KeyRound className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">Выдача доступа работнику</h3>
                  <p className="text-xs text-slate-400">Генерация учетных данных</p>
                </div>
              </div>
              <button
                onClick={() => setAcceptModalApp(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-4 flex-1 overflow-y-auto">
              <div className="p-3.5 bg-slate-950/80 rounded-xl text-xs text-slate-300 shadow-sm">
                Кандидат: <span className="font-semibold text-white">{acceptModalApp.name}</span>
                {acceptModalApp.telegramUsername && <span className="text-slate-400 font-mono"> ({acceptModalApp.telegramUsername})</span>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Логин работника *
                </label>
                <input
                  type="text"
                  required
                  value={assignLogin}
                  onChange={e => setAssignLogin(e.target.value)}
                  className="w-full h-10 min-h-[40px] px-3 py-2 bg-slate-950/90 border border-slate-700/80 hover:border-slate-600 focus:border-emerald-500/80 focus:ring-1 focus:ring-emerald-500/30 rounded-xl text-xs text-white font-mono focus:outline-none transition-all shadow-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Пароль *
                </label>
                <input
                  type="text"
                  required
                  value={assignPassword}
                  onChange={e => setAssignPassword(e.target.value)}
                  className="w-full h-10 min-h-[40px] px-3 py-2 bg-slate-950/90 border border-slate-700/80 hover:border-slate-600 focus:border-emerald-500/80 focus:ring-1 focus:ring-emerald-500/30 rounded-xl text-xs text-white font-mono focus:outline-none transition-all shadow-sm"
                />
              </div>

              {/* Select Locations */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Место работы (выберите пункты ПВЗ) *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {availableLocations.map(loc => {
                    const isSelected = assignLocations.includes(loc);
                    return (
                      <button
                        key={loc}
                        type="button"
                        onClick={() => toggleLocationSelection(loc)}
                        className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm ${
                          isSelected
                            ? 'bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-500/50'
                            : 'bg-slate-950/80 text-slate-400 hover:text-white'
                        }`}
                      >
                        <div className={`w-3.5 h-3.5 rounded flex items-center justify-center ${
                          isSelected ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800'
                        }`}>
                          {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                        </div>
                        <span className="font-mono">Пункт {loc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                type="button"
                onClick={handleCopy}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-sm"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-semibold">Данные скопированы для отправки</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Скопировать логин, пароль и локацию</span>
                  </>
                )}
              </button>

              <div className="p-3 bg-slate-950/80 rounded-xl text-[11px] text-slate-400 leading-relaxed shadow-sm">
                Работник будет создан со статусом «Активен». Вход осуществляется через общую страницу авторизации.
              </div>
            </div>

            <div className="p-4 sm:p-5 bg-slate-950/70 flex items-center justify-end gap-2.5">
              <button
                onClick={() => setAcceptModalApp(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
              >
                Отмена
              </button>
              <button
                onClick={confirmAccept}
                disabled={!assignLogin.trim() || !assignPassword.trim() || assignLocations.length === 0}
                className={`px-5 py-2 text-xs font-semibold rounded-xl transition-all shadow-sm ${
                  assignLogin.trim() && assignPassword.trim() && assignLocations.length > 0
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                Подтвердить и открыть доступ
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Rejection Modal with Reason */}
      {rejectModalApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            
            <div className="flex items-center justify-between p-4 sm:p-5 bg-slate-950/70 border-b border-slate-800 shrink-0">
              <h3 className="text-base font-semibold text-white">Отклонение заявки</h3>
              <button
                onClick={() => setRejectModalApp(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-3 flex-1 overflow-y-auto">
              <p className="text-xs text-slate-300">
                Вы отклоняете заявку кандидата <strong className="text-white font-semibold">{rejectModalApp.name}</strong>.
              </p>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Причина отклонения (необязательно)
                </label>
                <input
                  type="text"
                  placeholder="например, набор сотрудников временно закрыт"
                  value={rejectReason}
                  onChange={e => setRejectReason(e.target.value)}
                  className="w-full h-10 min-h-[40px] px-3 py-2 bg-slate-950/90 border border-slate-700/80 hover:border-slate-600 focus:border-rose-500/80 focus:ring-1 focus:ring-rose-500/30 rounded-xl text-xs text-white focus:outline-none transition-all shadow-sm"
                />
              </div>
            </div>

            <div className="p-4 sm:p-5 bg-slate-950/70 flex items-center justify-end gap-3">
              <button
                onClick={() => setRejectModalApp(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
              >
                Отмена
              </button>
              <button
                onClick={confirmReject}
                className="px-4 py-2 text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded-xl transition-all shadow-sm cursor-pointer"
              >
                Подтвердить отказ
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
