import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getCurrentAndPreviousMonth, formatMonthName, getAllAvailableMonths } from '../../utils/time';
import { exportMonthlyReportToExcel } from '../../utils/excelExport';
import { FileSpreadsheet, Download, Check, AlertCircle } from 'lucide-react';

export const ExcelExportView: React.FC = () => {
  const { records, staffList, rates } = useApp();
  const { current } = getCurrentAndPreviousMonth();
  const allMonths = getAllAvailableMonths(records, 12);

  const availableMonths = allMonths.map(m => ({
    id: m.key,
    label: `${m.label}${m.isCurrent ? ' (Текущий)' : ''}`,
  }));

  const [selectedMonths, setSelectedMonths] = useState<string[]>([current]);
  const [isExporting, setIsExporting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const toggleMonth = (mId: string) => {
    if (selectedMonths.includes(mId)) {
      if (selectedMonths.length > 1) {
        setSelectedMonths(selectedMonths.filter(id => id !== mId));
      }
    } else {
      setSelectedMonths([...selectedMonths, mId]);
    }
  };

  const handleExport = async () => {
    if (selectedMonths.length === 0) return;
    setIsExporting(true);
    setErrorMessage(null);

    try {
      exportMonthlyReportToExcel(records, staffList, selectedMonths, rates);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      console.error('Export error:', err);
      setErrorMessage(err?.message || 'Ошибка при формировании Excel файла.');
      setTimeout(() => setErrorMessage(null), 5000);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      <div className="p-5 sm:p-6 bg-slate-900 border border-slate-800 rounded-lg space-y-5 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-md bg-slate-800 text-emerald-400 flex items-center justify-center border border-slate-700/80 shrink-0">
            <FileSpreadsheet className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-white">Экспорт отчёта в Excel (.xlsx)</h3>
            <p className="text-xs text-slate-400">Выгрузка детализированной ведомости за выбранные периоды</p>
          </div>
        </div>

        {/* Period Selection */}
        <div className="space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <label className="block text-xs font-medium text-slate-300 uppercase tracking-wider">
              Выберите отчётные месяцы
            </label>
            <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-md bg-slate-950 text-slate-300 border border-slate-800">
              Выбрано: {selectedMonths.length}
            </span>
          </div>

          {/* Quick Preset Buttons */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => setSelectedMonths([current])}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                selectedMonths.length === 1 && selectedMonths.includes(current)
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'bg-slate-950 hover:bg-slate-850 text-slate-400 border border-slate-800'
              }`}
            >
              Текущий
            </button>
            {allMonths.length > 1 && (
              <button
                type="button"
                onClick={() => setSelectedMonths([allMonths[1].key])}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  selectedMonths.length === 1 && selectedMonths.includes(allMonths[1].key)
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'bg-slate-950 hover:bg-slate-850 text-slate-400 border border-slate-800'
                }`}
              >
                Прошлый
              </button>
            )}
            {allMonths.length >= 3 && (
              <button
                type="button"
                onClick={() => setSelectedMonths(allMonths.slice(0, 3).map(m => m.key))}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  selectedMonths.length === 3 && allMonths.slice(0, 3).every(m => selectedMonths.includes(m.key))
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'bg-slate-950 hover:bg-slate-850 text-slate-400 border border-slate-800'
                }`}
              >
                Квартал (3 мес.)
              </button>
            )}
            <button
              type="button"
              onClick={() => setSelectedMonths(allMonths.map(m => m.key))}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                selectedMonths.length === allMonths.length
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'bg-slate-950 hover:bg-slate-850 text-slate-400 border border-slate-800'
              }`}
            >
              Все ({allMonths.length})
            </button>
          </div>

          {/* Compact Month Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 pt-1">
            {availableMonths.map(m => {
              const isChecked = selectedMonths.includes(m.id);
              const isCurr = m.id === current;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => toggleMonth(m.id)}
                  className={`p-2.5 rounded-md border text-left transition-colors flex flex-col justify-between gap-1.5 cursor-pointer relative overflow-hidden ${
                    isChecked
                      ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500 text-white'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">{m.id}</span>
                    <div
                      className={`w-3.5 h-3.5 rounded-xs flex items-center justify-center transition-colors ${
                        isChecked
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-slate-900 border border-slate-700'
                      }`}
                    >
                      {isChecked && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-medium text-white truncate">
                      {formatMonthName(m.id)}
                    </span>
                    {isCurr && (
                      <span className="text-[11px] font-medium px-1.5 py-0.2 rounded-xs bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 shrink-0">
                        Тек.
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* What file contains info */}
        <div className="p-3.5 bg-slate-950 rounded-md border border-slate-800 text-xs text-slate-400 space-y-2">
          <div className="font-medium text-slate-300 flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 text-sky-400" />
            <span>Содержимое генерируемой таблицы Excel:</span>
          </div>
          <ul className="list-disc list-inside space-y-1 text-slate-400 pl-1 leading-relaxed">
            <li>Сводный лист по сотрудникам с разбивкой всех типов смен</li>
            <li>Выручка от продаж (Наличные и Безналичные / Карта)</li>
            <li>Итоговые денежные суммы выручки и фонд премий 5%</li>
            <li>Дневной подробный журнал смен и отметок времени</li>
          </ul>
        </div>

        {/* Error Message */}
        {errorMessage && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-md text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Export Button */}
        <div>
          <button
            onClick={handleExport}
            disabled={isExporting || selectedMonths.length === 0}
            className={`w-full py-2.5 px-4 rounded-md text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer ${
              success
                ? 'bg-emerald-600 text-white'
                : selectedMonths.length > 0
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {success ? (
              <>
                <Check className="w-4 h-4" />
                <span>Файл Excel успешно скачан</span>
              </>
            ) : isExporting ? (
              <span>Генерация файла...</span>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Выгрузить Excel-файл (.xlsx)</span>
              </>
            )}
          </button>
        </div>

      </div>

    </div>
  );
};
