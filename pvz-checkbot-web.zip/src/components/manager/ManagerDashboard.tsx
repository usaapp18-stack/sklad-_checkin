import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { TodayView } from './TodayView';
import { StaffManagementView } from './StaffManagementView';
import { ApplicationsView } from './ApplicationsView';
import { ReportsView } from './ReportsView';
import { ExcelExportView } from './ExcelExportView';
import { SchedulePlannerView } from './SchedulePlannerView';
import { ShiftSwapManagerView } from './ShiftSwapManagerView';
import { PickupPointsManagementView } from './PickupPointsManagementView';
import { PaybackCalculatorView } from './PaybackCalculatorView';
import { ScheduledNotificationsView } from './ScheduledNotificationsView';
import { TelegramSettingsView } from './TelegramSettingsView';
import {
  CalendarDays,
  Building2,
  Calculator,
  Users,
  UserPlus,
  BarChart3,
  FileSpreadsheet,
  Bell,
  MessageSquare,
  Send,
  CalendarCheck,
  ArrowLeftRight,
  TrendingUp,
  LayoutGrid,
  ChevronDown,
  ChevronRight,
  X,
  Layers,
  Clock,
} from 'lucide-react';

export const ManagerDashboard: React.FC = () => {
  const {
    staffList,
    applications,
    messages,
    swaps,
    notifications,
    pickupPoints,
    telegramSettings,
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'today' | 'pvz' | 'payback' | 'schedule' | 'swaps' | 'staff' | 'applications' | 'reports' | 'excel' | 'notifications' | 'telegram'
  >('today');

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const mobileNavRef = useRef<HTMLDivElement>(null);

  // Auto-scroll the active icon into view on mobile
  useEffect(() => {
    if (mobileNavRef.current) {
      const activeEl = mobileNavRef.current.querySelector('[data-active="true"]') as HTMLElement;
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }
  }, [activeTab]);

  const pendingAppsCount = applications.filter(a => a.status === 'pending').length;
  const pendingSwapsCount = swaps.filter(s => s.status === 'open' || s.status === 'claimed').length;
  const activeStaffCount = staffList.filter((s: any) => s.status === 'active').length;

  const categories = [
    { id: 'operations', title: 'Смены и операции', icon: CalendarDays },
    { id: 'network', title: 'Сеть ПВЗ и персонал', icon: Building2 },
    { id: 'finance', title: 'Финансы и отчётность', icon: BarChart3 },
    { id: 'system', title: 'Автоматизация', icon: Bell },
  ] as const;

  const navSections = [
    // 1. Смены и операции
    {
      id: 'today' as const,
      label: 'Сегодня',
      shortLabel: 'Сегодня',
      category: 'operations' as const,
      categoryLabel: 'Смены и выходы',
      desc: 'Явки, открытие смен и касса онлайн',
      icon: CalendarDays,
    },
    {
      id: 'schedule' as const,
      label: 'График смен',
      shortLabel: 'График',
      category: 'operations' as const,
      categoryLabel: 'Смены и выходы',
      desc: 'Планирование и назначение смен',
      icon: CalendarCheck,
    },
    {
      id: 'swaps' as const,
      label: 'Биржа смен',
      shortLabel: 'Биржа',
      category: 'operations' as const,
      categoryLabel: 'Смены и выходы',
      desc: 'Запросы сотрудников на обмен сменами',
      icon: ArrowLeftRight,
      badge: pendingSwapsCount > 0 ? pendingSwapsCount : undefined,
      badgeVariant: 'amber' as const,
    },

    // 2. Сеть ПВЗ и персонал
    {
      id: 'pvz' as const,
      label: 'Пункты выдачи (ПВЗ)',
      shortLabel: 'ПВЗ сети',
      category: 'network' as const,
      categoryLabel: 'Сеть и кадры',
      desc: 'Управление пунктами выдачи и привязка персонала',
      icon: Building2,
      badge: pickupPoints.length,
      badgeVariant: 'emerald' as const,
    },
    {
      id: 'staff' as const,
      label: 'Сотрудники',
      shortLabel: 'Кадры',
      category: 'network' as const,
      categoryLabel: 'Сеть и кадры',
      desc: 'Список сотрудников, ставки и выработка',
      icon: Users,
      badge: activeStaffCount,
      badgeVariant: 'emerald' as const,
    },
    {
      id: 'applications' as const,
      label: 'Заявки кандидатов',
      shortLabel: 'Заявки',
      category: 'network' as const,
      categoryLabel: 'Сеть и кадры',
      desc: 'Анкеты новых сотрудников на проверке',
      icon: UserPlus,
      badge: pendingAppsCount > 0 ? pendingAppsCount : undefined,
      badgeVariant: 'amber' as const,
    },

    // 3. Финансы и аналитика
    {
      id: 'payback' as const,
      label: 'Окупаемость ПВЗ',
      shortLabel: 'Окупаемость',
      category: 'finance' as const,
      categoryLabel: 'Финансы и аналитика',
      desc: 'Калькулятор окупаемости, доходы, расходы и сравнение пунктов',
      icon: Calculator,
    },
    {
      id: 'reports' as const,
      label: 'Отчеты',
      shortLabel: 'Отчеты',
      category: 'finance' as const,
      categoryLabel: 'Финансы и аналитика',
      desc: 'Детальные финансовые и зарплатные ведомости',
      icon: BarChart3,
    },
    {
      id: 'excel' as const,
      label: 'Экспорт Excel',
      shortLabel: 'Excel',
      category: 'finance' as const,
      categoryLabel: 'Финансы и аналитика',
      desc: 'Выгрузка сводных таблиц в формат .xlsx',
      icon: FileSpreadsheet,
    },

    // 4. Автоматизация
    {
      id: 'telegram' as const,
      label: 'Telegram-уведомления',
      shortLabel: 'Telegram',
      category: 'system' as const,
      categoryLabel: 'Автоматизация',
      desc: 'Привязка бота и ID руководителя для всех уведомлений',
      icon: Send,
      badge: telegramSettings?.isConfigured ? 'Активен' : 'Не настроен',
      badgeVariant: telegramSettings?.isConfigured ? ('emerald' as const) : ('amber' as const),
    },
    {
      id: 'notifications' as const,
      label: 'Планировщик Telegram',
      shortLabel: 'Рассылки',
      category: 'system' as const,
      categoryLabel: 'Автоматизация',
      desc: 'Авто-рассылки и напоминания сотрудникам в Telegram',
      icon: Clock,
    },
  ];

  const currentSection = navSections.find(s => s.id === activeTab) || navSections[0];
  const CurrentIcon = currentSection.icon;

  return (
    <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 space-y-6">
      
      {/* ========================================================================= */}
      {/* DESKTOP NAVIGATION (>= md): Crisp, Linear-style segmented control        */}
      {/* ========================================================================= */}
      <div className="hidden md:block bg-slate-900 border border-slate-800 rounded-lg p-1.5 shadow-sm">
        <div className="flex flex-wrap items-center gap-1">
          {navSections.map(section => {
            const Icon = section.icon;
            const isActive = activeTab === section.id;
            return (
              <button
                key={section.id}
                onClick={() => setActiveTab(section.id)}
                className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors relative cursor-pointer border ${
                  isActive
                    ? 'bg-slate-800 text-white border-slate-700/80 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border-transparent'
                }`}
                title={section.desc}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-200' : 'text-slate-500'}`} />
                <span>{section.label}</span>
                {section.badge !== undefined && (
                  <span
                    className={`text-[11px] font-mono font-medium ml-0.5 ${
                      section.badgeVariant === 'amber'
                        ? 'text-amber-400'
                        : 'text-slate-400'
                    }`}
                  >
                    {section.badge}
                  </span>
                )}
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-0.5" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MOBILE NAVIGATION (< md): Clean UX/UI without horizontal scroll          */}
      {/* ========================================================================= */}
      <div className="block md:hidden space-y-2">
        {/* 1. Active Section Summary Card with Menu Opener */}
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg shadow-sm">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-md bg-slate-800 text-emerald-400 flex items-center justify-center shrink-0 border border-slate-700/70">
                <CurrentIcon className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-medium text-slate-400">
                    {currentSection.categoryLabel}
                  </span>
                  {currentSection.badge !== undefined && (
                    <span className="text-xs font-mono font-medium text-amber-400 ml-1">
                      {currentSection.badge}
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-medium text-white truncate">
                  {currentSection.label}
                </h3>
              </div>
            </div>

            {/* Tap to open full categorized navigation sheet */}
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="flex items-center gap-1.5 py-1.5 px-3 bg-slate-800 hover:bg-slate-750 active:bg-slate-700 text-slate-200 rounded-md text-xs font-medium shrink-0 transition-colors shadow-xs cursor-pointer border border-slate-700/70"
              title="Открыть все разделы"
            >
              <LayoutGrid className="w-3.5 h-3.5 text-slate-400" />
              <span>Все разделы</span>
              {(pendingAppsCount > 0 || pendingSwapsCount > 0) && (
                <span className="w-2 h-2 rounded-full bg-amber-400" />
              )}
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>
        </div>

        {/* 2. Compact Icon-Only Navigation Bar (No text labels, maximum data density) */}
        <div
          ref={mobileNavRef}
          className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden shadow-sm"
        >
          {navSections.map(section => {
            const Icon = section.icon;
            const isActive = activeTab === section.id;
            return (
              <button
                key={section.id}
                onClick={() => setActiveTab(section.id)}
                data-active={isActive}
                className={`relative shrink-0 w-8.5 h-8.5 flex items-center justify-center rounded-md transition-colors cursor-pointer border ${
                  isActive
                    ? 'bg-slate-800 text-white border-slate-700/80'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border-transparent'
                }`}
                title={section.label}
                aria-label={section.label}
              >
                <Icon className="w-4 h-4" />
                {section.badge !== undefined && (
                  <span
                    className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full ${
                      section.badgeVariant === 'amber' ? 'bg-amber-400' : 'bg-emerald-400'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MOBILE FULL NAVIGATION DRAWER / BOTTOM SHEET MODAL                        */}
      {/* ========================================================================= */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex flex-col justify-end sm:justify-center p-0 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-3xl sm:rounded-2xl w-full max-w-lg mx-auto overflow-hidden shadow-2xl flex flex-col max-h-[88vh] animate-in slide-in-from-bottom duration-200">
            
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-850 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400">
                  <LayoutGrid className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-white">Разделы управления</h3>
                  <p className="text-xs text-slate-400">Выберите раздел для перехода</p>
                </div>
              </div>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                title="Закрыть"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: Categorized List of All 11 Sections */}
            <div className="p-4 overflow-y-auto space-y-4">
              {categories.map(cat => {
                const items = navSections.filter(s => s.category === cat.id);
                return (
                  <div key={cat.id} className="space-y-1.5">
                    <div className="flex items-center gap-1.5 px-1 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                      <span>{cat.title}</span>
                    </div>
                    <div className="grid grid-cols-1 gap-1.5">
                      {items.map(item => {
                        const ItemIcon = item.icon;
                        const isSelected = activeTab === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              setActiveTab(item.id);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                              isSelected
                                ? 'bg-emerald-500/15 border-emerald-500/50 text-white shadow-sm'
                                : 'bg-slate-950/60 hover:bg-slate-800 active:bg-slate-800 border-slate-800/80 text-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div
                                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                                  isSelected
                                    ? 'bg-emerald-500 text-white font-bold'
                                    : 'bg-slate-850 text-slate-400'
                                }`}
                              >
                                <ItemIcon className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className={`text-xs font-medium ${isSelected ? 'text-emerald-400' : 'text-slate-100'}`}>
                                    {item.label}
                                  </span>
                                  {item.badge !== undefined && (
                                    <span
                                      className={`text-xs font-mono font-medium ${
                                        item.badgeVariant === 'amber'
                                          ? 'text-amber-400 font-semibold'
                                          : 'text-slate-400'
                                      }`}
                                    >
                                      {item.badge}
                                    </span>
                                  )}
                                </div>
                                <p className="text-[11px] text-slate-400 truncate">{item.desc}</p>
                              </div>
                            </div>

                            <div className="shrink-0 ml-2">
                              {isSelected ? (
                                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                              ) : (
                                <ChevronRight className="w-4 h-4 text-slate-600" />
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Modal Footer */}
            <div className="p-3 border-t border-slate-800 bg-slate-850 flex justify-end">
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold transition-all text-center"
              >
                Закрыть меню
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Content Sections */}
      <div>
        {activeTab === 'today' && <TodayView />}
        {activeTab === 'pvz' && <PickupPointsManagementView />}
        {activeTab === 'payback' && <PaybackCalculatorView />}
        {activeTab === 'notifications' && <ScheduledNotificationsView />}
        {activeTab === 'telegram' && <TelegramSettingsView />}
        {activeTab === 'schedule' && <SchedulePlannerView />}
        {activeTab === 'swaps' && <ShiftSwapManagerView />}
        {activeTab === 'staff' && <StaffManagementView />}
        {activeTab === 'applications' && <ApplicationsView />}
        {activeTab === 'reports' && <ReportsView />}
        {activeTab === 'excel' && <ExcelExportView />}
      </div>

    </div>
  );
};
