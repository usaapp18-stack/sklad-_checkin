import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { formatCurrency } from '../../utils/calculations';
import { PaybackArticleItem, PaybackPvzRecord } from '../../types';
import { MiniCalculator } from '../common/MiniCalculator';
import {
  Calculator,
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart,
  Plus,
  Trash2,
  Edit3,
  Sliders,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Award,
  Layers,
  ChevronLeft,
  ChevronRight,
  Check,
  Building2,
  Calendar,
  BarChart3,
  ShieldAlert,
  Loader2,
} from 'lucide-react';

const MONTH_NAMES = [
  'Январь',
  'Февраль',
  'Март',
  'Апрель',
  'Май',
  'Июнь',
  'Июль',
  'Август',
  'Сентябрь',
  'Октябрь',
  'Ноябрь',
  'Декабрь',
];

const DEFAULT_INCOME_NAMES = [
  'Агентское вознаграждение',
  'Продажи за смену (выручка)',
];

const DEFAULT_EXPENSE_NAMES = [
  'Аренда помещения',
  'Фонд оплаты труда (ФОТ)',
  'Коммунальные услуги и интернет',
  'Эквайринг и банковское обслуживание',
  'Расходники (лента, скотч, пакетирование)',
  'Налоги',
];

// Visual number formatter dividing thousands with space (150000 -> 150 000)
function formatNumberWithSpaces(val: number | string | undefined): string {
  if (val === undefined || val === null || val === '') return '';
  const num = typeof val === 'number' ? val : Number(String(val).replace(/\s/g, ''));
  if (isNaN(num)) return '';
  if (num === 0) return '';
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

export const PaybackCalculatorView: React.FC = () => {
  const {
    pickupPoints,
    paybackRecords,
    paybackTemplates,
    savePaybackRecord,
    savePaybackArticle,
  } = useApp();

  // Active locations
  const activeLocations = useMemo(() => {
    return pickupPoints.filter(p => !p.isArchived);
  }, [pickupPoints]);

  // Selected period: Year and Month
  const [selectedYear, setSelectedYear] = useState<number>(() => new Date().getFullYear());
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number>(() => new Date().getMonth()); // 0 - 11

  const currentMonthStr = useMemo(() => {
    return `${selectedYear}-${String(selectedMonthIndex + 1).padStart(2, '0')}`;
  }, [selectedYear, selectedMonthIndex]);

  // Selected PVZ: code or 'ALL' for overview
  const [selectedPvzCode, setSelectedPvzCode] = useState<string>(() => {
    return activeLocations[0]?.code || '';
  });

  // Sync if selected PVZ was deleted or changed
  useEffect(() => {
    if (activeLocations.length > 0) {
      const exists = activeLocations.some(p => p.code === selectedPvzCode);
      if (!exists && selectedPvzCode !== 'ALL') {
        setSelectedPvzCode(activeLocations[0].code);
      }
    }
  }, [activeLocations, selectedPvzCode]);

  // Period navigation
  const handlePrevMonth = () => {
    if (selectedMonthIndex === 0) {
      setSelectedMonthIndex(11);
      setSelectedYear(y => y - 1);
    } else {
      setSelectedMonthIndex(m => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonthIndex === 11) {
      setSelectedMonthIndex(0);
      setSelectedYear(y => y + 1);
    } else {
      setSelectedMonthIndex(m => m + 1);
    }
  };

  // Local state for current PVZ & month
  const [localIncomes, setLocalIncomes] = useState<PaybackArticleItem[]>([]);
  const [localExpenses, setLocalExpenses] = useState<PaybackArticleItem[]>([]);

  // Independent edit modes for each block: [Редактировать] [Применить] [Отменить]
  const [isEditingIncomes, setIsEditingIncomes] = useState<boolean>(false);
  const [backupIncomes, setBackupIncomes] = useState<PaybackArticleItem[]>([]);

  const [isEditingExpenses, setIsEditingExpenses] = useState<boolean>(false);
  const [backupExpenses, setBackupExpenses] = useState<PaybackArticleItem[]>([]);

  const [isSavingIncomes, setIsSavingIncomes] = useState<boolean>(false);
  const [isSavingExpenses, setIsSavingExpenses] = useState<boolean>(false);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Mini Calculator Widget State (+ - * / %)
  const [isCalcOpen, setIsCalcOpen] = useState<boolean>(false);
  const [calcTargetArticle, setCalcTargetArticle] = useState<{ type: 'income' | 'expense'; id: string } | null>(null);

  // Active Template Articles (Incomes & Expenses)
  const activeTemplateIncomes = useMemo<string[]>(() => {
    if (Array.isArray(paybackTemplates.incomeArticles) && paybackTemplates.incomeArticles.length > 0) {
      return paybackTemplates.incomeArticles;
    }
    const custom = paybackTemplates.customIncomeArticles || [];
    return Array.from(new Set([...DEFAULT_INCOME_NAMES, ...custom]));
  }, [paybackTemplates]);

  const activeTemplateExpenses = useMemo<string[]>(() => {
    if (Array.isArray(paybackTemplates.expenseArticles) && paybackTemplates.expenseArticles.length > 0) {
      return paybackTemplates.expenseArticles;
    }
    const custom = paybackTemplates.customExpenseArticles || [];
    return Array.from(new Set([...DEFAULT_EXPENSE_NAMES, ...custom]));
  }, [paybackTemplates]);

  // Track PVZ and Period transitions so background context updates don't stomp active edits
  const prevPeriodRef = useRef<{ pvz: string; month: string }>({
    pvz: selectedPvzCode,
    month: currentMonthStr,
  });

  // Initialize or load record when selectedPvzCode or currentMonthStr changes
  useEffect(() => {
    if (!selectedPvzCode || selectedPvzCode === 'ALL') {
      setLocalIncomes([]);
      setLocalExpenses([]);
      setIsEditingIncomes(false);
      setIsEditingExpenses(false);
      setEditingArticleId(null);
      setEditingArticleName('');
      return;
    }

    const periodChanged =
      prevPeriodRef.current.pvz !== selectedPvzCode ||
      prevPeriodRef.current.month !== currentMonthStr;

    prevPeriodRef.current = { pvz: selectedPvzCode, month: currentMonthStr };

    // If user is actively editing a block and didn't switch PVZ or month, DO NOT stomp their work!
    if (!periodChanged && (isEditingIncomes || isEditingExpenses)) {
      return;
    }

    // Reset editing modes if period or PVZ actually changed
    if (periodChanged) {
      setIsEditingIncomes(false);
      setIsEditingExpenses(false);
      setEditingArticleId(null);
      setEditingArticleName('');
    }

    const savedRecord = paybackRecords.find(
      r => r.pvzCode === selectedPvzCode && r.month === currentMonthStr
    );

    let initialIncomes: PaybackArticleItem[] = [];
    if (savedRecord && Array.isArray(savedRecord.incomes) && savedRecord.incomes.length > 0) {
      initialIncomes = savedRecord.incomes.map(item => ({ ...item }));
      // Ensure any newly added template items exist with 0
      activeTemplateIncomes.forEach(name => {
        if (!initialIncomes.some(i => i.name === name)) {
          initialIncomes.push({
            id: `inc-${name}-${Date.now()}-${Math.random()}`,
            name,
            amount: 0,
          });
        }
      });
    } else {
      initialIncomes = activeTemplateIncomes.map(name => ({
        id: `inc-${name}-${Date.now()}-${Math.random()}`,
        name,
        amount: 0,
      }));
    }

    let initialExpenses: PaybackArticleItem[] = [];
    if (savedRecord && Array.isArray(savedRecord.expenses) && savedRecord.expenses.length > 0) {
      initialExpenses = savedRecord.expenses.map(item => ({ ...item }));
      // Ensure any newly added template items exist with 0
      activeTemplateExpenses.forEach(name => {
        if (!initialExpenses.some(e => e.name === name)) {
          initialExpenses.push({
            id: `exp-${name}-${Date.now()}-${Math.random()}`,
            name,
            amount: 0,
          });
        }
      });
    } else {
      initialExpenses = activeTemplateExpenses.map(name => ({
        id: `exp-${name}-${Date.now()}-${Math.random()}`,
        name,
        amount: 0,
      }));
    }

    setLocalIncomes(initialIncomes);
    setLocalExpenses(initialExpenses);
    setSaveSuccessNotice(null);
    setSaveError(null);
  }, [
    selectedPvzCode,
    currentMonthStr,
    paybackRecords,
    paybackTemplates,
    activeTemplateIncomes,
    activeTemplateExpenses,
    isEditingIncomes,
    isEditingExpenses,
  ]);

  // Article Modals & Editing
  const [isAddIncomeModalOpen, setIsAddIncomeModalOpen] = useState(false);
  const [newIncomeName, setNewIncomeName] = useState('');
  const [newIncomeAmount, setNewIncomeAmount] = useState('');

  const [isAddExpenseModalOpen, setIsAddExpenseModalOpen] = useState(false);
  const [newExpenseName, setNewExpenseName] = useState('');
  const [newExpenseAmount, setNewExpenseAmount] = useState('');

  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);
  const [editingArticleName, setEditingArticleName] = useState<string>('');


  // ACTIONS FOR BLOCK 1: ДОХОДЫ И АГЕНТСКИЕ (Редактировать, Применить, Отменить)
  const handleStartEditIncomes = () => {
    setBackupIncomes(JSON.parse(JSON.stringify(localIncomes)));
    setIsEditingIncomes(true);
    setEditingArticleId(null);
    setEditingArticleName('');
  };

  const handleCancelIncomes = () => {
    if (backupIncomes.length > 0) {
      setLocalIncomes(backupIncomes);
    }
    setIsEditingIncomes(false);
    setEditingArticleId(null);
    setEditingArticleName('');
  };

  const handleApplyIncomes = async () => {
    if (!selectedPvzCode || selectedPvzCode === 'ALL') return;

    // If an inline rename was open, commit it first
    let incomesToSave = [...localIncomes];
    if (editingArticleId) {
      const cleanNew = editingArticleName.trim();
      if (cleanNew) {
        incomesToSave = incomesToSave.map(i => i.id === editingArticleId ? { ...i, name: cleanNew } : i);
        setLocalIncomes(incomesToSave);
      }
      setEditingArticleId(null);
      setEditingArticleName('');
    }

    setIsSavingIncomes(true);
    setSaveError(null);

    const recordToSave: PaybackPvzRecord = {
      pvzCode: selectedPvzCode,
      month: currentMonthStr,
      incomes: incomesToSave.map(i => ({
        id: i.id,
        name: i.name.trim(),
        amount: Math.max(0, Number(i.amount) || 0),
      })),
      expenses: localExpenses.map(e => ({
        id: e.id,
        name: e.name.trim(),
        amount: Math.max(0, Number(e.amount) || 0),
      })),
      updatedAt: new Date().toISOString(),
    };

    try {
      const res = await savePaybackRecord(recordToSave);
      if (res.success) {
        setIsEditingIncomes(false);
        setSaveSuccessNotice('Доходы сохранены на сервере!');
        setTimeout(() => setSaveSuccessNotice(null), 3000);
      } else {
        const errText = typeof res.error === 'string' ? res.error : (res.error as any)?.message || 'Ошибка при сохранении на сервере';
        setSaveError(errText);
      }
    } catch (err: any) {
      setSaveError(err.message || 'Сетевая ошибка при сохранении');
    } finally {
      setIsSavingIncomes(false);
    }
  };

  // ACTIONS FOR BLOCK 2: ЕЖЕМЕСЯЧНЫЕ РАСХОДЫ (Редактировать, Применить, Отменить)
  const handleStartEditExpenses = () => {
    setBackupExpenses(JSON.parse(JSON.stringify(localExpenses)));
    setIsEditingExpenses(true);
    setEditingArticleId(null);
    setEditingArticleName('');
  };

  const handleCancelExpenses = () => {
    if (backupExpenses.length > 0) {
      setLocalExpenses(backupExpenses);
    }
    setIsEditingExpenses(false);
    setEditingArticleId(null);
    setEditingArticleName('');
  };

  const handleApplyExpenses = async () => {
    if (!selectedPvzCode || selectedPvzCode === 'ALL') return;

    // If an inline rename was open, commit it first
    let expensesToSave = [...localExpenses];
    if (editingArticleId) {
      const cleanNew = editingArticleName.trim();
      if (cleanNew) {
        expensesToSave = expensesToSave.map(e => e.id === editingArticleId ? { ...e, name: cleanNew } : e);
        setLocalExpenses(expensesToSave);
      }
      setEditingArticleId(null);
      setEditingArticleName('');
    }

    setIsSavingExpenses(true);
    setSaveError(null);

    const recordToSave: PaybackPvzRecord = {
      pvzCode: selectedPvzCode,
      month: currentMonthStr,
      incomes: localIncomes.map(i => ({
        id: i.id,
        name: i.name.trim(),
        amount: Math.max(0, Number(i.amount) || 0),
      })),
      expenses: expensesToSave.map(e => ({
        id: e.id,
        name: e.name.trim(),
        amount: Math.max(0, Number(e.amount) || 0),
      })),
      updatedAt: new Date().toISOString(),
    };

    try {
      const res = await savePaybackRecord(recordToSave);
      if (res.success) {
        setIsEditingExpenses(false);
        setSaveSuccessNotice('Расходы сохранены на сервере!');
        setTimeout(() => setSaveSuccessNotice(null), 3000);
      } else {
        const errText = typeof res.error === 'string' ? res.error : (res.error as any)?.message || 'Ошибка при сохранении на сервере';
        setSaveError(errText);
      }
    } catch (err: any) {
      setSaveError(err.message || 'Сетевая ошибка при сохранении');
    } finally {
      setIsSavingExpenses(false);
    }
  };

  // Inline rename handlers (Local ONLY! Does NOT call server, does NOT exit edit mode)
  const handleStartRename = (id: string, currentName: string) => {
    setEditingArticleId(id);
    setEditingArticleName(currentName);
  };

  const handleFinishRename = (type: 'income' | 'expense', id: string) => {
    const cleanNew = editingArticleName.trim();
    if (cleanNew) {
      if (type === 'income') {
        setLocalIncomes(prev => prev.map(i => i.id === id ? { ...i, name: cleanNew } : i));
      } else {
        setLocalExpenses(prev => prev.map(e => e.id === id ? { ...e, name: cleanNew } : e));
      }
    }
    setEditingArticleId(null);
    setEditingArticleName('');
  };

  const handleCancelRename = () => {
    setEditingArticleId(null);
    setEditingArticleName('');
  };

  // Delete article handler (Local ONLY in edit mode!)
  const handleDeleteArticle = (type: 'income' | 'expense', id: string) => {
    if (type === 'income') {
      setLocalIncomes(prev => prev.filter(i => i.id !== id));
    } else {
      setLocalExpenses(prev => prev.filter(e => e.id !== id));
    }
    if (editingArticleId === id) {
      setEditingArticleId(null);
      setEditingArticleName('');
    }
  };

  // Add Income Item handler
  const handleAddIncomeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newIncomeName.trim();
    if (!cleanName) return;
    const amountVal = Math.max(0, Number(newIncomeAmount.replace(/\D/g, '')) || 0);

    const newItem: PaybackArticleItem = {
      id: `inc-${Date.now()}-${Math.random()}`,
      name: cleanName,
      amount: amountVal,
    };

    const updated = [...localIncomes, newItem];
    setLocalIncomes(updated);
    setNewIncomeName('');
    setNewIncomeAmount('');
    setIsAddIncomeModalOpen(false);

    // If currently in edit mode, user will click "Применить" to save all changes
    if (isEditingIncomes) {
      return;
    }

    // If not in edit mode, save immediately
    if (selectedPvzCode && selectedPvzCode !== 'ALL') {
      await savePaybackRecord({
        pvzCode: selectedPvzCode,
        month: currentMonthStr,
        incomes: updated,
        expenses: localExpenses,
        updatedAt: new Date().toISOString(),
      });
      setSaveSuccessNotice('Статья доходов добавлена!');
      setTimeout(() => setSaveSuccessNotice(null), 3000);
    }
  };

  // Add Expense Item handler
  const handleAddExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newExpenseName.trim();
    if (!cleanName) return;
    const amountVal = Math.max(0, Number(newExpenseAmount.replace(/\D/g, '')) || 0);

    const newItem: PaybackArticleItem = {
      id: `exp-${Date.now()}-${Math.random()}`,
      name: cleanName,
      amount: amountVal,
    };

    const updated = [...localExpenses, newItem];
    setLocalExpenses(updated);
    setNewExpenseName('');
    setNewExpenseAmount('');
    setIsAddExpenseModalOpen(false);

    // If currently in edit mode, user will click "Применить" to save all changes
    if (isEditingExpenses) {
      return;
    }

    // If not in edit mode, save immediately
    if (selectedPvzCode && selectedPvzCode !== 'ALL') {
      await savePaybackRecord({
        pvzCode: selectedPvzCode,
        month: currentMonthStr,
        incomes: localIncomes,
        expenses: updated,
        updatedAt: new Date().toISOString(),
      });
      setSaveSuccessNotice('Статья расходов добавлена!');
      setTimeout(() => setSaveSuccessNotice(null), 3000);
    }
  };

  // Change amount directly (stores number)
  const handleAmountChange = (type: 'income' | 'expense', id: string, val: number) => {
    if (type === 'income') {
      setLocalIncomes(prev => prev.map(i => i.id === id ? { ...i, amount: val } : i));
    } else {
      setLocalExpenses(prev => prev.map(e => e.id === id ? { ...e, amount: val } : e));
    }
  };

  // CALCULATIONS for selected view
  const selectedPvzTotalIncome = useMemo(() => {
    return localIncomes.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  }, [localIncomes]);

  const selectedPvzTotalExpenses = useMemo(() => {
    return localExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [localExpenses]);

  const selectedPvzNetProfit = selectedPvzTotalIncome - selectedPvzTotalExpenses;
  const selectedPvzMargin = selectedPvzTotalIncome > 0
    ? (selectedPvzNetProfit / selectedPvzTotalIncome) * 100
    : 0;

  // 2. All PVZ Comparison list for the selected month
  const pvzComparisonList = useMemo(() => {
    return activeLocations.map(pvz => {
      const isCurrentlySelected = pvz.code === selectedPvzCode;
      let incTotal = 0;
      let expTotal = 0;
      let hasData = false;

      if (isCurrentlySelected && selectedPvzCode !== 'ALL') {
        incTotal = selectedPvzTotalIncome;
        expTotal = selectedPvzTotalExpenses;
        hasData = localIncomes.some(i => i.amount > 0) || localExpenses.some(e => e.amount > 0);
      } else {
        const rec = paybackRecords.find(r => r.pvzCode === pvz.code && r.month === currentMonthStr);
        if (rec) {
          incTotal = (rec.incomes || []).reduce((s, i) => s + (Number(i.amount) || 0), 0);
          expTotal = (rec.expenses || []).reduce((s, e) => s + (Number(e.amount) || 0), 0);
          hasData = (rec.incomes || []).some(i => i.amount > 0) || (rec.expenses || []).some(e => e.amount > 0);
        }
      }

      const net = incTotal - expTotal;
      const margin = incTotal > 0 ? (net / incTotal) * 100 : 0;

      return {
        code: pvz.code,
        name: pvz.name,
        address: pvz.address,
        income: incTotal,
        expenses: expTotal,
        netProfit: net,
        margin,
        hasData,
      };
    });
  }, [activeLocations, selectedPvzCode, selectedPvzTotalIncome, selectedPvzTotalExpenses, localIncomes, localExpenses, paybackRecords, currentMonthStr]);

  // Network Totals for selected month
  const networkTotals = useMemo(() => {
    let totalInc = 0;
    let totalExp = 0;
    pvzComparisonList.forEach(item => {
      totalInc += item.income;
      totalExp += item.expenses;
    });
    const net = totalInc - totalExp;
    const margin = totalInc > 0 ? (net / totalInc) * 100 : 0;
    return {
      income: totalInc,
      expenses: totalExp,
      netProfit: net,
      margin,
    };
  }, [pvzComparisonList]);

  // Active view KPI values (either single PVZ or entire network)
  const isNetworkView = selectedPvzCode === 'ALL';
  const displayTotalIncome = isNetworkView ? networkTotals.income : selectedPvzTotalIncome;
  const displayTotalExpenses = isNetworkView ? networkTotals.expenses : selectedPvzTotalExpenses;
  const displayNetProfit = isNetworkView ? networkTotals.netProfit : selectedPvzNetProfit;
  const displayMargin = isNetworkView ? networkTotals.margin : selectedPvzMargin;

  // Dynamic breakdown for Income KPI card (supports any renamed, added, or deleted articles)
  const incomeBreakdown = useMemo(() => {
    if (localIncomes.length === 0) return [];
    return localIncomes.slice(0, 2).map((item, idx) => {
      let amount = item.amount;
      if (isNetworkView) {
        amount = pvzComparisonList.reduce((sum, p) => {
          const rec = paybackRecords.find(r => r.pvzCode === p.code && r.month === currentMonthStr);
          const found = rec?.incomes.find(i => i.name === item.name) || rec?.incomes[idx];
          return sum + (found?.amount || 0);
        }, 0);
      }
      return {
        name: item.name,
        amount,
      };
    });
  }, [localIncomes, isNetworkView, pvzComparisonList, paybackRecords, currentMonthStr]);


  // 12-Month Timeline of Cumulative Cash Flow & Payback (supports both network 'ALL' and selected single PVZ)
  const timelineMonths = useMemo(() => {
    let runningCumulative = 0;

    return Array.from({ length: 12 }, (_, idx) => {
      const monthCode = `${selectedYear}-${String(idx + 1).padStart(2, '0')}`;
      const monthName = MONTH_NAMES[idx];

      let monthIncome = 0;
      let monthExpenses = 0;
      let hasData = false;

      const targetLocations = selectedPvzCode === 'ALL'
        ? activeLocations
        : activeLocations.filter(p => p.code === selectedPvzCode);

      targetLocations.forEach(pvz => {
        if (pvz.code === selectedPvzCode && monthCode === currentMonthStr && selectedPvzCode !== 'ALL') {
          monthIncome += selectedPvzTotalIncome;
          monthExpenses += selectedPvzTotalExpenses;
          if (localIncomes.some(i => i.amount > 0) || localExpenses.some(e => e.amount > 0)) {
            hasData = true;
          }
        } else {
          const rec = paybackRecords.find(r => r.pvzCode === pvz.code && r.month === monthCode);
          if (rec) {
            const inc = (rec.incomes || []).reduce((s, i) => s + (Number(i.amount) || 0), 0);
            const exp = (rec.expenses || []).reduce((s, e) => s + (Number(e.amount) || 0), 0);
            monthIncome += inc;
            monthExpenses += exp;
            if (inc > 0 || exp > 0) {
              hasData = true;
            }
          }
        }
      });

      const monthProfit = hasData ? (monthIncome - monthExpenses) : 0;
      runningCumulative += monthProfit;

      return {
        monthCode,
        monthName,
        monthIndex: idx,
        hasData,
        monthIncome,
        monthExpenses,
        monthProfit,
        cumulative: runningCumulative,
      };
    });
  }, [
    selectedYear,
    activeLocations,
    selectedPvzCode,
    currentMonthStr,
    selectedPvzTotalIncome,
    selectedPvzTotalExpenses,
    localIncomes,
    localExpenses,
    paybackRecords,
  ]);

  // Selected PVZ Object
  const currentPvzObj = useMemo(() => {
    return activeLocations.find(p => p.code === selectedPvzCode);
  }, [activeLocations, selectedPvzCode]);

  // Empty state guard: If no active PVZ in system
  if (activeLocations.length === 0) {
    return (
      <div className="p-8 bg-slate-900 border border-slate-800 rounded-lg text-center space-y-4 shadow-sm">
        <div className="w-12 h-12 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <h3 className="text-base font-medium text-white">Раздел «Окупаемость ПВЗ» не активен</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
          Для расчёта окупаемости необходимо завести хотя бы один пункт выдачи в разделе «Пункты выдачи (ПВЗ)».
          После создания пункта все блоки и калькуляторы станут доступны.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">

      {/* Top Banner & Header (ERP Standard) */}
      <div className="p-4 sm:p-5 bg-slate-900 border border-slate-800 rounded-lg shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 sm:gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md bg-slate-800 border border-slate-700/70 text-emerald-400 flex items-center justify-center shrink-0">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-medium text-white tracking-tight">
                  Окупаемость ПВЗ
                </h2>
                <span className="text-xs text-slate-400 font-normal">
                  · {activeLocations.length} {activeLocations.length === 1 ? 'пункт в системе' : 'пунктов в сети'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Расчёт окупаемости, доходов и расходов по каждому пункту с сохранением на сервере
              </p>
            </div>
          </div>

          {/* Header Controls: Calculator & Period Selector */}
          <div className="flex items-center gap-2 flex-wrap shrink-0">
            <button
              type="button"
              onClick={() => setIsCalcOpen(prev => !prev)}
              className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 border shrink-0 ${
                isCalcOpen
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 shadow-xs'
                  : 'bg-slate-950 hover:bg-slate-850 text-slate-300 border-slate-800'
              }`}
              title="Открыть быстрый калькулятор (+, −, ×, ÷, %)"
            >
              <Calculator className="w-3.5 h-3.5 text-emerald-400" />
              <span>Калькулятор</span>
              {isCalcOpen && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
            </button>

            {/* Period Selector (Month & Year) */}
            <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-md border border-slate-800 shrink-0">
              <button
                onClick={handlePrevMonth}
                title="Предыдущий месяц"
                className="p-1 text-slate-400 hover:text-white hover:bg-slate-900 rounded transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-1.5 px-2 text-xs font-medium text-white font-mono">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>{MONTH_NAMES[selectedMonthIndex]} {selectedYear}</span>
              </div>

              <button
                onClick={handleNextMonth}
                title="Следующий месяц"
                className="p-1 text-slate-400 hover:text-white hover:bg-slate-900 rounded transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* PVZ Choice Tabs (Linear-style Segmented Controls) */}
        <div className="mt-4 pt-3.5 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1 mr-1">
              <Building2 className="w-3.5 h-3.5 text-slate-400" />
              Пункт:
            </span>

            {activeLocations.map(pvz => {
              const isSelected = selectedPvzCode === pvz.code;
              return (
                <button
                  key={pvz.code}
                  onClick={() => setSelectedPvzCode(pvz.code)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 border ${
                    isSelected
                      ? 'bg-slate-800 text-white border-slate-700/80 shadow-xs'
                      : 'bg-slate-950 hover:bg-slate-850 text-slate-300 border-slate-800'
                  }`}
                >
                  <span>{pvz.name}</span>
                  <span className={`text-[11px] font-mono ${
                    isSelected ? 'text-slate-300' : 'text-slate-500'
                  }`}>
                    · {pvz.code}
                  </span>
                  {isSelected && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-0.5" />
                  )}
                </button>
              );
            })}

            {activeLocations.length > 1 && (
              <button
                onClick={() => setSelectedPvzCode('ALL')}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 border ${
                  selectedPvzCode === 'ALL'
                    ? 'bg-slate-800 text-white border-slate-700/80 shadow-xs'
                    : 'bg-slate-950 hover:bg-slate-850 text-slate-300 border-slate-800'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-slate-400" />
                <span>Вся сеть (Сводно)</span>
                {selectedPvzCode === 'ALL' && (
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400 ml-0.5" />
                )}
              </button>
            )}
          </div>

          {/* Feedback message indicator */}
          <div className="flex items-center gap-2">
            {saveSuccessNotice && (
              <span className="text-xs text-emerald-400 flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{saveSuccessNotice}</span>
              </span>
            )}
            {saveError && (
              <span className="text-xs text-red-400 flex items-center gap-1.5 font-medium">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{saveError}</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main KPI Summary Strip (ERP Standard) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 overflow-hidden shadow-sm">
        {/* KPI 1: Net Profit */}
        <div className="p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span className="truncate">
              {isNetworkView ? 'Чистая прибыль сети' : 'Чистая прибыль'}
            </span>
            <DollarSign className={`w-3.5 h-3.5 shrink-0 ${displayNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`} />
          </div>
          <div className={`text-2xl font-semibold font-mono tracking-tight tabular-nums mt-1 truncate ${
            displayNetProfit > 0 ? 'text-emerald-400' : displayNetProfit < 0 ? 'text-rose-400' : 'text-slate-300'
          }`}>
            {formatCurrency(displayNetProfit)}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            {isNetworkView ? 'Вся сеть (сводно)' : currentPvzObj?.name || selectedPvzCode}
          </div>
        </div>

        {/* KPI 2: Total Incomes */}
        <div className="p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span className="truncate">Совокупный доход</span>
            <TrendingUp className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </div>
          <div className="text-2xl font-semibold text-white font-mono tracking-tight tabular-nums mt-1 truncate">
            {formatCurrency(displayTotalIncome)}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            {incomeBreakdown[0] ? (
              <span>{incomeBreakdown[0].name}: {formatCurrency(incomeBreakdown[0].amount)}</span>
            ) : (
              <span>Доходы не внесены</span>
            )}
          </div>
        </div>

        {/* KPI 3: Monthly Expenses */}
        <div className="p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span className="truncate">Ежемесячные расходы</span>
            <TrendingDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </div>
          <div className="text-2xl font-semibold text-white font-mono tracking-tight tabular-nums mt-1 truncate">
            {formatCurrency(displayTotalExpenses)}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            Статей в расчёте: {isNetworkView ? pvzComparisonList.length * 6 : localExpenses.length}
          </div>
        </div>

        {/* KPI 4: Profitability Margin */}
        <div className="p-4 sm:p-5">
          <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
            <span className="truncate">Рентабельность</span>
            <PieChart className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </div>
          <div className="text-2xl font-semibold text-sky-400 font-mono tracking-tight tabular-nums mt-1">
            {displayMargin.toFixed(1)}%
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            Точка безубыточности: {formatCurrency(displayTotalExpenses)}
          </div>
        </div>
      </div>

      {/* Comparison Table Across All PVZ */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 sm:p-5 space-y-3.5 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-medium text-white">
              Сводная таблица окупаемости по всем ПВЗ за {MONTH_NAMES[selectedMonthIndex]} {selectedYear}
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            Для редактирования выберите пункт из таблицы
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-xs font-medium bg-slate-950/70">
                <th className="py-2.5 px-3 font-medium">Пункт выдачи (ПВЗ)</th>
                <th className="py-2.5 px-3 font-medium text-right">Доходы</th>
                <th className="py-2.5 px-3 font-medium text-right">Расходы</th>
                <th className="py-2.5 px-3 font-medium text-right">Чистая прибыль</th>
                <th className="py-2.5 px-3 font-medium text-right">Рентабельность</th>
                <th className="py-2.5 px-3 font-medium text-center">Статус</th>
                <th className="py-2.5 px-3 font-medium text-right">Действие</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {pvzComparisonList.map(item => {
                const isSelected = selectedPvzCode === item.code;
                return (
                  <tr
                    key={item.code}
                    className={`transition-colors ${
                      isSelected ? 'bg-slate-800/40' : 'hover:bg-slate-800/20'
                    }`}
                  >
                    <td className="py-3 px-3">
                      <div className="font-medium text-white flex items-center gap-1.5">
                        <span>{item.name}</span>
                        <span className="font-mono text-xs text-slate-400">
                          · {item.code}
                        </span>
                      </div>
                      {item.address && (
                        <div className="text-xs text-slate-500 truncate max-w-[200px] mt-0.5">
                          {item.address}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-medium text-white tabular-nums">
                      {formatCurrency(item.income)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-medium text-white tabular-nums">
                      {formatCurrency(item.expenses)}
                    </td>
                    <td className={`py-3 px-3 text-right font-mono font-medium tabular-nums ${
                      item.netProfit > 0
                        ? 'text-emerald-400'
                        : item.netProfit < 0
                        ? 'text-rose-400'
                        : 'text-slate-400'
                    }`}>
                      {formatCurrency(item.netProfit)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-sky-400 font-medium tabular-nums">
                      {item.margin.toFixed(1)}%
                    </td>
                    <td className="py-3 px-3 text-center">
                      {item.hasData ? (
                        <span className="inline-flex items-center gap-1.5 text-xs text-slate-300 font-normal">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          <span>Заполнено</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-xs text-slate-500 font-normal">
                          <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                          <span>Пусто (0 ₽)</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => setSelectedPvzCode(item.code)}
                        className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer border ${
                          isSelected
                            ? 'bg-slate-800 text-white border-slate-700'
                            : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
                        }`}
                      >
                        {isSelected ? 'Выбран' : 'Выбрать'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Network Summary Window (ERP standard) */}
        <div className="mt-2 p-4 sm:p-4.5 rounded-lg bg-slate-950 border border-slate-800 shadow-sm">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-md bg-slate-900 border border-slate-800 text-slate-400 flex items-center justify-center shrink-0">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <div className="text-sm font-medium text-white flex items-center gap-2">
                  <span>ИТОГО ПО СЕТИ</span>
                  <span className="text-xs text-slate-400 font-normal">
                    · {activeLocations.length} ПВЗ
                  </span>
                </div>
                <div className="text-xs text-slate-500 mt-0.5">
                  Совокупные показатели всей сети за {MONTH_NAMES[selectedMonthIndex]} {selectedYear}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-6 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-800/80">
              <div>
                <span className="text-xs text-slate-400 font-normal block">Доходы сети</span>
                <span className="font-mono text-sm sm:text-base font-semibold text-white tabular-nums">
                  {formatCurrency(networkTotals.income)}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 font-normal block">Расходы сети</span>
                <span className="font-mono text-sm sm:text-base font-semibold text-white tabular-nums">
                  {formatCurrency(networkTotals.expenses)}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 font-normal block">Чистая прибыль</span>
                <span className={`font-mono text-sm sm:text-base font-semibold tabular-nums ${
                  networkTotals.netProfit > 0
                    ? 'text-emerald-400'
                    : networkTotals.netProfit < 0
                    ? 'text-rose-400'
                    : 'text-slate-300'
                }`}>
                  {formatCurrency(networkTotals.netProfit)}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 font-normal block">Рентабельность</span>
                <span className="font-mono text-sm sm:text-base font-semibold text-sky-400 tabular-nums">
                  {networkTotals.margin.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Notice if network overview is selected (Without the "Перейти к первому ПВЗ" button) */}
      {selectedPvzCode === 'ALL' && (
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 flex items-center gap-2.5">
          <Layers className="w-4 h-4 text-sky-400 shrink-0" />
          <span>
            Вы просматриваете общую сводку по всей сети. Чтобы вносить доходы и расходы для конкретного пункта, выберите его в списке выше.
          </span>
        </div>
      )}

      {/* Detailed Calculator Section: Incomes & Expenses Blocks (Active when a specific PVZ is selected) */}
      {selectedPvzCode !== 'ALL' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

          {/* Block 1: Revenue & Incomes (Доходы и агентские - Компактный режим) */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 sm:p-4 space-y-2.5 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0" />
                <h3 className="text-sm font-medium text-white">Доходы и Агентские</h3>
                <span className="font-mono text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 border-0 px-2.5 py-0.5 rounded-md">
                  {formatCurrency(selectedPvzTotalIncome)}
                </span>
              </div>

              {/* Action buttons: Редактировать / Применить / Отменить / Добавить */}
              <div className="flex items-center gap-1.5">
                {!isEditingIncomes ? (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        handleStartEditIncomes();
                        setIsAddIncomeModalOpen(true);
                      }}
                      className="px-2 py-1 bg-slate-950 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                      title="Добавить новую статью доходов"
                    >
                      <Plus className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="hidden sm:inline">Добавить</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleStartEditIncomes}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Редактировать</span>
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => setIsAddIncomeModalOpen(true)}
                      className="px-2 py-1 bg-slate-950 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                      title="Добавить статью"
                    >
                      <Plus className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="hidden sm:inline">Статья</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleApplyIncomes}
                      disabled={isSavingIncomes}
                      className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      {isSavingIncomes ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Сохранение...</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Применить</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={handleCancelIncomes}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                      title="Отменить изменения"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Отмена</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Income Articles List - Compact Table Layout */}
            <div className="bg-slate-950 rounded-md border border-slate-800 divide-y divide-slate-800/60 overflow-hidden">
              <div className="max-h-[300px] overflow-y-auto divide-y divide-slate-800/60">
                {localIncomes.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500">
                    Статьи доходов не добавлены
                  </div>
                ) : (
                  localIncomes.map(item => {
                    const isEditingThis = editingArticleId === item.id;

                    return (
                      <div
                        key={item.id}
                        className={`py-1.5 px-3 flex items-center justify-between gap-2.5 transition-colors text-xs ${
                          isEditingIncomes ? 'bg-slate-900/40 hover:bg-slate-900/60' : 'hover:bg-slate-900/30'
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          {isEditingThis ? (
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={editingArticleName}
                                onChange={e => setEditingArticleName(e.target.value)}
                                onKeyDown={e => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    handleFinishRename('income', item.id);
                                  } else if (e.key === 'Escape') {
                                    handleCancelRename();
                                  }
                                }}
                                className="w-full bg-slate-900 rounded px-2 py-0.5 text-white border border-emerald-500/50 text-xs focus:outline-none"
                                autoFocus
                              />
                              <button
                                type="button"
                                onClick={() => handleFinishRename('income', item.id)}
                                className="p-1 bg-emerald-500 text-slate-950 rounded hover:bg-emerald-400 transition-colors shrink-0"
                                title="Применить название"
                              >
                                <Check className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 truncate">
                              <span className="font-medium text-slate-200 truncate" title={item.name}>
                                {item.name}
                              </span>
                              {isEditingIncomes && (
                                <button
                                  type="button"
                                  onClick={() => handleStartRename(item.id, item.name)}
                                  className="p-0.5 text-slate-500 hover:text-emerald-400 transition-colors cursor-pointer shrink-0"
                                  title="Переименовать"
                                >
                                  <Edit3 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {isEditingIncomes ? (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setCalcTargetArticle({ type: 'income', id: item.id });
                                  setIsCalcOpen(true);
                                }}
                                className="p-1 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded transition-colors"
                                title="Рассчитать на калькуляторе и вставить"
                              >
                                <Calculator className="w-3.5 h-3.5" />
                              </button>
                              <div className="relative">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  value={formatNumberWithSpaces(item.amount)}
                                  placeholder="0"
                                  onFocus={e => e.target.select()}
                                  onClick={e => (e.target as HTMLInputElement).select()}
                                  onChange={e => {
                                    const digits = e.target.value.replace(/\D/g, '');
                                    const num = digits ? parseInt(digits, 10) : 0;
                                    handleAmountChange('income', item.id, num);
                                  }}
                                  className="w-28 sm:w-32 h-7 bg-slate-900 rounded pr-5 pl-2 text-right text-emerald-400 font-mono font-medium text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500/50 border border-slate-700"
                                />
                                <span className="absolute right-1.5 top-1.5 text-[10px] text-slate-500 pointer-events-none">
                                  ₽
                                </span>
                              </div>

                              <button
                                type="button"
                                onClick={() => handleDeleteArticle('income', item.id)}
                                className="p-1 text-slate-500 hover:text-rose-400 hover:bg-slate-900 rounded transition-colors cursor-pointer"
                                title="Удалить статью"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <span className={`font-mono font-medium text-xs tabular-nums ${item.amount > 0 ? 'text-emerald-400' : 'text-slate-500'}`}>
                              {formatNumberWithSpaces(item.amount) || '0'} ₽
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Total Footer Row */}
              <div className="py-2 px-3 bg-slate-950 flex items-center justify-between text-xs font-medium border-t border-slate-800/80">
                <span className="text-slate-400">Итого доходов в месяц:</span>
                <span className="font-mono text-emerald-400 font-semibold tabular-nums">
                  {formatCurrency(selectedPvzTotalIncome)}
                </span>
              </div>
            </div>
          </div>

          {/* Block 2: Operational Expenses (Ежемесячные расходы - Компактный режим) */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 sm:p-4 space-y-2.5 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-amber-400 shrink-0" />
                <h3 className="text-sm font-medium text-white">Ежемесячные расходы</h3>
                <span className="font-mono text-xs font-medium text-amber-800 dark:text-amber-400 bg-amber-500/10 border-0 px-2.5 py-0.5 rounded-md">
                  {formatCurrency(selectedPvzTotalExpenses)}
                </span>
              </div>

              {/* Action buttons: Редактировать / Применить / Отменить / Добавить */}
              <div className="flex items-center gap-1.5">
                {!isEditingExpenses ? (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        handleStartEditExpenses();
                        setIsAddExpenseModalOpen(true);
                      }}
                      className="px-2 py-1 bg-slate-950 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                      title="Добавить новую статью расходов"
                    >
                      <Plus className="w-3.5 h-3.5 text-amber-400" />
                      <span className="hidden sm:inline">Добавить</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleStartEditExpenses}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                      <span>Редактировать</span>
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => setIsAddExpenseModalOpen(true)}
                      className="px-2 py-1 bg-slate-950 hover:bg-slate-850 text-slate-300 border border-slate-800 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                      title="Добавить статью"
                    >
                      <Plus className="w-3.5 h-3.5 text-amber-400" />
                      <span className="hidden sm:inline">Статья</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleApplyExpenses}
                      disabled={isSavingExpenses}
                      className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    >
                      {isSavingExpenses ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Сохранение...</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Применить</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={handleCancelExpenses}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                      title="Отменить изменения"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Отмена</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Expense Articles List - Compact Table Layout */}
            <div className="bg-slate-950 rounded-md border border-slate-800 divide-y divide-slate-800/60 overflow-hidden">
              <div className="max-h-[300px] overflow-y-auto divide-y divide-slate-800/60">
                {localExpenses.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-500">
                    Статьи расходов не добавлены
                  </div>
                ) : (
                  localExpenses.map(item => {
                    const isEditingThis = editingArticleId === item.id;

                    return (
                      <div
                        key={item.id}
                        className={`py-1.5 px-3 flex items-center justify-between gap-2.5 transition-colors text-xs ${
                          isEditingExpenses ? 'bg-slate-900/40 hover:bg-slate-900/60' : 'hover:bg-slate-900/30'
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          {isEditingThis ? (
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={editingArticleName}
                                onChange={e => setEditingArticleName(e.target.value)}
                                onKeyDown={e => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    handleFinishRename('expense', item.id);
                                  } else if (e.key === 'Escape') {
                                    handleCancelRename();
                                  }
                                }}
                                className="w-full bg-slate-900 rounded px-2 py-0.5 text-white border border-amber-500/50 text-xs focus:outline-none"
                                autoFocus
                              />
                              <button
                                type="button"
                                onClick={() => handleFinishRename('expense', item.id)}
                                className="p-1 bg-amber-500 text-slate-950 rounded hover:bg-amber-400 transition-colors shrink-0"
                                title="Применить название"
                              >
                                <Check className="w-3 h-3" />
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 truncate">
                              <span className="font-medium text-slate-200 truncate" title={item.name}>
                                {item.name}
                              </span>
                              {isEditingExpenses && (
                                <button
                                  type="button"
                                  onClick={() => handleStartRename(item.id, item.name)}
                                  className="p-0.5 text-slate-500 hover:text-amber-400 transition-colors cursor-pointer shrink-0"
                                  title="Переименовать"
                                >
                                  <Edit3 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {isEditingExpenses ? (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setCalcTargetArticle({ type: 'expense', id: item.id });
                                  setIsCalcOpen(true);
                                }}
                                className="p-1 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded transition-colors"
                                title="Рассчитать на калькуляторе и вставить"
                              >
                                <Calculator className="w-3.5 h-3.5" />
                              </button>
                              <div className="relative">
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  value={formatNumberWithSpaces(item.amount)}
                                  placeholder="0"
                                  onFocus={e => e.target.select()}
                                  onClick={e => (e.target as HTMLInputElement).select()}
                                  onChange={e => {
                                    const digits = e.target.value.replace(/\D/g, '');
                                    const num = digits ? parseInt(digits, 10) : 0;
                                    handleAmountChange('expense', item.id, num);
                                  }}
                                  className="w-28 sm:w-32 h-7 bg-slate-900 rounded pr-5 pl-2 text-right text-amber-400 font-mono font-medium text-xs focus:outline-none focus:ring-1 focus:ring-amber-500/50 border border-slate-700"
                                />
                                <span className="absolute right-1.5 top-1.5 text-[10px] text-slate-500 pointer-events-none">
                                  ₽
                                </span>
                              </div>

                              <button
                                type="button"
                                onClick={() => handleDeleteArticle('expense', item.id)}
                                className="p-1 text-slate-500 hover:text-rose-400 hover:bg-slate-900 rounded transition-colors cursor-pointer"
                                title="Удалить статью"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <span className={`font-mono font-medium text-xs tabular-nums ${item.amount > 0 ? 'text-amber-400' : 'text-slate-500'}`}>
                              {formatNumberWithSpaces(item.amount) || '0'} ₽
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Total Footer Row */}
              <div className="py-2 px-3 bg-slate-950 flex items-center justify-between text-xs font-medium border-t border-slate-800/80">
                <span className="text-slate-400">Итого расходов в месяц:</span>
                <span className="font-mono text-amber-400 font-semibold tabular-nums">
                  {formatCurrency(selectedPvzTotalExpenses)}
                </span>
              </div>
            </div>
          </div>

        </div>
      )}


      {/* Payback Horizon Forecast Chart / Timeline (Compact, Sleek, 12 Months) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 sm:p-5 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <h3 className="text-sm font-medium text-white tracking-tight">
                График накопительного денежного потока и окупаемости
              </h3>
              <p className="text-xs text-slate-400">
                Показатели всех активных пунктов сети по месяцам с накопительным итогом
              </p>
            </div>
          </div>
          <span className="text-xs text-slate-300 font-mono px-2.5 py-1 bg-slate-950 rounded-md border border-slate-800 self-start sm:self-auto shrink-0 font-medium">
            {timelineMonths[11]?.cumulative > 0
              ? `Итог за 12 мес: +${formatCurrency(timelineMonths[11]?.cumulative)}`
              : `Итог за 12 мес: ${formatCurrency(timelineMonths[11]?.cumulative || 0)}`}
          </span>
        </div>

        {/* 12 Cards Grid - Compact: 3-col on Mobile, 4-col on Tablet, 12-col on Desktop */}
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 xl:grid-cols-12 gap-2 text-xs">
          {timelineMonths.map(m => {
            const isPositive = m.cumulative > 0;
            const isSelectedMonth = m.monthIndex === selectedMonthIndex;

            return (
              <div
                key={m.monthCode}
                onClick={() => setSelectedMonthIndex(m.monthIndex)}
                className={`p-2.5 rounded-md border text-center flex flex-col justify-between transition-colors cursor-pointer shadow-sm relative overflow-hidden group ${
                  isSelectedMonth
                    ? 'ring-1 ring-emerald-500 bg-slate-900 border-emerald-500'
                    : m.hasData
                    ? isPositive
                      ? 'bg-slate-950 border-emerald-500/30 hover:border-emerald-500/60'
                      : 'bg-slate-950 border-rose-900/40 hover:border-rose-800/60'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Header: Month Name + Selection Indicator */}
                <div className="pb-1 border-b border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] text-white font-medium tracking-wide uppercase truncate">
                    {m.monthName.slice(0, 3)}
                  </span>
                  {isSelectedMonth ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" title="Выбранный месяц" />
                  ) : (
                    <span className="w-1 h-1 rounded-full bg-slate-700 shrink-0 opacity-40 group-hover:opacity-100" />
                  )}
                </div>

                {/* Body: Month Result */}
                <div className="my-2 py-0.5">
                  <span className="text-[11px] text-slate-500 block uppercase font-medium">За месяц</span>
                  <div className={`text-xs font-mono font-medium mt-0.5 truncate ${
                    !m.hasData
                      ? 'text-slate-500'
                      : m.monthProfit > 0
                      ? 'text-emerald-400'
                      : m.monthProfit < 0
                      ? 'text-rose-400'
                      : 'text-slate-400'
                  }`}>
                    {m.hasData ? formatCurrency(m.monthProfit) : '0 ₽'}
                  </div>
                </div>

                {/* Footer: Cumulative Pod */}
                <div className={`p-1.5 rounded-md border transition-colors ${
                  !m.hasData
                    ? 'bg-slate-900/60 border-slate-800 text-slate-500'
                    : isPositive
                    ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-950/20 border-rose-900/40 text-rose-300'
                }`}>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wide block font-medium">
                    Накоплено
                  </span>
                  <div className={`text-xs font-medium font-mono mt-0.5 truncate ${
                    !m.hasData && m.cumulative === 0
                      ? 'text-slate-500'
                      : m.cumulative > 0
                      ? 'text-emerald-400'
                      : m.cumulative < 0
                      ? 'text-rose-400'
                      : 'text-slate-400'
                  }`}>
                    {formatCurrency(m.cumulative)}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* BLOCK: График «Доходы и Расходы» (Compact & Polished) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 sm:p-5 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <h3 className="text-sm font-medium text-white tracking-tight">
                График: Доходы и Расходы ({isNetworkView ? 'Все ПВЗ сети' : `ПВЗ ${currentPvzObj?.name || selectedPvzCode}`})
              </h3>
              <p className="text-xs text-slate-400">
                Сопоставление ежемесячных доходов и операционных расходов за {selectedYear} год
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs self-start sm:self-auto">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800">
              <span className="w-2 h-2 rounded-sm bg-emerald-400 inline-block" />
              <span className="text-slate-300 text-xs font-medium">Доходы</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800">
              <span className="w-2 h-2 rounded-sm bg-rose-400 inline-block" />
              <span className="text-slate-300 text-xs font-medium">Расходы</span>
            </div>
          </div>
        </div>

        {/* Bar Chart Visualization - Compact Height & Proportional Columns */}
        {(() => {
          const maxVal = Math.max(
            1,
            ...timelineMonths.map(m => Math.max(m.monthIncome, m.monthExpenses))
          );

          return (
            <div className="space-y-3">
              {/* Responsive Bar Grid: 3-col on Mobile, 4-col on Tablet, 12-col on Desktop */}
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 xl:grid-cols-12 gap-2 text-xs pt-1">
                {timelineMonths.map(m => {
                  const incomeHeight = Math.max(3, Math.round((m.monthIncome / maxVal) * 88));
                  const expenseHeight = Math.max(3, Math.round((m.monthExpenses / maxVal) * 88));
                  const isCurrent = m.monthIndex === selectedMonthIndex;

                  return (
                    <div
                      key={m.monthCode}
                      onClick={() => setSelectedMonthIndex(m.monthIndex)}
                      className={`p-2.5 rounded-md border flex flex-col justify-between items-center transition-colors cursor-pointer group ${
                        isCurrent
                          ? 'bg-slate-900 border-emerald-500 ring-1 ring-emerald-500'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {/* Bars Graphic - Compact 88px container */}
                      <div className="h-24 sm:h-28 w-full flex items-end justify-center gap-1.5 pb-2 border-b border-slate-800">
                        {/* Income Bar (Emerald) */}
                        <div className="flex-1 flex flex-col items-center justify-end h-full group/bar">
                          <div
                            style={{ height: `${m.monthIncome > 0 ? incomeHeight : 3}px` }}
                            className={`w-full rounded-t-xs transition-colors ${
                              m.monthIncome > 0
                                ? 'bg-emerald-500 group-hover/bar:bg-emerald-400'
                                : 'bg-slate-800/40'
                            }`}
                            title={`Доходы: ${formatCurrency(m.monthIncome)}`}
                          />
                        </div>

                        {/* Expense Bar (Rose) */}
                        <div className="flex-1 flex flex-col items-center justify-end h-full group/bar">
                          <div
                            style={{ height: `${m.monthExpenses > 0 ? expenseHeight : 3}px` }}
                            className={`w-full rounded-t-xs transition-colors ${
                              m.monthExpenses > 0
                                ? 'bg-rose-500 group-hover/bar:bg-rose-400'
                                : 'bg-slate-800/40'
                            }`}
                            title={`Расходы: ${formatCurrency(m.monthExpenses)}`}
                          />
                        </div>
                      </div>

                      {/* Month Label */}
                      <div className="pt-2 text-center w-full">
                        <div className="text-[11px] font-medium text-white uppercase tracking-wider truncate">
                          {m.monthName.slice(0, 3)}
                        </div>
                        <div className="mt-1 space-y-0.5 font-mono text-[11px]">
                          <div className="text-emerald-400 font-medium truncate" title={`Доход: ${formatCurrency(m.monthIncome)}`}>
                            +{formatNumberWithSpaces(m.monthIncome)}
                          </div>
                          <div className="text-rose-400 font-medium truncate" title={`Расход: ${formatCurrency(m.monthExpenses)}`}>
                            -{formatNumberWithSpaces(m.monthExpenses)}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Total Footnote */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 p-3 bg-slate-950 rounded-md border border-slate-800 text-xs">
                <span className="text-slate-400">
                  Годовые итоги ({isNetworkView ? 'вся сеть' : currentPvzObj?.name}):
                </span>
                <div className="flex items-center gap-3 sm:gap-4 font-mono font-medium flex-wrap">
                  <span className="text-emerald-400">
                    Доходы: +{formatCurrency(timelineMonths.reduce((s, m) => s + m.monthIncome, 0))}
                  </span>
                  <span className="text-rose-400">
                    Расходы: -{formatCurrency(timelineMonths.reduce((s, m) => s + m.monthExpenses, 0))}
                  </span>
                  <span className={
                    timelineMonths.reduce((s, m) => s + m.monthProfit, 0) >= 0
                      ? 'text-sky-400'
                      : 'text-amber-400'
                  }>
                    Сальдо: {formatCurrency(timelineMonths.reduce((s, m) => s + m.monthProfit, 0))}
                  </span>
                </div>
              </div>
            </div>
          );
        })()}
      </div>

      {/* Modal: Add Income Item */}
      {isAddIncomeModalOpen && (
        <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-medium text-white">Добавить статью доходов</h3>
            <p className="text-xs text-slate-400">
              Новая статья сохранится в шаблонах и будет доступна для всех последующих месяцев.
            </p>
            <form onSubmit={handleAddIncomeSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 text-xs font-medium">Наименование дохода</label>
                <input
                  type="text"
                  required
                  placeholder="Например: Постамат, субаренда, упаковка"
                  value={newIncomeName}
                  onChange={e => setNewIncomeName(e.target.value)}
                  className="w-full bg-slate-950 rounded-md px-3 py-2 text-white text-xs border border-slate-800 focus:outline-none focus:border-slate-700"
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1 text-xs font-medium">Сумма в месяц (₽)</label>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="0"
                    value={formatNumberWithSpaces(newIncomeAmount)}
                    onFocus={e => e.target.select()}
                    onClick={e => (e.target as HTMLInputElement).select()}
                    onChange={e => {
                      const digits = e.target.value.replace(/\D/g, '');
                      setNewIncomeAmount(digits);
                    }}
                    className="w-full bg-slate-950 rounded-md px-3 py-2 pr-8 text-white font-mono text-xs focus:outline-none border border-slate-800 focus:border-slate-700"
                  />
                  <span className="absolute right-3 top-2 text-xs text-slate-500 pointer-events-none">
                    ₽
                  </span>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddIncomeModalOpen(false)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-md text-xs font-medium cursor-pointer transition-colors"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md text-xs font-medium cursor-pointer transition-colors"
                >
                  Добавить статью
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Expense Item */}
      {isAddExpenseModalOpen && (
        <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md p-5 space-y-4 shadow-xl">
            <h3 className="text-sm font-medium text-white">Добавить статью расходов</h3>
            <p className="text-xs text-slate-400">
              Новая статья сохранится в шаблонах и будет автоматически отображаться для будущих месяцев.
            </p>
            <form onSubmit={handleAddExpenseSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 text-xs font-medium">Наименование расхода</label>
                <input
                  type="text"
                  required
                  placeholder="Например: Услуги охраны, клининг, софт"
                  value={newExpenseName}
                  onChange={e => setNewExpenseName(e.target.value)}
                  className="w-full bg-slate-950 rounded-md px-3 py-2 text-white text-xs border border-slate-800 focus:outline-none focus:border-slate-700"
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1 text-xs font-medium">Сумма в месяц (₽)</label>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="0"
                    value={formatNumberWithSpaces(newExpenseAmount)}
                    onFocus={e => e.target.select()}
                    onClick={e => (e.target as HTMLInputElement).select()}
                    onChange={e => {
                      const digits = e.target.value.replace(/\D/g, '');
                      setNewExpenseAmount(digits);
                    }}
                    className="w-full bg-slate-950 rounded-md px-3 py-2 pr-8 text-white font-mono text-xs focus:outline-none border border-slate-800 focus:border-slate-700"
                  />
                  <span className="absolute right-3 top-2 text-xs text-slate-500 pointer-events-none">
                    ₽
                  </span>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddExpenseModalOpen(false)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-md text-xs font-medium cursor-pointer transition-colors"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-md text-xs font-medium cursor-pointer transition-colors"
                >
                  Добавить статью
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Floating Mini Calculator Widget */}
      <MiniCalculator
        isOpen={isCalcOpen}
        onClose={() => {
          setIsCalcOpen(false);
          setCalcTargetArticle(null);
        }}
        onInsertValue={calcTargetArticle ? (val) => {
          if (calcTargetArticle.type === 'income') {
            handleAmountChange('income', calcTargetArticle.id, Math.round(val));
          } else {
            handleAmountChange('expense', calcTargetArticle.id, Math.round(val));
          }
          setCalcTargetArticle(null);
        } : undefined}
      />

    </div>
  );
};
