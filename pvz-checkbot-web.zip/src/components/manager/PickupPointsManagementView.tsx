import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { PickupPoint } from '../../types';
import { calculateDailySales, formatCurrency, getBaseShiftPay, normalizeShiftType, calculateShiftTotalSalary } from '../../utils/calculations';
import { getCurrentAndPreviousMonth, formatMonthName, getAllAvailableMonths, formatDateRuDMY } from '../../utils/time';
import { CustomPeriodSelect } from '../common/CustomPeriodSelect';
import {
  Building2,
  Plus,
  Search,
  Users,
  MapPin,
  Phone,
  FileText,
  Edit2,
  Trash2,
  XCircle,
  BarChart3,
  TrendingUp,
  DollarSign,
  X,
  Shield,
  Calendar,
  AlertTriangle,
  UserCheck,
  ChevronDown,
  ChevronUp,
  Archive,
  RotateCcw,
  CheckCircle2,
  Inbox,
  AlertCircle,
  Info,
} from 'lucide-react';

export function formatPhoneNumber(val: string): string {
  const digits = val.replace(/\D/g, '').slice(0, 11);
  if (!digits) return '';

  let res = digits[0];
  if (digits.length > 1) {
    res += ` (${digits.slice(1, Math.min(4, digits.length))}`;
  }
  if (digits.length >= 4) {
    res += ')';
  }
  if (digits.length > 4) {
    res += ` ${digits.slice(4, Math.min(7, digits.length))}`;
  }
  if (digits.length > 7) {
    res += `-${digits.slice(7, Math.min(9, digits.length))}`;
  }
  if (digits.length > 9) {
    res += `-${digits.slice(9, 11)}`;
  }
  return res;
}

export const PickupPointsManagementView: React.FC = () => {
  const {
    pickupPoints,
    staffList,
    records,
    rates,
    addPickupPoint,
    updatePickupPoint,
    archivePickupPoint,
    restorePickupPoint,
    deletePickupPoint,
    assignStaffToPickupPoint,
    paybackRecords,
  } = useApp();

  const { current } = getCurrentAndPreviousMonth();
  const allAvailableMonths = getAllAvailableMonths();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive' | 'archived'>('all');
  const [selectedMonth, setSelectedMonth] = useState<string>(current);

  // Accordion state for compact & expandable PVZ cards
  const [expandedPointIds, setExpandedPointIds] = useState<Set<string>>(new Set());

  const toggleExpand = (id: string) => {
    setExpandedPointIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const expandAll = () => setExpandedPointIds(new Set(filteredPoints.map(p => p.id)));
  const collapseAll = () => setExpandedPointIds(new Set());

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingPoint, setEditingPoint] = useState<PickupPoint | null>(null);

  // Assignment Modal
  const [assigningPoint, setAssigningPoint] = useState<PickupPoint | null>(null);
  const [assignedStaffIds, setAssignedStaffIds] = useState<string[]>([]);
  const [staffSearchQuery, setStaffSearchQuery] = useState('');

  // Form State for Add / Edit
  const [formName, setFormName] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formAddress, setFormAddress] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formActive, setFormActive] = useState(true);
  const [formStaffIds, setFormStaffIds] = useState<string[]>([]);

  // Detailed Analytics Modal for specific location
  const [analyticsPoint, setAnalyticsPoint] = useState<PickupPoint | null>(null);

  // Action Confirmation Modals State
  const [deactivatingPoint, setDeactivatingPoint] = useState<PickupPoint | null>(null);
  const [archivingPoint, setArchivingPoint] = useState<PickupPoint | null>(null);
  const [restoringPoint, setRestoringPoint] = useState<PickupPoint | null>(null);
  const [deletingPoint, setDeletingPoint] = useState<PickupPoint | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteWarning, setDeleteWarning] = useState<string | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Status & Error handling
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Safari focus trap for accessibility
  React.useEffect(() => {
    if (!isAddModalOpen && !assigningPoint && !analyticsPoint && !deactivatingPoint && !archivingPoint && !restoringPoint && !deletingPoint) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        const modal = document.querySelector('.fixed.inset-0.z-50') || document.querySelector('.fixed.inset-0');
        if (!modal) return;
        
        const focusableElements = modal.querySelectorAll<HTMLElement>(
          'input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex="0"]'
        );
        
        if (focusableElements.length === 0) return;
        
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        const activeElement = document.activeElement as HTMLElement;
        
        if (e.shiftKey) {
          if (activeElement === firstElement || !Array.from(focusableElements).includes(activeElement)) {
            lastElement.focus();
            e.preventDefault();
          }
        } else {
          if (activeElement === lastElement || !Array.from(focusableElements).includes(activeElement)) {
            firstElement.focus();
            e.preventDefault();
          }
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAddModalOpen, assigningPoint, analyticsPoint, deactivatingPoint, archivingPoint, restoringPoint, deletingPoint]);

  // Active employees
  const activeStaff = staffList.filter(s => s.status === 'active');

  // Reliable bidirectional assigned staff finder
  const getAssignedStaffIdsForPoint = (point: PickupPoint): string[] => {
    const ids = new Set<string>(point.assignedStaffIds || []);
    staffList.forEach(s => {
      const locs = s.locations && s.locations.length > 0 ? s.locations : (s.location ? [s.location] : []);
      if (locs.some(l => l === point.code || l === point.name || l === point.id)) {
        ids.add(s.id);
      }
    });
    return Array.from(ids);
  };

  const openAddModal = () => {
    setEditingPoint(null);
    setFormName('');
    setFormCode('');
    setFormAddress('');
    setFormPhone('');
    setFormNotes('');
    setFormActive(true);
    setFormStaffIds([]);
    setErrorMsg('');
    setIsAddModalOpen(true);
  };

  const openEditModal = (point: PickupPoint) => {
    setEditingPoint(point);
    setFormName(point.name.slice(0, 30));
    setFormCode(point.code);
    setFormAddress(point.address || '');
    setFormPhone(formatPhoneNumber(point.contactPhone || ''));
    setFormNotes(point.notes || '');
    setFormActive(point.active !== false);
    setFormStaffIds(getAssignedStaffIdsForPoint(point));
    setErrorMsg('');
    setIsAddModalOpen(true);
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    if (formPhone.length > raw.length && (formPhone.endsWith('-') || formPhone.endsWith(') ') || formPhone.endsWith(')'))) {
      const stripped = raw.replace(/\D*$/, '');
      setFormPhone(formatPhoneNumber(stripped.slice(0, -1)));
      return;
    }
    setFormPhone(formatPhoneNumber(raw));
  };

  const openAssignModal = (point: PickupPoint) => {
    setAssigningPoint(point);
    setAssignedStaffIds(getAssignedStaffIdsForPoint(point));
    setStaffSearchQuery('');
  };

  const togglePointActive = async (point: PickupPoint) => {
    const nextActive = point.active === false ? true : false;
    await updatePickupPoint(point.id, { active: nextActive });
  };

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = formName.trim().slice(0, 30);
    if (!cleanName) {
      setErrorMsg('Укажите название пункта выдачи (до 30 знаков)');
      return;
    }

    // Check unique name constraint (case-insensitive)
    const duplicate = pickupPoints.find(
      p => p.name.trim().toLowerCase() === cleanName.toLowerCase() && (!editingPoint || p.id !== editingPoint.id)
    );
    if (duplicate) {
      setErrorMsg(`Пункт выдачи с названием «${cleanName}» уже существует. Названия ПВЗ должны быть уникальными.`);
      return;
    }

    const cleanCode = formCode.trim().slice(0, 18).toUpperCase();
    const isEditing = Boolean(editingPoint);
    const targetPoint = editingPoint;
    const staffIdsToSave = formStaffIds;
    const addressToSave = formAddress.trim();
    const phoneToSave = formPhone.trim();
    const notesToSave = formNotes.trim();
    const activeToSave = formActive;

    setIsSubmitting(true);
    setErrorMsg('');

    try {
      if (isEditing && targetPoint) {
        const res = await updatePickupPoint(targetPoint.id, {
          name: cleanName,
          code: cleanCode || targetPoint.code,
          address: addressToSave,
          contactPhone: phoneToSave,
          notes: notesToSave,
          active: activeToSave,
          assignedStaffIds: staffIdsToSave,
        });
        if (!res.success) {
          setErrorMsg(res.error || 'Ошибка обновления ПВЗ');
          setIsSubmitting(false);
          return;
        }
      } else {
        const res = await addPickupPoint({
          name: cleanName,
          code: cleanCode,
          address: addressToSave,
          contactPhone: phoneToSave,
          notes: notesToSave,
          assignedStaffIds: staffIdsToSave,
        });
        if (!res.success) {
          setErrorMsg(res.error || 'Ошибка создания ПВЗ');
          setIsSubmitting(false);
          return;
        }
      }

      setIsAddModalOpen(false);
      setActionSuccessMsg(isEditing ? `Изменения ПВЗ «${cleanName}» сохранены` : `ПВЗ «${cleanName}» успешно создан`);
      setTimeout(() => setActionSuccessMsg(null), 3500);
      setEditingPoint(null);
      setFormName('');
      setFormCode('');
      setFormAddress('');
      setFormPhone('');
      setFormNotes('');
      setFormActive(true);
      setFormStaffIds([]);
      setErrorMsg('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Ошибка сохранения ПВЗ');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveStaffAssignment = async () => {
    if (!assigningPoint) return;
    setIsSubmitting(true);
    await assignStaffToPickupPoint(assigningPoint.id, assignedStaffIds);
    setIsSubmitting(false);
    setAssigningPoint(null);
  };

  // Archive Flow
  const handleRequestArchive = (point: PickupPoint) => {
    setArchivingPoint(point);
  };

  const handleConfirmArchive = async () => {
    if (!archivingPoint) return;
    setIsSubmitting(true);
    try {
      const res = await archivePickupPoint(archivingPoint.id);
      if (res.success) {
        setArchivingPoint(null);
        setActionSuccessMsg(`ПВЗ «${archivingPoint.name}» успешно перемещен в Архив.`);
        setTimeout(() => setActionSuccessMsg(null), 4000);
      } else {
        setDeleteError(res.error || 'Ошибка архивации ПВЗ');
      }
    } catch (err: any) {
      setDeleteError(err.message || 'Ошибка архивации ПВЗ');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Restore Flow
  const handleConfirmRestore = async () => {
    if (!restoringPoint) return;
    setIsSubmitting(true);
    try {
      const res = await restorePickupPoint(restoringPoint.id);
      if (res.success) {
        setRestoringPoint(null);
        setActionSuccessMsg(`ПВЗ «${restoringPoint.name}» успешно восстановлен из архива и активирован.`);
        setTimeout(() => setActionSuccessMsg(null), 4000);
      } else {
        setDeleteError(res.error || 'Ошибка восстановления ПВЗ');
      }
    } catch (err: any) {
      setDeleteError(err.message || 'Ошибка восстановления ПВЗ');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Permanent Delete Flow
  const handleRequestPermanentDelete = (point: PickupPoint) => {
    setDeleteError(null);
    setDeletingPoint(point);
  };

  const handleConfirmPermanentDelete = async () => {
    if (!deletingPoint) return;
    setIsSubmitting(true);
    setDeleteError(null);
    try {
      const targetId = deletingPoint.id || deletingPoint.code;
      const res = await deletePickupPoint(targetId);
      if (res.success) {
        setDeletingPoint(null);
        setDeleteError(null);
        setActionSuccessMsg(`ПВЗ «${deletingPoint.name}» окончательно удален из базы данных.`);
        setTimeout(() => setActionSuccessMsg(null), 4000);
      } else {
        setDeleteError(res.error || 'Ошибка при удалении пункта выдачи');
      }
    } catch (err: any) {
      setDeleteError(err.message || 'Ошибка удаления ПВЗ');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Memoized Location Stats calculation (Выручка, Смены, ЗП/ФОТ)
  interface LocationStatsResult {
    shiftCount: number;
    totalRevenue: number;
    cashRevenue: number;
    cardRevenue: number;
    avgRevenuePerShift: number;
    totalShiftSalary: number;
    totalBonus: number;
    totalSalary: number;
    records: typeof records;
  }

  const defaultStats: LocationStatsResult = {
    shiftCount: 0,
    totalRevenue: 0,
    cashRevenue: 0,
    cardRevenue: 0,
    avgRevenuePerShift: 0,
    totalShiftSalary: 0,
    totalBonus: 0,
    totalSalary: 0,
    records: [],
  };

  const locationStatsMap = useMemo(() => {
    const map = new Map<string, LocationStatsResult>();
    const monthRecs = records.filter(r => r.date?.startsWith(selectedMonth));

    // Helper to resolve canonical code for any location name/id/code
    const getCanonicalLocCode = (locStr?: string): string => {
      if (!locStr) return (pickupPoints[0]?.code || '').toUpperCase();
      const clean = locStr.trim();
      const matched = pickupPoints.find(
        p =>
          p.code.toUpperCase() === clean.toUpperCase() ||
          p.name.toUpperCase() === clean.toUpperCase() ||
          p.id.toUpperCase() === clean.toUpperCase()
      );
      return matched ? matched.code.toUpperCase() : clean.toUpperCase();
    };

    // Group records by canonical location code uppercase
    const byLoc = new Map<string, typeof records>();
    for (const r of monthRecs) {
      const codeKey = getCanonicalLocCode(r.location);
      let arr = byLoc.get(codeKey);
      if (!arr) {
        arr = [];
        byLoc.set(codeKey, arr);
      }
      arr.push(r);
    }

    const staffMap = new Map(staffList.map(s => [s.id, s]));

    for (const [codeKey, locRecords] of byLoc.entries()) {
      let totalRevenue = 0;
      let cashRevenue = 0;
      let cardRevenue = 0;
      let totalShiftSalary = 0;
      let totalBonus = 0;

      for (const r of locRecords) {
        const sales = calculateDailySales(r.sales);
        totalRevenue += sales.totalSales;
        cashRevenue += sales.totalCash;
        cardRevenue += sales.totalCard;
        totalBonus += sales.bonus;

        const staff = staffMap.get(r.employeeId);
        let pay = calculateShiftTotalSalary(r, staff, rates);

        totalShiftSalary += pay;
      }

      const shiftCount = locRecords.length;
      const avgRevenuePerShift = shiftCount > 0 ? Math.round(totalRevenue / shiftCount) : 0;
      const totalSalary = totalShiftSalary + totalBonus;

      map.set(codeKey, {
        shiftCount,
        totalRevenue,
        cashRevenue,
        cardRevenue,
        avgRevenuePerShift,
        totalShiftSalary,
        totalBonus,
        totalSalary,
        records: locRecords,
      });
    }

    return map;
  }, [records, selectedMonth, staffList, rates, pickupPoints]);

  const getLocationStats = (locCode: string): LocationStatsResult => {
    return locationStatsMap.get((locCode || '').toUpperCase()) || defaultStats;
  };

  // Non-archived and archived counts
  const nonArchivedPoints = pickupPoints.filter(p => !p.isArchived);
  const archivedPoints = pickupPoints.filter(p => p.isArchived);
  const activePointsCount = nonArchivedPoints.filter(p => p.active !== false).length;
  const inactivePointsCount = nonArchivedPoints.filter(p => p.active === false).length;

  // Network total revenue & salary for selected month (active network)
  const totalNetworkRevenue = useMemo(() => {
    return records
      .filter(r => r.date?.startsWith(selectedMonth))
      .reduce((sum, r) => sum + calculateDailySales(r.sales).totalSales, 0);
  }, [records, selectedMonth]);

  const totalNetworkSalary = useMemo(() => {
    return nonArchivedPoints.reduce((sum, point) => {
      return sum + getLocationStats(point.code).totalSalary;
    }, 0);
  }, [nonArchivedPoints, locationStatsMap]);

  // Net profit (Чистая прибыль / мес) per PVZ from Payback section (Окупаемость ПВЗ)
  const getPvzNetProfit = (pointCode: string): number => {
    const rec = paybackRecords.find(
      r => (r.pvzCode || '').toUpperCase() === (pointCode || '').toUpperCase() && r.month === selectedMonth
    );
    if (!rec) return 0;
    const totalInc = (rec.incomes || []).reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    const totalExp = (rec.expenses || []).reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    return totalInc - totalExp;
  };

  // Total positive net profit across the network for share calculation, or total net profit
  const totalNetworkNetProfit = useMemo(() => {
    return nonArchivedPoints.reduce((sum, point) => {
      const net = getPvzNetProfit(point.code);
      return sum + (net > 0 ? net : 0);
    }, 0);
  }, [nonArchivedPoints, paybackRecords, selectedMonth]);

  // Overall net profit (sum of all PVZ net profits including negatives)
  const networkOverallNetProfit = useMemo(() => {
    return nonArchivedPoints.reduce((sum, point) => sum + getPvzNetProfit(point.code), 0);
  }, [nonArchivedPoints, paybackRecords, selectedMonth]);

  // Filtered pickup points list for cards and matrix
  const filteredPoints = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    const filtered = pickupPoints.filter(point => {
      const matchesSearch =
        !term ||
        point.name.toLowerCase().includes(term) ||
        point.code.toLowerCase().includes(term) ||
        (point.address && point.address.toLowerCase().includes(term));

      if (filterStatus === 'archived') {
        return matchesSearch && point.isArchived === true;
      }

      // For all, active, inactive tabs: hide archived points
      if (point.isArchived) return false;

      if (filterStatus === 'active') return matchesSearch && point.active !== false;
      if (filterStatus === 'inactive') return matchesSearch && point.active === false;
      return matchesSearch;
    });

    // Sort alphabetically by name
    return [...filtered].sort((a, b) => a.name.localeCompare(b.name, 'ru'));
  }, [pickupPoints, searchTerm, filterStatus]);

  // Automatic sorting for Comparative Matrix by "ДОЛЯ В СЕТИ" (рассчитанной от Чистой прибыли) descending
  const sortedMatrixPoints = useMemo(() => {
    return [...filteredPoints].sort((a, b) => {
      const netA = getPvzNetProfit(a.code);
      const netB = getPvzNetProfit(b.code);
      if (netB !== netA) {
        return netB - netA; // Чем выше чистая прибыль, тем выше в списке
      }
      const statsA = getLocationStats(a.code);
      const statsB = getLocationStats(b.code);
      return statsB.totalRevenue - statsA.totalRevenue;
    });
  }, [filteredPoints, paybackRecords, selectedMonth, locationStatsMap]);

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {actionSuccessMsg && (
        <div className="toast-banner fixed top-5 right-5 z-50 p-4 bg-slate-900 text-white border border-emerald-500/60 rounded-xl text-xs font-semibold shadow-2xl flex items-center gap-2.5 animate-in slide-in-from-top duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-white font-medium">{actionSuccessMsg}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="p-4 sm:p-5 bg-slate-900 border border-slate-800 rounded-lg shadow-sm space-y-4">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 w-full xl:w-auto">
            <div className="w-10 h-10 rounded-md bg-slate-800 border border-slate-700/80 text-slate-200 flex items-center justify-center shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-base sm:text-lg font-semibold text-white tracking-tight">
                  Управление пунктами выдачи (ПВЗ)
                </h2>

                {/* Info Tooltip Icon 'i' */}
                <div className="relative group inline-flex items-center shrink-0">
                  <button
                    type="button"
                    className="w-5 h-5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-emerald-400 flex items-center justify-center transition-colors cursor-help focus:outline-none"
                    aria-label="Информация о разделе"
                    title="Создание до 30 локаций, произвольные названия, распределение персонала, архив и глубокая аналитика по каждому пункту"
                  >
                    <Info className="w-3 h-3" />
                  </button>

                  {/* Popover on hover/focus */}
                  <div className="absolute left-0 sm:left-1/2 sm:-translate-x-1/2 top-full mt-2 hidden group-hover:flex group-focus-within:flex z-50 w-72 sm:w-80 p-3 bg-slate-950 border border-slate-800 rounded-lg shadow-2xl text-xs text-slate-300 font-normal leading-relaxed pointer-events-none">
                    <div className="flex items-start gap-2.5">
                      <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-medium text-white block mb-0.5">О разделе «ПВЗ»</span>
                        <span className="text-slate-400 text-xs leading-relaxed">
                          Создание до 30 локаций, произвольные названия, распределение персонала, архив и глубокая аналитика по каждому пункту
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <span className="text-slate-400 font-mono text-xs font-normal whitespace-nowrap ml-1">
                  {nonArchivedPoints.length} / 30
                </span>
                {archivedPoints.length > 0 && (
                  <span className="text-slate-500 font-mono text-xs font-normal whitespace-nowrap">
                    ({archivedPoints.length} в архиве)
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Action Bar: Period and +Добавить ПВЗ */}
          <div className="flex items-center gap-3 shrink-0 flex-wrap sm:flex-nowrap self-start xl:self-center">
            {/* Custom Styled Theme Period Dropdown */}
            <CustomPeriodSelect
              value={selectedMonth}
              onChange={setSelectedMonth}
              options={allAvailableMonths}
              labelPrefix="Период:"
              align="right"
            />

            {/* Add PVZ button */}
            <button
              onClick={openAddModal}
              disabled={pickupPoints.length >= 30}
              className="py-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-medium text-xs rounded-md transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed shrink-0 whitespace-nowrap cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 shrink-0" />
              <span>Добавить ПВЗ</span>
            </button>
          </div>
        </div>

        {/* Capacity Indicator Progress Bar */}
        <div className="mt-4 pt-3.5 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-950 p-3 rounded-md border border-slate-800/80">
            <span className="text-slate-400 block text-xs">Активных пунктов</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-base font-semibold text-white font-mono">{nonArchivedPoints.length}</span>
              <span className="text-slate-500 text-xs">/ 30 макс</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-md border border-slate-800/80">
            <span className="text-slate-400 block text-xs">Работают сейчас</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-base font-semibold text-emerald-400 font-mono">{activePointsCount}</span>
              <span className="text-slate-500 text-xs">в строю</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-md border border-slate-800/80">
            <span className="text-slate-400 block text-xs">Персонала на ПВЗ</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-base font-semibold text-sky-400 font-mono">{activeStaff.length}</span>
              <span className="text-slate-500 text-xs">активных</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded-md border border-slate-800/80">
            <span className="text-slate-400 block text-xs">Выручка сети ({formatMonthName(selectedMonth)})</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-base font-semibold text-amber-400 font-mono">{formatCurrency(totalNetworkRevenue)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 1. Network Multi-Location Comparison Table Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-medium text-white">
              Сравнительная матрица всех ПВЗ сети ({formatMonthName(selectedMonth)})
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Оборот сети: <span className="font-medium text-amber-400">{formatCurrency(totalNetworkRevenue)}</span> · ФОТ: <span className="font-medium text-emerald-400">{formatCurrency(totalNetworkSalary)}</span> · Прибыль: <span className={`font-medium ${networkOverallNetProfit < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>{formatCurrency(networkOverallNetProfit)}</span>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300 border-collapse">
            <thead>
              <tr className="bg-slate-950 text-slate-400 text-xs font-medium border-b border-slate-800">
                <th className="py-2.5 px-3 font-medium">Код / Название ПВЗ</th>
                <th className="py-2.5 px-3 font-medium">Статус</th>
                <th className="py-2.5 px-3 font-medium text-center">Персонал</th>
                <th className="py-2.5 px-3 font-medium text-center">Смен</th>
                <th className="py-2.5 px-3 font-medium text-right">Выручка</th>
                <th className="py-2.5 px-3 font-medium text-right">ЗП за тек. месяц</th>
                <th className="py-2.5 px-3 font-medium text-right" title="Доля в сети рассчитывается от значения «Чистая прибыль / мес» из раздела «Окупаемость ПВЗ»">
                  Доля в сети
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {sortedMatrixPoints.map(point => {
                const stats = getLocationStats(point.code);
                const assignedCount = activeStaff.filter(
                  s => point.assignedStaffIds?.includes(s.id) || s.locations?.includes(point.code)
                ).length;

                // Net profit from Payback section (Окупаемость ПВЗ)
                const netProfit = getPvzNetProfit(point.code);
                const shareNum =
                  totalNetworkNetProfit > 0 && netProfit > 0
                    ? (netProfit / totalNetworkNetProfit) * 100
                    : 0;
                const share = shareNum.toFixed(1);

                return (
                  <tr key={point.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-medium text-white font-sans">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 dark:bg-slate-800 text-emerald-700 dark:text-emerald-400 font-mono text-xs font-semibold">
                          {point.code}
                        </span>
                        <span className="truncate max-w-[200px]">{point.name}</span>
                        {point.isArchived && (
                          <span className="text-[10px] bg-amber-500/10 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded-md font-sans font-medium">
                            В архиве
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 font-sans">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-xs font-medium ${
                          point.isArchived
                            ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400'
                            : point.active !== false
                            ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            point.isArchived
                              ? 'bg-amber-500'
                              : point.active !== false
                              ? 'bg-emerald-500'
                              : 'bg-slate-400'
                          }`}
                        />
                        {point.isArchived ? 'Архив' : point.active !== false ? 'Активен' : 'Отключен'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center font-medium text-sky-400">{assignedCount} чел.</td>
                    <td className="py-2.5 px-3 text-center font-medium text-white">{stats.shiftCount}</td>
                    <td className="py-2.5 px-3 text-right font-medium text-amber-400">
                      {formatCurrency(stats.totalRevenue)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-emerald-400">
                      {formatCurrency(stats.totalSalary)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-medium text-slate-200 font-sans">
                      <div className="flex items-center justify-end gap-1.5" title={`Чистая прибыль: ${formatCurrency(netProfit)} (раздел «Окупаемость ПВЗ»)`}>
                        <div className="w-12 bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800 hidden sm:block">
                          <div
                            className={`h-full rounded-full ${netProfit < 0 ? 'bg-rose-500' : 'bg-emerald-400'}`}
                            style={{ width: `${Math.min(Math.max(shareNum, 0), 100)}%` }}
                          />
                        </div>
                        <span className={`font-mono ${netProfit < 0 ? 'text-rose-400' : 'text-slate-200'}`}>
                          {netProfit < 0 ? '0.0%' : `${share}%`}
                        </span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Controls: Search & Status Filters including Archive */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900 p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Поиск ПВЗ по названию, коду, адресу..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 pl-8 pr-3 py-1.5 rounded-md text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={expandAll}
              className="py-1.5 px-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-md text-xs font-medium transition-colors hidden md:block cursor-pointer"
              title="Развернуть все карточки"
            >
              Развернуть все
            </button>
            <button
              onClick={collapseAll}
              className="py-1.5 px-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-md text-xs font-medium transition-colors hidden md:block cursor-pointer"
              title="Свернуть все карточки"
            >
              Свернуть все
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 flex-wrap">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Все ({nonArchivedPoints.length})
          </button>
          <button
            onClick={() => setFilterStatus('active')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              filterStatus === 'active'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Активные ({activePointsCount})
          </button>
          <button
            onClick={() => setFilterStatus('inactive')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              filterStatus === 'inactive'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Отключенные ({inactivePointsCount})
          </button>
          <button
            onClick={() => setFilterStatus('archived')}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              filterStatus === 'archived'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Archive className="w-3.5 h-3.5" />
            <span>Архив ({archivedPoints.length})</span>
          </button>
        </div>
      </div>

      {/* Archive Context Banner (shown when viewing Archive tab) */}
      {filterStatus === 'archived' && (
        <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-lg flex items-start gap-3 shadow-xs">
          <div className="w-8 h-8 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
            <Archive className="w-4 h-4" />
          </div>
          <div className="text-xs text-slate-300">
            <h4 className="font-medium text-white text-xs sm:text-sm">Архив пунктов выдачи</h4>
            <p className="mt-0.5 text-slate-400 text-xs leading-relaxed">
              В архиве хранятся закрытые или выведенные из эксплуатации ПВЗ. Вся история смен, продаж и аналитика по ним сохраняются в полном объеме. Вы можете в любой момент восстановить ПВЗ в рабочую сеть или удалить его окончательно.
            </p>
          </div>
        </div>
      )}

      {/* 2. Expandable / Compact Pickup Points Cards List (Accordion Layout) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-medium uppercase tracking-wider text-slate-400">
            {filterStatus === 'archived' ? 'Архивированные ПВЗ' : 'Пункты выдачи'} ({filteredPoints.length})
          </h3>
          <span className="text-[11px] text-slate-500">
            Нажмите на строку для просмотра деталей
          </span>
        </div>

        {filteredPoints.length === 0 ? (
          <div className="text-center py-10 bg-slate-900 rounded-lg border border-slate-800 text-slate-500 text-xs">
            {filterStatus === 'archived' ? (
              <>
                <Inbox className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-xs font-medium text-slate-300">В архиве пока нет пунктов выдачи</p>
                <p className="text-[11px] text-slate-500 mt-1">При отправке ПВЗ в архив он появится здесь с возможностью восстановления</p>
              </>
            ) : (
              <>
                <Building2 className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-xs font-medium text-slate-300">Пункты выдачи не найдены</p>
                <p className="text-[11px] text-slate-500 mt-1">Попробуйте изменить поисковый запрос или фильтр</p>
              </>
            )}
          </div>
        ) : (
          filteredPoints.map(point => {
            const stats = getLocationStats(point.code);
            const assignedStaffMembers = activeStaff.filter(
              s => point.assignedStaffIds?.includes(s.id) || s.locations?.includes(point.code)
            );
            const isExpanded = expandedPointIds.has(point.id);

            const revenueShare =
              totalNetworkRevenue > 0
                ? Math.round((stats.totalRevenue / totalNetworkRevenue) * 100)
                : 0;

            return (
              <div
                key={point.id}
                className={`rounded-lg transition-all overflow-hidden border ${
                  point.isArchived
                    ? 'bg-slate-900/80 border-slate-800/60'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Compact Header Row */}
                <div className="p-3 flex items-center justify-between gap-3 flex-wrap sm:flex-nowrap">
                  
                  {/* Left: Code badge, Name, Address, Active status */}
                  <div
                    onClick={() => toggleExpand(point.id)}
                    className="flex items-center gap-3 cursor-pointer select-none flex-1 min-w-[200px]"
                  >
                    <div className={`w-8 h-8 rounded-md flex items-center justify-center shrink-0 border ${
                      point.isArchived
                        ? 'bg-slate-800/40 text-slate-500 border-slate-800'
                        : 'bg-slate-800 text-slate-200 border-slate-700/80'
                    }`}>
                      {point.isArchived ? (
                        <Archive className="w-4 h-4" />
                      ) : (
                        <Building2 className="w-4 h-4" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="font-medium text-white text-xs sm:text-sm flex items-center gap-2 flex-wrap">
                        <span className="truncate">{point.name}</span>
                        <span className="font-mono text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 shrink-0 whitespace-nowrap">
                          {point.code}
                        </span>
                        <span
                          className={`inline-flex items-center gap-1.5 text-[10px] font-medium px-2 py-0.5 rounded-md ${
                            point.isArchived
                              ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400'
                              : point.active !== false
                              ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              point.isArchived
                                ? 'bg-amber-500'
                                : point.active !== false
                                ? 'bg-emerald-500'
                                : 'bg-slate-400'
                            }`}
                          />
                          {point.isArchived ? 'В архиве' : point.active !== false ? 'Активен' : 'Отключен'}
                        </span>
                        {point.isArchived && point.archivedAt && (
                          <span className="text-[10px] text-slate-500 font-normal">
                            (с {formatDateRuDMY(point.archivedAt.split('T')[0])})
                          </span>
                        )}
                      </div>

                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5 truncate">
                        <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                        <span className="truncate">{point.address || 'Адрес не указан'}</span>
                        {point.contactPhone && (
                          <span className="text-slate-500 hidden sm:inline">· {point.contactPhone}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Middle: 3 Compact Indicators for Selected Month */}
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="text-center px-2 py-1 bg-slate-950 rounded-md border border-slate-800 min-w-[50px]">
                      <div className="text-[9px] text-slate-500 uppercase font-medium">Смен</div>
                      <div className="text-xs font-semibold font-mono text-white">{stats.shiftCount}</div>
                    </div>

                    <div className="text-center px-2.5 py-1 bg-slate-950 rounded-md border border-slate-800 min-w-[75px]">
                      <div className="text-[9px] text-amber-400 uppercase font-medium">Выручка</div>
                      <div className="text-xs font-semibold font-mono text-amber-400">{formatCurrency(stats.totalRevenue)}</div>
                    </div>

                    <div className="text-center px-2.5 py-1 bg-slate-950 rounded-md border border-slate-800 min-w-[75px]">
                      <div className="text-[9px] text-emerald-400 uppercase font-medium">ЗП за месяц</div>
                      <div className="text-xs font-semibold font-mono text-emerald-400">{formatCurrency(stats.totalSalary)}</div>
                    </div>
                  </div>

                  {/* Right: Quick Action Buttons */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => setAnalyticsPoint(point)}
                      className="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer border border-slate-700/60"
                      title="Показатели и аналитика"
                    >
                      <BarChart3 className="w-3.5 h-3.5 text-sky-400" />
                      <span className="hidden sm:inline">Аналитика</span>
                    </button>

                    {point.isArchived ? (
                      <button
                        onClick={() => setRestoringPoint(point)}
                        className="py-1 px-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                        title="Восстановить ПВЗ"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Восстановить</span>
                      </button>
                    ) : (
                      <>
                        <button
                          onClick={() => openEditModal(point)}
                          className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors cursor-pointer border border-transparent hover:border-slate-700"
                          title="Редактировать ПВЗ"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleRequestArchive(point)}
                          className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-md transition-colors cursor-pointer border border-transparent hover:border-amber-500/20"
                          title="В архив"
                        >
                          <Archive className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}

                    <button
                      onClick={() => handleRequestPermanentDelete(point)}
                      className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-md transition-colors cursor-pointer border border-transparent hover:border-red-500/20"
                      title="Удалить окончательно"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => toggleExpand(point.id)}
                      className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors cursor-pointer"
                      title={isExpanded ? 'Свернуть' : 'Развернуть'}
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>

                </div>

                {/* Expanded Detailed Section */}
                {isExpanded && (
                  <div className="p-3 pt-0 border-t border-slate-800 bg-slate-950/40 space-y-3">
                    
                    {/* Monthly KPI Metrics 4-grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2.5 text-xs">
                      <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">Выручка за месяц</span>
                        <span className="text-sm font-semibold text-amber-400 font-mono block mt-0.5">
                          {formatCurrency(stats.totalRevenue)}
                        </span>
                        <span className="text-[10px] text-slate-500">{revenueShare}% от оборота сети</span>
                      </div>

                      <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">Смен за месяц</span>
                        <span className="text-sm font-semibold text-white font-mono block mt-0.5">
                          {stats.shiftCount} <span className="text-xs font-normal text-slate-400">смен</span>
                        </span>
                        <span className="text-[10px] text-slate-500">
                          ~{stats.avgRevenuePerShift} ₽ / смена
                        </span>
                      </div>

                      <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-[11px] text-emerald-400 font-medium block">ЗП за тек. месяц</span>
                        <span className="text-sm font-semibold text-emerald-400 font-mono block mt-0.5">
                          {formatCurrency(stats.totalSalary)}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          Оклад: {formatCurrency(stats.totalShiftSalary)} + Премия: {formatCurrency(stats.totalBonus)}
                        </span>
                      </div>

                      <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                        <span className="text-[11px] text-slate-400 block">Статус работы</span>
                        <div className="flex items-center justify-between mt-1">
                          <span className={`text-xs font-medium ${point.isArchived ? 'text-amber-400' : point.active !== false ? 'text-emerald-400' : 'text-slate-500'}`}>
                            {point.isArchived ? 'В архиве' : point.active !== false ? 'Включен' : 'Отключен'}
                          </span>
                          {!point.isArchived && (
                            <button
                              onClick={() => {
                                if (point.active !== false) {
                                  setDeactivatingPoint(point);
                                } else {
                                  togglePointActive(point);
                                }
                              }}
                              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors cursor-pointer border-0 ${
                                point.active !== false
                                  ? 'bg-amber-100 text-amber-800 hover:bg-amber-200 dark:bg-amber-500/20 dark:text-amber-300'
                                  : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400'
                              }`}
                            >
                              {point.active !== false ? 'Отключить' : 'Включить'}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Address, Phone, Notes & Personnel Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                      
                      {/* Left: Contact Info */}
                      <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-xs space-y-2">
                        <div className="flex items-center justify-between text-slate-400 font-sans">
                          <span className="text-[10px] uppercase font-medium tracking-wider text-slate-400">Параметры локации</span>
                          {!point.isArchived && (
                            <button
                              onClick={() => openEditModal(point)}
                              className="text-[10px] text-sky-400 hover:text-sky-300 flex items-center gap-1 font-medium cursor-pointer"
                            >
                              <Edit2 className="w-3 h-3" />
                              <span>Изменить</span>
                            </button>
                          )}
                        </div>

                        <div className="space-y-1.5 text-slate-300">
                          <div className="flex items-start gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                            <span>{point.address || 'Адрес не указан'}</span>
                          </div>
                          {point.contactPhone && (
                            <div className="flex items-center gap-1.5">
                              <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                              <span className="font-mono">{point.contactPhone}</span>
                            </div>
                          )}
                          {point.notes && (
                            <div className="flex items-start gap-1.5 text-slate-400 text-[11px] pt-1.5 border-t border-slate-800">
                              <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                              <span>{point.notes}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: Assigned Staff List */}
                      <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase font-medium tracking-wider text-slate-400 flex items-center gap-1">
                            <Users className="w-3.5 h-3.5 text-sky-400" />
                            Персонал ПВЗ ({assignedStaffMembers.length})
                          </span>
                          {!point.isArchived && (
                            <button
                              onClick={() => openAssignModal(point)}
                              className="text-[10px] text-sky-400 hover:text-sky-300 font-medium cursor-pointer"
                            >
                              Распределить
                            </button>
                          )}
                        </div>

                        {assignedStaffMembers.length > 0 ? (
                          <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto pr-1">
                            {assignedStaffMembers.map(staff => (
                              <span
                                key={staff.id}
                                className="px-2 py-0.5 rounded-md text-[11px] bg-slate-950 text-slate-200 border border-slate-800 flex items-center gap-1"
                              >
                                <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                                {staff.name}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <p className="text-[11px] text-slate-500 italic py-1">
                            {point.isArchived
                              ? 'Локация в архиве (сотрудники отключены)'
                              : 'Сотрудники не закреплены (пункт доступен всем)'}
                          </p>
                        )}
                      </div>

                    </div>

                    {/* Bottom Action Toolbar */}
                    <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-800 flex-wrap">
                      <div className="flex items-center gap-2">
                        {!point.isArchived && (
                          <button
                            onClick={() => openAssignModal(point)}
                            className="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-sky-400 rounded-md text-xs font-medium transition-colors border border-slate-700/60 flex items-center gap-1.5 cursor-pointer"
                          >
                            <Users className="w-3.5 h-3.5" />
                            <span>Распределить персонал</span>
                          </button>
                        )}
                        <button
                          onClick={() => setAnalyticsPoint(point)}
                          className="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded-md text-xs font-medium transition-colors border border-slate-700/60 flex items-center gap-1.5 cursor-pointer"
                        >
                          <BarChart3 className="w-3.5 h-3.5" />
                          <span>Подробная аналитика</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        {point.isArchived ? (
                          <button
                            onClick={() => setRestoringPoint(point)}
                            className="py-1 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md text-xs font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Восстановить из архива</span>
                          </button>
                        ) : (
                          <>
                            <button
                              onClick={() => openEditModal(point)}
                              className="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-md text-xs font-medium transition-colors border border-slate-700 flex items-center gap-1 cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                              <span>Параметры</span>
                            </button>
                            <button
                              onClick={() => handleRequestArchive(point)}
                              className="py-1 px-2.5 bg-amber-100 hover:bg-amber-200 text-amber-900 dark:bg-amber-950/40 dark:hover:bg-amber-900/60 dark:text-amber-300 rounded-md text-xs font-medium transition-colors border-0 flex items-center gap-1 cursor-pointer"
                            >
                              <Archive className="w-3.5 h-3.5" />
                              <span>В архив</span>
                            </button>
                          </>
                        )}

                        <button
                          onClick={() => handleRequestPermanentDelete(point)}
                          className="py-1 px-2.5 bg-rose-100 hover:bg-rose-200 text-rose-900 dark:bg-red-950/40 dark:hover:bg-red-900/60 dark:text-red-400 rounded-md text-xs font-medium transition-colors border-0 flex items-center gap-1 cursor-pointer"
                          title="Удалить окончательно"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Удалить</span>
                        </button>
                      </div>
                    </div>

                  </div>
                )}

              </div>
            );
          })
        )}
      </div>

      {/* Modal: Add or Edit PVZ */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900 shrink-0">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">
                  {editingPoint ? 'Редактировать пункт выдачи' : 'Добавить новый ПВЗ'}
                </h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="p-4 space-y-3.5 flex-1 overflow-y-auto">
              {errorMsg && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-md text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-medium text-slate-300">
                    Название пункта выдачи <span className="text-red-400">*</span>
                  </label>
                  <span className={`text-[10px] ${formName.length >= 30 ? 'text-amber-400 font-medium' : 'text-slate-500'}`}>
                    {formName.length} / 30
                  </span>
                </div>
                <input
                  type="text"
                  required
                  maxLength={30}
                  placeholder="Например: ПВЗ Октябрьский"
                  value={formName}
                  onChange={e => setFormName(e.target.value.slice(0, 30))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-md px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Код / Аббревиатура
                  </label>
                  <input
                    type="text"
                    placeholder="Например: ОКТ42"
                    maxLength={18}
                    value={formCode}
                    onChange={e => setFormCode(e.target.value.slice(0, 18))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-md px-3 py-1.5 text-xs text-white uppercase placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                  <div className="flex items-center justify-between mt-0.5 text-[10px] text-slate-500">
                    <span>Короткий код для отчетов</span>
                    <span className={formCode.length >= 18 ? 'text-amber-400 font-medium' : 'text-slate-500'}>
                      {formCode.length} / 18
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Телефон ПВЗ</label>
                  <input
                    type="tel"
                    placeholder="1 (234) 567-89-10"
                    value={formPhone}
                    onChange={handlePhoneChange}
                    className="w-full bg-slate-950 border border-slate-800 rounded-md px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">Формат: 1 (234) 567-89-10</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Фактический адрес</label>
                <input
                  type="text"
                  placeholder="г. Москва, Октябрьский проспект, д. 42"
                  value={formAddress}
                  onChange={e => setFormAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-md px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Заметки / Режим работы</label>
                <textarea
                  rows={2}
                  placeholder="Время работы, особенности выдачи или контакта с курьерами..."
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-md px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Active Toggle */}
              <label className="flex items-center justify-between p-2.5 bg-slate-950 rounded-md border border-slate-800 hover:border-slate-700 cursor-pointer transition-all">
                <div>
                  <span className="text-xs font-medium text-white block">Статус работы пункта</span>
                  <span className="text-[11px] text-slate-400">
                    {formActive ? 'Пункт активен и доступен для выбора сотрудниками' : 'Пункт временно отключен'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={formActive}
                  onChange={e => setFormActive(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 cursor-pointer rounded focus:outline-none focus:ring-1 focus:ring-emerald-400"
                />
              </label>

              {/* Staff Multi-Select */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Закрепленные сотрудники ({formStaffIds.length})
                </label>
                <div className="max-h-36 overflow-y-auto bg-slate-950 border border-slate-800 rounded-md p-2 space-y-1">
                  {activeStaff.map(staff => {
                    const isChecked = formStaffIds.includes(staff.id);
                    return (
                      <label
                        key={staff.id}
                        className="flex items-center justify-between p-1.5 rounded-md hover:bg-slate-900 cursor-pointer text-xs transition-all"
                      >
                        <span className="text-slate-200">{staff.name}</span>
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={e => {
                            if (e.target.checked) {
                              setFormStaffIds(prev => [...prev, staff.id]);
                            } else {
                              setFormStaffIds(prev => prev.filter(id => id !== staff.id));
                            }
                          }}
                          className="w-3.5 h-3.5 accent-emerald-500 cursor-pointer rounded focus:outline-none"
                        />
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-medium transition-all cursor-pointer border border-slate-700/60"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md text-xs font-medium transition-all disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? 'Сохранение...' : editingPoint ? 'Сохранить изменения' : 'Создать ПВЗ'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Staff Assignment for Location */}
      {assigningPoint && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900 shrink-0">
              <div>
                <h3 className="text-sm font-semibold text-white">Распределение персонала</h3>
                <p className="text-xs text-emerald-400 font-mono mt-0.5">
                  ПВЗ: {assigningPoint.name} ({assigningPoint.code})
                </p>
              </div>
              <button
                onClick={() => setAssigningPoint(null)}
                className="p-1 text-slate-400 hover:text-white rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3 flex-1 overflow-y-auto">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Поиск сотрудника..."
                  value={staffSearchQuery}
                  onChange={e => setStaffSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 pl-8 pr-3 py-1.5 rounded-md text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>Выбрано: {assignedStaffIds.length} чел.</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setAssignedStaffIds(activeStaff.map(s => s.id))}
                    className="text-sky-400 hover:underline cursor-pointer font-medium"
                  >
                    Выбрать всех
                  </button>
                  <span>·</span>
                  <button onClick={() => setAssignedStaffIds([])} className="text-slate-400 hover:underline cursor-pointer">
                    Сбросить
                  </button>
                </div>
              </div>

              <div className="max-h-60 overflow-y-auto bg-slate-950 border border-slate-800 rounded-md p-1.5 space-y-1">
                {activeStaff
                  .filter(s => s.name.toLowerCase().includes(staffSearchQuery.toLowerCase()))
                  .map(staff => {
                    const isAssigned = assignedStaffIds.includes(staff.id);
                    return (
                      <div
                        key={staff.id}
                        onClick={() => {
                          if (isAssigned) {
                            setAssignedStaffIds(prev => prev.filter(id => id !== staff.id));
                          } else {
                            setAssignedStaffIds(prev => [...prev, staff.id]);
                          }
                        }}
                        className={`flex items-center justify-between p-2 rounded-md cursor-pointer text-xs transition-colors border ${
                          isAssigned
                            ? 'bg-sky-500/10 border-sky-500/30 text-white font-medium'
                            : 'bg-slate-900 border-slate-800/80 text-slate-300 hover:bg-slate-850'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <UserCheck className={`w-3.5 h-3.5 ${isAssigned ? 'text-sky-400' : 'text-slate-500'}`} />
                          <span>{staff.name}</span>
                        </div>
                        <input
                          type="checkbox"
                          checked={isAssigned}
                          onChange={() => {}} // Handled by div click
                          className="w-3.5 h-3.5 accent-sky-500 cursor-pointer rounded"
                        />
                      </div>
                    );
                  })}
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  onClick={() => setAssigningPoint(null)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-medium transition-all cursor-pointer border border-slate-700/60"
                >
                  Отмена
                </button>
                <button
                  onClick={handleSaveStaffAssignment}
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-md text-xs font-medium transition-all disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? 'Сохранение...' : 'Применить доступ'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Detailed Location Analytics */}
      {analyticsPoint && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 z-50 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-2xl max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <BarChart3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Аналитика ПВЗ: {analyticsPoint.name}</h3>
                  <span className="text-xs text-emerald-400 font-mono">
                    Код: {analyticsPoint.code} · Месяц: {formatMonthName(selectedMonth)}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setAnalyticsPoint(null)}
                className="p-1 text-slate-400 hover:text-white rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {(() => {
              const stats = getLocationStats(analyticsPoint.code);
              return (
                <div className="p-4 space-y-3.5 flex-1 overflow-y-auto">
                  {/* Top Stats Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <div className="bg-slate-950 p-2.5 rounded-md border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Совокупная выручка</span>
                      <span className="text-sm font-semibold text-amber-400 font-mono mt-0.5 block">
                        {formatCurrency(stats.totalRevenue)}
                      </span>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-md border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Всего смен</span>
                      <span className="text-sm font-semibold text-white font-mono mt-0.5 block">
                        {stats.shiftCount} смен
                      </span>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-md border border-slate-800">
                      <span className="text-emerald-400 font-medium block text-[11px]">ЗП за тек. месяц</span>
                      <span className="text-sm font-semibold text-emerald-400 font-mono mt-0.5 block">
                        {formatCurrency(stats.totalSalary)}
                      </span>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-md border border-slate-800">
                      <span className="text-slate-400 block text-[11px]">Доля от всей сети</span>
                      <span className="text-sm font-semibold text-sky-400 font-mono mt-0.5 block">
                        {totalNetworkRevenue > 0
                          ? ((stats.totalRevenue / totalNetworkRevenue) * 100).toFixed(1)
                          : 0}
                        %
                      </span>
                    </div>
                  </div>

                  {/* Revenue Breakdown by Payment Method */}
                  <div className="bg-slate-950 border border-slate-800 rounded-md p-3 space-y-2">
                    <h4 className="text-xs font-medium text-white flex items-center gap-1.5">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                      Выручка от продаж смен на данном ПВЗ
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                      <div className="bg-slate-900 p-2 rounded-md border border-slate-800 text-center">
                        <span className="text-[11px] text-slate-400 block">Наличные</span>
                        <span className="font-semibold text-emerald-400 font-mono mt-0.5 block">
                          {formatCurrency(stats.cashRevenue)}
                        </span>
                      </div>
                      <div className="bg-slate-900 p-2 rounded-md border border-slate-800 text-center">
                        <span className="text-[11px] text-slate-400 block">Безналичные / Карта</span>
                        <span className="font-semibold text-sky-400 font-mono mt-0.5 block">
                          {formatCurrency(stats.cardRevenue)}
                        </span>
                      </div>
                      <div className="bg-slate-900 p-2 rounded-md border border-slate-800 text-center col-span-2 sm:col-span-1">
                        <span className="text-[11px] text-slate-400 block">Общая выручка</span>
                        <span className="font-semibold text-white font-mono mt-0.5 block">
                          {formatCurrency(stats.totalRevenue)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Recent Shifts Log for this location */}
                  <div>
                    <h4 className="text-xs font-medium text-white mb-2 flex items-center justify-between">
                      <span>Журнал смен на этом ПВЗ за {formatMonthName(selectedMonth)}</span>
                      <span className="text-slate-500 font-normal font-mono">{stats.records.length} записей</span>
                    </h4>

                    {stats.records.length > 0 ? (
                      <div className="max-h-52 overflow-y-auto bg-slate-950 border border-slate-800 rounded-md divide-y divide-slate-800/60">
                        {stats.records.map(r => {
                          const sales = calculateDailySales(r.sales);
                          return (
                            <div key={r.id} className="p-2.5 flex items-center justify-between text-xs hover:bg-slate-900/50">
                              <div>
                                <span className="font-medium text-white block">{r.employeeName}</span>
                                <span className="text-[10px] text-slate-400 font-mono">{r.date} · {r.shiftType || 'standard'}</span>
                              </div>
                              <div className="text-right font-mono">
                                <span className="font-medium text-amber-400 block">
                                  {formatCurrency(sales.totalSales)}
                                </span>
                                <span className="text-[10px] text-emerald-400">
                                  Премия 5%: {formatCurrency(sales.bonus)}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="p-4 bg-slate-950 border border-slate-800 rounded-md text-center text-xs text-slate-500">
                        Смен за выбранный месяц на этом ПВЗ пока не зафиксировано
                      </div>
                    )}
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => setAnalyticsPoint(null)}
                      className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md text-xs font-medium transition-all cursor-pointer border border-slate-700/60"
                    >
                      Закрыть
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Modal: Confirm Deactivate PVZ */}
      {deactivatingPoint && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Отключение пункта выдачи</h3>
                  <p className="text-xs text-slate-400">Подтверждение действия</p>
                </div>
              </div>
              <button
                onClick={() => setDeactivatingPoint(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3.5">
              <p className="text-xs text-slate-200 leading-relaxed">
                Вы уверены, что хотите отключить пункт выдачи{' '}
                <span className="font-semibold text-white">«{deactivatingPoint.name}»</span>{' '}
                <span className="px-1.5 py-0.5 rounded text-[11px] font-mono font-medium bg-slate-800 text-emerald-400">
                  {deactivatingPoint.code}
                </span>
                ?
              </p>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-md text-xs text-slate-400 space-y-1.5">
                <div className="flex items-start gap-2">
                  <span className="text-amber-400 font-semibold">•</span>
                  <span>Пункт перейдет в статус <strong>«Отключен»</strong> и не будет доступен сотрудникам для открытия новых смен.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-emerald-400 font-semibold">•</span>
                  <span>Все финансовые показатели, история смен и аналитика сохраняются в полном объеме.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-emerald-400 font-semibold">•</span>
                  <span>Вы сможете включить его обратно в любой момент одним нажатием кнопки <strong>«Включить»</strong>.</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDeactivatingPoint(null)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-medium transition-all cursor-pointer border border-slate-700/60"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const target = deactivatingPoint;
                    setDeactivatingPoint(null);
                    const res = await updatePickupPoint(target.id, { active: false });
                    if (res.success) {
                      setActionSuccessMsg(`Пункт выдачи «${target.name}» успешно отключен`);
                      setTimeout(() => setActionSuccessMsg(null), 3000);
                    }
                  }}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-md text-xs font-medium transition-all cursor-pointer"
                >
                  Отключить
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Confirm Archive PVZ */}
      {archivingPoint && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Archive className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Перемещение в архив</h3>
                  <p className="text-xs text-slate-400">Архивация пункта выдачи</p>
                </div>
              </div>
              <button
                onClick={() => {
                  if (!isSubmitting) setArchivingPoint(null);
                }}
                disabled={isSubmitting}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3.5">
              <p className="text-xs text-slate-200 leading-relaxed">
                Вы уверены, что хотите отправить в архив пункт выдачи{' '}
                <span className="font-semibold text-white">«{archivingPoint.name}»</span>{' '}
                <span className="px-1.5 py-0.5 rounded text-[11px] font-mono font-medium bg-slate-800 text-emerald-400">
                  {archivingPoint.code}
                </span>
                ?
              </p>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-md text-xs text-slate-400 space-y-1.5">
                <div className="flex items-start gap-2">
                  <span className="text-emerald-400 font-semibold">•</span>
                  <span>ПВЗ будет перемещен во вкладку <strong>«Архив»</strong> и отключен для новых смен сотрудников.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-emerald-400 font-semibold">•</span>
                  <span>Все ранее сохраненные отчеты, смены и финансовые показатели сохраняются.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-emerald-400 font-semibold">•</span>
                  <span>Вы сможете <strong>восстановить</strong> этот ПВЗ в любой момент одним нажатием.</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setArchivingPoint(null)}
                  disabled={isSubmitting}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-medium transition-all disabled:opacity-50 cursor-pointer border border-slate-700/60"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  onClick={handleConfirmArchive}
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
                      <span>Архивация...</span>
                    </>
                  ) : (
                    <>
                      <Archive className="w-3.5 h-3.5" />
                      <span>В архив</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Confirm Restore PVZ from Archive */}
      {restoringPoint && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Восстановление из архива</h3>
                  <p className="text-xs text-slate-400">Возврат ПВЗ в рабочую сеть</p>
                </div>
              </div>
              <button
                onClick={() => {
                  if (!isSubmitting) setRestoringPoint(null);
                }}
                disabled={isSubmitting}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3.5">
              <p className="text-xs text-slate-200 leading-relaxed">
                Восстановить пункт выдачи{' '}
                <span className="font-semibold text-white">«{restoringPoint.name}»</span>{' '}
                <span className="px-1.5 py-0.5 rounded text-[11px] font-mono font-medium bg-slate-800 text-emerald-400">
                  {restoringPoint.code}
                </span>{' '}
                из архива и вернуть его в активный список?
              </p>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-md text-xs text-slate-400 space-y-1.5">
                <div className="flex items-start gap-2">
                  <span className="text-emerald-400 font-semibold">•</span>
                  <span>ПВЗ снова появится в основном списке активных пунктов и станет доступен для работы.</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRestoringPoint(null)}
                  disabled={isSubmitting}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-medium transition-all disabled:opacity-50 cursor-pointer border border-slate-700/60"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  onClick={handleConfirmRestore}
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md text-xs font-medium transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin" />
                      <span>Восстановление...</span>
                    </>
                  ) : (
                    <>
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Восстановить ПВЗ</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Confirm Permanent Delete PVZ */}
      {deletingPoint && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400">
                  <Trash2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Окончательное удаление</h3>
                  <p className="text-xs text-slate-400">Полное удаление из базы данных</p>
                </div>
              </div>
              <button
                onClick={() => {
                  if (!isSubmitting) {
                    setDeletingPoint(null);
                    setDeleteError(null);
                  }
                }}
                disabled={isSubmitting}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3.5">
              {deleteError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-md text-xs text-red-400 flex items-center gap-2">
                  <XCircle className="w-4 h-4 shrink-0" />
                  <span>{deleteError}</span>
                </div>
              )}

              <p className="text-xs text-slate-200 leading-relaxed">
                Вы уверены, что хотите окончательно удалить пункт выдачи{' '}
                <span className="font-semibold text-white">«{deletingPoint.name}»</span>{' '}
                <span className="px-1.5 py-0.5 rounded text-[11px] font-mono font-medium bg-slate-800 text-emerald-400">
                  {deletingPoint.code}
                </span>
                ?
              </p>

              <div className="p-3 bg-red-950/20 border border-red-500/20 rounded-md text-xs text-red-300 space-y-1.5">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>Локация будет полностью удалена из настроек сети. Если вы хотите временно скрыть пункт — используйте кнопку <strong>«В архив»</strong>.</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setDeletingPoint(null);
                    setDeleteError(null);
                  }}
                  disabled={isSubmitting}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md text-xs font-medium transition-all disabled:opacity-50 cursor-pointer border border-slate-700/60"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPermanentDelete}
                  disabled={isSubmitting}
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-md text-xs font-medium transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Удаление...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Удалить навсегда</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Delete Warning for Single Remaining PVZ */}
      {deleteWarning && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Невозможно выполнить действие</h3>
                  <p className="text-xs text-slate-400">Ограничение структуры сети</p>
                </div>
              </div>
              <button
                onClick={() => setDeleteWarning(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3.5">
              <p className="text-xs text-slate-300 leading-relaxed">
                {deleteWarning}
              </p>
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setDeleteWarning(null)}
                  className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md text-xs font-medium transition-all cursor-pointer"
                >
                  Понятно
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

