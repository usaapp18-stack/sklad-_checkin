import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { getCurrentAndPreviousMonth, formatMonthName, getAllAvailableMonths } from '../../utils/time';
import { CustomPeriodSelect } from '../common/CustomPeriodSelect';
import { CustomSelect } from '../common/CustomSelect';
import { aggregateMonthlyStats, formatCurrency, normalizeShiftType, getBaseShiftPay, calculateShiftTotalSalary, getShiftLabel } from '../../utils/calculations';
import { Calendar, TrendingUp, DollarSign, Download, BarChart2, Wallet, Coins, Sliders, Settings, Lock, Unlock, Edit3, Save, X, Plus, Trash2, Archive, UserCheck, ChevronDown, AlertTriangle } from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { records, staffList, rates, saveRates, pickupPoints } = useApp();
  const { current, previous } = getCurrentAndPreviousMonth();
  const allAvailableMonths = getAllAvailableMonths(records, 12);
  const [selectedMonth, setSelectedMonth] = useState<string>(current);
  const [showRatesConfig, setShowRatesConfig] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formRates, setFormRates] = useState(rates);
  const [localShiftTypes, setLocalShiftTypes] = useState<any[]>([]);
  const [localPartTimeShiftTypes, setLocalPartTimeShiftTypes] = useState<any[]>([]);
  const [localBonuses, setLocalBonuses] = useState<any[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState('');

  // Default initial shift types for backwards compatibility
  const getDefaultShiftTypes = () => [
    { code: 'standard', name: 'Обычная смена', baseRate: rates.standard || 2000, isArchived: false },
    { code: '400+', name: 'Смена 400+', baseRate: rates['400+'] || 2200, isArchived: false },
    { code: '500+', name: 'Смена 500+', baseRate: rates['500+'] || 2500, isArchived: false },
    { code: '8h', name: 'Смена 8 часов', baseRate: rates['8h'] || 1500, isArchived: false },
    { code: '4h', name: 'Смена 4 часа', baseRate: rates['4h'] || 800, isArchived: false },
  ];

  // Default initial part-time shift types
  const getDefaultPartTimeShiftTypes = () => [
    { code: '4h', name: 'Смена 4 часа', baseRate: rates['4h'] || 800, isArchived: false },
    { code: 'pt_standard', name: 'Смена подработчика (полная)', baseRate: rates.partTimeShiftRate || 1800, isArchived: false },
  ];

  // Default initial bonuses/adjustments without hardcoded demo locations
  const getDefaultBonuses = () => [
    { code: 'seniorBonus', name: 'Доплата Старшему (Ст.С.)', value: rates.seniorBonus || 200, isArchived: false, target: 'senior' },
    { code: 'partTimeBonus', name: 'Доплата Подработчику', value: rates.partTimeBonus || 0, isArchived: false, target: 'part_time' },
  ];

  // Sync formRates when rates state updates
  useEffect(() => {
    setFormRates(rates);
    const initialTypes = rates.shiftTypes && rates.shiftTypes.length > 0
      ? rates.shiftTypes
      : getDefaultShiftTypes();
    setLocalShiftTypes(initialTypes);

    const initialPartTimeTypes = rates.partTimeShiftTypes && rates.partTimeShiftTypes.length > 0
      ? rates.partTimeShiftTypes
      : getDefaultPartTimeShiftTypes();
    setLocalPartTimeShiftTypes(initialPartTimeTypes);

    const initialBonuses = rates.bonuses && rates.bonuses.length > 0
      ? rates.bonuses
      : getDefaultBonuses();
    setLocalBonuses(initialBonuses);
  }, [rates]);

  const handleEditToggle = () => {
    setFormRates(rates);
    const initialTypes = rates.shiftTypes && rates.shiftTypes.length > 0
      ? rates.shiftTypes
      : getDefaultShiftTypes();
    setLocalShiftTypes(initialTypes);

    const initialPartTimeTypes = rates.partTimeShiftTypes && rates.partTimeShiftTypes.length > 0
      ? rates.partTimeShiftTypes
      : getDefaultPartTimeShiftTypes();
    setLocalPartTimeShiftTypes(initialPartTimeTypes);

    const initialBonuses = rates.bonuses && rates.bonuses.length > 0
      ? rates.bonuses
      : getDefaultBonuses();
    setLocalBonuses(initialBonuses);
    setIsEditing(true);
    setSaveError('');
  };

  const handleCancel = () => {
    setFormRates(rates);
    const initialTypes = rates.shiftTypes && rates.shiftTypes.length > 0
      ? rates.shiftTypes
      : getDefaultShiftTypes();
    setLocalShiftTypes(initialTypes);

    const initialPartTimeTypes = rates.partTimeShiftTypes && rates.partTimeShiftTypes.length > 0
      ? rates.partTimeShiftTypes
      : getDefaultPartTimeShiftTypes();
    setLocalPartTimeShiftTypes(initialPartTimeTypes);

    const initialBonuses = rates.bonuses && rates.bonuses.length > 0
      ? rates.bonuses
      : getDefaultBonuses();
    setLocalBonuses(initialBonuses);
    setIsEditing(false);
    setSaveError('');
  };

  const handleApply = async () => {
    setIsSaving(true);
    setSaveError('');

    // Validation
    const emptyName = localShiftTypes.some(t => !t.isArchived && !t.name.trim());
    if (emptyName) {
      setSaveError('Название смены не может быть пустым');
      setIsSaving(false);
      return;
    }

    const emptyPtName = localPartTimeShiftTypes.some(t => !t.isArchived && !t.name.trim());
    if (emptyPtName) {
      setSaveError('Название смены подработчика не может быть пустым');
      setIsSaving(false);
      return;
    }

    const emptyBonusName = localBonuses.some(b => !b.isArchived && !b.name.trim());
    if (emptyBonusName) {
      setSaveError('Название корректировки не может быть пустым');
      setIsSaving(false);
      return;
    }

    const cleanedRates: any = {};
    Object.entries(formRates).forEach(([k, v]) => {
      if (k !== 'shiftTypes' && k !== 'partTimeShiftTypes' && k !== 'bonuses') {
        cleanedRates[k] = Number(v) || 0;
      }
    });

    // Populate top-level rates for compatibility
    localShiftTypes.forEach(t => {
      cleanedRates[t.code] = Number(t.baseRate) || 0;
    });

    // Populate part-time shift rates
    localPartTimeShiftTypes.forEach(t => {
      cleanedRates[t.code] = Number(t.baseRate) || 0;
    });
    const ptStd = localPartTimeShiftTypes.find(t => !t.isArchived && (t.code === 'pt_standard' || t.name.toLowerCase().includes('полн')));
    if (ptStd) cleanedRates.partTimeShiftRate = Number(ptStd.baseRate) || 0;
    const pt4h = localPartTimeShiftTypes.find(t => !t.isArchived && t.code === '4h');
    if (pt4h) cleanedRates['4h'] = Number(pt4h.baseRate) || 0;

    // Populate top-level bonuses for compatibility
    localBonuses.forEach(b => {
      if (['seniorBonus', 'partTimeBonus'].includes(b.code)) {
        cleanedRates[b.code] = Number(b.value) || 0;
      }
    });

    cleanedRates.shiftTypes = localShiftTypes;
    cleanedRates.partTimeShiftTypes = localPartTimeShiftTypes;
    cleanedRates.bonuses = localBonuses;

    const res = await saveRates(cleanedRates);
    setIsSaving(false);
    if (res.success) {
      setIsEditing(false);
    } else {
      setSaveError(res.error || 'Ошибка при сохранении ставок');
    }
  };

  const resetRates = async () => {
    const DEFAULT_RATES = {
      standard: 2000,
      '400+': 2200,
      '500+': 2500,
      '8h': 1500,
      '4h': 800,
      partTimeShiftRate: 1800,
      seniorBonus: 200,
      partTimeBonus: 0,
      shiftTypes: [
        { code: 'standard', name: 'Обычная смена', baseRate: 2000, isArchived: false },
        { code: '400+', name: 'Смена 400+', baseRate: 2200, isArchived: false },
        { code: '500+', name: 'Смена 500+', baseRate: 2500, isArchived: false },
        { code: '8h', name: 'Смена 8 часов', baseRate: 1500, isArchived: false },
        { code: '4h', name: 'Смена 4 часа', baseRate: 800, isArchived: false },
      ],
      partTimeShiftTypes: [
        { code: '4h', name: 'Смена 4 часа', baseRate: 800, isArchived: false },
        { code: 'pt_standard', name: 'Смена подработчика (полная)', baseRate: 1800, isArchived: false },
      ],
      bonuses: [
        { code: 'seniorBonus', name: 'Доплата Старшему (Ст.С.)', value: 200, isArchived: false, target: 'senior' },
        { code: 'partTimeBonus', name: 'Доплата Подработчику', value: 0, isArchived: false, target: 'part_time' },
      ]
    };
    setIsSaving(true);
    setSaveError('');
    const res = await saveRates(DEFAULT_RATES);
    setIsSaving(false);
    if (res.success) {
      setIsEditing(false);
    } else {
      setSaveError(res.error || 'Ошибка при сбросе ставок');
    }
  };

  const updateFormField = (key: string, val: any) => {
    setFormRates({ ...formRates, [key]: val });
  };

  const handleUpdateShiftType = (index: number, field: string, val: any) => {
    setLocalShiftTypes(prev => prev.map((t, idx) => idx === index ? { ...t, [field]: val } : t));
  };

  const handleArchiveShiftType = (index: number) => {
    setLocalShiftTypes(prev => prev.map((t, idx) => idx === index ? { ...t, isArchived: true } : t));
  };

  const handleRestoreShiftType = (index: number) => {
    setLocalShiftTypes(prev => prev.map((t, idx) => idx === index ? { ...t, isArchived: false } : t));
  };

  const handleAddShiftType = () => {
    const code = `shift_${Date.now()}`;
    setLocalShiftTypes(prev => [
      ...prev,
      { code, name: 'Смена...', baseRate: 1500, isArchived: false }
    ]);
  };

  const handleUpdatePartTimeShiftType = (index: number, field: string, val: any) => {
    setLocalPartTimeShiftTypes(prev => prev.map((t, idx) => idx === index ? { ...t, [field]: val } : t));
  };

  const handleArchivePartTimeShiftType = (index: number) => {
    setLocalPartTimeShiftTypes(prev => prev.map((t, idx) => idx === index ? { ...t, isArchived: true } : t));
  };

  const handleRestorePartTimeShiftType = (index: number) => {
    setLocalPartTimeShiftTypes(prev => prev.map((t, idx) => idx === index ? { ...t, isArchived: false } : t));
  };

  const handleAddPartTimeShiftType = () => {
    const code = `pt_shift_${Date.now()}`;
    setLocalPartTimeShiftTypes(prev => [
      ...prev,
      { code, name: 'Смена подработчика...', baseRate: 1000, isArchived: false }
    ]);
  };

  const handleUpdateBonus = (index: number, field: string, val: any) => {
    setLocalBonuses(prev => prev.map((b, idx) => idx === index ? { ...b, [field]: val } : b));
  };

  const handleArchiveBonus = (index: number) => {
    setLocalBonuses(prev => prev.map((b, idx) => idx === index ? { ...b, isArchived: true } : b));
  };

  const handleRestoreBonus = (index: number) => {
    setLocalBonuses(prev => prev.map((b, idx) => idx === index ? { ...b, isArchived: false } : b));
  };

  const handleAddBonus = () => {
    const code = `bonus_${Date.now()}`;
    setLocalBonuses(prev => [
      ...prev,
      { code, name: 'Новая доплата', value: 100, isArchived: false, target: 'always' }
    ]);
  };

  const statsMap = aggregateMonthlyStats(records, selectedMonth, undefined);

  // Enrichment of stats with calculations based on current rates
  const enrichedStats = Array.from(statsMap.values()).map(stat => {
    const staff = staffList.find(s => s.id === stat.employeeId);
    
    // Calculate salary for each shift record
    let totalShiftSalary = 0;
    stat.records.forEach(rec => {
      if (rec.shiftType) {
        totalShiftSalary += calculateShiftTotalSalary(rec, staff, rates);
      }
    });

    const totalBonus = stat.sales.totalBonus;
    const totalEarnings = totalShiftSalary + totalBonus;

    return {
      ...stat,
      totalShiftSalary,
      totalEarnings,
    };
  });

  const selectedMonthRecords = useMemo(
    () => records.filter(r => r.date && r.date.startsWith(selectedMonth)),
    [records, selectedMonth]
  );

  // Set of all shift codes that were actually checked into during selectedMonth (from deduplicated records in enrichedStats)
  const workedShiftCodes = useMemo(() => {
    const codesMap = new Map<string, number>();
    enrichedStats.forEach(stat => {
      (stat.records || []).forEach((rec: any) => {
        if (rec.shiftType) {
          codesMap.set(rec.shiftType, (codesMap.get(rec.shiftType) || 0) + 1);
        }
      });
    });
    return Array.from(codesMap.keys());
  }, [enrichedStats]);

  // Overall totals calculation
  let grandTotalShifts = 0;
  let grandCash = 0;
  let grandCard = 0;
  let grandRevenue = 0;
  let grandBonus = 0;
  let grandShiftSalary = 0;
  let grandTotalEarnings = 0;

  for (const stat of enrichedStats) {
    grandTotalShifts += stat.shiftsCount.total;
    grandCash += stat.sales.totalCash;
    grandCard += stat.sales.totalCard;
    grandRevenue += stat.sales.totalRevenue;
    grandBonus += stat.sales.totalBonus;
    grandShiftSalary += stat.totalShiftSalary;
    grandTotalEarnings += stat.totalEarnings;
  }

  return (
    <div className="space-y-6">
      
      {/* Month Switcher Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-md border border-slate-800">
            <button
              onClick={() => setSelectedMonth(current)}
              className={`py-1.5 px-3.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                selectedMonth === current
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {formatMonthName(current)} (Текущий)
            </button>
            <button
              onClick={() => setSelectedMonth(previous)}
              className={`py-1.5 px-3.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                selectedMonth === previous
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {formatMonthName(previous)} (Прошлый)
            </button>
          </div>

          <CustomPeriodSelect
            value={selectedMonth}
            onChange={setSelectedMonth}
            options={allAvailableMonths}
            labelPrefix="Период:"
            align="left"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowRatesConfig(!showRatesConfig)}
            className={`flex items-center gap-1.5 px-3 py-1.5 cursor-pointer rounded-md text-xs font-medium border transition-colors ${
              showRatesConfig
                ? 'bg-slate-800 text-emerald-400 border-slate-700'
                : 'bg-slate-900 hover:bg-slate-850 text-slate-300 border-slate-800'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Настройка смен и тарифных ставок</span>
          </button>
        </div>
      </div>

      {/* Collapsible Tariff Config Panel */}
      {showRatesConfig && (
        <div className="p-4 sm:p-5 bg-slate-900 border border-slate-800 rounded-lg space-y-4 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-medium uppercase tracking-wider text-white">Параметры окладов за смену</h4>
              
              {/* Protection status badge */}
              {isEditing ? (
                <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-400 font-medium">
                  <Unlock className="w-3 h-3" />
                  Редактирование активно
                </span>
              ) : (
                <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-slate-400 font-medium">
                  <Lock className="w-3 h-3 text-slate-500" />
                  Защищено от правок
                </span>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2">
              {isEditing ? (
                <>
                  <button
                    onClick={handleApply}
                    disabled={isSaving}
                    className="flex items-center gap-1 px-3 py-1.5 cursor-pointer bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-medium rounded-md transition-colors disabled:opacity-50"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Применить</span>
                  </button>
                  <button
                    onClick={handleCancel}
                    disabled={isSaving}
                    className="flex items-center gap-1 px-3 py-1.5 cursor-pointer bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium rounded-md transition-colors disabled:opacity-50"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Отмена</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={handleEditToggle}
                    className="flex items-center gap-1 px-3 py-1.5 cursor-pointer bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-medium rounded-md transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Редактировать</span>
                  </button>
                  <button
                    onClick={resetRates}
                    disabled={isSaving}
                    className="text-xs text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
                  >
                    Сбросить к заводским
                  </button>
                </>
              )}
            </div>
          </div>

          {saveError && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-md text-xs text-rose-300 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{saveError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            
            {/* Block 1: Base shift rates */}
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-md space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <div>
                    <h5 className="text-xs font-medium text-slate-200 uppercase tracking-wider">Базовые оклады (₽)</h5>
                    <div className="text-[11px] text-slate-500">Для штатных сотрудников</div>
                  </div>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={handleAddShiftType}
                      className="flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-slate-200 bg-slate-850 border border-slate-700 rounded-md hover:bg-slate-800 cursor-pointer transition-colors"
                    >
                      <Plus className="w-3 h-3 text-sky-400" />
                      <span>Смена</span>
                    </button>
                  )}
                </div>
                
                <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
                  {localShiftTypes.filter(t => !t.isArchived).map((t) => {
                    const actualIndex = localShiftTypes.findIndex(x => x.code === t.code);
                    return (
                      <div key={t.code} className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded-md flex items-center justify-between gap-2 shadow-xs transition-colors">
                        <div className="flex-1 min-w-0">
                          {isEditing ? (
                            <input
                              type="text"
                              required
                              placeholder="Название смены..."
                              value={t.name}
                              onChange={e => handleUpdateShiftType(actualIndex, 'name', e.target.value)}
                              className="w-full px-2 py-0.5 text-xs bg-slate-950 border border-slate-800 focus:border-slate-700 rounded-md text-slate-100 font-medium outline-none"
                            />
                          ) : (
                            <span className="text-xs font-medium text-slate-200 truncate block">{t.name}</span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-md overflow-hidden focus-within:border-slate-700">
                            <input
                              type="text"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              placeholder="0"
                              value={t.baseRate ?? ''}
                              disabled={!isEditing}
                              onFocus={e => e.target.select()}
                              onClick={e => (e.target as HTMLInputElement).select()}
                              onChange={e => handleUpdateShiftType(actualIndex, 'baseRate', e.target.value === '' ? '' : Number(e.target.value.replace(/\D/g, '')))}
                              className="w-14 px-1.5 py-0.5 text-xs text-right bg-transparent text-emerald-400 font-mono outline-none disabled:opacity-75 font-medium"
                            />
                            <span className="text-[11px] text-slate-500 pr-1.5 font-medium">₽</span>
                          </div>

                          {isEditing && (
                            <button
                              type="button"
                              onClick={() => handleArchiveShiftType(actualIndex)}
                              className="p-1 text-slate-500 hover:text-rose-400 rounded-md transition-colors cursor-pointer"
                              title="Архивировать смену"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Collapsible list of archived shift types */}
              {localShiftTypes.some(t => t.isArchived) && (
                <div className="space-y-1 pt-2 border-t border-slate-800">
                  <div className="text-[11px] text-slate-500 uppercase tracking-wider font-medium">Архивные типы смен</div>
                  <div className="space-y-1 max-h-20 overflow-y-auto">
                    {localShiftTypes.filter(t => t.isArchived).map((t) => {
                      const actualIndex = localShiftTypes.findIndex(x => x.code === t.code);
                      return (
                        <div key={t.code} className="px-2 py-1 bg-slate-900 border border-slate-850 rounded-md flex items-center justify-between text-xs text-slate-400">
                          <span className="line-through truncate mr-1">{t.name} ({t.baseRate} ₽)</span>
                          {isEditing && (
                            <button
                              type="button"
                              onClick={() => handleRestoreShiftType(actualIndex)}
                              className="text-xs text-sky-400 hover:text-sky-300 hover:underline cursor-pointer shrink-0"
                            >
                              Восстановить
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Block 2: Part-timer shift rates */}
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-md space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <div>
                    <h5 className="text-xs font-medium text-amber-400 uppercase tracking-wider">Смены Подработчика (₽)</h5>
                    <div className="text-[11px] text-slate-500">Доступны только подработчикам</div>
                  </div>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={handleAddPartTimeShiftType}
                      className="flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-slate-200 bg-slate-850 border border-slate-700 rounded-md hover:bg-slate-800 cursor-pointer transition-colors"
                    >
                      <Plus className="w-3 h-3 text-amber-400" />
                      <span>Смена</span>
                    </button>
                  )}
                </div>
                
                <div className="space-y-1.5 max-h-[300px] overflow-y-auto pr-1">
                  {localPartTimeShiftTypes.filter(t => !t.isArchived).map((t) => {
                    const actualIndex = localPartTimeShiftTypes.findIndex(x => x.code === t.code);
                    return (
                      <div key={t.code} className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded-md flex items-center justify-between gap-2 shadow-xs transition-colors">
                        <div className="flex-1 min-w-0">
                          {isEditing ? (
                            <input
                              type="text"
                              required
                              placeholder="Смена подработчика..."
                              value={t.name}
                              onChange={e => handleUpdatePartTimeShiftType(actualIndex, 'name', e.target.value)}
                              className="w-full px-2 py-0.5 text-xs bg-slate-950 border border-slate-800 focus:border-slate-700 rounded-md text-slate-100 font-medium outline-none"
                            />
                          ) : (
                            <span className="text-xs font-medium text-slate-200 truncate block">{t.name}</span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-md overflow-hidden focus-within:border-slate-700">
                            <input
                              type="text"
                              inputMode="numeric"
                              pattern="[0-9]*"
                              placeholder="0"
                              value={t.baseRate ?? ''}
                              disabled={!isEditing}
                              onFocus={e => e.target.select()}
                              onClick={e => (e.target as HTMLInputElement).select()}
                              onChange={e => handleUpdatePartTimeShiftType(actualIndex, 'baseRate', e.target.value === '' ? '' : Number(e.target.value.replace(/\D/g, '')))}
                              className="w-14 px-1.5 py-0.5 text-xs text-right bg-transparent text-amber-300 font-mono outline-none disabled:opacity-75 font-medium"
                            />
                            <span className="text-[11px] text-slate-500 pr-1.5 font-medium">₽</span>
                          </div>

                          {isEditing && (
                            <button
                              type="button"
                              onClick={() => handleArchivePartTimeShiftType(actualIndex)}
                              className="p-1 text-slate-500 hover:text-rose-400 rounded-md transition-colors cursor-pointer"
                              title="Архивировать смену"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 space-y-1.5">
                <div className="text-[11px] text-slate-400 leading-tight">
                  <em>Подработчики могут отмечать чекин только для этих типов смен (либо взятых с биржи).</em>
                </div>

                {/* Collapsible list of archived part-time shift types */}
                {localPartTimeShiftTypes.some(t => t.isArchived) && (
                  <div className="space-y-1 pt-1">
                    <div className="text-[11px] text-slate-500 uppercase tracking-wider font-medium">Архивные смены подработчика</div>
                    <div className="space-y-1 max-h-20 overflow-y-auto">
                      {localPartTimeShiftTypes.filter(t => t.isArchived).map((t) => {
                        const actualIndex = localPartTimeShiftTypes.findIndex(x => x.code === t.code);
                        return (
                          <div key={t.code} className="px-2 py-1 bg-slate-900 border border-slate-850 rounded-md flex items-center justify-between text-xs text-slate-400">
                            <span className="line-through truncate mr-1">{t.name} ({t.baseRate} ₽)</span>
                            {isEditing && (
                              <button
                                type="button"
                                onClick={() => handleRestorePartTimeShiftType(actualIndex)}
                                className="text-xs text-amber-400 hover:text-amber-300 hover:underline cursor-pointer shrink-0"
                              >
                                Восстановить
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Block 3: Status & Location Modifiers */}
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-md space-y-3 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <div>
                    <h5 className="text-xs font-medium text-slate-200 uppercase tracking-wider">Корректировки и бонусы (₽)</h5>
                    <div className="text-[11px] text-slate-500">Доплаты за статус, ПВЗ и дни</div>
                  </div>
                  {isEditing && (
                    <button
                      type="button"
                      onClick={handleAddBonus}
                      className="flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-slate-200 bg-slate-855 border border-slate-700 rounded-md hover:bg-slate-800 cursor-pointer transition-colors"
                    >
                      <Plus className="w-3 h-3 text-sky-400" />
                      <span>Бонус</span>
                    </button>
                  )}
                </div>
                
                <div className={`space-y-2 pr-1 ${isEditing ? 'overflow-visible' : 'max-h-[300px] overflow-y-auto'}`}>
                  {localBonuses.filter(b => !b.isArchived).map((b) => {
                    const actualIndex = localBonuses.findIndex(x => x.code === b.code);
                    return (
                      <div key={b.code} className="px-2.5 py-2 bg-slate-900 border border-slate-800 rounded-md space-y-2 shadow-xs transition-colors relative">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            {isEditing ? (
                              <input
                                type="text"
                                required
                                placeholder="Название доплаты..."
                                value={b.name}
                                onChange={e => handleUpdateBonus(actualIndex, 'name', e.target.value)}
                                className="w-full px-2 py-0.5 text-xs bg-slate-950 border border-slate-800 focus:border-slate-700 rounded-md text-slate-100 font-medium outline-none"
                              />
                            ) : (
                              <span className="text-xs font-medium text-slate-200 truncate block">{b.name}</span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-md overflow-hidden focus-within:border-slate-700">
                              <input
                                type="text"
                                inputMode="numeric"
                                pattern="[0-9]*"
                                placeholder="0"
                                value={b.value ?? ''}
                                disabled={!isEditing}
                                onFocus={e => e.target.select()}
                                onClick={e => (e.target as HTMLInputElement).select()}
                                onChange={e => handleUpdateBonus(actualIndex, 'value', e.target.value === '' ? '' : Number(e.target.value.replace(/\D/g, '')))}
                                className="w-14 px-1.5 py-0.5 text-xs text-right bg-transparent text-emerald-400 font-mono outline-none disabled:opacity-75 font-medium"
                              />
                              <span className="text-[11px] text-slate-500 pr-1.5 font-medium">₽</span>
                            </div>

                            {isEditing && (
                              <button
                                type="button"
                                onClick={() => handleArchiveBonus(actualIndex)}
                                className="p-1 text-slate-500 hover:text-rose-400 rounded-md transition-colors cursor-pointer"
                                title="Архивировать доплату"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        <div>
                          <label className="block text-slate-400 font-medium mb-1 text-[11px] uppercase tracking-wider">Кому:</label>
                          {isEditing ? (
                            <CustomSelect
                              size="sm"
                              value={b.target || 'always'}
                              onChange={val => handleUpdateBonus(actualIndex, 'target', val)}
                              menuHeaderTitle="Кому начисляется доплата"
                              options={[
                                { value: 'senior', label: 'Старшему (Ст.С.)' },
                                { value: 'part_time', label: 'Подработчику' },
                                ...(pickupPoints || []).map(p => ({
                                  value: `location_${p.code.toLowerCase()}`,
                                  label: `Пункт ${p.code}`
                                })),
                                { value: 'always', label: 'Всем всегда' },
                                { value: 'weekend', label: 'Только в выходные' },
                              ]}
                            />
                          ) : (
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {b.target === 'senior' && (
                                <span className="text-xs px-2 py-0.5 bg-sky-500/10 border border-sky-500/20 rounded-md text-sky-300 font-medium">
                                  Старшему (Ст.С.)
                                </span>
                              )}
                              {b.target === 'part_time' && (
                                <span className="text-xs px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 rounded-md text-amber-300 font-medium">
                                  Подработчику
                                </span>
                              )}
                              {b.target && (b.target.startsWith('location_') || b.target.startsWith('loc_')) && (
                                <span className="text-xs px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded-md text-emerald-300 font-medium font-mono">
                                  Пункт {b.target.replace(/^(location_|loc_)/, '').toUpperCase()}
                                </span>
                              )}
                              {(!b.target || b.target === 'always') && (
                                <span className="text-xs px-2 py-0.5 bg-slate-900 border border-slate-800 rounded-md text-slate-300 font-medium">
                                  Всем всегда
                                </span>
                              )}
                              {b.target === 'weekend' && (
                                <span className="text-xs px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 rounded-md text-amber-300 font-medium">
                                  Только в выходные (Сб/Вс)
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Collapsible list of archived bonuses */}
              {localBonuses.some(b => b.isArchived) && (
                <div className="space-y-1 pt-2 border-t border-slate-800">
                  <div className="text-[11px] text-slate-500 uppercase tracking-wider font-medium">Архивные доплаты</div>
                  <div className="space-y-1 max-h-20 overflow-y-auto">
                    {localBonuses.filter(b => b.isArchived).map((b) => {
                      const actualIndex = localBonuses.findIndex(x => x.code === b.code);
                      return (
                        <div key={b.code} className="px-2 py-1 bg-slate-900 border border-slate-850 rounded-md flex items-center justify-between text-xs text-slate-400">
                          <span className="line-through truncate mr-1">{b.name} ({b.value} ₽)</span>
                          {isEditing && (
                            <button
                              type="button"
                              onClick={() => handleRestoreBonus(actualIndex)}
                              className="text-xs text-sky-400 hover:text-sky-300 hover:underline cursor-pointer shrink-0"
                            >
                              Восстановить
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

          </div>
          
          <div className="text-[11px] text-slate-400 pt-1 leading-relaxed">
            <strong>Защита от правок активна по умолчанию.</strong> Нажмите кнопку «Редактировать», внесите желаемые изменения, а затем зафиксируйте их кнопкой «Применить». Изменения сразу запишутся на сервер в базу данных и пересчитают все оклады.
          </div>
        </div>
      )}

      {/* Aggregate KPI Summary Strip */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 overflow-hidden shadow-sm">
        <div className="p-4 sm:p-4.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-slate-400 mb-1">Всего отработано смен</div>
          <div className="text-xl font-medium text-white font-mono tabular-nums">
            {grandTotalShifts}
          </div>
          <div className="text-xs text-slate-400 mt-1 truncate" title={workedShiftCodes.map((c: string) => `${getShiftLabel(c, rates)}: ${selectedMonthRecords.filter((r: any) => r.shiftType === c).length}`).join(' · ')}>
            {workedShiftCodes.length > 0
              ? workedShiftCodes.map((c: string) => `${getShiftLabel(c, rates)}: ${selectedMonthRecords.filter((r: any) => r.shiftType === c).length}`).join(' · ')
              : 'Нет смен за период'}
          </div>
        </div>

        <div className="p-4 sm:p-4.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-slate-400 mb-1">Общая выручка</div>
          <div className="text-xl font-medium text-sky-400 font-mono tabular-nums">
            {formatCurrency(grandRevenue)}
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Нал: {formatCurrency(grandCash)} · Безнал: {formatCurrency(grandCard)}
          </div>
        </div>

        <div className="p-4 sm:p-4.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-slate-400 mb-1">ФОТ (Оклады смен)</div>
          <div className="text-xl font-medium text-white font-mono tabular-nums">
            {formatCurrency(grandShiftSalary)}
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Премии (5%): +{formatCurrency(grandBonus)}
          </div>
        </div>

        <div className="p-4 sm:p-4.5 flex flex-col justify-between bg-slate-950/40">
          <div className="text-[11px] font-medium text-emerald-400 mb-1">Итого начислено (ФОТ + Премии)</div>
          <div className="text-xl font-medium text-emerald-400 font-mono tabular-nums">
            {formatCurrency(grandTotalEarnings)}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            К выплате за {formatMonthName(selectedMonth)}
          </div>
        </div>
      </div>

      {/* Detailed Monthly Report Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden shadow-sm">
        <div className="p-3.5 sm:p-4 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-medium text-white">
              Отчёт и начисления по сотрудникам за {formatMonthName(selectedMonth)}
            </h3>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs font-medium uppercase tracking-wider text-slate-400 bg-slate-950/70">
                <th className="py-2.5 px-3 font-medium">Сотрудник</th>
                <th className="py-2.5 px-2 font-medium text-center bg-slate-950/80">Смен</th>
                {workedShiftCodes.length > 0 ? (
                  workedShiftCodes.map(code => (
                    <th key={code} className="py-2.5 px-2 font-medium text-center whitespace-nowrap" title={getShiftLabel(code, rates)}>
                      {getShiftLabel(code, rates)}
                    </th>
                  ))
                ) : (
                  <th className="py-2.5 px-2 font-medium text-center text-slate-500">Смены</th>
                )}
                <th className="py-2.5 px-3 font-medium text-right">Выручка</th>
                <th className="py-2.5 px-3 font-medium text-right">Оклады смен</th>
                <th className="py-2.5 px-3 font-medium text-right">Премия (5%)</th>
                <th className="py-2.5 px-3 font-medium text-right">Всего начислено</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {enrichedStats.map(stat => {
                const staff = staffList.find(s => s.id === stat.employeeId);
                return (
                  <tr key={stat.employeeId} className="hover:bg-slate-850/40 transition-colors">
                    <td className="py-2.5 px-3 font-medium text-white">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span>{stat.employeeName}</span>
                        {staff?.isSenior && (
                          <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                            Старший
                          </span>
                        )}
                        {staff?.isPartTime && (
                          <span className="text-xs font-medium text-amber-300 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.5 rounded-md">
                            Подработчик
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono tabular-nums font-medium text-white bg-slate-950/30">
                      {stat.shiftsCount.total}
                    </td>
                    {workedShiftCodes.length > 0 ? (
                      workedShiftCodes.map(code => {
                        const count = (stat.records || []).filter(r => r.shiftType === code).length;
                        return (
                          <td key={code} className="py-2.5 px-2 text-center font-mono tabular-nums text-slate-300 font-medium">
                            {count || 0}
                          </td>
                        );
                      })
                    ) : (
                      <td className="py-2.5 px-2 text-center font-mono text-slate-500">—</td>
                    )}
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-medium text-white">
                      {formatCurrency(stat.sales.totalRevenue)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-white font-medium">
                      {formatCurrency(stat.totalShiftSalary)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-medium text-emerald-400">
                      +{formatCurrency(stat.sales.totalBonus)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums font-medium text-emerald-400 text-sm">
                      {formatCurrency(stat.totalEarnings)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="border-t border-slate-800 bg-slate-950 text-xs font-medium">
                <td className="py-3 px-3 text-white uppercase tracking-wider font-medium">Итого:</td>
                <td className="py-3 px-2 text-center font-mono tabular-nums text-white font-medium bg-slate-950/80">{grandTotalShifts}</td>
                {workedShiftCodes.length > 0 ? (
                  workedShiftCodes.map((code: string) => {
                    const total = enrichedStats.reduce((sum, s) => sum + (s.records || []).filter((r: any) => r.shiftType === code).length, 0);
                    return (
                      <td key={code} className="py-3 px-2 text-center font-mono tabular-nums text-white font-medium">
                        {total}
                      </td>
                    );
                  })
                ) : (
                  <td className="py-3 px-2 text-center font-mono text-slate-500">—</td>
                )}
                <td className="py-3 px-3 text-right font-mono tabular-nums text-white font-medium">{formatCurrency(grandRevenue)}</td>
                <td className="py-3 px-3 text-right font-mono tabular-nums text-white font-medium">{formatCurrency(grandShiftSalary)}</td>
                <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-400 font-medium">+{formatCurrency(grandBonus)}</td>
                <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-400 text-sm font-medium">{formatCurrency(grandTotalEarnings)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

    </div>
  );
};
