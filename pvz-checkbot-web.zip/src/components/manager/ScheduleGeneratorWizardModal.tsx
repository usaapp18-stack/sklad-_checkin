import React, { useState, useMemo, useEffect } from 'react';
import { PickupPoint, StaffMember, PlannedShift, ShiftType, AvailabilityRequest, ShiftSwapRequest } from '../../types';
import { CustomSelect } from '../common/CustomSelect';
import {
  SlidersHorizontal,
  X,
  MapPin,
  AlertTriangle,
  Info,
  CheckCircle2,
  Users,
  Layers,
  Calendar as CalendarIcon,
  ArrowLeft,
  ArrowRight,
  Check,
  Loader2,
  FileDown,
  ArrowLeftRight,
  ChevronDown,
} from 'lucide-react';
import {
  generateSchedulePlan,
  DayInfo,
  ScheduleType,
  Weekend52Mode,
  ReinforcementMode,
  ThreeStaffScenario,
  GeneratorResult,
} from '../../utils/scheduleGenerator';
import { exportScheduleToPdf } from '../../utils/schedulePdfExporter';

function formatShortName(fullName: string): string {
  if (!fullName) return '';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length >= 2) {
    return `${parts[0]} ${parts[1][0]}.`;
  }
  return parts[0];
}

interface ScheduleGeneratorWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  monthStr: string;
  monthName: string;
  daysList: DayInfo[];
  activePvzs: PickupPoint[];
  staffList: StaffMember[];
  availability: AvailabilityRequest[];
  getStaffForPvz: (pvzCode: string) => StaffMember[];
  existingShifts?: PlannedShift[];
  swapRequests?: ShiftSwapRequest[];
  onApplySchedule: (
    shifts: PlannedShift[],
    template?: {
      name: string;
      location: string;
      scenarioType: any;
      mainStaffIds: string[];
      defaultShiftType: ShiftType;
      notes: string;
    }
  ) => Promise<void>;
  loading: boolean;
  initialPvz?: string;
}

export const ScheduleGeneratorWizardModal: React.FC<ScheduleGeneratorWizardModalProps> = ({
  isOpen,
  onClose,
  monthStr,
  monthName,
  daysList,
  activePvzs,
  staffList,
  availability,
  getStaffForPvz,
  existingShifts = [],
  swapRequests = [],
  onApplySchedule,
  loading,
  initialPvz,
}) => {
  // Stepper: 1..6
  const [step, setStep] = useState<number>(1);

  // Step 1: Location
  const [location, setLocation] = useState<string>(() => {
    return initialPvz && initialPvz !== 'ALL' ? initialPvz : (activePvzs[0]?.code || '');
  });

  // Step 2: Schedule Type & Cycle
  const [scheduleType, setScheduleType] = useState<ScheduleType>('2/2');
  const [startCycleDay, setStartCycleDay] = useState<number>(1);
  const [customWorkDays, setCustomWorkDays] = useState<number>(4);
  const [customRestDays, setCustomRestDays] = useState<number>(2);
  const [weekend52Mode, setWeekend52Mode] = useState<Weekend52Mode>('floating');
  const [manualWeekends52, setManualWeekends52] = useState<Record<string, number[]>>({});

  // Step 3: Staff Selection
  const [selectedStaffIds, setSelectedStaffIds] = useState<string[]>(() => {
    const loc = initialPvz && initialPvz !== 'ALL' ? initialPvz : (activePvzs[0]?.code || '');
    return getStaffForPvz(loc).slice(0, 2).map(s => s.id);
  });
  const [hybridConfig, setHybridConfig] = useState<
    Record<string, { type: '2/2' | '3/3' | '5/2' | 'custom'; workDays?: number; restDays?: number }>
  >({});
  const [expandedStaffWishes, setExpandedStaffWishes] = useState<string | null>(null);
  const [expandedStaffOtherShifts, setExpandedStaffOtherShifts] = useState<string | null>(null);

  // Step 4: Coverage & Reinforcement
  const [baseCoverage, setBaseCoverage] = useState<number>(1);
  const [reinforcementMode, setReinforcementMode] = useState<ReinforcementMode>('none');
  const [reinforcementCoverage, setReinforcementCoverage] = useState<number>(2);
  const [reinforcementDaysOfWeek, setReinforcementDaysOfWeek] = useState<number[]>([1, 2, 3, 4, 5]);
  const [threeStaffMode, setThreeStaffMode] = useState<ThreeStaffScenario>('queue');

  // Step 5: Wishes
  const [respectWishes, setRespectWishes] = useState<boolean>(true);
  const [ignoredWishKeys, setIgnoredWishKeys] = useState<string[]>([]);

  // Step 6: Preview & Overrides (Standard shift by default, workers select rate during check-in)
  const shiftType: ShiftType = 'standard';
  const [manualOverrides, setManualOverrides] = useState<Record<string, string[]>>({});
  const [crossConflictAlert, setCrossConflictAlert] = useState<string | null>(null);
  const [previewTab, setPreviewTab] = useState<'calendar' | 'matrix' | 'balance' | 'conflicts'>('calendar');
  const [filterStaffId, setFilterStaffId] = useState<string>('all');
  const [staffDropdownOpen, setStaffDropdownOpen] = useState<boolean>(false);
  const [saveTemplate, setSaveTemplate] = useState<boolean>(false);
  const [templateName, setTemplateName] = useState<string>('');

  // Synchronize when modal is opened for a specific PVZ
  useEffect(() => {
    if (isOpen) {
      const target = initialPvz && initialPvz !== 'ALL' ? initialPvz : (activePvzs[0]?.code || '');
      setLocation(target);
      const eligible = getStaffForPvz(target);
      setSelectedStaffIds(eligible.slice(0, 2).map(s => s.id));
      setStep(1);
      setManualOverrides({});
      setIgnoredWishKeys([]);
    }
  }, [isOpen, initialPvz]);

  // Handle PVZ change
  const handleLocationChange = (newLoc: string) => {
    setLocation(newLoc);
    const eligible = getStaffForPvz(newLoc);
    setSelectedStaffIds(eligible.slice(0, 2).map(s => s.id));
    setManualOverrides({});
  };

  // Toggle ignoring a wish
  const toggleIgnoreWish = (staffId: string, dateStr: string) => {
    const key = `${staffId}_${dateStr}`;
    setIgnoredWishKeys(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  // Manual shift override on calendar click
  const toggleStaffOnDate = (dateStr: string, staffId: string) => {
    const currentAssigned = generatorResult?.dayAnalysis[dateStr]?.assignedStaffIds || [];
    const isCurrentlyAssigned = currentAssigned.includes(staffId);

    // Enforce Rule: If attempting to ADD an employee, check if they already have a shift at another PVZ!
    if (!isCurrentlyAssigned) {
      const busyAtOther = existingShifts.find(
        s => s.employeeId === staffId &&
             s.date === dateStr &&
             s.location !== location &&
             s.location !== activePvzs.find(p => p.code === location)?.name
      );
      if (busyAtOther) {
        const staff = staffList.find(s => s.id === staffId);
        setCrossConflictAlert(
          `Невозможно назначить: сотрудник ${staff?.name || 'Сотрудник'} уже имеет смену в пункте «${busyAtOther.location}» на эту дату. Один сотрудник не может работать в двух ПВЗ одновременно!`
        );
        return;
      }
    }

    const nextAssigned = isCurrentlyAssigned
      ? currentAssigned.filter(id => id !== staffId)
      : [...currentAssigned, staffId];

    setCrossConflictAlert(null);
    setManualOverrides(prev => ({
      ...prev,
      [dateStr]: nextAssigned,
    }));
  };

  // Compute Generated Plan with full priority logic
  const generatorResult: GeneratorResult | null = useMemo(() => {
    if (!isOpen || !location || selectedStaffIds.length === 0) return null;
    return generateSchedulePlan({
      location,
      monthStr,
      daysList,
      scheduleType,
      startCycleDay,
      customWorkDays,
      customRestDays,
      weekend52Mode,
      manualWeekends52,
      selectedStaffIds,
      staffList,
      hybridStaffConfig: hybridConfig,
      baseCoverage,
      reinforcementMode,
      reinforcementCoverage,
      reinforcementDaysOfWeek,
      threeStaffMode,
      respectWishes,
      availabilityList: availability.filter(a => a.status === 'approved'),
      ignoredWishKeys,
      swapRequests,
      shiftType,
      manualOverrides,
      otherExistingShifts: existingShifts,
    });
  }, [
    isOpen,
    location,
    monthStr,
    daysList,
    scheduleType,
    startCycleDay,
    customWorkDays,
    customRestDays,
    weekend52Mode,
    manualWeekends52,
    selectedStaffIds,
    staffList,
    hybridConfig,
    baseCoverage,
    reinforcementMode,
    reinforcementCoverage,
    reinforcementDaysOfWeek,
    threeStaffMode,
    respectWishes,
    availability,
    ignoredWishKeys,
    swapRequests,
    shiftType,
    manualOverrides,
    existingShifts,
  ]);

  if (!isOpen) return null;

  const eligibleStaff = getStaffForPvz(location);

  // All Cross-PVZ conflicts occurring in generated shifts for this PVZ
  const allCrossPvzConflicts = useMemo(() => {
    if (!generatorResult) return [];
    const list: {
      dateStr: string;
      dayNum: number;
      dayName: string;
      employeeId: string;
      employeeName: string;
      otherLocation: string;
    }[] = [];

    daysList.forEach(d => {
      const analysis = generatorResult.dayAnalysis[d.dateStr];
      if (analysis?.crossPvzConflicts && analysis.crossPvzConflicts.length > 0) {
        analysis.crossPvzConflicts.forEach(c => {
          list.push({
            dateStr: d.dateStr,
            dayNum: d.dayNum,
            dayName: d.dayName,
            employeeId: c.employeeId,
            employeeName: c.employeeName,
            otherLocation: c.location,
          });
        });
      }
    });

    return list;
  }, [generatorResult, daysList]);

  const [isApplying, setIsApplying] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  // Download PDF Handler
  const handleDownloadPdf = async () => {
    if (!generatorResult || isExportingPdf) return;
    setIsExportingPdf(true);
    try {
      const scenarioMap: Record<string, string> = {
        '2/2': 'График 2/2',
        '3/3': 'График 3/3',
        '5/2': 'График 5/2',
        'hybrid': 'Гибридный график',
        'custom': `Пользовательский (${customWorkDays}/${customRestDays})`,
      };
      await exportScheduleToPdf({
        location,
        monthStr,
        monthName,
        daysList,
        generatorResult,
        staffList,
        scenarioTitle: templateName.trim() || scenarioMap[scheduleType] || scheduleType,
      });
    } catch (err) {
      console.error('[ScheduleGenerator] PDF export error:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  // Apply Handler
  const handleApply = async () => {
    if (!generatorResult || generatorResult.shifts.length === 0 || isApplying) return;

    let tplConfig: any = undefined;
    if (saveTemplate && templateName.trim()) {
      tplConfig = {
        name: templateName.trim(),
        location,
        scenarioType: scheduleType === 'hybrid' ? 'custom' : scheduleType,
        mainStaffIds: selectedStaffIds,
        defaultShiftType: shiftType,
        notes: `Сценарий ${scheduleType}, покрытие ${baseCoverage}, усиление ${reinforcementMode}`,
      };
    }

    setIsApplying(true);
    try {
      await onApplySchedule(generatorResult.shifts, tplConfig);
      onClose();
    } catch (err) {
      console.error('[ScheduleGenerator] Apply error:', err);
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 animate-fade-in overflow-hidden">
      <div className="bg-slate-900 border-t sm:border border-slate-800 rounded-t-2xl sm:rounded-2xl w-full max-w-5xl max-h-[96dvh] sm:max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        
        {/* Mobile Drag Handle */}
        <div className="sm:hidden pt-2.5 pb-1 flex justify-center shrink-0">
          <div className="w-10 h-1 bg-slate-700/80 rounded-full" />
        </div>

        {/* Modal Header */}
        <div className="flex items-center justify-between p-3.5 sm:p-4 border-b border-slate-800 shrink-0 bg-slate-900">
          <div>
            <div className="text-sm sm:text-base font-semibold text-white flex items-center gap-2">
              <span>Мастер верстки графика смен</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-800 text-emerald-400 border border-slate-700">
                {monthName}
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              Построение графика, учёт пожеланий и ручная корректировка
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper Bar (6 Steps) */}
        <div className="px-3 sm:px-5 py-2.5 bg-slate-950/70 border-b border-slate-800 shrink-0 overflow-x-auto">
          <div className="flex items-center justify-between gap-1 min-w-[580px]">
            {[
              { num: 1, label: 'ПВЗ' },
              { num: 2, label: 'Тип графика' },
              { num: 3, label: 'Сотрудники' },
              { num: 4, label: 'Покрытие' },
              { num: 5, label: 'Пожелания' },
              { num: 6, label: 'Результат и правка' },
            ].map(st => {
              const isActive = step === st.num;
              const isDone = step > st.num;
              return (
                <button
                  key={st.num}
                  type="button"
                  onClick={() => setStep(st.num)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 font-semibold shadow-sm'
                      : isDone
                      ? 'bg-slate-850/80 border border-slate-750 text-slate-300 hover:bg-slate-800'
                      : 'text-slate-500 hover:text-slate-400'
                  }`}
                >
                  <span
                    className={`step-circle w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                      isActive
                        ? 'bg-emerald-500 text-white'
                        : isDone
                        ? 'bg-emerald-500/30 text-emerald-300'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {isDone ? '✓' : st.num}
                  </span>
                  <span>{st.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Mobile Step Status Header */}
        <div className="sm:hidden px-3.5 py-1.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-[11px] text-slate-300 shrink-0">
          <span className="font-semibold text-white">
            Шаг {step} из 6: {
              step === 1 ? 'Пункт выдачи (ПВЗ)' :
              step === 2 ? 'Тип графика' :
              step === 3 ? 'Выбор сотрудников' :
              step === 4 ? 'Настройка покрытия' :
              step === 5 ? 'Учёт пожеланий' : 'Результат и правка'
            }
          </span>
          <span className="text-[ text-emerald-400 font-mono px]$2font-medium">
            {Math.round((step / 6) * 100)}%
          </span>
        </div>

        {/* Modal Body */}
        <div className="p-3 sm:p-6 space-y-4 text-xs flex-1 overflow-y-auto">
          
          {/* STEP 1: Выбор ПВЗ */}
          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <h3 className="text-sm sm:text-base font-semibold text-white mb-1">Шаг 1. Выберите Пункт выдачи (ПВЗ)</h3>
                <p className="text-slate-400 text-xs">
                  Базовый принцип: ПВЗ работают без выходных. От выбора пункта зависит список доступных сотрудников на следующих шагах.
                </p>
              </div>

              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-2xl space-y-3">
                <label className="block text-slate-300 font-semibold text-xs">Пункт выдачи заказов:</label>
                <CustomSelect
                  value={location}
                  onChange={handleLocationChange}
                  menuHeaderTitle="Выберите ПВЗ"
                  options={activePvzs.map(p => ({
                    value: p.code,
                    label: p.name || p.code,
                    sublabel: `Адрес: ${p.address || '—'} · Прикреплено: ${getStaffForPvz(p.code).length} сотр.`,
                  }))}
                />

                {location && (
                  <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-xl flex items-center justify-between text-xs mt-3">
                    <div className="flex items-center gap-2.5">
                      <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="font-semibold text-white">
                          {activePvzs.find(p => p.code === location)?.name || location}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {activePvzs.find(p => p.code === location)?.address || 'Адрес не указан'}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-emerald-400 font-mono font-semibold">
                        {eligibleStaff.length}
                      </span>
                      <span className="text-slate-400 text-[11px] ml-1">доступных сотр.</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 2: Выбор типа графика */}
          {step === 2 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <h3 className="text-sm sm:text-base font-semibold text-white mb-1">Шаг 2. Выберите тип графика</h3>
                <p className="text-slate-400 text-xs">
                  Задайте шаблон рабочей сменности и дату начала цикла.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                {[
                  { id: '2/2', title: 'Схема 2 / 2', desc: 'Основная ротация 2 раб. через 2 вых.' },
                  { id: '3/3', title: 'Схема 3 / 3', desc: '3 дня раб. через 3 вых.' },
                  { id: '5/2', title: 'Схема 5 / 2', desc: 'Пятидневная неделя с выходными' },
                  { id: 'hybrid', title: 'Гибридный', desc: 'Разные сотрудники по своим графикам' },
                  { id: 'custom', title: 'Кастомный', desc: 'Своя длина рабочего/выходного цикла' },
                ].map(sc => (
                  <button
                    key={sc.id}
                    type="button"
                    onClick={() => setScheduleType(sc.id as ScheduleType)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      scheduleType === sc.id
                        ? 'bg-emerald-500/15 border-emerald-500 text-white font-semibold ring-1 ring-emerald-500/50 shadow-md'
                        : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-750'
                    }`}
                  >
                    <div className="text-xs text-emerald-400 font-mono font-semibold mb-1">{sc.title}</div>
                    <div className="text-[11px] text-slate-400 leading-tight font-normal">{sc.desc}</div>
                  </button>
                ))}
              </div>

              {/* Cycle Start Day & Custom Options */}
              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1.5">
                      Дата начала цикла в этом месяце:
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        max={daysList.length}
                        value={startCycleDay}
                        onChange={e => setStartCycleDay(Math.max(1, Math.min(daysList.length, parseInt(e.target.value) || 1)))}
                        className="w-24 px-3 py-2 bg-slate-900 border border-slate-750 rounded-xl text-white font-mono text-center focus:ring-1 focus:ring-emerald-500"
                      />
                      <span className="text-xs text-slate-400">
                        -е число месяца (влияет на чередование смен)
                      </span>
                    </div>
                  </div>

                  {scheduleType === 'custom' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-slate-300 font-semibold mb-1.5">Рабочих дней:</label>
                        <input
                          type="number"
                          min="1"
                          max="14"
                          value={customWorkDays}
                          onChange={e => setCustomWorkDays(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-750 rounded-xl text-white font-mono text-center"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 font-semibold mb-1.5">Выходных дней:</label>
                        <input
                          type="number"
                          min="1"
                          max="14"
                          value={customRestDays}
                          onChange={e => setCustomRestDays(Math.max(1, parseInt(e.target.value) || 1))}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-750 rounded-xl text-white font-mono text-center"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* 5/2 Weekend Strategy */}
                {scheduleType === '5/2' && (
                  <div className="pt-3 border-t border-slate-800/80 space-y-2">
                    <label className="block text-slate-300 font-semibold">Тип выходных для графика 5/2:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'floating', title: 'Плавающие выходные', desc: 'Система сама балансирует дни, чтобы покрытие ПВЗ не страдало' },
                        { id: 'fixed', title: 'Фиксированные (Сб+Вс)', desc: 'Классические выходные в субботу и воскресенье' },
                        { id: 'manual', title: 'Ручной выбор', desc: 'Персональная настройка дней отдыха сотрудникам' },
                      ].map(opt => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setWeekend52Mode(opt.id as Weekend52Mode)}
                          className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                            weekend52Mode === opt.id
                              ? 'bg-emerald-500/15 border-emerald-500 text-white font-semibold'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                          }`}
                        >
                          <div className="text-xs text-emerald-400 mb-0.5">{opt.title}</div>
                          <div className="text-[10px] text-slate-400">{opt.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 3: Выбор сотрудников */}
          {step === 3 && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm sm:text-base font-semibold text-white mb-1">
                    Шаг 3. Выбор сотрудников для {location}
                  </h3>
                  <p className="text-slate-400 text-xs">
                    Фильтрация: показаны сотрудники с доступом к данному ПВЗ. Рядом отображаются заявленные пожелания.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedStaffIds(eligibleStaff.map(s => s.id))}
                    className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-lg cursor-pointer"
                  >
                    Выбрать всех
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedStaffIds([])}
                    className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-750 text-slate-400 rounded-lg cursor-pointer"
                  >
                    Снять выбор
                  </button>
                </div>
              </div>

              {/* Staff List */}
              <div className="space-y-2">
                {eligibleStaff.length === 0 ? (
                  <div className="p-6 text-center text-slate-500 bg-slate-950/60 border border-slate-800 rounded-2xl">
                    К данному ПВЗ не прикреплено ни одного сотрудника в разделе «Сотрудники».
                  </div>
                ) : (
                  eligibleStaff.map(s => {
                    const isSelected = selectedStaffIds.includes(s.id);
                    
                    // Only display wishes that the manager has APPROVED
                    const staffMonthWishes = availability.filter(
                      a => a.employeeId === s.id && a.date.startsWith(monthStr) && a.type !== 'preferred' && a.status === 'approved'
                    );
                    const staffPendingWishes = availability.filter(
                      a => a.employeeId === s.id && a.date.startsWith(monthStr) && a.type !== 'preferred' && (!a.status || a.status === 'pending')
                    );
                    const hasWishes = staffMonthWishes.length > 0;

                    // Shifts already scheduled for this employee at OTHER PVZs in this month
                    const staffOtherPvzShifts = (existingShifts || []).filter(
                      shift => shift.employeeId === s.id && shift.date.startsWith(monthStr) && shift.location !== location
                    );
                    const hasOtherPvzShifts = staffOtherPvzShifts.length > 0;

                    return (
                      <div
                        key={s.id}
                        className={`p-3 rounded-xl border transition-all ${
                          isSelected
                            ? 'bg-slate-900 border-emerald-500/40 shadow-sm'
                            : 'bg-slate-950/60 border-slate-850 opacity-80'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                          <label className="flex items-center gap-3 cursor-pointer flex-1 select-none">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {
                                if (isSelected) {
                                  setSelectedStaffIds(prev => prev.filter(id => id !== s.id));
                                } else {
                                  setSelectedStaffIds(prev => [...prev, s.id]);
                                }
                              }}
                              className="w-4 h-4 rounded bg-slate-950 border-slate-700 text-emerald-500 focus:ring-emerald-500/30 cursor-pointer"
                            />
                            <div>
                              <div className="font-semibold text-white flex items-center gap-2 flex-wrap">
                                <span>{s.name}</span>
                                {s.isSenior && (
                                  <span className="text-[ px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 px]$2font-medium">
                                    Старший
                                  </span>
                                )}
                                {s.isPartTime && (
                                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300">
                                    Подработка
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-400 font-mono">
                                {s.login}
                              </div>
                            </div>
                          </label>

                          {/* Indicators: Other PVZs & Approved Wishes */}
                          <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
                            {/* Other PVZ indicator */}
                            {hasOtherPvzShifts && (
                              <button
                                type="button"
                                onClick={() => setExpandedStaffOtherShifts(expandedStaffOtherShifts === s.id ? null : s.id)}
                                className="px-2.5 py-1 rounded-lg bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-[11px] font-semibold flex items-center gap-1.5 cursor-pointer hover:bg-indigo-500/25 transition-colors"
                                title="Сотрудник уже задействован в других ПВЗ в этом месяце"
                              >
                                <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                                <span>{staffOtherPvzShifts.length} смен в др. ПВЗ</span>
                              </button>
                            )}

                            {hasWishes ? (
                              <button
                                type="button"
                                onClick={() => setExpandedStaffWishes(expandedStaffWishes === s.id ? null : s.id)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-[11px] font-semibold flex items-center gap-1.5 cursor-pointer hover:bg-emerald-500/25 transition-colors"
                                title="Посмотреть одобренные даты (только они исключаются из графика)"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                                <span>{staffMonthWishes.length} дн. одобрено</span>
                              </button>
                            ) : (
                              !hasOtherPvzShifts && (
                                <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-400 text-[10px]">
                                  Без ограничений
                                </span>
                              )
                            )}

                            {/* Pending wishes indicator */}
                            {staffPendingWishes.length > 0 && (
                              <span
                                className="px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/25 text-amber-300 text-[10px] flex items-center gap-1"
                                title="Есть нерассмотренные пожелания в шапке раздела «График» (не учитываются, пока не одобрены)"
                              >
                                <span>{staffPendingWishes.length} не одобр.</span>
                              </span>
                            )}

                            {/* Hybrid mode schedule selector */}
                            {scheduleType === 'hybrid' && isSelected && (
                              <select
                                value={hybridConfig[s.id]?.type || '2/2'}
                                onChange={e => {
                                  const val = e.target.value as any;
                                  setHybridConfig(prev => ({
                                    ...prev,
                                    [s.id]: { type: val },
                                  }));
                                }}
                                className="px-2.5 py-1 bg-slate-950 border border-slate-750 rounded-lg text-emerald-400 text-xs font-semibold cursor-pointer"
                              >
                                <option value="2/2">2 / 2</option>
                                <option value="3/3">3 / 3</option>
                                <option value="5/2">5 / 2</option>
                                <option value="custom">Кастом</option>
                              </select>
                            )}
                          </div>
                        </div>

                        {/* Expanded Other PVZ Shifts details - Borderless */}
                        {expandedStaffOtherShifts === s.id && hasOtherPvzShifts && (
                          <div className="mt-2.5 p-2.5 bg-slate-950 rounded-xl text-[11px] text-slate-300 space-y-1.5 animate-fade-in">
                            <div className="font-semibold text-indigo-300 flex items-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                              <span>Сотрудник уже стоит в графике в другом пункте и недоступен в эти даты:</span>
                            </div>
                            <div className="flex flex-wrap gap-1.5 pt-0.5">
                              {staffOtherPvzShifts.map((sh, idx) => (
                                <span
                                  key={idx}
                                  className="px-2 py-0.5 rounded-lg bg-indigo-950/70 text-indigo-200 flex items-center gap-1"
                                >
                                  <span className="font-mono font-semibold">{sh.date.slice(8)} {monthName.slice(0, 3)}</span>
                                  <span className="text-slate-400">→</span>
                                  <span className="text-indigo-300 font-semibold">{sh.location}</span>
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Expanded wish dates - Approved Only - Borderless */}
                        {expandedStaffWishes === s.id && hasWishes && (
                          <div className="mt-2.5 p-2.5 bg-slate-950 rounded-xl text-[11px] text-slate-300 space-y-1.5 animate-fade-in">
                            <div className="font-semibold text-emerald-300 flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Одобренные руководителем пожелания (исключаются из графика):</span>
                            </div>
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {staffMonthWishes.map((w, idx) => (
                                <span key={idx} className="px-2 py-0.5 rounded-lg bg-emerald-950/60 text-emerald-200 font-mono text-[11px] flex items-center gap-1">
                                  <span>{w.date.slice(8)} {monthName.slice(0, 3)}</span>
                                  {w.comment && <span className="text-slate-300 font-sans">({w.comment})</span>}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Validation warnings */}
              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl text-xs space-y-1.5">
                {scheduleType === '2/2' && selectedStaffIds.length < 2 && (
                  <div className="text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>Для графика 2/2 требуется минимум 2 человека (сейчас выбрано: {selectedStaffIds.length}).</span>
                  </div>
                )}
                {scheduleType === '3/3' && selectedStaffIds.length < 2 && (
                  <div className="text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>Для графика 3/3 требуется минимум 2 человека (сейчас выбрано: {selectedStaffIds.length}).</span>
                  </div>
                )}
                {scheduleType === '5/2' && selectedStaffIds.length === 1 && (
                  <div className="text-amber-300 flex items-center gap-1.5">
                    <Info className="w-4 h-4 shrink-0" />
                    <span>При 1 сотруднике он будет работать без выходных, либо потребуется сменщик.</span>
                  </div>
                )}
                {selectedStaffIds.length >= 3 && (
                  <div className="text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Выбрано {selectedStaffIds.length} сотрудников (больше минимума). На Шаге 4 можно настроить усиление или ротацию.</span>
                  </div>
                )}
                {/* Cross-PVZ notice */}
                {selectedStaffIds.some(id => (existingShifts || []).some(sh => sh.employeeId === id && sh.date.startsWith(monthStr) && sh.location !== location)) && (
                  <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/25 rounded-lg text-indigo-300 text-xs flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-white">Внимание: пересечение смен в других ПВЗ</div>
                      <div className="text-slate-300 text-[11px] mt-0.5">
                        Один или несколько выбранных сотрудников уже имеют смены в других пунктах выдачи в этом месяце. Система автоматически учтёт их занятость и предупредит руководителя при попытке поставить смену в эти даты.
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 4: Настройка покрытия */}
          {step === 4 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <h3 className="text-sm sm:text-base font-semibold text-white mb-1">
                  Шаг 4. Настройка покрытия смен и усиления
                </h3>
                <p className="text-slate-400 text-xs">
                  Определяет, сколько сотрудников должно быть на смене и в какие дни нужно усиление.
                </p>
              </div>

              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-4">
                {/* 1. Base Coverage */}
                <div className="space-y-1.5">
                  <label className="block text-slate-300 font-semibold text-xs">
                    1. Сколько сотрудников нужно в обычный день:
                  </label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3].map(cnt => (
                      <button
                        key={cnt}
                        type="button"
                        onClick={() => setBaseCoverage(cnt)}
                        className={`px-4 py-2 rounded-xl border text-xs font-semibold cursor-pointer transition-all ${
                          baseCoverage === cnt
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-semibold'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {cnt} {cnt === 1 ? 'сотрудник' : 'сотрудника'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. Reinforcement Mode */}
                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <label className="block text-slate-300 font-semibold text-xs">
                    2. Нужно ли усиление в отдельные дни:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'none', title: 'Без усиления', desc: 'Ровно 1 человек каждый день' },
                      { id: 'weekdays', title: 'По будням', desc: 'Усиление с Пн по Пт' },
                      { id: 'weekends', title: 'По выходным', desc: 'Усиление в Сб и Вс' },
                      { id: 'custom_days', title: 'По дням недели', desc: 'Выбор конкретных дней' },
                    ].map(mode => (
                      <button
                        key={mode.id}
                        type="button"
                        onClick={() => setReinforcementMode(mode.id as ReinforcementMode)}
                        className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                          reinforcementMode === mode.id
                            ? 'bg-emerald-500/15 border-emerald-500 text-white font-semibold ring-1 ring-emerald-500/40'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <div className="text-xs text-emerald-400 font-semibold mb-0.5">{mode.title}</div>
                        <div className="text-[10px] text-slate-400 leading-tight">{mode.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 3. Coverage on Reinforcement Days */}
                {reinforcementMode !== 'none' && (
                  <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-slate-300 font-semibold text-xs">
                        3. Сколько человек в день усиления:
                      </label>
                      <div className="flex items-center gap-2">
                        {[2, 3, 4].map(cnt => (
                          <button
                            key={cnt}
                            type="button"
                            onClick={() => setReinforcementCoverage(cnt)}
                            className={`px-3 py-1 rounded-lg border text-xs cursor-pointer ${
                              reinforcementCoverage === cnt
                                ? 'bg-emerald-500 text-white font-bold border-emerald-400'
                                : 'bg-slate-950 border-slate-750 text-slate-400'
                            }`}
                          >
                            {cnt} сотр.
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Custom days of week */}
                    {reinforcementMode === 'custom_days' && (
                      <div className="space-y-1.5 pt-2 border-t border-slate-800">
                        <label className="text-slate-400 text-[11px]">Дни недели для усиления:</label>
                        <div className="flex flex-wrap gap-1.5">
                          {[
                            { day: 1, label: 'Пн' },
                            { day: 2, label: 'Вт' },
                            { day: 3, label: 'Ср' },
                            { day: 4, label: 'Чт' },
                            { day: 5, label: 'Пт' },
                            { day: 6, label: 'Сб' },
                            { day: 0, label: 'Вс' },
                          ].map(d => {
                            const active = reinforcementDaysOfWeek.includes(d.day);
                            return (
                              <button
                                key={d.day}
                                type="button"
                                onClick={() => {
                                  setReinforcementDaysOfWeek(prev =>
                                    active ? prev.filter(x => x !== d.day) : [...prev, d.day]
                                  );
                                }}
                                className={`px-3 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer ${
                                  active
                                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-semibold'
                                    : 'bg-slate-950 border-slate-800 text-slate-400'
                                }`}
                              >
                                {d.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Special 3-staff scenarios */}
                {selectedStaffIds.length === 3 && (
                  <div className="pt-3 border-t border-slate-800 space-y-2">
                    <label className="block text-slate-300 font-semibold text-xs">
                      Сценарий для 3 сотрудников:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'queue', title: 'Очередь (2/2)', desc: 'Равномерная ротация всех троих' },
                        { id: 'weekdays', title: 'Усиление в будни', desc: 'Основная пара 2/2 + третий выходит на будни' },
                        { id: 'weekends', title: 'Усиление в сб/вс', desc: 'Основная пара 2/2 + третий усиливает выходные' },
                      ].map(sc => (
                        <button
                          key={sc.id}
                          type="button"
                          onClick={() => setThreeStaffMode(sc.id as ThreeStaffScenario)}
                          className={`p-2.5 rounded-xl border text-left cursor-pointer transition-all ${
                            threeStaffMode === sc.id
                              ? 'bg-emerald-500/15 border-emerald-500 text-white font-semibold'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-300'
                          }`}
                        >
                          <div className="text-xs text-emerald-400 font-semibold">{sc.title}</div>
                          <div className="text-[10px] text-slate-400 leading-tight">{sc.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 5: Учёт пожеланий */}
          {step === 5 && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <h3 className="text-sm sm:text-base font-semibold text-white mb-1">
                  Шаг 5. Учёт пожеланий сотрудников
                </h3>
                <p className="text-slate-400 text-xs">
                  Сотрудники отмечают дни, когда не могут выйти на работу. Включите учет, чтобы система распределила смены в обход этих дат.
                </p>
              </div>

              {/* Main Toggle */}
              <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl space-y-3">
                <label className="flex items-start gap-3 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={respectWishes}
                    onChange={e => setRespectWishes(e.target.checked)}
                    className="w-5 h-5 mt-0.5 rounded bg-slate-900 border-slate-700 text-emerald-500 focus:ring-emerald-500/30 cursor-pointer"
                  />
                  <div>
                    <div className="font-semibold text-white text-sm">
                      Учитывать пожелания сотрудников («не могу выйти в этот день»)
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      {respectWishes
                        ? 'Система будет распределять смены так, чтобы никто не ставился в свой отмеченный день. Приоритет: точная дата → диапазон → день недели.'
                        : 'Галочка снята: пожелания игнорируются, график строится строго по циклу и норме сменности.'}
                    </div>
                  </div>
                </label>

                {/* Analysis Preview */}
                {respectWishes && generatorResult && (
                  <div className="pt-3 border-t border-slate-800/80 space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-semibold">Анализ пожеланий на {monthName}:</span>
                      <span className="text-emerald-400 font-mono">
                        Учтено: {generatorResult.metrics.wishesRespected} из {generatorResult.metrics.totalWishesInMonth}
                      </span>
                    </div>

                    {generatorResult.metrics.criticalConflicts.length > 0 ? (
                      <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl space-y-2">
                        <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs">
                          <AlertTriangle className="w-4 h-4 shrink-0" />
                          <span>
                            Внимание: обнаружены непокрытые дни из-за совпадения пожеланий и цикла ({generatorResult.metrics.criticalConflicts.length}):
                          </span>
                        </div>
                        <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                          {generatorResult.metrics.criticalConflicts.map((conf, idx) => (
                            <div
                              key={idx}
                              className="p-2 bg-slate-900/90 border border-rose-500/20 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px]"
                            >
                              <div>
                                <span className="font-semibold text-white">{conf.dayNum} {monthName.slice(0, 3)} ({conf.dayName}): </span>
                                <span className="text-slate-300">{conf.reason}</span>
                              </div>
                              <div className="flex items-center gap-1.5 shrink-0">
                                {conf.staffWithWishes.map(st => (
                                  <button
                                    key={st.id}
                                    type="button"
                                    onClick={() => toggleIgnoreWish(st.id, conf.dateStr)}
                                    className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-750 text-amber-300 border border-amber-500/30 text-[10px] font-semibold cursor-pointer"
                                    title="Временно снять пожелание сотрудника"
                                  >
                                    Снять пожелание {formatShortName(st.name)}
                                  </button>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-emerald-300 text-xs">
                        <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                        <span>Все дни месяца полностью закрыты, и пожелания сотрудников успешно соблюдены!</span>
                      </div>
                    )}

                    {/* Shift Exchange Summary in Month */}
                    {generatorResult.metrics.totalExchangeShiftsInMonth !== undefined && generatorResult.metrics.totalExchangeShiftsInMonth > 0 && (
                      <div className="p-3 bg-sky-500/10 border border-sky-500/30 rounded-xl flex items-center justify-between text-xs text-sky-200">
                        <div className="flex items-center gap-2">
                          <ArrowLeftRight className="w-4 h-4 text-sky-400 shrink-0" />
                          <span>Смены из «Биржи смен» для этого ПВЗ:</span>
                        </div>
                        <span className="font-mono font-semibold text-sky-300">
                          Учтено {generatorResult.metrics.exchangeShiftsIncluded || 0} из {generatorResult.metrics.totalExchangeShiftsInMonth}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 6: Результат и ручная правка графика (ПРЕДПРОСМОТР) */}
          {step === 6 && (
            <div className="space-y-4 animate-fade-in">
              {crossConflictAlert && (
                <div className="p-3 bg-rose-950/80 border border-rose-500/50 rounded-xl flex items-center justify-between text-xs text-rose-200 animate-fade-in shadow-lg">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span className="font-semibold">{crossConflictAlert}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCrossConflictAlert(null)}
                    className="p-1 hover:bg-rose-900/50 rounded text-rose-400 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              
              {/* Top Stats Bar */}
              {generatorResult && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="text-[10px] uppercase font-medium text-slate-400 tracking-wider">Закрыто дней</div>
                    <div className="text-lg font-mono font-semibold text-white mt-0.5">
                      <span className={generatorResult.metrics.coveredDays === generatorResult.metrics.totalDays ? 'text-emerald-400' : 'text-amber-400'}>
                        {generatorResult.metrics.coveredDays}
                      </span>
                      <span className="text-slate-500 text-xs font-normal"> / {generatorResult.metrics.totalDays}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="text-[10px] uppercase font-medium text-slate-400 tracking-wider">Пожеланий учтено</div>
                    <div className="text-lg font-mono font-semibold text-white mt-0.5">
                      <span className="text-emerald-400">{generatorResult.metrics.wishesRespected}</span>
                      <span className="text-slate-500 text-xs font-normal"> / {generatorResult.metrics.totalWishesInMonth}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="text-[10px] uppercase font-medium text-slate-400 tracking-wider">Всего смен</div>
                    <div className="text-lg font-mono font-semibold text-emerald-400 mt-0.5">
                      {generatorResult.shifts.length}
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="text-[10px] uppercase font-medium text-slate-400 tracking-wider">Статус графика</div>
                    <div className="text-xs font-semibold mt-1.5 flex items-center gap-1.5">
                      {generatorResult.metrics.uncoveredDays === 0 ? (
                        <span className="text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Полностью готов
                        </span>
                      ) : (
                        <span className="text-rose-400 flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Есть пропуски ({generatorResult.metrics.uncoveredDays})
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Mode Tabs for Preview */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2.5">
                <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none w-full sm:w-auto">
                  {[
                    { id: 'calendar', label: 'Календарь (Сетка)', icon: CalendarIcon },
                    { id: 'matrix', label: 'Матрица смен', icon: Layers },
                    { id: 'balance', label: 'Баланс сотрудников', icon: Users },
                    ...(generatorResult && (generatorResult.metrics.criticalConflicts.length > 0 || allCrossPvzConflicts.length > 0)
                      ? [{
                          id: 'conflicts',
                          label: `Конфликты (${generatorResult.metrics.criticalConflicts.length + allCrossPvzConflicts.length})`,
                          icon: AlertTriangle,
                        }]
                      : []),
                  ].map(tab => {
                    const Icon = tab.icon;
                    const active = previewTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setPreviewTab(tab.id as any)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-all shrink-0 ${
                          active
                            ? tab.id === 'conflicts'
                              ? 'bg-rose-500/20 text-rose-300 font-semibold'
                              : 'bg-emerald-500/20 text-emerald-300 font-semibold shadow-sm'
                            : 'bg-slate-850 hover:bg-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Custom Staff Filter Dropdown - Seamless & Borderless */}
                  <div className="relative">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setStaffDropdownOpen(prev => !prev)}
                        className={`h-8 px-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                          filterStaffId !== 'all'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white'
                        }`}
                        title="Фильтрация смен по сотруднику"
                      >
                        <Users className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="truncate max-w-[140px] sm:max-w-[190px]">
                          {filterStaffId === 'all'
                            ? `Сотрудник: Все (${selectedStaffIds.length})`
                            : formatShortName(staffList.find(s => s.id === filterStaffId)?.name || 'Сотрудник')}
                        </span>
                        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${staffDropdownOpen ? 'rotate-180' : ''}`} />
                      </button>

                      {filterStaffId !== 'all' && (
                        <button
                          type="button"
                          onClick={() => setFilterStaffId('all')}
                          className="h-8 px-2 text-[11px] text-slate-300 hover:text-white rounded-xl bg-slate-850 hover:bg-slate-800 transition-colors cursor-pointer flex items-center gap-1"
                          title="Сбросить фильтр и показать всех"
                        >
                          <X className="w-3 h-3 text-rose-400" />
                          <span className="hidden sm:inline">Все</span>
                        </button>
                      )}
                    </div>

                    {/* Dropdown Menu in Approved Design (Dark slate, emerald accents, NO borders!) */}
                    {staffDropdownOpen && (
                      <>
                        <div
                          className="fixed inset-0 z-40"
                          onClick={() => setStaffDropdownOpen(false)}
                        />
                        <div className="absolute left-0 sm:left-auto sm:right-0 top-full mt-1.5 w-64 max-w-[calc(100vw-2.5rem)] bg-slate-900/98 backdrop-blur-md rounded-2xl shadow-2xl p-1.5 z-50 animate-fade-in text-xs space-y-1">
                          <div className="px-2.5 py-1.5 text-[10px] font-medium uppercase tracking-wider text-slate-400 flex items-center justify-between">
                            <span>Фильтр сотрудника</span>
                            <span className="text-emerald-400">{selectedStaffIds.length} доступно</span>
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              setFilterStaffId('all');
                              setStaffDropdownOpen(false);
                            }}
                            className={`w-full px-2.5 py-1.5 rounded-xl text-left flex items-center justify-between transition-colors cursor-pointer ${
                              filterStaffId === 'all'
                                ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                                : 'text-slate-300 hover:bg-slate-850 hover:text-white'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <div className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px] text-slate-400">
                                <Users className="w-3 h-3" />
                              </div>
                              <span>Все сотрудники ({selectedStaffIds.length})</span>
                            </div>
                            {filterStaffId === 'all' && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                          </button>

                          <div className="max-h-52 overflow-y-auto space-y-0.5 pr-0.5">
                            {selectedStaffIds.map(stId => {
                              const st = staffList.find(s => s.id === stId);
                              const isSelected = filterStaffId === stId;
                              const workload = generatorResult?.metrics.staffWorkload.find(w => w.employeeId === stId);

                              return (
                                <button
                                  key={stId}
                                  type="button"
                                  onClick={() => {
                                    setFilterStaffId(stId);
                                    setStaffDropdownOpen(false);
                                  }}
                                  className={`w-full px-2.5 py-1.5 rounded-xl text-left flex items-center justify-between transition-colors cursor-pointer ${
                                    isSelected
                                      ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                                      : 'text-slate-300 hover:bg-slate-850 hover:text-white'
                                  }`}
                                >
                                  <div className="flex items-center gap-2 min-w-0">
                                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs $2font-medium shrink-0 ${
                                      isSelected ? 'bg-emerald-500 text-white font-bold' : 'bg-slate-800 text-slate-300'
                                    }`}>
                                      {st?.name ? st.name[0] : 'С'}
                                    </div>
                                    <div className="truncate">
                                      <span className="block truncate font-medium">{st?.name || 'Сотрудник'}</span>
                                      <div className="flex items-center gap-1 text-[10px]">
                                        {st?.isSenior && <span className="text-amber-400">Старший</span>}
                                        {st?.isPartTime && <span className="text-indigo-400">Подработка</span>}
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1.5 shrink-0 ml-2">
                                    {workload && (
                                      <span className="text-[ font-mono text-emerald-400 px]$2font-medium">
                                        {workload.shiftsCount} см.
                                      </span>
                                    )}
                                    {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                  <div className="text-[11px] text-slate-400 hidden lg:flex items-center gap-1.5 ml-2">
                    <Info className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>Кликните по сотруднику, чтобы снять или добавить смену</span>
                  </div>
                </div>
              </div>

              {/* Mobile Filter Notification Chip - Seamless */}
              {filterStaffId !== 'all' && (
                <div className="sm:hidden p-2.5 bg-emerald-950/40 rounded-xl flex items-center justify-between text-xs text-emerald-300 animate-fade-in shadow-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-semibold text-xs">
                      {staffList.find(s => s.id === filterStaffId)?.name?.[0] || 'С'}
                    </div>
                    <div>
                      <span className="font-semibold text-white">
                        {formatShortName(staffList.find(s => s.id === filterStaffId)?.name || 'Сотрудник')}
                      </span>
                      <span className="text-[10px] text-slate-400 ml-1.5 font-mono">
                        {generatorResult?.metrics.staffWorkload.find(w => w.employeeId === filterStaffId)?.shiftsCount || 0} смен
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFilterStaffId('all')}
                    className="px-2.5 py-1 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] cursor-pointer transition-colors"
                  >
                    ✕ Все
                  </button>
                </div>
              )}

              {/* TAB 1: CALENDAR VIEW */}
              {previewTab === 'calendar' && generatorResult && (
                <div className="p-2 sm:p-3 bg-slate-950/80 rounded-2xl space-y-2 animate-fade-in overflow-x-auto">
                  <div className="min-w-[460px] sm:min-w-0 space-y-2">
                    {/* Weekday Labels */}
                    <div className="grid grid-cols-7 gap-1 text-center font-semibold text-[11px] text-slate-400 py-1">
                      {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map((d, i) => (
                        <div key={i} className={i >= 5 ? 'text-rose-400/80' : ''}>{d}</div>
                      ))}
                    </div>

                    {/* Month Grid */}
                    <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
                      {/* Leading empty cells for alignment */}
                      {Array.from({ length: (daysList[0].dayOfWeek + 6) % 7 }).map((_, i) => (
                        <div key={`blank-${i}`} className="min-h-14 sm:min-h-18 rounded-xl bg-slate-900/25" />
                      ))}

                    {/* Actual Days */}
                    {daysList.map(d => {
                      const analysis = generatorResult.dayAnalysis[d.dateStr];
                      const assignedIds = analysis?.assignedStaffIds || [];
                      const isWeekend = d.dayOfWeek === 0 || d.dayOfWeek === 6;
                      const isPartial = analysis?.coverageStatus === 'understaffed';
                      const isEmpty = analysis?.coverageStatus === 'empty';
                      const isFilterActive = filterStaffId !== 'all';
                      const isFilteredStaffWorking = isFilterActive && assignedIds.includes(filterStaffId);

                      return (
                        <div
                          key={d.dateStr}
                          className={`min-h-16 sm:min-h-20 p-1 sm:p-1.5 rounded-xl border flex flex-col justify-between transition-all ${
                            isFilterActive
                              ? isFilteredStaffWorking
                                ? 'bg-emerald-950/30 border-emerald-500/30 shadow-sm'
                                : 'bg-slate-950/40 border-transparent opacity-30'
                              : isEmpty
                              ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                              : isPartial
                              ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                              : 'bg-slate-900 border-slate-800/80 hover:border-slate-750'
                          }`}
                        >
                          {/* Day Header with subtle green dot for working employee instead of bulky badge */}
                          <div className="flex items-center justify-between text-[11px]">
                            <div className="flex items-center gap-1">
                              <span className={`font-mono font-semibold ${
                                isFilterActive && isFilteredStaffWorking
                                  ? 'text-emerald-300'
                                  : isWeekend
                                  ? 'text-rose-400'
                                  : 'text-slate-300'
                              }`}>
                                {d.dayNum}
                              </span>
                              {isFilterActive && isFilteredStaffWorking && (
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block shrink-0 shadow-sm shadow-emerald-400/50" title="Смена сотрудника" />
                              )}
                            </div>
                            {analysis?.isReinforcedDay ? (
                              <span className="text-[ px-1 rounded bg-amber-500/20 text-amber-300 px]$2font-medium" title="День усиления">
                                Усил.
                              </span>
                            ) : null}
                          </div>

                          {/* Assigned Staff Badges */}
                          <div className="space-y-1 my-1">
                            {assignedIds.length === 0 ? (
                              <div className="text-[10px] text-rose-400/80 italic text-center py-1">
                                Нет смены
                              </div>
                            ) : (
                              assignedIds.map(stId => {
                                const staff = staffList.find(s => s.id === stId);
                                const hasWish = analysis?.wishesOnThisDay.some(w => w.employeeId === stId);
                                const crossPvz = analysis?.crossPvzConflicts?.find(c => c.employeeId === stId);
                                const exchangeItem = analysis?.exchangeShiftsOnThisDay?.find(e => e.employeeId === stId);
                                const isFocusedStaff = filterStaffId === 'all' || filterStaffId === stId;
                                const isExactFilterTarget = filterStaffId !== 'all' && filterStaffId === stId;

                                return (
                                  <button
                                    key={stId}
                                    type="button"
                                    onClick={() => toggleStaffOnDate(d.dateStr, stId)}
                                    className={`w-full text-left px-1.5 py-0.5 rounded text-[10px] font-semibold truncate transition-all cursor-pointer flex items-center justify-between ${
                                      !isFocusedStaff
                                        ? 'opacity-25 bg-slate-800/40 text-slate-500'
                                        : isExactFilterTarget
                                        ? 'bg-emerald-500/25 text-emerald-200 font-semibold'
                                        : crossPvz
                                        ? 'bg-indigo-500/25 text-indigo-200 hover:bg-rose-500/30'
                                        : exchangeItem
                                        ? 'bg-sky-500/20 text-sky-200 hover:bg-rose-500/20'
                                        : hasWish
                                        ? 'bg-amber-500/20 text-amber-200'
                                        : 'bg-emerald-500/20 text-emerald-300 hover:bg-rose-500/20 hover:text-rose-300'
                                    }`}
                                    title={
                                      crossPvz
                                        ? `Внимание: ${staff?.name || 'Сотрудник'} уже стоит в ${crossPvz.location} в этот день. Кликните, чтобы снять.`
                                        : exchangeItem
                                        ? `Смена взята из «Биржи смен»${exchangeItem.requesterName ? ` (замена: ${exchangeItem.requesterName})` : ''}. Кликните, чтобы снять.`
                                        : `${staff?.name || 'Сотрудник'} (кликните, чтобы снять)`
                                    }
                                  >
                                    <span className="truncate flex items-center gap-1">
                                      {crossPvz && <AlertTriangle className="w-2.5 h-2.5 text-indigo-400 shrink-0" />}
                                      {exchangeItem && <ArrowLeftRight className="w-2.5 h-2.5 text-sky-400 shrink-0" />}
                                      <span>{formatShortName(staff?.name || 'Сотрудник')}</span>
                                    </span>
                                    <span className="text-[8px] opacity-60">✕</span>
                                  </button>
                                );
                              })
                            )}
                          </div>

                          {/* Quick Add Available Staff */}
                          <div className="flex items-center justify-between pt-0.5">
                            <span className="text-[9px] text-slate-500 font-mono">
                              {assignedIds.length}/{analysis?.targetCount || 1}
                            </span>
                            {selectedStaffIds.length > assignedIds.length && (
                              <button
                                type="button"
                                onClick={() => {
                                  // Find next unassigned staff who is NOT busy at another PVZ on this date
                                  const unassigned = selectedStaffIds.find(id => {
                                    if (assignedIds.includes(id)) return false;
                                    const busyAtOther = existingShifts.some(
                                      s => s.employeeId === id &&
                                           s.date === d.dateStr &&
                                           s.location !== location &&
                                           s.location !== activePvzs.find(p => p.code === location)?.name
                                    );
                                    return !busyAtOther;
                                  });
                                  if (unassigned) {
                                    toggleStaffOnDate(d.dateStr, unassigned);
                                  } else {
                                    setCrossConflictAlert(`Все остальные сотрудники уже имеют смену в других ПВЗ на ${d.dayNum} ${monthName.slice(0, 3)}!`);
                                  }
                                }}
                                className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                                title="Назначить следующего свободного сотрудника"
                              >
                                +
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Mobile-friendly filtered staff shift list - Borderless */}
                {filterStaffId !== 'all' && (
                  <div className="sm:hidden pt-2 space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-300 font-semibold px-1">
                      <span>Назначенные смены ({daysList.filter(d => (generatorResult.dayAnalysis[d.dateStr]?.assignedStaffIds || []).includes(filterStaffId)).length} дн.):</span>
                      <span className="text-[10px] text-emerald-400 font-mono">
                        {daysList.filter(d => (generatorResult.dayAnalysis[d.dateStr]?.assignedStaffIds || []).includes(filterStaffId)).length * 12} ч
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      {daysList.map(d => {
                        const assignedIds = generatorResult.dayAnalysis[d.dateStr]?.assignedStaffIds || [];
                        const isWorking = assignedIds.includes(filterStaffId);
                        if (!isWorking) return null;
                        const isWeekend = d.dayOfWeek === 0 || d.dayOfWeek === 6;

                        return (
                          <div
                            key={`mob-shift-${d.dateStr}`}
                            className="p-2 rounded-xl bg-slate-900 flex items-center justify-between text-xs shadow-sm"
                          >
                            <div className="flex items-center gap-1.5">
                              <span className={`font-mono font-semibold ${isWeekend ? 'text-rose-400' : 'text-white'}`}>
                                {d.dayNum} {monthName.slice(0, 3)}
                              </span>
                              <span className="text-[10px] text-slate-400">({d.dayName})</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => toggleStaffOnDate(d.dateStr, filterStaffId)}
                              className="text-[10px] text-rose-400 hover:text-rose-300 px-2 py-0.5 rounded-lg bg-rose-950/40 cursor-pointer transition-colors"
                              title="Снять смену"
                            >
                              ✕
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

              </div>
            )}

              {/* TAB 2: MATRIX TABLE VIEW */}
              {previewTab === 'matrix' && generatorResult && (
                <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden max-h-72 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="bg-slate-900 sticky top-0 text-[10px] uppercase font-medium text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2.5">Дата</th>
                        <th className="p-2.5">День</th>
                        <th className="p-2.5">План / Факт</th>
                        <th className="p-2.5">Назначенные сотрудники</th>
                        <th className="p-2.5">Статус</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850">
                      {daysList.map(d => {
                        const analysis = generatorResult.dayAnalysis[d.dateStr];
                        const isWeekend = d.dayOfWeek === 0 || d.dayOfWeek === 6;
                        const isFilterActive = filterStaffId !== 'all';
                        const isFilteredStaffWorking = isFilterActive && (analysis?.assignedStaffIds || []).includes(filterStaffId);

                        return (
                          <tr
                            key={d.dateStr}
                            className={`transition-colors ${
                              isFilterActive
                                ? isFilteredStaffWorking
                                  ? 'bg-emerald-950/30 border-l-4 border-l-emerald-500 hover:bg-emerald-950/40'
                                  : 'opacity-35 hover:opacity-70'
                                : 'hover:bg-slate-900/60'
                            }`}
                          >
                            <td className="p-2.5 font-mono text-white font-semibold">{d.dayNum} {monthName.slice(0, 3)}</td>
                            <td className={`p-2.5 font-semibold ${isWeekend ? 'text-rose-400' : 'text-slate-400'}`}>{d.dayName}</td>
                            <td className="p-2.5 font-mono">
                              <span className={analysis?.coverageStatus === 'ok' ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                                {analysis?.assignedStaffIds.length || 0}
                              </span>
                              <span className="text-slate-500"> / {analysis?.targetCount || 1}</span>
                            </td>
                            <td className="p-2.5">
                              <div className="flex flex-wrap gap-1">
                                {(analysis?.assignedStaffIds || []).map(stId => {
                                  const staff = staffList.find(s => s.id === stId);
                                  const isFocusedStaff = filterStaffId === 'all' || filterStaffId === stId;
                                  const isExactFilterTarget = filterStaffId !== 'all' && filterStaffId === stId;

                                  return (
                                    <button
                                      key={stId}
                                      type="button"
                                      onClick={() => toggleStaffOnDate(d.dateStr, stId)}
                                      className={`px-2 py-0.5 rounded font-semibold cursor-pointer text-[11px] transition-all ${
                                        !isFocusedStaff
                                          ? 'opacity-25 bg-slate-800 text-slate-500'
                                          : isExactFilterTarget
                                          ? 'ring-2 ring-emerald-400 bg-emerald-500/30 text-white font-semibold'
                                          : 'bg-emerald-500/20 text-emerald-300 hover:bg-rose-500/20 hover:text-rose-300'
                                      }`}
                                      title="Нажмите, чтобы снять"
                                    >
                                      {formatShortName(staff?.name || 'Сотрудник')} ✕
                                    </button>
                                  );
                                })}
                              </div>
                            </td>
                            <td className="p-2.5">
                              {analysis?.coverageStatus === 'ok' ? (
                                <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 font-medium text-[10px] border border-emerald-500/20">Закрыт</span>
                              ) : analysis?.coverageStatus === 'understaffed' ? (
                                <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-400 font-medium text-[10px] border border-amber-500/20">Частично</span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-400 font-medium text-[10px] border border-rose-500/20">Пропуск</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              {/* TAB 3: WORKLOAD BALANCE */}
              {previewTab === 'balance' && generatorResult && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 animate-fade-in">
                  {generatorResult.metrics.staffWorkload.map(st => {
                    const isFilterTarget = filterStaffId !== 'all' && filterStaffId === st.employeeId;
                    const isOtherStaff = filterStaffId !== 'all' && filterStaffId !== st.employeeId;

                    return (
                      <div
                        key={st.employeeId}
                        className={`p-4 rounded-2xl space-y-3 transition-all ${
                          isFilterTarget
                            ? 'bg-slate-900 border-2 border-emerald-500 ring-2 ring-emerald-500/30 shadow-lg'
                            : isOtherStaff
                            ? 'bg-slate-950/60 border border-slate-850 opacity-40'
                            : 'bg-slate-950 border border-slate-800'
                        }`}
                      >
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-white text-sm flex items-center gap-2">
                            <span>{st.employeeName}</span>
                            {st.isSenior && <span className="text-[ px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 px]$2font-medium">Старший</span>}
                          </div>
                          <div className="text-xs text-slate-400">{st.hours} рабочих часов в месяце</div>
                        </div>
                        <div className="text-right">
                          <span className="text-xl font-mono font-semibold text-emerald-400">{st.shiftsCount}</span>
                          <span className="text-xs text-slate-400 ml-1">смен</span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-slate-400">
                          <span>Доля месяца:</span>
                          <span className="font-mono font-semibold text-slate-200">{st.percentOfMonth}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-850 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
                            style={{ width: `${Math.min(100, st.percentOfMonth)}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-850">
                        <span className="text-slate-400">Пожелания:</span>
                        <span className="text-emerald-400 font-semibold">Соблюдено: {st.wishesMet}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
              )}

              {/* TAB 4: CONFLICTS VIEW */}
              {previewTab === 'conflicts' && generatorResult && (
                <div className="space-y-2 animate-fade-in max-h-72 overflow-y-auto">
                  {/* Cross-PVZ Conflict Banners */}
                  {allCrossPvzConflicts.map((conf, idx) => (
                    <div
                      key={`cross-${idx}`}
                      className="p-3 bg-indigo-950/40 border border-indigo-500/40 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs"
                    >
                      <div>
                        <div className="font-semibold text-white flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          <span className="text-indigo-400">Пересечение с другим ПВЗ</span>
                          <span className="font-mono text-slate-300 ml-1">
                            {conf.dayNum} {monthName.slice(0, 3)} ({conf.dayName})
                          </span>
                        </div>
                        <div className="text-slate-300 text-[11px] mt-0.5">
                          Сотрудник <strong className="text-white">{conf.employeeName}</strong> уже стоит в графике в пункте{' '}
                          <strong className="text-indigo-300">{conf.otherLocation}</strong> в эту дату и не может выйти сюда.
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => toggleStaffOnDate(conf.dateStr, conf.employeeId)}
                          className="px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-semibold cursor-pointer text-[11px] hover:bg-rose-500/20 hover:text-rose-300 hover:border-rose-500/40 transition-colors"
                          title="Снять сотрудника с этой даты на данном ПВЗ"
                        >
                          Снять с этой даты
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Standard Critical Wishes Conflicts */}
                  {generatorResult.metrics.criticalConflicts.length === 0 && allCrossPvzConflicts.length === 0 ? (
                    <div className="p-6 text-center text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl">
                      Критических конфликтов нет! Все смены распределены успешно.
                    </div>
                  ) : (
                    generatorResult.metrics.criticalConflicts.map((conf, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-950 border border-rose-500/30 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs"
                      >
                        <div>
                          <div className="font-semibold text-white flex items-center gap-2">
                            <span>{conf.dayNum} {monthName.slice(0, 3)} ({conf.dayName})</span>
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-mono">
                              Не закрыт
                            </span>
                          </div>
                          <div className="text-slate-300 text-[11px] mt-0.5">{conf.reason}</div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {conf.staffWithWishes.map(st => (
                            <button
                              key={st.id}
                              type="button"
                              onClick={() => toggleIgnoreWish(st.id, conf.dateStr)}
                              className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold cursor-pointer text-[11px] hover:bg-amber-500/30 transition-colors"
                            >
                              Снять пожелание {formatShortName(st.name)}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Bottom Options: Save as Template */}
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300 font-medium text-xs select-none">
                  <input
                    type="checkbox"
                    checked={saveTemplate}
                    onChange={e => setSaveTemplate(e.target.checked)}
                    className="w-4 h-4 rounded bg-slate-900 border-slate-700 text-emerald-500 cursor-pointer"
                  />
                  <span>Сохранить эту схему как шаблон для будущих месяцев</span>
                </label>
                {saveTemplate && (
                  <input
                    type="text"
                    placeholder="Название шаблона (напр., 2/2 Основной)"
                    value={templateName}
                    onChange={e => setTemplateName(e.target.value)}
                    className="w-full sm:max-w-md px-3 py-1.5 bg-slate-900 border border-slate-750 rounded-xl text-white text-xs"
                  />
                )}
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer with Stepper Controls - Responsive for Mobile */}
        {/* Modal Footer with Stepper Controls - Compact Single-Line on Mobile */}
        <div className="p-2.5 sm:p-4 border-t border-slate-800 shrink-0 bg-slate-900/95 flex items-center justify-between gap-2">
          {step === 6 ? (
            /* Step 6: All 4 buttons in ONE single compact line on mobile */
            <div className="flex items-center justify-between gap-1.5 sm:gap-2 w-full">
              <div className="flex items-center gap-1.5 sm:gap-2">
                {/* Назад */}
                <button
                  type="button"
                  onClick={() => setStep(s => s - 1)}
                  className="h-8 sm:h-9 px-2 sm:px-3.5 bg-slate-800 hover:bg-slate-750 text-slate-200 font-semibold rounded-lg sm:rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1 sm:gap-1.5 text-[11px] sm:text-xs shrink-0"
                  title="Назад к шагу 5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Назад</span>
                </button>

                {/* В PDF */}
                <button
                  type="button"
                  onClick={handleDownloadPdf}
                  disabled={isExportingPdf || !generatorResult || generatorResult.shifts.length === 0}
                  className="h-8 sm:h-9 px-2 sm:px-3.5 bg-slate-850 hover:bg-slate-800 text-emerald-400 font-semibold rounded-lg sm:rounded-xl shadow-sm transition-all cursor-pointer disabled:opacity-50 text-[11px] sm:text-xs flex items-center justify-center gap-1 sm:gap-1.5 shrink-0"
                  title="Скачать PDF с графиком смен"
                >
                  {isExportingPdf ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                      <span>PDF...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span className="hidden sm:inline">В </span>
                      <span>PDF</span>
                    </>
                  )}
                </button>

                {/* Отмена */}
                <button
                  type="button"
                  onClick={onClose}
                  className="h-8 sm:h-9 px-2 sm:px-3 text-slate-400 hover:text-white bg-slate-850/60 sm:bg-transparent hover:bg-slate-800 sm:hover:bg-transparent rounded-lg transition-colors cursor-pointer text-[11px] sm:text-xs flex items-center justify-center gap-1 shrink-0"
                  title="Закрыть мастер верстки"
                >
                  <X className="w-3.5 h-3.5 sm:hidden text-slate-400" />
                  <span className="hidden sm:inline">Отмена</span>
                </button>
              </div>

              {/* Применить (без слова график) */}
              <div className="flex items-center gap-1.5 sm:gap-2">
                <button
                  type="button"
                  disabled={isApplying || loading || !generatorResult || generatorResult.shifts.length === 0}
                  onClick={handleApply}
                  className="h-8 sm:h-9 px-3 sm:px-5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-semibold rounded-lg sm:rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50 text-[11px] sm:text-xs flex items-center justify-center gap-1.5 active:scale-95 flex-1 sm:flex-initial"
                  title="Применить сформированный график"
                >
                  {isApplying || loading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Сохранение...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                      <span>Применить</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : (
            /* Steps 1 - 5 */
            <div className="flex items-center justify-between gap-2 w-full">
              <div className="flex items-center gap-2">
                {step > 1 ? (
                  <button
                    type="button"
                    onClick={() => setStep(s => s - 1)}
                    className="h-8 sm:h-9 px-3 sm:px-3.5 bg-slate-800 hover:bg-slate-750 text-slate-200 font-semibold rounded-lg sm:rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 text-xs"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Назад</span>
                  </button>
                ) : <div />}

                <button
                  type="button"
                  onClick={onClose}
                  className="h-8 sm:h-9 px-3 text-slate-400 hover:text-white transition-colors cursor-pointer text-xs"
                >
                  Отмена
                </button>
              </div>

              <button
                type="button"
                onClick={() => setStep(s => s + 1)}
                className="h-8 sm:h-9 px-4 sm:px-5 bg-emerald-500 hover:bg-emerald-400 text-white font-bold rounded-lg sm:rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5 text-xs active:scale-95"
              >
                <span>Далее</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
