import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { LocationType, ShiftType, StaffMember, PlannedShift, ScheduleTemplate } from '../../types';
import { formatCurrency, calculateShiftTotalSalary } from '../../utils/calculations';
import { formatMonthName } from '../../utils/time';
import { CustomSelect } from '../common/CustomSelect';
import { ScheduleGeneratorWizardModal } from './ScheduleGeneratorWizardModal';
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  AlertTriangle,
  Clock,
  MapPin,
  Users,
  CalendarCheck,
  Eye,
  X,
  SlidersHorizontal,
  Send,
  Bookmark,
  Layers,
  CheckCircle2,
  FileSpreadsheet,
  Info,
  Calendar as CalendarIcon,
  RefreshCw,
  UserCheck,
  ShieldCheck,
  Sliders,
  Filter,
  Search,
  ArrowRight,
  ArrowLeft,
  Check,
  CheckCheck,
  HelpCircle,
  Settings2,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
  FileDown,
  Loader2,
} from 'lucide-react';
import {
  generateSchedulePlan,
  ScheduleType,
  Weekend52Mode,
  ReinforcementMode,
  ThreeStaffScenario,
  GeneratorResult,
  hasEmployeeUnavailability,
} from '../../utils/scheduleGenerator';
import { exportExistingPvzScheduleToPdf } from '../../utils/schedulePdfExporter';

function formatShortName(fullName: string): string {
  if (!fullName) return '';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length >= 2) {
    return `${parts[0]} ${parts[1][0]}.`;
  }
  return parts[0];
}

export const SchedulePlannerView: React.FC = () => {
  const {
    staffList,
    records,
    schedules,
    scheduleTemplates,
    availability,
    rates,
    pickupPoints,
    swaps = [],
    savePlannedShift,
    saveSlotShifts,
    deletePlannedShift,
    clearMonthSchedules,
    saveScheduleBatch,
    publishSchedule,
    saveScheduleTemplate,
    deleteScheduleTemplate,
    updateAvailabilityStatus,
  } = useApp();

  const now = new Date();
  const [currentYear, setCurrentYear] = useState(now.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(now.getMonth()); // 0-indexed
  const [selectedPvzCode, setSelectedPvzCode] = useState<string>('ALL');
  const [searchPvzQuery, setSearchPvzQuery] = useState('');
  const viewMode = 'matrix';

  // Modals state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [isEditingSlot, setIsEditingSlot] = useState(false);
  const [modalDate, setModalDate] = useState('');
  const [modalLocation, setModalLocation] = useState<LocationType>('');
  const [modalEmployeeId, setModalEmployeeId] = useState('');
  const [modalEmployeeIds, setModalEmployeeIds] = useState<string[]>([]);
  const [modalShiftType, setModalShiftType] = useState<ShiftType>('standard');
  const [modalNote, setModalNote] = useState('');
  const [slotModalError, setSlotModalError] = useState<string | null>(null);
  const [viewPvzCalendar, setViewPvzCalendar] = useState<any | null>(null);

  // Generator Wizard State
  const [genModalOpen, setGenModalOpen] = useState(false);
  const [genLocation, setGenLocation] = useState<string>("");

  // Scenarios Modal state
  const [tplModalOpen, setTplModalOpen] = useState(false);

  // Publish Modal state
  const [pubModalOpen, setPubModalOpen] = useState(false);
  const [pubSuccessMsg, setPubSuccessMsg] = useState('');
  const [wishesModalOpen, setWishesModalOpen] = useState(false);
  const [wishesFilterStatus, setWishesFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [updatingWishId, setUpdatingWishId] = useState<string | null>(null);

  // Auto-dismiss publication & generator success messages after 3.5 seconds
  useEffect(() => {
    if (pubSuccessMsg) {
      const timer = setTimeout(() => {
        setPubSuccessMsg('');
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [pubSuccessMsg]);

  // Human-readable reason helper for employee wishes with smart reason detection
  const getWishCategoryInfo = (type: string, comment?: string) => {
    const c = (comment || '').toLowerCase();
    let resolvedType = type;
    if (resolvedType === 'unavailable' || !resolvedType) {
      if (c.includes('учеб') || c.includes('сесси') || c.includes('экзамен') || c.includes('пар') || c.includes('институт')) {
        resolvedType = 'study';
      } else if (c.includes('отпуск') || c.includes('отгул') || c.includes('море') || c.includes('поездк') || c.includes('дач')) {
        resolvedType = 'vacation';
      } else if (c.includes('больнич') || c.includes('боле') || c.includes('врач') || c.includes('клиник') || c.includes('температур')) {
        resolvedType = 'sick';
      }
    }

    switch (resolvedType) {
      case 'vacation':
        return { label: 'Отпуск / Отгул', badgeClass: 'bg-amber-500/20 text-amber-300' };
      case 'study':
        return { label: 'Учёба / Сессия', badgeClass: 'bg-sky-500/20 text-sky-300' };
      case 'sick':
        return { label: 'Больничный', badgeClass: 'bg-rose-500/20 text-rose-300' };
      case 'preferred':
        return { label: 'Желаемая смена', badgeClass: 'bg-emerald-500/20 text-emerald-300' };
      case 'unavailable':
      default:
        return { label: 'Личные обстоятельства', badgeClass: 'bg-orange-500/20 text-orange-300' };
    }
  };

  const getWishReasonLabel = (type: string, comment?: string) => {
    const info = getWishCategoryInfo(type, comment);
    const trimmed = (comment || '').trim();
    if (trimmed && trimmed.toLowerCase() !== info.label.toLowerCase() && !trimmed.toLowerCase().includes('не могу') && !trimmed.toLowerCase().includes('не может')) {
      return `${info.label} • «${trimmed}»`;
    }
    return info.label;
  };

  const handleSetWishStatus = async (availId: string, status: 'approved' | 'rejected' | 'pending') => {
    setUpdatingWishId(availId);
    try {
      await updateAvailabilityStatus(availId, status);
    } catch (e) {
      console.error('Error updating wish status:', e);
    } finally {
      setUpdatingWishId(null);
    }
  };

  const handleBatchSetWishesStatus = async (wishIds: string[], status: 'approved' | 'rejected') => {
    for (const id of wishIds) {
      await updateAvailabilityStatus(id, status);
    }
  };

  // Confirmation dialogs state (safe for iframes, avoids window.confirm)
  const [shiftToDelete, setShiftToDelete] = useState<{ id: string; employeeName: string; date: string } | null>(null);
  const [clearMonthConfirmPvz, setClearMonthConfirmPvz] = useState<{ code: string; name: string } | null>(null);

  const [loading, setLoading] = useState(false);
  const [isExportingPvzPdf, setIsExportingPvzPdf] = useState(false);

  // PDF Export for viewed PVZ Calendar
  const handleExportPvzCalendarPdf = async () => {
    if (!viewPvzCalendar || isExportingPvzPdf) return;
    setIsExportingPvzPdf(true);
    try {
      const targetCode = viewPvzCalendar.code;
      const targetName = viewPvzCalendar.name || viewPvzCalendar.code;
      const targetId = (viewPvzCalendar as any).id;

      // Filter all shifts for this PVZ in the current month matching code, name, id or address
      const pvzShifts = monthPlannedShifts.filter(s => {
        if (!s) return false;
        if (s.location === targetCode) return true;
        if (s.location === targetName) return true;
        if (targetId && s.location === targetId) return true;
        if (viewPvzCalendar.address && s.location === viewPvzCalendar.address) return true;
        return false;
      });

      await exportExistingPvzScheduleToPdf({
        location: targetName,
        locationCode: targetCode,
        monthStr,
        monthName,
        daysList,
        plannedShifts: pvzShifts,
        staffList,
      });
    } catch (err) {
      console.error('Failed to export PVZ calendar to PDF:', err);
    } finally {
      setIsExportingPvzPdf(false);
    }
  };

  const monthStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}`;
  const monthName = formatMonthName(monthStr);

  const activePvzs = useMemo(() => {
    return pickupPoints.filter(p => p.active && !p.isArchived);
  }, [pickupPoints]);

  const activeStaff = useMemo(() => {
    return staffList.filter(s => s.status === 'active');
  }, [staffList]);

  // Filter PVZs by code or search query
  const filteredPvzs = useMemo(() => {
    let list = activePvzs;
    if (selectedPvzCode !== 'ALL') {
      list = list.filter(p => p.code === selectedPvzCode || p.name === selectedPvzCode);
    }
    if (searchPvzQuery.trim()) {
      const q = searchPvzQuery.toLowerCase().trim();
      list = list.filter(
        p => p.code.toLowerCase().includes(q) ||
             p.name.toLowerCase().includes(q) ||
             (p.address && p.address.toLowerCase().includes(q))
      );
    }
    return list;
  }, [activePvzs, selectedPvzCode, searchPvzQuery]);

  // Month navigation
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  // Days list for selected month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const daysList = useMemo(() => {
    const list: { dateStr: string; dayNum: number; dayOfWeek: number; dayName: string }[] = [];
    const weekDayNames = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];

    for (let d = 1; d <= daysInMonth; d++) {
      const dStr = `${monthStr}-${String(d).padStart(2, '0')}`;
      const dateObj = new Date(currentYear, currentMonth, d);
      const dayOfWeek = dateObj.getDay();
      list.push({
        dateStr: dStr,
        dayNum: d,
        dayOfWeek,
        dayName: weekDayNames[dayOfWeek],
      });
    }
    return list;
  }, [currentYear, currentMonth, daysInMonth, monthStr]);

  // Month planned shifts
  const monthPlannedShifts = useMemo(() => {
    return schedules.filter(s => s.date.startsWith(monthStr));
  }, [schedules, monthStr]);

  // Filter staff by location access
  const getStaffForPvz = (pvzCode: string) => {
    if (!pvzCode || pvzCode === 'ALL') return activeStaff;
    const targetPvz = activePvzs.find(p => p.code === pvzCode || p.id === pvzCode);
    const codeToMatch = targetPvz ? targetPvz.code : pvzCode;
    const idToMatch = targetPvz ? targetPvz.id : pvzCode;

    return activeStaff.filter(s => {
      const locs = s.locations || (s.location ? [s.location] : []);
      return locs.includes(codeToMatch) || locs.includes(idToMatch);
    });
  };

  // Estimated FOT
  const estimatedFOT = useMemo(() => {
    let sum = 0;
    monthPlannedShifts.forEach(p => {
      const staff = staffList.find(s => s.id === p.employeeId);
      sum += calculateShiftTotalSalary(p, staff, rates);
    });
    return sum;
  }, [monthPlannedShifts, staffList, rates]);

  // Open Edit Slot Modal (supporting multiple employees)
  const openEditSlotModal = (dateStr: string, locationCode: string) => {
    setModalDate(dateStr);
    setModalLocation(locationCode);
    setSlotModalError(null);

    const existing = schedules.filter(
      s => s.date === dateStr && (s.location === locationCode || s.location === activePvzs.find(p => p.code === locationCode)?.name)
    );

    setIsEditingSlot(existing.length > 0);

    if (existing.length > 0) {
      setModalEmployeeIds(existing.map(s => s.employeeId));
      setModalShiftType(existing[0].shiftType);
      setModalNote(existing[0].note || '');
    } else {
      setModalEmployeeIds([]);
      setModalShiftType('standard');
      setModalNote('');
    }
    setEditModalOpen(true);
  };

  // Save Slots (Delete existing for date/location, and save selected)
  const handleSaveSlot = async (e: React.FormEvent) => {
    e.preventDefault();
    setSlotModalError(null);

    const targetPvz = activePvzs.find(p => p.code === modalLocation || p.name === modalLocation || p.id === modalLocation);
    const targetLocCode = targetPvz?.code || modalLocation;
    const targetLocName = targetPvz?.name || modalLocation;

    // Enforce Rule: An employee cannot have a shift at another PVZ on the same date!
    for (const empId of modalEmployeeIds) {
      const busyOther = schedules.find(
        sch => sch.employeeId === empId &&
               sch.date === modalDate &&
               sch.location !== targetLocCode &&
               sch.location !== targetLocName &&
               sch.location !== targetPvz?.id
      );
      if (busyOther) {
        const staff = staffList.find(s => s.id === empId);
        setSlotModalError(
          `Невозможно назначить: сотрудник ${staff?.name || 'Сотрудник'} уже имеет смену в пункте «${busyOther.location}» на эту дату (${modalDate}). Один сотрудник не может работать в двух ПВЗ одновременно!`
        );
        return;
      }
    }

    setLoading(true);

    const shiftPayload = modalEmployeeIds.map(empId => {
      const staff = staffList.find(s => s.id === empId);
      return {
        employeeId: empId,
        employeeName: staff ? staff.name : 'Сотрудник',
        shiftType: modalShiftType,
        note: modalNote,
      };
    });

    const res = await saveSlotShifts(modalDate, modalLocation, shiftPayload);
    setLoading(false);

    if (!res.success) {
      setSlotModalError(res.error || 'Ошибка сохранения смен');
      return;
    }

    setEditModalOpen(false);
  };

  // Delete Slots for Date & Location
  const handleDeleteSlot = async (dateStr: string, locationCode: string) => {
    const existing = schedules.filter(
      s => s.date === dateStr && (s.location === locationCode || s.location === activePvzs.find(p => p.code === locationCode)?.name)
    );
    if (existing.length === 0) return;
    setLoading(true);
    for (const item of existing) {
      await deletePlannedShift(item.id);
    }
    setLoading(false);
  };

  // Open Generator Modal
  const openGeneratorModal = (pvzCode?: string) => {
    if (activePvzs.length === 0) {
      setPubSuccessMsg('Для верстки графика необходимо сначала добавить хотя бы один пункт выдачи (ПВЗ) в разделе «Пункты выдачи».');
      return;
    }
    const targetCode = pvzCode && pvzCode !== "ALL" ? pvzCode : (activePvzs[0]?.code || "");
    setGenLocation(targetCode);
    setGenModalOpen(true);
  };

  // Run Saved Scenario Template
  const handleApplyTemplate = async (tpl: ScheduleTemplate) => {
    const staffAId = tpl.mainStaffIds[0] || activeStaff[0]?.id || '';
    const staffBId = tpl.mainStaffIds[1] || staffAId;
    const partTimeId = tpl.partTimeStaffIds?.[0] || '';

    const staffA = staffList.find(s => s.id === staffAId);
    const staffB = staffList.find(s => s.id === staffBId) || staffA;
    const staffPart = staffList.find(s => s.id === partTimeId);

    const batch: PlannedShift[] = [];

    daysList.forEach((d, idx) => {
      let chosenStaff: StaffMember | undefined = undefined;
      const isWeekend = d.dayOfWeek === 0 || d.dayOfWeek === 6;

      if (tpl.scenarioType === '2/2') {
        const cycleDay = idx % 4;
        chosenStaff = cycleDay < 2 ? staffA : staffB;
      } else if (tpl.scenarioType === '3/3') {
        const cycleDay = idx % 6;
        chosenStaff = cycleDay < 3 ? staffA : staffB;
      } else if (tpl.scenarioType === '2/2+P') {
        const cycleDay = idx % 4;
        chosenStaff = cycleDay < 2 ? staffA : staffB;
        if (!isWeekend && staffPart) {
          const isUnavail = availability.some(a => a.employeeId === chosenStaff?.id && a.date === d.dateStr);
          if (isUnavail) chosenStaff = staffPart;
        }
      } else if (tpl.scenarioType === '5/2') {
        chosenStaff = isWeekend ? (staffPart || staffB) : staffA;
      }

      if (chosenStaff) {
        // Enforce rule: never assign employee if they already have a shift at another PVZ today!
        const busyAtOther = schedules.find(
          s => s.employeeId === chosenStaff?.id && s.date === d.dateStr && s.location !== tpl.location
        );
        if (!busyAtOther) {
          batch.push({
            id: `tpl-${d.dateStr}-${tpl.location}`,
            date: d.dateStr,
            location: tpl.location,
            employeeId: chosenStaff.id,
            employeeName: chosenStaff.name,
            shiftType: tpl.defaultShiftType || 'standard',
            note: `Шаблон: ${tpl.name}`,
            createdAt: new Date().toISOString(),
          });
        }
      }
    });

    setLoading(true);
    await saveScheduleBatch(batch, { replaceMonth: monthStr, replaceLocation: tpl.location });
    setLoading(false);
    setTplModalOpen(false);
  };

  // Publish to Staff
  const handlePublishSchedule = async () => {
    setLoading(true);
    const targetLoc = selectedPvzCode === 'ALL' ? undefined : selectedPvzCode;
    const count = monthPlannedShifts.filter(s => selectedPvzCode === 'ALL' || s.location === selectedPvzCode).length;

    const res = await publishSchedule(monthName, targetLoc, count);
    setLoading(false);
    if (res.success) {
      setPubSuccessMsg(`График смен на ${monthName} (${count} смен) успешно опубликован! Все сотрудники получили уведомления.`);
      setPubModalOpen(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      
      {/* Success Notification Toast - Auto-dismissing after 3.5 seconds and borderless */}
      {pubSuccessMsg && (
        <div className="fixed top-4 right-4 left-4 sm:left-auto sm:w-96 z-[100] p-3.5 bg-slate-900/95 backdrop-blur-md rounded-2xl shadow-2xl flex items-center justify-between text-xs text-emerald-300 animate-slide-in">
          <div className="flex items-center gap-2.5 font-medium min-w-0">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="truncate">
              <span className="font-semibold text-white block">Успешно</span>
              <span className="text-[11px] text-white font-medium truncate">{pubSuccessMsg}</span>
            </div>
          </div>
          <button
            onClick={() => setPubSuccessMsg('')}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl cursor-pointer transition-colors shrink-0 ml-2"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Header & Actions - Compact and Responsive for Mobile */}
      <div className="bg-slate-900/95 border border-slate-800 p-3 sm:p-5 rounded-2xl shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-[11px] font-semibold uppercase tracking-wider mb-0.5">
              <CalendarCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
              <span>Управление расписанием</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-xl font-semibold text-white tracking-tight">
                График смен сотрудникам
              </h2>
              <span className="text-sm font-mono font-normal text-slate-400 ml-1">
                {monthName}
              </span>
            </div>
          </div>

          {/* Month Selector - Borderless */}
          <div className="flex items-center justify-between sm:justify-start bg-slate-950 p-1 rounded-xl shrink-0 self-start sm:self-auto w-full sm:w-auto">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Предыдущий месяц"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-white px-3 font-mono text-center flex-1 sm:flex-initial">
              {monthName}
            </span>
            <button
              onClick={handleNextMonth}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              title="Следующий месяц"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Action Controls Group: 3 Clean ERP Buttons (No bouncing or game micro-interactions) */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
          {/* 1. Generator Wizard Button */}
          <button
            type="button"
            onClick={() => openGeneratorModal(selectedPvzCode !== 'ALL' ? selectedPvzCode : undefined)}
            disabled={activePvzs.length === 0}
            className={`h-8.5 px-3 rounded-md text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer border ${
              activePvzs.length === 0
                ? 'bg-slate-900 border-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-slate-800 hover:bg-slate-750 border-slate-700/80 text-white'
            }`}
            title={activePvzs.length === 0 ? 'Сначала добавьте хотя бы один ПВЗ в разделе «Пункты выдачи»' : 'Сверстать график смен'}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Сверстать график</span>
          </button>

          {/* 2. Saved Scenarios Button */}
          <button
            type="button"
            onClick={() => setTplModalOpen(true)}
            className="h-8.5 px-3 bg-slate-800 hover:bg-slate-750 border border-slate-700/80 text-white font-medium text-xs rounded-md transition-colors cursor-pointer flex items-center justify-center gap-2"
            title="Сценарии и шаблоны ПВЗ"
          >
            <Bookmark className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Сценарии ПВЗ</span>
            {scheduleTemplates.length > 0 && (
              <span className="text-[11px] text-amber-400 font-mono ml-0.5">
                ({scheduleTemplates.length})
              </span>
            )}
          </button>

          {/* 3. Publish & Send Button */}
          <button
            type="button"
            onClick={() => setPubModalOpen(true)}
            disabled={monthPlannedShifts.length === 0}
            className="h-8.5 px-3 bg-slate-800 hover:bg-slate-750 border border-slate-700/80 text-white font-medium text-xs rounded-md transition-colors cursor-pointer flex items-center justify-center gap-2 disabled:opacity-40 disabled:hover:bg-slate-800 disabled:cursor-not-allowed"
            title="Отправить и опубликовать график"
          >
            <Send className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Отправить график</span>
          </button>
        </div>
      </div>

      {/* KPI Summary Strip (ERP Standard) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 overflow-hidden shadow-sm">
        <div className="p-4 sm:p-4.5">
          <div className="text-xs text-slate-400 font-medium">Запланировано смен</div>
          <div className="text-2xl font-semibold text-white font-mono tabular-nums tracking-tight mt-1">
            {monthPlannedShifts.length} <span className="text-xs font-normal text-slate-500 font-sans">смен</span>
          </div>
          <div className="text-xs text-slate-500 mt-1 truncate">
            На текущий месяц
          </div>
        </div>

        <div className="p-4 sm:p-4.5">
          <div className="text-xs text-slate-400 font-medium">Плановый ФОТ (Оклады)</div>
          <div className="text-2xl font-semibold text-white font-mono tabular-nums tracking-tight mt-1">
            {formatCurrency(estimatedFOT)}
          </div>
          <div className="text-xs text-slate-500 mt-1 truncate">
            Базовые ставки сотрудников
          </div>
        </div>

        {(() => {
          const monthWishes = availability.filter(a => a.date.startsWith(monthStr) && a.type !== 'preferred');
          const approvedCount = monthWishes.filter(a => a.status === 'approved').length;
          const pendingCount = monthWishes.filter(a => !a.status || a.status === 'pending').length;
          const rejectedCount = monthWishes.filter(a => a.status === 'rejected').length;

          return (
            <div
              onClick={() => setWishesModalOpen(true)}
              className="p-4 sm:p-4.5 cursor-pointer hover:bg-slate-850/60 transition-colors group"
              title="Нажмите, чтобы посмотреть пожелания сотрудников"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium group-hover:text-slate-200 transition-colors">
                  Пожелания сотрудников
                </span>
                {pendingCount > 0 && (
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                )}
              </div>
              <div className="text-2xl font-semibold text-white font-mono tabular-nums tracking-tight mt-1">
                {monthWishes.length} <span className="text-xs font-normal text-slate-500 font-sans">запросов</span>
              </div>
              <div className="text-xs text-slate-400 mt-1 truncate">
                {pendingCount > 0 ? (
                  <span className="text-amber-400 font-medium">{pendingCount} ждут решения · Реестр →</span>
                ) : approvedCount > 0 ? (
                  <span>{approvedCount} одобрено · Реестр →</span>
                ) : (
                  <span className="text-slate-500">Нет ограничений · Реестр →</span>
                )}
              </div>
            </div>
          );
        })()}

        <div className="p-4 sm:p-4.5">
          <div className="text-xs text-slate-400 font-medium">Пункты выдачи (ПВЗ)</div>
          <div className="text-2xl font-semibold text-white font-mono tabular-nums tracking-tight mt-1">
            {activePvzs.length} <span className="text-xs font-normal text-slate-500 font-sans">активных</span>
          </div>
          <div className="text-xs text-slate-500 mt-1 truncate">
            Всего локаций в сети
          </div>
        </div>
      </div>

      {/* Control Panel: PVZ Search, Filters & View Switcher */}
      <div className="bg-slate-900 border border-slate-800 p-3 sm:p-4 rounded-lg space-y-3 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          
          {/* PVZ Search & Filters */}
          <div className="flex items-center gap-2 flex-wrap flex-1">
            
            {/* Search Input for 30+ PVZs */}
            <div className="relative min-w-[200px] max-w-xs flex-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Поиск ПВЗ по названию или коду..."
                value={searchPvzQuery}
                onChange={e => setSearchPvzQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
              />
              {searchPvzQuery && (
                <button
                  onClick={() => setSearchPvzQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* Quick PVZ Dropdown/Buttons */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                onClick={() => setSelectedPvzCode('ALL')}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                  selectedPvzCode === 'ALL'
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                Все ({activePvzs.length})
              </button>

              {activePvzs.slice(0, 6).map(pvz => {
                const countForPvz = monthPlannedShifts.filter(s => s.location === pvz.code || s.location === pvz.name).length;
                return (
                  <button
                    key={pvz.id}
                    onClick={() => setSelectedPvzCode(pvz.code)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer flex items-center gap-1 ${
                      selectedPvzCode === pvz.code
                        ? 'bg-emerald-500 text-slate-950 shadow-sm'
                        : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800'
                    }`}
                  >
                    <span>{pvz.code || pvz.name}</span>
                    <span className={`text-[10px] px-1 py-0.1 rounded font-mono ${
                      selectedPvzCode === pvz.code ? 'bg-slate-950/30 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {countForPvz}
                    </span>
                  </button>
                );
              })}

              {activePvzs.length > 6 && (
                <div className="min-w-[140px]">
                  <CustomSelect
                    size="sm"
                    value={selectedPvzCode}
                    onChange={setSelectedPvzCode}
                    placeholder="Ещё ПВЗ..."
                    options={[
                      { value: 'ALL', label: `Все пункты (${activePvzs.length})` },
                      ...activePvzs.map(p => ({
                        value: p.code,
                        label: p.name || p.code,
                        sublabel: p.code,
                      }))
                    ]}
                  />
                </div>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* VIEW 1: Ultra-Compact PVZ Matrix Spreadsheet Table */}
      {viewMode === 'matrix' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          
          {/* Matrix Header Bar */}
          <div className="p-3.5 sm:p-4 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2 bg-slate-900/90">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="text-xs font-semibold text-white uppercase tracking-wider">
                Матрица смен ПВЗ ({filteredPvzs.length} пунктов · {monthName})
              </span>
            </div>

            <div className="flex items-center gap-3 text-[11px] text-slate-400 flex-wrap">
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Вышел (Факт)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400"></span> Запланирован (План)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span> Пожелание / Занят
              </span>
            </div>
          </div>

          {/* Matrix Table Container with Fixed Headers */}
          <div className="overflow-x-auto max-w-full">
            <table className="w-full border-collapse text-left text-xs">
              
              {/* Table Header: Days of Month (1..31) */}
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/90 text-slate-400 font-mono text-[10px]">
                  {/* Sticky Column: PVZ Title */}
                  <th className="sticky left-0 z-20 bg-slate-950 p-2.5 min-w-[180px] max-w-[200px] border-r border-slate-800 font-semibold uppercase tracking-wider text-slate-300">
                    Пункт выдачи (ПВЗ)
                  </th>

                  {/* Day Columns */}
                  {daysList.map(d => {
                    const isWeekend = d.dayOfWeek === 0 || d.dayOfWeek === 6;
                    return (
                      <th
                        key={d.dateStr}
                        className="p-2 text-center min-w-[90px] w-[90px] border-r border-slate-855/60 font-medium"
                      >
                        <div className={`font-semibold text-xs ${isWeekend ? 'text-rose-400' : 'text-slate-200'}`}>
                          {d.dayNum}
                        </div>
                        <div className={`text-[9px] uppercase font-sans font-medium ${isWeekend ? 'text-rose-400/90' : 'text-slate-500'}`}>
                          {d.dayName}
                        </div>
                      </th>
                    );
                  })}
                </tr>
              </thead>

              {/* Table Body: 1 Row per PVZ */}
              <tbody className="divide-y divide-slate-800/80">
                {filteredPvzs.length === 0 ? (
                  <tr>
                    <td colSpan={daysList.length + 1} className="p-8 text-center text-slate-500 text-xs italic">
                      Пункт выдачи по запросу не найден. Измените поиск или сбросьте фильтр.
                    </td>
                  </tr>
                ) : (
                  filteredPvzs.map(pvz => {
                    const eligibleStaff = getStaffForPvz(pvz.code);

                    return (
                      <tr key={pvz.id} className="hover:bg-slate-850/40 transition-colors">
                        
                        {/* Sticky Left PVZ Cell */}
                        <td className="sticky left-0 z-20 bg-slate-900 border-r border-slate-800 p-2.5 min-w-[180px] max-w-[200px] space-y-1 shadow-[2px_0_10px_rgba(0,0,0,0.5)]">
                          <div className="flex items-center justify-between gap-1">
                            <span className="font-semibold text-white text-xs truncate" title={pvz.name || pvz.code}>
                              {pvz.name || pvz.code}
                            </span>
                            <span className="px-1.5 py-0.2 rounded bg-slate-800 text-emerald-400 font-mono text-[9px] font-medium shrink-0">
                              {pvz.code}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5 flex-wrap gap-1">
                            <span className="truncate">Доступно: {eligibleStaff.length} чел.</span>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                onClick={() => openGeneratorModal(pvz.code)}
                                className="text-[10px] text-emerald-400 hover:underline font-medium flex items-center gap-0.5 cursor-pointer"
                                title="Сверстать график для этого ПВЗ"
                              >
                                <SlidersHorizontal className="w-2.5 h-2.5" />
                                <span>Сверстать</span>
                              </button>
                              <button
                                onClick={() => setViewPvzCalendar(pvz)}
                                className="text-[10px] text-sky-400 hover:underline font-medium flex items-center gap-0.5 cursor-pointer"
                                title="Посмотреть график ПВЗ в виде календаря"
                              >
                                <CalendarIcon className="w-2.5 h-2.5" />
                                <span>Посмотреть</span>
                              </button>
                            </div>
                          </div>
                        </td>

                        {/* Day Cells for this PVZ */}
                        {daysList.map(d => {
                          const isWeekend = d.dayOfWeek === 0 || d.dayOfWeek === 6;

                          // Find all shifts for this date & PVZ
                          const plans = monthPlannedShifts.filter(
                            s => s.date === d.dateStr && (s.location === pvz.code || s.location === pvz.name)
                          );

                          return (
                            <td
                              key={d.dateStr}
                              onClick={() => openEditSlotModal(d.dateStr, pvz.code)}
                              className={`p-1.5 text-center min-w-[95px] w-[95px] border-r border-slate-850/60 align-middle cursor-pointer transition-all hover:bg-slate-800/80 group ${
                                isWeekend ? 'bg-slate-950/30' : ''
                              }`}
                            >
                              {plans.length > 0 ? (
                                <div className="space-y-1 w-full h-full flex flex-col justify-center">
                                  {plans.map(plan => {
                                    const fact = records.find(
                                      r => r.date === d.dateStr && r.employeeId === plan.employeeId && (r.location === pvz.code || r.location === pvz.name)
                                    );
                                    const staff = staffList.find(s => s.id === plan.employeeId);
                                    return (
                                      <div key={plan.id} className={`p-1 rounded-lg border text-left flex flex-col justify-between transition-all shadow-sm ${
                                        fact
                                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                                          : 'bg-slate-950/90 border-slate-800 group-hover:border-slate-700 text-slate-200'
                                      }`}>
                                        <div className="flex items-center justify-between gap-1">
                                          <span className="font-medium text-[10px] truncate" title={plan.employeeName}>
                                            {formatShortName(plan.employeeName)}
                                          </span>
                                          {fact ? (
                                            <CheckCircle className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                                          ) : (
                                            <span className="w-1.5 h-1.5 rounded-full bg-sky-400 shrink-0" />
                                          )}
                                        </div>
                                        <div className="flex items-center justify-between text-[8px] text-slate-500 font-mono mt-0.5">
                                          <span>{plan.shiftType.slice(0, 5)}</span>
                                          {staff?.isSenior && (
                                            <span className="px-0.5 bg-sky-500/20 text-sky-400 rounded font-medium">С</span>
                                          )}
                                          {staff?.isPartTime && (
                                            <span className="px-0.5 bg-amber-500/20 text-amber-400 rounded font-medium">П</span>
                                          )}
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              ) : (
                                <div className="h-10 flex flex-col items-center justify-center text-slate-600 hover:text-emerald-400 hover:bg-slate-950/50 rounded-lg border border-transparent hover:border-slate-800 transition-all">
                                  <Plus className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                                  <span className="text-[10px] text-slate-600 font-mono group-hover:hidden">—</span>
                                </div>
                              )}
                            </td>
                          );
                        })}

                      </tr>
                    );
                  })
                )}
              </tbody>

            </table>
          </div>

        </div>
      )}

      {/* MODAL 1: Generator Wizard («Сверстать график») */}
      {genModalOpen && (
        <ScheduleGeneratorWizardModal
          isOpen={genModalOpen}
          onClose={() => {
            setGenModalOpen(false);
            setGenLocation("");
          }}
          monthStr={monthStr}
          monthName={monthName}
          daysList={daysList}
          activePvzs={activePvzs}
          staffList={staffList}
          availability={availability}
          getStaffForPvz={getStaffForPvz}
          existingShifts={schedules}
          swapRequests={swaps}
          initialPvz={genLocation}
          loading={loading}
          onApplySchedule={async (shifts, tpl) => {
            setLoading(true);
            try {
              const targetLoc = shifts[0]?.location || genLocation;
              const promises: Promise<any>[] = [
                saveScheduleBatch(shifts, { replaceMonth: monthStr, replaceLocation: targetLoc })
              ];
              if (tpl) {
                promises.push(saveScheduleTemplate(tpl));
              }
              const [res] = await Promise.all(promises);
              if (res?.success) {
                const msg = `График смен успешно сверстан и сохранен (${shifts.length} смен)!`;
                setPubSuccessMsg(msg);
                setTimeout(() => {
                  setPubSuccessMsg(prev => prev === msg ? '' : prev);
                }, 3500);
              }
            } finally {
              setLoading(false);
              setGenModalOpen(false);
              setGenLocation("");
            }
          }}
        />
      )}

      {/* MODAL 2: Saved Scenarios Modal */}
      {tplModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            
            <div className="flex items-center justify-between p-4 sm:p-5 shrink-0">
              <div className="flex items-center gap-2 text-base font-semibold text-white">
                <Bookmark className="w-5 h-5 text-amber-400" />
                <span>Сохраненные сценарии графиков ПВЗ</span>
              </div>
              <button
                onClick={() => setTplModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-3 text-xs flex-1 overflow-y-auto">
              {scheduleTemplates.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs italic bg-slate-950/60 rounded-xl">
                  Сохраненных сценариев пока нет. При верстке графика через Мастер отметьте галочку «Сохранить сценарий», чтобы быстро применять его в будущем.
                </div>
              ) : (
                scheduleTemplates.map(tpl => (
                  <div key={tpl.id} className="p-3.5 bg-slate-950/90 rounded-2xl flex items-center justify-between gap-3 shadow-sm">
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white text-xs">{tpl.name}</span>
                        <span className="px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 text-[10px] font-mono font-medium">
                          ПВЗ {tpl.location}
                        </span>
                        <span className="text-[10px] text-slate-400 bg-slate-850 px-2 py-0.5 rounded-lg">{tpl.scenarioType}</span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Сотрудники: {tpl.mainStaffIds.map((id: string) => staffList.find(s => s.id === id)?.name || id).join(', ')}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleApplyTemplate(tpl)}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-lg transition-colors cursor-pointer text-xs"
                      >
                        Запустить
                      </button>
                      <button
                        onClick={() => deleteScheduleTemplate(tpl.id)}
                        className="p-1.5 text-rose-400 hover:bg-rose-950/40 rounded-lg cursor-pointer"
                        title="Удалить сценарий"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

          </div>
        </div>
      )}

      {/* MODAL: Employee Wishes Registry with Approval / Rejection Controls */}
      {wishesModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 rounded-2xl w-full max-w-3xl max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            
            {/* Modal Header - Borderless */}
            <div className="p-3.5 sm:p-5 shrink-0 bg-slate-900/95 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm sm:text-base font-semibold text-white flex items-center gap-2">
                      <span>Пожелания сотрудников по графику</span>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-800 text-amber-400 font-mono border border-slate-750">
                        {monthName}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Одобряйте или отклоняйте пожелания. В график попадут только одобренные даты!
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setWishesModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl cursor-pointer transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Status Filter Tabs & Bulk Actions */}
              {(() => {
                const monthWishes = availability.filter(a => a.date.startsWith(monthStr) && a.type !== 'preferred');
                const pendingWishes = monthWishes.filter(a => !a.status || a.status === 'pending');
                const approvedWishes = monthWishes.filter(a => a.status === 'approved');
                const rejectedWishes = monthWishes.filter(a => a.status === 'rejected');

                return (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
                    {/* Filter Tabs - Borderless */}
                    <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                      {[
                        { id: 'all', label: 'Все', count: monthWishes.length },
                        { id: 'pending', label: 'Ожидают', count: pendingWishes.length },
                        { id: 'approved', label: 'Одобрены', count: approvedWishes.length },
                        { id: 'rejected', label: 'Отклонены', count: rejectedWishes.length },
                      ].map(tab => {
                        const active = wishesFilterStatus === tab.id;
                        return (
                          <button
                            key={tab.id}
                            type="button"
                            onClick={() => setWishesFilterStatus(tab.id as any)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                              active
                                ? 'bg-emerald-500 text-slate-950 font-medium shadow-sm'
                                : 'bg-slate-800 hover:bg-slate-750 text-slate-300'
                            }`}
                          >
                            <span>{tab.label}</span>
                            <span className={`px-1.5 py-0.2 rounded-md font-mono text-[10px] ${
                              active ? 'bg-slate-950/20 text-slate-950 font-medium' : 'bg-slate-900 text-slate-400'
                            }`}>
                              {tab.count}
                            </span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Quick Batch Actions - Borderless */}
                    {pendingWishes.length > 0 && (
                      <div className="flex items-center gap-1.5 self-end sm:self-auto">
                        <button
                          type="button"
                          onClick={() => handleBatchSetWishesStatus(pendingWishes.map(w => w.id), 'approved')}
                          className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer transition-all shadow-sm active:scale-95"
                          title="Одобрить все оставшиеся нерассмотренные пожелания"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Одобрить все ({pendingWishes.length})</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            {/* Modal Body */}
            <div className="p-3.5 sm:p-5 space-y-4 text-xs flex-1 overflow-y-auto">
              {(() => {
                const monthWishes = availability.filter(a => a.date.startsWith(monthStr) && a.type !== 'preferred');
                if (monthWishes.length === 0) {
                  return (
                    <div className="p-8 text-center text-slate-500 bg-slate-950/60 rounded-2xl space-y-2">
                      <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto opacity-80" />
                      <div className="text-sm font-semibold text-slate-300">В этом месяце пожеланий нет</div>
                      <p className="text-xs text-slate-500 max-w-sm mx-auto">
                        Все сотрудники доступны для работы в любые дни месяца без ограничений.
                      </p>
                    </div>
                  );
                }

                // Filter by selected tab
                const filteredWishes = monthWishes.filter(w => {
                  if (wishesFilterStatus === 'pending') return !w.status || w.status === 'pending';
                  if (wishesFilterStatus === 'approved') return w.status === 'approved';
                  if (wishesFilterStatus === 'rejected') return w.status === 'rejected';
                  return true;
                });

                if (filteredWishes.length === 0) {
                  return (
                    <div className="p-8 text-center text-slate-500 bg-slate-950/60 rounded-2xl space-y-2">
                      <Info className="w-8 h-8 text-slate-400 mx-auto opacity-60" />
                      <div className="text-sm font-semibold text-slate-300">Нет записей в этой категории</div>
                      <p className="text-xs text-slate-500">
                        {wishesFilterStatus === 'pending'
                          ? 'Все пожелания сотрудников уже рассмотрены!'
                          : wishesFilterStatus === 'approved'
                          ? 'Пока нет одобренных пожеланий.'
                          : 'Нет отклоненных пожеланий.'}
                      </p>
                    </div>
                  );
                }

                // Group by employee
                const wishesByStaff: Record<string, typeof filteredWishes> = {};
                filteredWishes.forEach(w => {
                  if (!wishesByStaff[w.employeeId]) {
                    wishesByStaff[w.employeeId] = [];
                  }
                  wishesByStaff[w.employeeId].push(w);
                });

                return (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                      <span>Сотрудников в списке: <strong className="font-semibold text-white">{Object.keys(wishesByStaff).length}</strong></span>
                      <span>Отображено заявок: <strong className="font-semibold text-amber-400 font-mono">{filteredWishes.length}</strong></span>
                    </div>

                    <div className="space-y-3">
                      {Object.entries(wishesByStaff).map(([stId, stWishes]) => {
                        const staff = staffList.find(s => s.id === stId);
                        const sortedWishes = [...stWishes].sort((a, b) => a.date.localeCompare(b.date));
                        const staffPending = sortedWishes.filter(w => !w.status || w.status === 'pending');

                        return (
                          <div
                            key={stId}
                            className="p-3.5 bg-slate-950/80 rounded-2xl space-y-2.5 shadow-sm"
                          >
                            {/* Staff Header + Quick Actions */}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2">
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-xl bg-slate-800 flex items-center justify-center font-medium text-white text-xs">
                                  {staff?.name ? staff.name[0] : 'С'}
                                </div>
                                <div>
                                  <div className="font-semibold text-white text-sm flex items-center gap-1.5">
                                    <span>{staff?.name || 'Сотрудник'}</span>
                                    {staff?.isSenior && (
                                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold">
                                        Старший
                                      </span>
                                    )}
                                    {staff?.isPartTime && (
                                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300">
                                        Подработка
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-[11px] text-slate-400 font-mono">
                                    {staff?.login || '—'}
                                  </div>
                                </div>
                              </div>

                              {/* Staff Batch Actions */}
                              <div className="flex items-center gap-1.5 self-start sm:self-auto">
                                {staffPending.length > 0 && (
                                  <button
                                    type="button"
                                    onClick={() => handleBatchSetWishesStatus(staffPending.map(w => w.id), 'approved')}
                                    className="px-2.5 py-1 rounded-xl bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-all"
                                    title="Одобрить все нерассмотренные даты этого сотрудника"
                                  >
                                    <Check className="w-3 h-3" />
                                    <span>Одобрить все ({staffPending.length})</span>
                                  </button>
                                )}
                                <span className="text-xs font-mono font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-lg">
                                  {sortedWishes.length} дн.
                                </span>
                              </div>
                            </div>

                            {/* Wish Items List - Borderless Card Rows (like Shift Exchange) */}
                            <div className="grid grid-cols-1 gap-1.5">
                              {sortedWishes.map(w => {
                                const d = daysList.find(day => day.dateStr === w.date);
                                const isApproved = w.status === 'approved';
                                const isRejected = w.status === 'rejected';
                                const isPending = !w.status || w.status === 'pending';
                                const isUpdating = updatingWishId === w.id;
                                const catInfo = getWishCategoryInfo(w.type, w.comment);
                                const commentText = (w.comment || '').trim();
                                const hasDistinctComment = commentText && !commentText.toLowerCase().includes('не мог') && !commentText.toLowerCase().includes('не мож');

                                return (
                                  <div
                                    key={w.id}
                                    className={`p-2.5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 transition-all ${
                                      isApproved
                                        ? 'bg-emerald-950/25 text-emerald-200'
                                        : isRejected
                                        ? 'bg-rose-950/20 text-rose-300 opacity-60'
                                        : 'bg-slate-900/90 hover:bg-slate-850/80'
                                    }`}
                                  >
                                    {/* Date & Reason Info */}
                                    <div className="flex items-center gap-2.5 flex-wrap">
                                      <div className="flex items-center gap-1.5">
                                        <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
                                        <span className="font-mono font-semibold text-white text-xs sm:text-sm">
                                          {w.date.slice(8)} {monthName.slice(0, 3)}
                                        </span>
                                        {d && (
                                          <span className={`text-xs font-medium ${
                                            d.dayOfWeek === 0 || d.dayOfWeek === 6 ? 'text-rose-400' : 'text-slate-400'
                                          }`}>
                                            ({d.dayName})
                                          </span>
                                        )}
                                      </div>

                                      {/* Clear Reason Category (Отпуск, Учеба, Больничный, Личные дела) */}
                                      <div className="flex items-center gap-2 flex-wrap">
                                        <span className={`text-[11px] px-2.5 py-1 rounded-xl font-semibold shrink-0 ${catInfo.badgeClass}`}>
                                          {catInfo.label}
                                        </span>
                                        {hasDistinctComment && (
                                          <span className="text-xs text-slate-300 italic truncate max-w-[260px]" title={commentText}>
                                            «{commentText}»
                                          </span>
                                        )}
                                      </div>

                                      {/* Status Badge */}
                                      {isApproved && (
                                        <span className="px-2.5 py-0.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-[10px] font-medium flex items-center gap-1">
                                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                          <span>Одобрено</span>
                                        </span>
                                      )}
                                      {isRejected && (
                                        <span className="px-2.5 py-0.5 rounded-xl bg-rose-500/20 text-rose-300 text-[10px] font-medium flex items-center gap-1">
                                          <X className="w-3 h-3 text-rose-400" />
                                          <span>Отклонено</span>
                                        </span>
                                      )}
                                      {isPending && (
                                        <span className="px-2.5 py-0.5 rounded-xl bg-amber-500/20 text-amber-300 text-[10px] font-medium flex items-center gap-1">
                                          <Clock className="w-3 h-3 text-amber-400" />
                                          <span>Ожидает</span>
                                        </span>
                                      )}
                                    </div>

                                    {/* Action Buttons: Одобрить / Отклонить - Borderless */}
                                    <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                                      {/* Approve Button */}
                                      <button
                                        type="button"
                                        disabled={isUpdating || isApproved}
                                        onClick={() => handleSetWishStatus(w.id, 'approved')}
                                        className={`h-7 w-7 sm:w-auto px-0 sm:px-2.5 py-0.5 rounded-lg text-[11px] flex items-center justify-center gap-1 transition-all cursor-pointer ${
                                          isApproved
                                            ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm shadow-emerald-950/40 cursor-default'
                                            : 'bg-slate-800 hover:bg-emerald-500/20 text-slate-400 hover:text-emerald-300 font-medium active:scale-95'
                                        }`}
                                        title="Одобрить пожелание (будет учтено в мастере верстки)"
                                      >
                                        <Check className="w-3.5 h-3.5 sm:w-3 sm:h-3" />
                                        <span className="hidden sm:inline">Одобрить</span>
                                      </button>

                                      {/* Reject Button */}
                                      <button
                                        type="button"
                                        disabled={isUpdating || isRejected}
                                        onClick={() => handleSetWishStatus(w.id, 'rejected')}
                                        className={`h-7 w-7 sm:w-auto px-0 sm:px-2.5 py-0.5 rounded-lg text-[11px] flex items-center justify-center gap-1 transition-all cursor-pointer ${
                                          isRejected
                                            ? 'bg-rose-500 text-white font-semibold shadow-sm shadow-rose-950/40 cursor-default'
                                            : 'bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 font-medium active:scale-95'
                                        }`}
                                        title="Отклонить пожелание (не будет учитываться при верстке)"
                                      >
                                        <X className="w-3.5 h-3.5 sm:w-3 sm:h-3" />
                                        <span className="hidden sm:inline">Отклонить</span>
                                      </button>

                                      {/* Reset to Pending if already decided */}
                                      {!isPending && (
                                        <button
                                          type="button"
                                          disabled={isUpdating}
                                          onClick={() => handleSetWishStatus(w.id, 'pending')}
                                          className="h-7 w-7 p-0 text-slate-400 hover:text-amber-300 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer flex items-center justify-center shrink-0"
                                          title="Вернуть на рассмотрение (сбросить выбор)"
                                        >
                                          <RefreshCw className="w-3.5 h-3.5 sm:w-3 sm:h-3" />
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Modal Footer */}
            <div className="p-3.5 sm:p-4 border-t border-slate-800 bg-slate-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 shrink-0">
              <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Одобренные пожелания сразу исключаются из назначения смен на Шаге 3</span>
              </div>
              <div className="flex items-center gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setWishesModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-medium cursor-pointer transition-colors"
                >
                  Закрыть
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setWishesModalOpen(false);
                    setGenLocation(selectedPvzCode === 'ALL' ? '' : selectedPvzCode);
                    setGenModalOpen(true);
                  }}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl text-xs cursor-pointer transition-all flex items-center gap-1.5 shadow-md active:scale-95"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Сверстать график с учётом пожеланий</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* MODAL 3: Quick Edit Slot Modal */}
      {editModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            
            <div className="flex items-center justify-between p-4 border-b border-slate-800 shrink-0">
              <div className="text-sm font-semibold text-white flex items-center gap-2">
                <CalendarCheck className="w-4 h-4 text-emerald-400" />
                <span>Назначение смены: {modalDate} (ПВЗ {modalLocation})</span>
              </div>
              <button
                onClick={() => setEditModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSlot} className="p-4 space-y-3.5 text-xs flex-1 overflow-y-auto">
              {slotModalError && (
                <div className="p-3 bg-rose-950/80 border border-rose-500/50 rounded-xl flex items-center gap-2 text-xs text-rose-200 animate-fade-in shadow-md">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{slotModalError}</span>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-slate-300 font-semibold">
                    Назначить сотрудников (ПВЗ {modalLocation}):
                  </label>
                  <button
                    type="button"
                    onClick={() => setModalEmployeeIds([])}
                    className="text-[ text-rose-400 hover:text-rose-300 px]$2font-medium hover:underline cursor-pointer"
                  >
                    Сбросить / Отменить всех
                  </button>
                </div>

                <div className="p-2 bg-slate-950 border border-slate-800 rounded-xl overflow-y-auto max-h-48 space-y-1.5">
                  {getStaffForPvz(modalLocation).length === 0 ? (
                    <div className="text-slate-500 italic p-4 text-center">
                      Нет закрепленных сотрудников за ПВЗ {modalLocation}
                    </div>
                  ) : (
                    getStaffForPvz(modalLocation).map(s => {
                      const isSelected = modalEmployeeIds.includes(s.id);
                      const isUnavail = availability.some(a => a.employeeId === s.id && a.date === modalDate);

                      const targetPvz = activePvzs.find(p => p.code === modalLocation || p.name === modalLocation || p.id === modalLocation);
                      const targetLocCode = targetPvz?.code || modalLocation;
                      const targetLocName = targetPvz?.name || modalLocation;

                      // Enforce rule: if employee already has a shift on modalDate at another PVZ
                      const otherPvzShift = schedules.find(
                        sch => sch.employeeId === s.id &&
                               sch.date === modalDate &&
                               sch.location !== targetLocCode &&
                               sch.location !== targetLocName &&
                               sch.location !== targetPvz?.id
                      );

                      return (
                        <button
                          key={s.id}
                          type="button"
                          disabled={Boolean(otherPvzShift)}
                          onClick={() => {
                            if (otherPvzShift) return;
                            if (isSelected) {
                              setModalEmployeeIds(prev => prev.filter(id => id !== s.id));
                            } else {
                              setModalEmployeeIds(prev => [...prev, s.id]);
                            }
                          }}
                          className={`w-full py-2 px-3 rounded-xl border transition-all flex items-center justify-between text-xs ${
                            otherPvzShift
                              ? 'bg-rose-950/20 border-rose-900/40 text-slate-500 cursor-not-allowed opacity-60'
                              : isSelected
                              ? 'bg-emerald-950/90 border-emerald-500 text-emerald-300 font-semibold shadow-sm cursor-pointer'
                              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white cursor-pointer'
                          }`}
                          title={
                            otherPvzShift
                              ? `Сотрудник уже назначен на смену в ПВЗ ${otherPvzShift.location} на дату ${modalDate}. Добавление в другой пункт невозможно!`
                              : undefined
                          }
                        >
                          <div className="flex flex-col items-start min-w-0">
                            <span className="truncate font-semibold">{s.name}</span>
                            {otherPvzShift ? (
                              <span className="text-[ text-rose-400 px]$2font-medium flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
                                <span>На смене в {otherPvzShift.location}</span>
                              </span>
                            ) : isUnavail ? (
                              <span className="text-[10px] text-amber-400 font-medium truncate max-w-[220px] flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
                                <span>{(() => {
                                  const wishObj = availability.find(a => a.employeeId === s.id && a.date === modalDate);
                                  if (!wishObj) return 'Пожелание по графику';
                                  return getWishReasonLabel(wishObj.type, wishObj.comment);
                                })()}</span>
                              </span>
                            ) : null}
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {s.isSenior && (
                              <span className="px-1.5 py-0.2 bg-sky-500/20 text-sky-400 rounded-md text-xs $2font-medium">
                                Ст.С.
                              </span>
                            )}
                            {otherPvzShift ? (
                              <span className="text-[ text-rose-300 font-mono px]$2font-medium px-1.5 py-0.5 rounded-md bg-rose-500/20">
                                Занят
                              </span>
                            ) : isSelected ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : (
                              <div className="w-4 h-4 rounded-full border border-slate-750 shrink-0" />
                            )}
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Категория смены:</label>
                <CustomSelect<ShiftType>
                  value={modalShiftType}
                  onChange={v => setModalShiftType(v)}
                  menuHeaderTitle="Категория смены"
                  options={[
                    { value: 'standard', label: 'Стандартная смена' },
                    { value: 'rate400', label: '400+' },
                    { value: 'rate500', label: '500+' },
                    { value: 'shift8h', label: '8 часов' },
                    { value: 'shift4h', label: '4 часа' },
                  ]}
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Заметка / комментарий:</label>
                <input
                  type="text"
                  placeholder="Например, усиление в час пик"
                  value={modalNote}
                  onChange={e => setModalNote(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 focus:border-emerald-500 rounded-xl text-white text-xs focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {loading ? 'Сохранение...' : (isEditingSlot ? 'Сохранить' : 'Назначить смену')}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* MODAL 4: Publish Confirmation Modal */}
      {pubModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            
            <div className="p-5 space-y-4 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-500/10 text-sky-400 flex items-center justify-center shrink-0 border border-sky-500/30">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">Опубликовать график сотрудникам?</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Утверждение графиков смен на {monthName}
                  </p>
                </div>
              </div>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 text-slate-300">
                <div className="flex items-center justify-between font-medium">
                  <span>Запланировано смен:</span>
                  <strong className="text-white font-mono">{monthPlannedShifts.length}</strong>
                </div>
                <div className="flex items-center justify-between font-medium">
                  <span>Охват ПВЗ:</span>
                  <strong className="text-white">{selectedPvzCode === 'ALL' ? 'Все ПВЗ' : selectedPvzCode}</strong>
                </div>
                <div className="text-[11px] text-slate-400 pt-1 border-t border-slate-850">
                  После публикации все сотрудники моментально увидят свои плановые смены в мобильном личнком кабинете в «Календаре отработанных смен».
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setPubModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="button"
                  disabled={loading}
                  onClick={handlePublishSchedule}
                  className="px-5 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold rounded-xl shadow-md cursor-pointer transition-colors"
                >
                  {loading ? 'Рассылка...' : 'Утвердить и отправить'}
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* MODAL 5: PVZ Calendar Viewer with editing/deleting controls */}
      {viewPvzCalendar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[95dvh] sm:max-h-[92vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-900 shrink-0 flex items-center justify-between gap-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-500/10 border border-sky-500/30 text-sky-400 flex items-center justify-center shrink-0">
                  <CalendarIcon className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-semibold text-white">
                    График смен ПВЗ «{viewPvzCalendar.name || viewPvzCalendar.code}»
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Режим просмотра календаря · {monthName}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewPvzCalendar(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer bg-slate-800/50 hover:bg-slate-800 transition-colors"
                title="Закрыть"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-4 sm:p-5 flex-1 overflow-y-auto space-y-4">
              
              {/* Calendar Days Grid */}
              <div className="grid grid-cols-7 gap-1 text-center shrink-0">
                {/* Days of Week Row */}
                {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(day => (
                  <div key={day} className="py-1 text-[10px] font-medium text-slate-500 uppercase tracking-wider">
                    {day}
                  </div>
                ))}

                {/* Padding Empty Cells */}
                {Array.from({ length: (daysList[0]?.dayOfWeek === 0) ? 6 : (daysList[0]?.dayOfWeek - 1) }).map((_, idx) => (
                  <div key={`pad-${idx}`} className="bg-slate-950/20 rounded-xl min-h-[64px] border border-transparent" />
                ))}

                {/* Day Cells */}
                {daysList.map(d => {
                  const isWeekend = d.dayOfWeek === 0 || d.dayOfWeek === 6;
                  const plans = monthPlannedShifts.filter(
                    s => s.date === d.dateStr && (s.location === viewPvzCalendar.code || s.location === viewPvzCalendar.name)
                  );

                  return (
                    <div
                      key={d.dateStr}
                      className={`p-1.5 rounded-xl border min-h-[84px] text-left flex flex-col justify-between transition-all ${
                        plans.length > 0
                          ? 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                          : 'bg-slate-950/40 border-slate-900/60 hover:border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-xs $2font-medium font-mono ${isWeekend ? 'text-rose-400' : 'text-slate-400'}`}>
                          {d.dayNum}
                        </span>
                        {plans.length > 0 && (
                          <span className="text-[ px-1 bg-sky-500/10 text-sky-400 border border-sky-500/20 rounded-md px]$2font-medium">
                            {plans.length}
                          </span>
                        )}
                      </div>

                      {/* List of Shifts for this Day */}
                      <div className="space-y-1 mt-1 flex-1 overflow-y-auto">
                        {plans.map(plan => (
                          <div
                            key={plan.id}
                            className="px-1.5 py-0.5 bg-slate-900 border border-slate-850 rounded text-[9px] font-semibold text-slate-200 flex items-center justify-between gap-1"
                          >
                            <span className="truncate max-w-[56px] text-slate-200" title={plan.employeeName}>
                              {formatShortName(plan.employeeName)}
                            </span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setShiftToDelete({ id: plan.id, employeeName: plan.employeeName, date: d.dateStr });
                              }}
                              className="p-0.5 text-slate-500 hover:text-rose-400 hover:bg-slate-850 rounded transition-colors shrink-0 cursor-pointer"
                              title="Убрать смену"
                            >
                              <X className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        ))}
                      </div>

                      {/* Add Slot Button */}
                      <button
                        onClick={() => openEditSlotModal(d.dateStr, viewPvzCalendar.code)}
                        className="mt-1 w-full py-0.5 px-1 bg-slate-800/80 hover:bg-emerald-500/20 hover:text-emerald-400 text-[9px] font-semibold rounded-lg flex items-center justify-center gap-0.5 transition-all text-slate-400 cursor-pointer border border-transparent hover:border-emerald-500/10"
                      >
                        <Plus className="w-2.5 h-2.5" />
                        <span>Добавить</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-5 border-t border-slate-800 shrink-0 bg-slate-900 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  setClearMonthConfirmPvz({
                    code: viewPvzCalendar.code,
                    name: viewPvzCalendar.name || viewPvzCalendar.code
                  });
                }}
                disabled={monthPlannedShifts.filter(s => s.location === viewPvzCalendar.code || s.location === viewPvzCalendar.name).length === 0}
                className="px-4 py-2 bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 hover:text-rose-300 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Очистить весь месяц</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportPvzCalendarPdf}
                  disabled={isExportingPvzPdf}
                  className="group px-4 py-2 bg-slate-800 hover:bg-emerald-500 text-slate-200 hover:text-slate-950 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm hover:shadow-lg hover:shadow-emerald-500/25 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  title="Скачать график смен данного ПВЗ в PDF (Календарь, Матрица, Баланс)"
                >
                  {isExportingPvzPdf ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400 group-hover:text-slate-950" />
                      <span>Формирование...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-3.5 h-3.5 text-emerald-400 group-hover:text-slate-950 transition-colors" />
                      <span>Сохранить в PDF</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setViewPvzCalendar(null)}
                  className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl transition-colors cursor-pointer border border-slate-700"
                >
                  Закрыть
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* CONFIRM MODAL: Single Shift Deletion */}
      {shiftToDelete && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Снять со смены?</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Сотрудник: <strong className="text-white">{shiftToDelete.employeeName}</strong>
                </p>
                <p className="text-[11px] text-slate-500">
                  Дата: {shiftToDelete.date}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShiftToDelete(null)}
                className="px-3.5 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl"
              >
                Отмена
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={async () => {
                  setLoading(true);
                  await deletePlannedShift(shiftToDelete.id);
                  setLoading(false);
                  setShiftToDelete(null);
                }}
                className="px-4 py-2 bg-rose-500 hover:bg-rose-400 text-white font-semibold text-xs rounded-xl transition-colors shadow-sm disabled:opacity-50"
              >
                {loading ? 'Удаление...' : 'Да, снять со смены'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM MODAL: Clear All Month Shifts for PVZ */}
      {clearMonthConfirmPvz && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-rose-500/30 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Очистить весь месяц?</h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  ПВЗ «{clearMonthConfirmPvz.name}» · {monthName}
                </p>
              </div>
            </div>

            <p className="text-xs text-rose-300/90 bg-rose-950/40 border border-rose-800/40 p-3 rounded-xl">
              Внимание: Все запланированные смены для этого пункта на данный месяц будут удалены. Это действие необратимо.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setClearMonthConfirmPvz(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-xl"
              >
                Отмена
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={async () => {
                  setLoading(true);
                  await clearMonthSchedules(monthStr, clearMonthConfirmPvz.code);
                  setLoading(false);
                  setClearMonthConfirmPvz(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs rounded-xl transition-colors shadow-sm disabled:opacity-50"
              >
                {loading ? 'Очистка...' : 'Удалить все смены'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
