import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ShiftSwapRequest, ShiftType, LocationType, SHIFT_LABELS } from '../../types';
import { CustomSelect } from '../common/CustomSelect';
import { CustomDatePicker } from '../common/CustomDatePicker';
import { formatDateDDMMYYYY, getShiftLabel } from '../../utils/calculations';
import {
  ArrowLeftRight,
  CheckCircle2,
  XCircle,
  Clock,
  User,
  Calendar,
  MapPin,
  AlertCircle,
  Plus,
  X,
  Send,
  Check,
  Filter,
  Pencil,
  RotateCcw,
  Trash2
} from 'lucide-react';

export const ShiftSwapManagerView: React.FC = () => {
  const {
    swaps,
    staffList,
    approveSwapRequest,
    rejectSwapRequest,
    createSwapRequest,
    cancelSwapRequest,
    updateSwapRequest,
    pickupPoints = [],
    rates,
  } = useApp();

  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'claimed' | 'approved' | 'open'>('all');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [createDate, setCreateDate] = useState(new Date().toISOString().slice(0, 10));
  const [createShiftType, setCreateShiftType] = useState<ShiftType>('standard');
  const [createLocation, setCreateLocation] = useState<LocationType>(pickupPoints[0]?.code || '');
  const [createReason, setCreateReason] = useState('Открытая смена от руководителя');
  const [loading, setLoading] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Manager Editing Modal State
  const [editingSwap, setEditingSwap] = useState<ShiftSwapRequest | null>(null);
  const [cancelConfirmSwap, setCancelConfirmSwap] = useState<ShiftSwapRequest | null>(null);
  const [editDate, setEditDate] = useState('');
  const [editLocation, setEditLocation] = useState<LocationType>(pickupPoints[0]?.code || '');
  const [editShiftType, setEditShiftType] = useState<ShiftType>('standard');
  const [editReason, setEditReason] = useState('');
  const [editStatus, setEditStatus] = useState<ShiftSwapRequest['status']>('approved');
  const [editRequesterId, setEditRequesterId] = useState('');
  const [editCandidateId, setEditCandidateId] = useState('');

  const openEditModal = (sw: ShiftSwapRequest) => {
    setEditingSwap(sw);
    setEditDate(sw.date);
    setEditLocation(sw.location);
    setEditShiftType(sw.shiftType);
    setEditReason(sw.reason || '');
    setEditStatus(sw.status);
    setEditRequesterId(sw.requesterId);
    setEditCandidateId(sw.candidateId || '');
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSwap) return;
    setLoading(true);
    setActionNotice(null);

    const reqUser = staffList.find(s => s.id === editRequesterId);
    const candUser = staffList.find(s => s.id === editCandidateId);

    const res = await updateSwapRequest(editingSwap.id, {
      date: editDate,
      location: editLocation,
      shiftType: editShiftType,
      reason: editReason,
      status: editStatus,
      requesterId: editRequesterId || editingSwap.requesterId,
      requesterName: reqUser ? reqUser.name : editingSwap.requesterName,
      candidateId: editCandidateId || undefined,
      candidateName: editCandidateId ? (candUser ? candUser.name : editingSwap.candidateName) : undefined,
    });
    setLoading(false);
    if (res.success) {
      setActionNotice('Заявка успешно отредактирована!');
      setEditingSwap(null);
      setTimeout(() => setActionNotice(null), 3500);
    }
  };

  const handleReopenToMarket = async (id: string) => {
    setLoading(true);
    setActionNotice(null);
    const res = await updateSwapRequest(id, {
      status: 'open',
      candidateId: undefined,
      candidateName: undefined,
      clearCandidate: true,
    } as any);
    setLoading(false);
    if (res.success) {
      setActionNotice('Заявка переоткрыта и снова размещена на бирже смен!');
      setTimeout(() => setActionNotice(null), 3500);
    }
  };

  const handleCancelByManager = async (id: string) => {
    setLoading(true);
    setActionNotice(null);
    const res = await updateSwapRequest(id, {
      status: 'cancelled',
    });
    setLoading(false);
    if (res.success) {
      setActionNotice('Заявка аннулирована руководителем.');
      setTimeout(() => setActionNotice(null), 3500);
    }
  };

  const pendingSwaps = swaps.filter(s => s.status === 'open' || s.status === 'claimed');
  const claimedSwaps = swaps.filter(s => s.status === 'claimed');
  const approvedSwaps = swaps.filter(s => s.status === 'approved');
  const openSwaps = swaps.filter(s => s.status === 'open');

  const filteredSwaps = swaps.filter(s => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'pending') return s.status === 'open' || s.status === 'claimed';
    if (filterStatus === 'claimed') return s.status === 'claimed';
    if (filterStatus === 'approved') return s.status === 'approved';
    if (filterStatus === 'open') return s.status === 'open';
    return true;
  });

  // Helper to group swaps by date and sort dates ascending (from old to new: e.g. 10th, 11th...)
  const groupSwapsByDateAscending = (list: ShiftSwapRequest[]) => {
    const groups: { [date: string]: ShiftSwapRequest[] } = {};
    list.forEach(item => {
      if (!groups[item.date]) groups[item.date] = [];
      groups[item.date].push(item);
    });
    // Sort dates from old to new (10.10, 11.10, 12.10...)
    const sortedEntries = Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));

    // Sort items inside each date: claimed first, then open/approved
    sortedEntries.forEach(([, items]) => {
      items.sort((a, b) => {
        if (a.status === 'claimed' && b.status !== 'claimed') return -1;
        if (b.status === 'claimed' && a.status !== 'claimed') return 1;
        return 0;
      });
    });

    return sortedEntries;
  };

  // Separate active (open/claimed) and completed (approved/rejected/cancelled)
  const activeList = filteredSwaps.filter(s => s.status === 'open' || s.status === 'claimed');
  const completedList = filteredSwaps.filter(s => s.status === 'approved' || s.status === 'rejected' || s.status === 'cancelled');

  const activeGrouped = groupSwapsByDateAscending(activeList);
  const completedGrouped = groupSwapsByDateAscending(completedList);
  const allFilteredGrouped = groupSwapsByDateAscending(filteredSwaps);

  const handleApprove = async (id: string) => {
    setLoading(true);
    setActionNotice(null);
    const res = await approveSwapRequest(id);
    setLoading(false);
    if (res.success) {
      setActionNotice('Смена успешно утверждена и закреплена за сотрудником!');
      setTimeout(() => setActionNotice(null), 3500);
    }
  };

  const handleReject = async (id: string) => {
    setLoading(true);
    setActionNotice(null);
    const res = await rejectSwapRequest(id);
    setLoading(false);
    if (res.success) {
      setActionNotice('Отклик отклонен. Смена возвращена в открытый статус на биржу.');
      setTimeout(() => setActionNotice(null), 3500);
    }
  };

  const handleCreateOpenShift = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setActionNotice(null);
    const res = await createSwapRequest(createDate, createShiftType, createLocation, createReason);
    setLoading(false);
    if (res.success) {
      setActionNotice('Открытая смена успешно выставлена! Все сотрудники получили push-уведомление.');
      setIsCreateOpen(false);
      setTimeout(() => setActionNotice(null), 3500);
    }
  };

  const handleCancel = async (id: string) => {
    setLoading(true);
    await cancelSwapRequest(id);
    setLoading(false);
  };

  const renderGroupedList = (grouped: [string, ShiftSwapRequest[]][]) => {
    return grouped.map(([grpDate, items]) => (
      <div key={grpDate} className="space-y-2.5">
        {/* Date Group Header in DD-MM-YYYY format */}
        <div className="flex items-center gap-2 px-1">
          <div className="p-1 rounded-md bg-sky-500/10 text-sky-400">
            <Calendar className="w-3.5 h-3.5" />
          </div>
          <h3 className="text-xs font-medium text-slate-300 font-mono tracking-wide">
            Дата смены: {formatDateDDMMYYYY(grpDate)}
          </h3>
          <span className="text-xs text-slate-500 font-mono">({items.length} заявок)</span>
        </div>

        {/* Horizontal Cards List */}
        <div className="flex flex-col gap-2 w-full">
          {items.map(sw => {
            const isClaimed = sw.status === 'claimed';
            const isApproved = sw.status === 'approved';
            const isOpenStatus = sw.status === 'open';

            return (
              <div
                key={sw.id}
                className="p-3 sm:p-3.5 rounded-lg border border-slate-800 bg-slate-900 hover:border-slate-700/80 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3 w-full"
              >
                {/* Column 1: Badges Cluster (Linear / Modern SaaS standard) */}
                <div className="flex items-center gap-1.5 shrink-0 flex-wrap sm:flex-nowrap md:w-[420px] lg:w-[450px]">
                  <span className="px-2 py-1 rounded-md bg-slate-950 border border-slate-800/80 text-white font-mono text-xs font-medium min-w-[85px] justify-center text-center shrink-0 flex items-center">
                    {formatDateDDMMYYYY(sw.date)}
                  </span>

                  <span
                    className="px-2 py-1 rounded-md bg-slate-950 border border-slate-800/80 text-sky-400 font-medium font-mono text-xs min-w-[85px] max-w-[110px] truncate shrink-0 text-center flex items-center justify-center"
                    title={sw.location}
                  >
                    {sw.location}
                  </span>

                  <span className="px-2 py-1 rounded-md bg-slate-950 border border-slate-800/80 text-slate-300 text-xs font-medium shrink-0 min-w-[105px] max-w-[120px] truncate text-center flex items-center justify-center">
                    {getShiftLabel(sw.shiftType, rates)}
                  </span>

                  <span
                    className={`text-xs font-medium px-2.5 py-1 rounded-md truncate shrink-0 min-w-[130px] max-w-[160px] text-center flex items-center justify-center gap-1.5 ${
                      isOpenStatus
                        ? 'bg-sky-500/10 text-sky-700 dark:text-sky-400'
                        : isClaimed
                        ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400'
                        : isApproved
                        ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                        : 'bg-red-500/10 text-red-700 dark:text-red-400'
                    }`}
                    title={
                      isOpenStatus
                        ? 'Открыта на бирже'
                        : isClaimed
                        ? `Откликнулся: ${sw.candidateName}`
                        : isApproved
                        ? `Договорились: ${sw.candidateName || 'Утверждено'}`
                        : 'Отклонено'
                    }
                  >
                    {isOpenStatus
                      ? 'Открыта на бирже'
                      : isClaimed
                      ? `Откликнулся: ${sw.candidateName}`
                      : isApproved
                      ? `Договорились: ${sw.candidateName || 'Утверждено'}`
                      : 'Отклонено'}
                  </span>
                </div>

                {/* Column 2: Participants & Reason Block (Standardized 3-row uniform layout) */}
                <div className="flex-1 min-w-0 space-y-1 px-1 text-xs text-slate-300">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-slate-500 shrink-0 min-w-[65px]">Передает:</span>
                    <strong className="text-white font-medium truncate max-w-[180px]" title={sw.requesterName}>
                      {sw.requesterName}
                    </strong>
                  </div>

                  <div className="flex items-center gap-1.5 truncate">
                    <span className="text-slate-500 shrink-0 min-w-[65px]">
                      {isApproved ? 'Смену забрал:' : 'Откликнулся:'}
                    </span>
                    {sw.candidateName ? (
                      <strong className="text-emerald-400 font-medium truncate max-w-[180px]" title={sw.candidateName}>
                        {sw.candidateName}
                      </strong>
                    ) : (
                      <span className="text-slate-500 italic truncate">— (ожидает отклика)</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 truncate text-[11px]">
                    <span className="text-slate-500 shrink-0 min-w-[65px]">Причина:</span>
                    <span className={`truncate max-w-[240px] ${sw.reason ? 'text-slate-300 italic' : 'text-slate-500'}`} title={sw.reason || '—'}>
                      {sw.reason ? `«${sw.reason}»` : '—'}
                    </span>
                  </div>
                </div>

                {/* Column 3: Manager Action Buttons */}
                <div className="pt-2 md:pt-0 flex items-center justify-end gap-1.5 shrink-0 flex-wrap text-xs">
                  <button
                    type="button"
                    onClick={() => openEditModal(sw)}
                    disabled={loading}
                    className="py-1.5 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/50 rounded-md text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
                    title="Редактировать параметры заявки"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    <span>Редактировать</span>
                  </button>

                  {isApproved && (
                    <button
                      type="button"
                      onClick={() => handleReopenToMarket(sw.id)}
                      disabled={loading}
                      className="py-1.5 px-2.5 bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700/50 rounded-md text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
                      title="Отменить договоренность и вернуть смену на биржу"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                      <span>Вернуть на биржу</span>
                    </button>
                  )}

                  {isClaimed && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleReject(sw.id)}
                        disabled={loading}
                        className="py-1.5 px-2.5 bg-slate-800 hover:bg-red-950/50 text-red-400 border border-slate-700/50 rounded-md text-xs font-medium transition-colors cursor-pointer disabled:opacity-50"
                      >
                        Отклонить
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApprove(sw.id)}
                        disabled={loading}
                        className="py-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-medium rounded-md text-xs flex items-center gap-1 transition-colors shadow-sm cursor-pointer disabled:opacity-50"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Утвердить</span>
                      </button>
                    </>
                  )}

                  {isOpenStatus && (
                    <button
                      type="button"
                      onClick={() => setCancelConfirmSwap(sw)}
                      disabled={loading}
                      className="py-1.5 px-2.5 text-xs text-slate-400 hover:text-red-400 hover:bg-slate-800/80 rounded-md transition-colors cursor-pointer"
                    >
                      Снять с биржи
                    </button>
                  )}

                  {isApproved && (
                    <button
                      type="button"
                      onClick={() => setCancelConfirmSwap(sw)}
                      disabled={loading}
                      className="py-1.5 px-2.5 text-xs text-slate-400 hover:text-red-400 hover:bg-slate-800/80 rounded-md transition-colors cursor-pointer"
                      title="Аннулировать закрытую заявку"
                    >
                      Аннулировать
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    ));
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-semibold text-white tracking-tight flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-sky-400" />
            <span>Биржа смен и подмен</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Все запросы сотрудников на обмен сменами, отклики, согласования и открытые смены сети
          </p>
        </div>

        <button
          onClick={() => setIsCreateOpen(true)}
          className="flex items-center gap-1.5 py-1.5 px-3 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-md text-xs font-medium transition-colors shadow-sm self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Выставить открытую смену</span>
        </button>
      </div>

      {actionNotice && (
        <div className="p-3 bg-slate-900 text-white border border-emerald-500/50 rounded-lg text-xs flex items-center gap-2 shadow-md">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <span className="text-white font-medium">{actionNotice}</span>
        </div>
      )}

      {/* KPI & Status Filter Tabs: Segmented Control */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 w-fit">
        <button
          type="button"
          onClick={() => setFilterStatus('all')}
          className={`py-1.5 px-3 rounded-md text-xs font-medium transition-colors cursor-pointer ${
            filterStatus === 'all'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
          }`}
        >
          Все заявки ({swaps.length})
        </button>
        <button
          type="button"
          onClick={() => setFilterStatus('claimed')}
          className={`py-1.5 px-3 rounded-md text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
            filterStatus === 'claimed'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
          }`}
        >
          <span>Есть отклики ({claimedSwaps.length})</span>
          {claimedSwaps.length > 0 && filterStatus !== 'claimed' && (
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          )}
        </button>
        <button
          type="button"
          onClick={() => setFilterStatus('open')}
          className={`py-1.5 px-3 rounded-md text-xs font-medium transition-colors cursor-pointer ${
            filterStatus === 'open'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
          }`}
        >
          Ищут замену ({openSwaps.length})
        </button>
        <button
          type="button"
          onClick={() => setFilterStatus('approved')}
          className={`py-1.5 px-3 rounded-md text-xs font-medium transition-colors cursor-pointer ${
            filterStatus === 'approved'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
          }`}
        >
          Договорились / Одобрено ({approvedSwaps.length})
        </button>
      </div>

      {/* Grouped Requests by Date */}
      <div className="space-y-6">
        {filterStatus === 'all' ? (
          <>
            {/* Active Requests Section at TOP */}
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2">
                <div className="text-xs font-medium text-amber-400 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                  <span>Активные заявки (на бирже и ждут подтверждения) — {activeList.length}</span>
                </div>
              </div>

              {activeGrouped.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 border border-slate-800 rounded-lg">
                  Активных заявок в данный момент нет.
                </div>
              ) : (
                renderGroupedList(activeGrouped)
              )}
            </div>

            {/* Completed Requests Section BELOW */}
            <div className="space-y-4 pt-4">
              <div className="flex items-center justify-between pb-2">
                <div className="text-xs font-medium text-sky-400 uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-400" />
                  <span>Завершённые и закрытые заявки — {completedList.length}</span>
                </div>
              </div>

              {completedGrouped.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 border border-slate-800 rounded-lg">
                  Завершённых и закрытых заявок пока нет.
                </div>
              ) : (
                renderGroupedList(completedGrouped)
              )}
            </div>
          </>
        ) : (
          /* When a specific filter tab is selected */
          allFilteredGrouped.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 bg-slate-900 border border-slate-800 rounded-lg">
              Заявок по выбранному фильтру не найдено.
            </div>
          ) : (
            renderGroupedList(allFilteredGrouped)
          )
        )}
      </div>

      {/* Create Open Shift Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 shrink-0">
              <div className="text-sm font-semibold text-white flex items-center gap-2">
                <ArrowLeftRight className="w-4 h-4 text-sky-400" />
                <span>Выставить открытую смену на биржу</span>
              </div>
              <button
                onClick={() => setIsCreateOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-md cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateOpenShift} className="p-4 space-y-3.5 text-xs flex-1 overflow-y-auto">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Дата смены:</label>
                <CustomDatePicker
                  value={createDate}
                  onChange={v => setCreateDate(v)}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Пункт:</label>
                  <CustomSelect<LocationType>
                    value={createLocation}
                    onChange={v => setCreateLocation(v)}
                    menuHeaderTitle="Пункт выдачи"
                    options={(pickupPoints || []).map(pt => ({
                      value: pt.code as LocationType,
                      label: pt.code,
                      sublabel: pt.name && pt.name !== pt.code ? pt.name : undefined,
                    }))}
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Категория:</label>
                  <CustomSelect<ShiftType>
                    value={createShiftType}
                    onChange={v => setCreateShiftType(v)}
                    align="right"
                    menuHeaderTitle="Категория смены"
                    options={[
                      { value: 'standard', label: 'Обычная смена' },
                      { value: '400+', label: 'Смена 400+' },
                      { value: '500+', label: 'Смена 500+' },
                      { value: '8h', label: 'Смена 8 часов' },
                      { value: '4h', label: 'Смена 4 часа' },
                    ]}
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Описание / Примечание:</label>
                <input
                  type="text"
                  value={createReason}
                  onChange={e => setCreateReason(e.target.value)}
                  placeholder="Заметка или причина создания смены"
                  className="w-full h-9 px-3 py-1.5 bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/30 rounded-md text-white text-xs focus:outline-none transition-colors"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-3.5 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/60 rounded-md transition-colors cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-3.5 py-1.5 text-xs font-medium bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-md transition-colors shadow-sm disabled:opacity-50 cursor-pointer"
                >
                  {loading ? 'Публикация...' : 'Опубликовать смену'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Swap Modal */}
      {editingSwap && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-lg max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 shrink-0">
              <div className="text-sm font-semibold text-white flex items-center gap-2">
                <Pencil className="w-4 h-4 text-sky-400" />
                <span>Редактирование заявки биржи</span>
              </div>
              <button
                onClick={() => setEditingSwap(null)}
                className="p-1 text-slate-400 hover:text-white rounded-md cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-4 space-y-3.5 text-xs flex-1 overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Дата смены:</label>
                  <CustomDatePicker
                    value={editDate}
                    onChange={v => setEditDate(v)}
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Пункт выдачи:</label>
                  <CustomSelect<LocationType>
                    value={editLocation}
                    onChange={v => setEditLocation(v)}
                    menuHeaderTitle="Пункт выдачи"
                    options={(pickupPoints || []).map(pt => ({
                      value: pt.code as LocationType,
                      label: pt.code,
                      sublabel: pt.name && pt.name !== pt.code ? pt.name : undefined,
                    }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Категория смены:</label>
                  <CustomSelect<ShiftType>
                    value={editShiftType}
                    onChange={v => setEditShiftType(v)}
                    menuHeaderTitle="Категория смены"
                    options={[
                      { value: 'standard', label: 'Обычная смена' },
                      { value: '400+', label: 'Смена 400+' },
                      { value: '500+', label: 'Смена 500+' },
                      { value: '8h', label: 'Смена 8 часов' },
                      { value: '4h', label: 'Смена 4 часа' },
                    ]}
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Статус заявки:</label>
                  <CustomSelect<ShiftSwapRequest['status']>
                    value={editStatus}
                    onChange={v => setEditStatus(v)}
                    menuHeaderTitle="Статус заявки"
                    options={[
                      { value: 'approved', label: 'Договорились (Утверждено)' },
                      { value: 'claimed', label: 'Откликнулся (Ожидает)' },
                      { value: 'open', label: 'Открыта на бирже' },
                      { value: 'cancelled', label: 'Аннулирована' },
                    ]}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Инициатор (кто передает):</label>
                  <CustomSelect<string>
                    value={editRequesterId}
                    onChange={v => setEditRequesterId(v)}
                    menuHeaderTitle="Инициатор смены"
                    options={staffList.map(st => ({
                      value: st.id,
                      label: st.name,
                      sublabel: st.isSenior ? 'Старший сотрудник' : st.login,
                    }))}
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Кто забирает / выходит:</label>
                  <CustomSelect<string>
                    value={editCandidateId}
                    onChange={v => setEditCandidateId(v)}
                    menuHeaderTitle="Исполнитель смены"
                    options={[
                      { value: '', label: '— Без исполнителя (Открытая) —' },
                      ...staffList.map(st => ({
                        value: st.id,
                        label: st.name,
                        sublabel: st.isSenior ? 'Старший сотрудник' : st.login,
                      })),
                    ]}
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Причина / Заметка:</label>
                <input
                  type="text"
                  value={editReason}
                  onChange={e => setEditReason(e.target.value)}
                  placeholder="Заметка или причина изменения"
                  className="w-full h-9 px-3 py-1.5 bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/30 rounded-md text-white text-xs focus:outline-none transition-colors"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => setEditingSwap(null)}
                  className="px-3.5 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/60 rounded-md transition-colors cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-3.5 py-1.5 text-xs font-medium bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-md transition-colors shadow-sm disabled:opacity-50 cursor-pointer"
                >
                  {loading ? 'Сохранение...' : 'Сохранить изменения'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Annul Confirmation Modal */}
      {cancelConfirmSwap && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-lg w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl p-5 space-y-4 my-auto">
            <div className="flex items-center gap-2.5 text-red-400 font-semibold text-sm pb-2 border-b border-slate-800/80 shrink-0">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>Подтверждение аннулирования заявки</span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Вы действительно хотите аннулировать заявку на смену за{' '}
              <strong className="text-white font-mono">{formatDateDDMMYYYY(cancelConfirmSwap.date)}</strong>{' '}
              на пункте <strong className="text-white font-mono">{cancelConfirmSwap.location}</strong>?
              {cancelConfirmSwap.candidateName && (
                <span className="block mt-1.5 text-slate-400">
                  Закрепленный сотрудник: <strong className="text-emerald-400">{cancelConfirmSwap.candidateName}</strong>.
                </span>
              )}
            </p>

            <div className="pt-2 flex items-center justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setCancelConfirmSwap(null)}
                disabled={loading}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/60 font-medium rounded-md transition-colors cursor-pointer"
              >
                Отмена
              </button>
              <button
                type="button"
                onClick={async () => {
                  const target = cancelConfirmSwap;
                  setCancelConfirmSwap(null);
                  if (target.status === 'approved') {
                    await handleCancelByManager(target.id);
                  } else {
                    await handleCancel(target.id);
                  }
                }}
                disabled={loading}
                className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white font-medium rounded-md shadow-sm transition-colors cursor-pointer disabled:opacity-50"
              >
                {loading ? 'Аннулирование...' : 'Да, аннулировать'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
