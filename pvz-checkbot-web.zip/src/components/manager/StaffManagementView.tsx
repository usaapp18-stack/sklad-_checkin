import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StaffMember, LocationType, ShiftType, SHIFT_LABELS } from '../../types';
import { aggregateMonthlyStats, formatCurrency, calculateDailySales, normalizeShiftType, getBaseShiftPay, calculateShiftBonuses, calculateShiftTotalSalary, getShiftLabel } from '../../utils/calculations';
import { getCurrentAndPreviousMonth, formatMonthName, formatDisplayDate, formatDateRuDMY, getAllAvailableMonths } from '../../utils/time';
import { copyToClipboard } from '../../utils/clipboard';
import { CustomPeriodSelect } from '../common/CustomPeriodSelect';
import { CustomSelect } from '../common/CustomSelect';
import { CustomDatePicker } from '../common/CustomDatePicker';
import {
  Users,
  User,
  UserCheck,
  UserX,
  Archive,
  RotateCcw,
  BarChart3,
  Search,
  CheckCircle,
  AlertCircle,
  Eye,
  EyeOff,
  X,
  Calendar,
  KeyRound,
  UserPlus,
  Lock,
  Copy,
  Check,
  Edit2,
  ShieldCheck,
  ShieldAlert,
  MapPin,
  Trash2,
  ChevronDown,
  ChevronUp,
  Plus,
  Clock,
  CalendarPlus,
  CheckCircle2,
  SlidersHorizontal,
  ChevronRight,
  AlertTriangle,
  Banknote,
  CreditCard
} from 'lucide-react';

export const StaffManagementView: React.FC = () => {
  const {
    staffList,
    records,
    rates,
    deactivateStaff,
    restoreStaff,
    archiveStaff,
    deleteStaffPermanently,
    createEmployeeAccount,
    updateEmployeeCredentials,
    toggleEmployeeAccess,
    managerAddOrUpdateShift,
    managerDeleteShift,
    submitSales,
    pickupPoints = [],
  } = useApp();

  const calculateFOT = (staff: StaffMember, stat: any) => {
    if (!stat || !stat.records) return 0;
    let totalShiftSalary = 0;
    stat.records.forEach((rec: any) => {
      if (rec.shiftType) {
        totalShiftSalary += calculateShiftTotalSalary(rec, staff, rates);
      }
    });
    return totalShiftSalary;
  };

  const calculateShiftSinglePay = (staff: StaffMember, rec: any) => {
    if (!rec || !rec.shiftType) return 0;
    return calculateShiftTotalSalary(rec, staff, rates);
  };

  const allAvailableMonths = getAllAvailableMonths(records, 12);
  const { current } = getCurrentAndPreviousMonth();
  const currentMonthStats = aggregateMonthlyStats(records, current);

  const [activeTab, setActiveTab] = useState<'active' | 'archived'>('active');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Accordion state for compact employee list
  const [expandedStaffIds, setExpandedStaffIds] = useState<Set<string>>(new Set());

  const toggleExpand = (id: string) => {
    setExpandedStaffIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const expandAll = () => setExpandedStaffIds(new Set(filteredStaff.map(s => s.id)));
  const collapseAll = () => setExpandedStaffIds(new Set());

  // Indicators modal state
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [selectedStaffMonth, setSelectedStaffMonth] = useState<string>(current);
  const [shiftToDelete, setShiftToDelete] = useState<any | null>(null);

  // Staff action confirmation state (block, archive, restore, delete) without native browser confirm()
  const [staffActionConfirm, setStaffActionConfirm] = useState<{
    type: 'block' | 'archive' | 'restore' | 'delete';
    staff: StaffMember;
  } | null>(null);
  const [staffActionProcessing, setStaffActionProcessing] = useState(false);
  const [staffActionError, setStaffActionError] = useState<string | null>(null);

  const handleExecuteStaffAction = async () => {
    if (!staffActionConfirm) return;
    const { type, staff } = staffActionConfirm;
    setStaffActionConfirm(null);
    setStaffActionProcessing(false);

    const actionText = 
      type === 'block' ? `Доступ сотрудника «${staff.name}» отключен` :
      type === 'archive' ? `Сотрудник «${staff.name}» перенесен в архив` :
      type === 'restore' ? `Сотрудник «${staff.name}» восстановлен` :
      `Сотрудник «${staff.name}» удален`;

    setActionToastMsg(actionText);
    setTimeout(() => setActionToastMsg(null), 3500);

    try {
      let res: { success: boolean; error?: string } = { success: false };
      if (type === 'block') {
        res = await deactivateStaff(staff.id);
      } else if (type === 'archive') {
        res = await archiveStaff(staff.id);
      } else if (type === 'restore') {
        res = await restoreStaff(staff.id);
      } else if (type === 'delete') {
        res = await deleteStaffPermanently(staff.id);
        if (res.success && selectedStaff?.id === staff.id) {
          setSelectedStaff(null);
        }
      }

      if (!res.success) {
        setActionToastMsg(null);
        setActionErrorMsg(res.error || 'Ошибка при выполнении операции');
        setTimeout(() => setActionErrorMsg(null), 5000);
      }
    } catch (err: any) {
      setActionToastMsg(null);
      setActionErrorMsg(err.message || 'Ошибка сети');
      setTimeout(() => setActionErrorMsg(null), 5000);
    }
  };

  // Add shift state in manager indicators modal
  const [isAddShiftOpen, setIsAddShiftOpen] = useState(false);
  const [newShiftDate, setNewShiftDate] = useState(new Date().toISOString().slice(0, 10));
  const [newShiftType, setNewShiftType] = useState<ShiftType>('standard');
  const [newShiftLocation, setNewShiftLocation] = useState<LocationType>(pickupPoints[0]?.code || '');
  const [shiftActionLoading, setShiftActionLoading] = useState(false);
  const [shiftActionMsg, setShiftActionMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Edit individual shift inline state
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);
  const [editingShiftType, setEditingShiftType] = useState<ShiftType>('standard');
  const [editingShiftLocation, setEditingShiftLocation] = useState<LocationType>(pickupPoints[0]?.code || '');

  // Edit individual sales inline state (Наличные и Безналичные)
  const [editingCashSales, setEditingCashSales] = useState<string>('0');
  const [editingCardSales, setEditingCardSales] = useState<string>('0');

  // Modals state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editCredStaff, setEditCredStaff] = useState<StaffMember | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [visiblePasswords, setVisiblePasswords] = useState<Set<string>>(new Set());

  const togglePasswordVisibility = (id: string) => {
    setVisiblePasswords(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Create form state
  const [newName, setNewName] = useState('');
  const [newLogin, setNewLogin] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newLocations, setNewLocations] = useState<LocationType[]>([]);
  const [newTelegram, setNewTelegram] = useState('');
  const [newIsPartTime, setNewIsPartTime] = useState(false);
  const [newIsSenior, setNewIsSenior] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Edit creds state
  const [editName, setEditName] = useState('');
  const [editLogin, setEditLogin] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editLocations, setEditLocations] = useState<LocationType[]>([]);
  const [editIsPartTime, setEditIsPartTime] = useState(false);
  const [editIsSenior, setEditIsSenior] = useState(false);
  const [editTelegram, setEditTelegram] = useState('');
  const [editError, setEditError] = useState<string | null>(null);

  // Instant notification toasts
  const [actionToastMsg, setActionToastMsg] = useState<string | null>(null);
  const [actionErrorMsg, setActionErrorMsg] = useState<string | null>(null);

  // Safari focus trap for accessibility
  React.useEffect(() => {
    if (!isCreateOpen && !editCredStaff && !selectedStaff && !staffActionConfirm) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        const modal = document.querySelector('.fixed.inset-0.z-50') || document.querySelector('.fixed.inset-0');
        if (!modal) return;
        
        const focusableElements = modal.querySelectorAll<HTMLElement>(
          'input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex="0"]'
        );
        
        if (focusableElements.length === 0) return;
        
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        const activeElement = document.activeElement as HTMLElement;
        
        if (e.shiftKey) {
          if (activeElement === firstElement || !Array.from(focusableElements).includes(activeElement)) {
            lastElement.focus();
            e.preventDefault();
          }
        } else {
          if (activeElement === lastElement || !Array.from(focusableElements).includes(activeElement)) {
            firstElement.focus();
            e.preventDefault();
          }
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCreateOpen, editCredStaff, selectedStaff, staffActionConfirm]);

  const filteredStaff = staffList.filter(s => {
    const sLogin = s.login || '';
    const sName = s.name || '';
    const sTg = s.telegramUsername || '';
    const term = searchTerm.toLowerCase();

    const matchesSearch =
      sName.toLowerCase().includes(term) ||
      sLogin.toLowerCase().includes(term) ||
      sTg.toLowerCase().includes(term);
    if (!matchesSearch) return false;

    if (activeTab === 'active') {
      return s.status === 'active';
    } else {
      return s.status !== 'active';
    }
  });

  const copyCredentials = async (staff: StaffMember) => {
    const locs = staff.locations && staff.locations.length > 0 ? staff.locations.join(', ') : (staff.location || 'Не указан');
    const passwordText = staff.password || 'Не задан';
    const text = `Логин: ${staff.login || ''}\nПароль: ${passwordText}\nМесто работы: ${locs}`;
    await copyToClipboard(text);
    setCopiedId(staff.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleLocationSelection = (loc: LocationType, list: LocationType[], setList: (l: LocationType[]) => void) => {
    if (list.includes(loc)) {
      setList(list.filter(item => item !== loc));
    } else {
      setList([...list, loc]);
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);

    const nameToSave = newName.trim();
    const loginToSave = newLogin.trim().toLowerCase();
    const passToSave = newPassword.trim();
    const locsToSave = newLocations;
    const tgToSave = newTelegram.trim();
    const partTimeToSave = newIsPartTime;
    const seniorToSave = newIsSenior;

    if (staffList.length >= 150) {
      setCreateError('Достигнут лимит: максимально допустимо 150 сотрудников.');
      return;
    }

    if (!nameToSave) {
      setCreateError('Укажите ФИО сотрудника');
      return;
    }
    if (!loginToSave || !passToSave) {
      setCreateError('Логин и пароль обязательны для заполнения');
      return;
    }
    if (locsToSave.length === 0) {
      setCreateError('Необходимо выбрать хотя бы одно место работы');
      return;
    }

    const duplicate = staffList.find(s => (s.login || '').toLowerCase() === loginToSave);
    if (duplicate) {
      setCreateError('Сотрудник с таким логином уже зарегистрирован');
      return;
    }

    // Fast saving: immediately close modal and reset form
    setIsCreateOpen(false);
    setNewName('');
    setNewLogin('');
    setNewPassword('');
    setNewTelegram('');
    setNewLocations([]);
    setNewIsPartTime(false);
    setNewIsSenior(false);

    setActionToastMsg(`Сотрудник «${nameToSave}» успешно добавлен`);
    setTimeout(() => setActionToastMsg(null), 3500);

    const result = await createEmployeeAccount(nameToSave, loginToSave, passToSave, locsToSave, tgToSave, partTimeToSave, seniorToSave);
    if (!result.success) {
      setActionToastMsg(null);
      setActionErrorMsg(result.error || 'Ошибка создания учетной записи');
      setTimeout(() => setActionErrorMsg(null), 5000);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editCredStaff) return;
    setEditError(null);

    const targetStaff = editCredStaff;
    const nameToSave = editName.trim();
    const loginToSave = editLogin.trim().toLowerCase();
    const passToSave = editPassword.trim();
    const locsToSave = editLocations;
    const tgToSave = editTelegram.trim();
    const partTimeToSave = editIsPartTime;
    const seniorToSave = editIsSenior;

    if (!nameToSave) {
      setEditError('Имя обязательно для заполнения');
      return;
    }
    if (!loginToSave) {
      setEditError('Логин обязателен для заполнения');
      return;
    }
    if (locsToSave.length === 0) {
      setEditError('Необходимо выбрать хотя бы одно место работы');
      return;
    }

    const conflict = staffList.find(s => s.id !== targetStaff.id && (s.login || '').toLowerCase() === loginToSave);
    if (conflict) {
      setEditError('Такой логин уже занят другим сотрудником');
      return;
    }

    // Fast saving: immediately close modal and sync selectedStaff
    setEditCredStaff(null);
    setSelectedStaff(prev => (prev && prev.id === targetStaff.id ? {
      ...prev,
      name: nameToSave,
      login: loginToSave,
      password: passToSave || prev.password,
      locations: locsToSave,
      telegramUsername: tgToSave,
      isPartTime: partTimeToSave,
      isSenior: seniorToSave,
    } : prev));

    setActionToastMsg(`Данные сотрудника «${nameToSave}» успешно сохранены`);
    setTimeout(() => setActionToastMsg(null), 3500);

    const result = await updateEmployeeCredentials(
      targetStaff.id,
      loginToSave,
      passToSave || undefined,
      locsToSave,
      partTimeToSave,
      seniorToSave,
      nameToSave,
      tgToSave
    );
    if (!result.success) {
      setActionToastMsg(null);
      setActionErrorMsg(result.error || 'Ошибка обновления данных сотрудника');
      setTimeout(() => setActionErrorMsg(null), 5000);
    }
  };

  const openEditModal = (staff: StaffMember) => {
    setEditCredStaff(staff);
    setEditName(staff.name || '');
    setEditLogin(staff.login || '');
    setEditPassword('');
    setEditTelegram(staff.telegramUsername || '');
    setEditLocations(staff.locations && staff.locations.length > 0 ? staff.locations : (staff.location ? [staff.location] : []));
    setEditIsPartTime(!!staff.isPartTime);
    setEditIsSenior(!!staff.isSenior);
    setEditError(null);
  };

  const handleSaveNewShift = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaff) return;
    setShiftActionLoading(true);
    setShiftActionMsg(null);

    const res = await managerAddOrUpdateShift(selectedStaff.id, newShiftDate, newShiftType, newShiftLocation);
    setShiftActionLoading(false);
    if (res.success) {
      if (newShiftDate.length >= 7) {
        setSelectedStaffMonth(newShiftDate.slice(0, 7));
      }
      setShiftActionMsg({ type: 'success', text: `Смена на ${formatDateRuDMY(newShiftDate)} успешно сохранена!` });
      setIsAddShiftOpen(false);
      setTimeout(() => setShiftActionMsg(null), 3000);
    } else {
      setShiftActionMsg({ type: 'error', text: res.error || 'Ошибка сохранения смены' });
    }
  };

  const handleSaveEditedShift = async (rec: any) => {
    if (!selectedStaff) return;
    setShiftActionLoading(true);
    setShiftActionMsg(null);

    // 1. Update shift details
    const res = await managerAddOrUpdateShift(selectedStaff.id, rec.date, editingShiftType, editingShiftLocation);
    
    if (res.success) {
      // 2. Update sales details only for non-part-time staff when sales are present or entered
      if (!selectedStaff.isPartTime) {
        const cashVal = Math.max(0, parseInt(editingCashSales, 10) || 0);
        const cardVal = Math.max(0, parseInt(editingCardSales, 10) || 0);
        const totalEntered = cashVal + cardVal;
        const hadSales = rec.sales && (rec.sales.total > 0 || rec.sales.photo || rec.sales.print || rec.sales.cash || rec.sales.card);

        if (totalEntered > 0 || hadSales) {
          const parsedSales = {
            cash: cashVal,
            card: cardVal,
            total: totalEntered,
          };

          const salesRes = await submitSales(selectedStaff.id, parsedSales, rec.date);
          if (!salesRes.success) {
            setShiftActionLoading(false);
            setShiftActionMsg({
              type: 'error',
              text: `Смена сохранена, но возникла ошибка при обновлении выручки: ${salesRes.error}`,
            });
            return;
          }
        }
      }

      setShiftActionLoading(false);
      setEditingRecordId(null);
      setShiftActionMsg({ type: 'success', text: `Смена на ${formatDateRuDMY(rec.date)} успешно обновлена!` });
      setTimeout(() => setShiftActionMsg(null), 3000);
    } else {
      setShiftActionLoading(false);
      setShiftActionMsg({ type: 'error', text: res.error || 'Ошибка изменения смены' });
    }
  };

  const handleConfirmDeleteShift = async () => {
    if (!shiftToDelete || !selectedStaff) return;
    setShiftActionLoading(true);
    setShiftActionMsg(null);
    const recDate = shiftToDelete.date;
    const res = await managerDeleteShift(shiftToDelete.id);
    setShiftActionLoading(false);
    setShiftToDelete(null);
    if (editingRecordId === shiftToDelete.id) {
      setEditingRecordId(null);
    }
    if (res.success) {
      setShiftActionMsg({ type: 'success', text: `Смена за ${formatDateRuDMY(recDate)} успешно удалена!` });
      setTimeout(() => setShiftActionMsg(null), 3000);
    } else {
      setShiftActionMsg({ type: 'error', text: res.error || 'Ошибка удаления смены' });
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {actionToastMsg && (
        <div className="toast-banner fixed top-5 right-5 z-50 p-4 bg-slate-900 text-white border border-emerald-500/60 rounded-xl text-xs font-semibold shadow-2xl flex items-center gap-2.5 animate-in slide-in-from-top duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-white">{actionToastMsg}</span>
        </div>
      )}
      {actionErrorMsg && (
        <div className="toast-banner fixed top-5 right-5 z-50 p-4 bg-slate-900 text-white border border-red-500/60 rounded-xl text-xs font-semibold shadow-2xl flex items-center gap-2.5 animate-in slide-in-from-top duration-200">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
          <span className="text-white">{actionErrorMsg}</span>
        </div>
      )}

      {/* Top Header & Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h2 className="text-base font-semibold text-white tracking-wide uppercase flex items-center gap-2">
              <span>Сотрудники</span>
              <span className="text-slate-400 font-mono text-sm font-normal tracking-normal normal-case ml-1">
                {staffList.filter(s => s.status === 'active').length}
              </span>
            </h2>
            <span className="text-xs font-normal text-slate-500 whitespace-nowrap">
              Всего: {staffList.length} / 150
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Управление персоналом ({staffList.filter(s => s.status === 'active').length} активных из {staffList.length}), выдача доступов и детальные показатели
          </p>
        </div>

        {/* Tab switcher: Active vs Archived */}
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setActiveTab('active')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'active'
                  ? 'bg-slate-800 text-white font-medium shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5 text-slate-400" />
              <span>Активные ({staffList.filter(s => s.status === 'active').length})</span>
            </button>

            <button
              onClick={() => setActiveTab('archived')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'archived'
                  ? 'bg-slate-800 text-white font-medium shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Archive className="w-3.5 h-3.5 text-slate-400" />
              <span>Архив ({staffList.filter(s => s.status !== 'active').length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search & Bulk Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Поиск по имени, логину, telegram..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-md text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-slate-600 transition-colors"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={expandAll}
              className="py-1.5 px-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-md text-xs font-medium transition-colors hidden md:block cursor-pointer"
              title="Развернуть все карточки"
            >
              Развернуть все
            </button>
            <button
              onClick={collapseAll}
              className="py-1.5 px-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 rounded-md text-xs font-medium transition-colors hidden md:block cursor-pointer"
              title="Свернуть все карточки"
            >
              Свернуть все
            </button>
          </div>
        </div>

        <button
          onClick={() => {
            if (staffList.length >= 150) return;
            setNewName('');
            setNewLogin(`emp_${Math.floor(100 + Math.random() * 900)}`);
            setNewPassword(`pass${Math.floor(100 + Math.random() * 900)}`);
            setNewLocations([]);
            setCreateError(null);
            setIsCreateOpen(true);
          }}
          disabled={staffList.length >= 150}
          title={staffList.length >= 150 ? 'Достигнут лимит: 150 сотрудников' : 'Создать доступ'}
          className="flex items-center justify-center gap-1.5 py-1.5 px-3.5 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 rounded-md text-xs font-medium whitespace-nowrap shadow-xs transition-colors cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>Создать доступ</span>
        </button>
      </div>

      {/* Staff Compact & Expandable List */}
      <div className="space-y-2">
        {filteredStaff.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs bg-slate-900/40 border border-slate-800/80 rounded-lg">
            Работники не найдены
          </div>
        ) : (
          filteredStaff.map(staff => {
            const stat = currentMonthStats.get(staff.id);
            const isCopied = copiedId === staff.id;
            const staffLocations = staff.locations && staff.locations.length > 0 ? staff.locations : [];
            const isExpanded = expandedStaffIds.has(staff.id);
            const fot = calculateFOT(staff, stat);
            const bonus = stat?.sales.totalBonus || 0;

            return (
              <div
                key={staff.id}
                className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-lg transition-colors overflow-hidden"
              >
                {/* Compact Row Header */}
                <div className="p-3 sm:p-3.5 flex items-center justify-between gap-3 flex-wrap sm:flex-nowrap">
                  
                  {/* Left: Avatar & Identity info */}
                  <div
                    onClick={() => toggleExpand(staff.id)}
                    className="flex items-center gap-3 cursor-pointer select-none flex-1 min-w-[200px]"
                  >
                    <div className={`w-8 h-8 rounded-md flex items-center justify-center shrink-0 font-mono font-medium text-xs ${
                      staff.status === 'active'
                        ? 'bg-slate-800 text-slate-200 border border-slate-700/80'
                        : 'bg-slate-800/40 text-slate-500 border border-slate-800'
                    }`}>
                      {staff.name
                        ? staff.name.split(' ').map(p => p[0]).join('').slice(0, 2).toUpperCase()
                        : '??'}
                    </div>

                    <div className="min-w-0">
                      <div className="text-sm font-medium text-slate-100 flex items-center gap-1.5 flex-wrap">
                        <span className="truncate">{staff.name}</span>
                        {staff.isSenior && (
                          <span className="text-emerald-700 dark:text-purple-400 font-medium text-xs">· Старший смены</span>
                        )}
                        <span className="text-slate-400 font-normal text-xs">
                          · {staff.isPartTime ? 'Подработчик' : 'Штатный'}
                        </span>
                        {staffLocations.length > 0 && (
                          <span className="text-slate-500 font-normal text-xs">
                            · {staffLocations.join(', ')}
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                        <span className="font-mono text-slate-300">{staff.login}</span>
                        {staff.telegramUsername && (
                          <span className="text-slate-500">· {staff.telegramUsername}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Middle: Compact Current Month Indicators (Stripe/Linear clean stats) */}
                  <div className="flex items-center gap-4 sm:gap-6 shrink-0 text-right">
                    <div>
                      <div className="text-[11px] text-slate-400 font-normal">Смен</div>
                      <div className="text-xs font-medium font-mono text-slate-200 tabular-nums">{stat?.shiftsCount.total || 0}</div>
                    </div>

                    <div>
                      <div className="text-[11px] text-slate-400 font-normal">ФОТ</div>
                      <div className="text-xs font-semibold font-mono text-sky-400 tabular-nums">{formatCurrency(fot)}</div>
                    </div>

                    <div className="hidden sm:block">
                      <div className="text-[11px] text-slate-400 font-normal">Премия</div>
                      <div className="text-xs font-medium font-mono text-emerald-400 tabular-nums">+{formatCurrency(bonus)}</div>
                    </div>
                  </div>

                  {/* Right: Action Buttons */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => {
                        setSelectedStaff(staff);
                        setSelectedStaffMonth(current);
                        setIsAddShiftOpen(false);
                        setEditingRecordId(null);
                        setShiftActionMsg(null);
                      }}
                      className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors shadow-sm"
                    >
                      <Eye className="w-3.5 h-3.5 text-slate-400" />
                      <span>Показатели</span>
                    </button>

                    <button
                      onClick={() => toggleExpand(staff.id)}
                      className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
                      title={isExpanded ? 'Свернуть' : 'Развернуть'}
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>

                </div>

                {/* Expanded Detailed Section */}
                {isExpanded && (
                  <div className="p-3.5 pt-0 border-t border-slate-800/60 bg-slate-950/40 space-y-3 animate-fade-in">
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3">
                      
                      {/* Credentials card */}
                      <div className="p-3 bg-slate-900/90 rounded-xl text-xs space-y-2 font-mono">
                        <div className="flex items-center justify-between text-slate-400 font-sans">
                          <span className="text-[10px] uppercase font-medium text-slate-500">Учетные данные для входа</span>
                          <button
                            onClick={() => openEditModal(staff)}
                            className="text-[10px] text-sky-400 hover:text-sky-300 flex items-center gap-1 font-medium"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>Изменить данные</span>
                          </button>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 font-sans">Логин:</span>
                          <span className="font-medium text-slate-100 tabular-nums">{staff.login}</span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-slate-400 font-sans">Пароль:</span>
                          <div className="flex items-center gap-1.5">
                            <span className="font-medium text-slate-100 tabular-nums">
                              {visiblePasswords.has(staff.id) ? (staff.password || 'Не задан') : '••••••••'}
                            </span>
                            <button
                              type="button"
                              onClick={() => togglePasswordVisibility(staff.id)}
                              className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
                              title={visiblePasswords.has(staff.id) ? "Скрыть пароль" : "Показать пароль"}
                            >
                              {visiblePasswords.has(staff.id) ? (
                                <EyeOff className="w-3.5 h-3.5" />
                              ) : (
                                <Eye className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </div>

                        <button
                          onClick={() => copyCredentials(staff)}
                          className="w-full mt-1 py-1.5 px-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white rounded-lg text-[11px] font-sans font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                        >
                          {isCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400 font-medium">Данные скопированы для выдачи</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-slate-400" />
                              <span>Скопировать логин, пароль и локацию</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* Workplaces & Status Controls */}
                      <div className="p-3 bg-slate-900/90 rounded-xl text-xs space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Доступные пункты:</span>
                          <span className="text-slate-200 font-medium">{staffLocations.join(', ')}</span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Статус аккаунта:</span>
                          <span
                            className={`text-[10px] font-medium px-2 py-0.5 rounded-md ${
                              staff.status === 'active'
                                ? 'bg-emerald-950/60 text-emerald-400'
                                : staff.status === 'archived'
                                ? 'bg-amber-950/60 text-amber-300'
                                : 'bg-rose-950/60 text-rose-400'
                            }`}
                          >
                            {staff.status === 'active'
                              ? 'Активен (доступ открыт)'
                              : staff.status === 'archived'
                              ? 'В архиве'
                              : 'Заблокирован'}
                          </span>
                        </div>

                        <div className="pt-2 flex items-center gap-2">
                          {staff.status === 'active' ? (
                            <>
                              <button
                                onClick={() => setStaffActionConfirm({ type: 'block', staff })}
                                className="flex-1 py-1 px-2 text-[11px] font-medium text-rose-400 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
                              >
                                <UserX className="w-3.5 h-3.5" />
                                <span>Заблокировать</span>
                              </button>
                              <button
                                onClick={() => setStaffActionConfirm({ type: 'archive', staff })}
                                className="py-1 px-2.5 text-[11px] font-medium text-amber-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                              >
                                <Archive className="w-3.5 h-3.5" />
                                <span>В архив</span>
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => setStaffActionConfirm({ type: 'restore', staff })}
                                className="flex-1 py-1 px-2 text-[11px] font-medium text-emerald-400 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center justify-center gap-1"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Восстановить доступ</span>
                              </button>
                              <button
                                onClick={() => setStaffActionConfirm({ type: 'delete', staff })}
                                className="py-1 px-2 text-[11px] font-medium text-red-400 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Удалить</span>
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                    </div>

                  </div>
                )}

              </div>
            );
          })
        )}
      </div>

      {/* Staff Indicators & Shift Management Modal (3-Month History + Manual Shift Add/Edit/Delete) */}
      {selectedStaff && (() => {
        const activeStaff = staffList.find(s => s.id === selectedStaff.id) || selectedStaff;
        const activeStaffLocations = activeStaff.locations && activeStaff.locations.length > 0 ? activeStaff.locations : [];
        const isCopied = copiedId === activeStaff.id;

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
              
              {/* Modal Header */}
              <div className="p-4 bg-slate-950/70 border-b border-slate-800/80 space-y-3 shrink-0">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      activeStaff.status === 'active'
                        ? 'bg-emerald-500/10 text-emerald-400'
                        : 'bg-amber-500/10 text-amber-400'
                    }`}>
                      {activeStaff.status === 'active' ? (
                        <User className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <UserX className="w-5 h-5 text-amber-400" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-white flex items-center gap-2 flex-wrap">
                        <span>{activeStaff.name}</span>
                        <span className="text-xs font-mono font-normal text-slate-400">(Логин: {activeStaff.login})</span>
                        <span
                          className={`text-[10px] font-medium px-2 py-0.5 rounded-md border ${
                            activeStaff.status === 'active'
                              ? 'bg-emerald-950/40 text-emerald-400 border-emerald-500/20'
                              : activeStaff.status === 'archived'
                              ? 'bg-amber-950/40 text-amber-300 border-amber-500/20'
                              : 'bg-rose-950/40 text-rose-400 border-rose-500/20'
                          }`}
                        >
                          {activeStaff.status === 'active'
                            ? 'Активен (доступ открыт)'
                            : activeStaff.status === 'archived'
                            ? 'В архиве'
                            : 'Заблокирован'}
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Статус: {activeStaff.isSenior ? 'Старший смены · ' : ''}{activeStaff.isPartTime ? 'Подработчик' : 'Основной работник'} · Локации: {activeStaffLocations.join(', ')}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedStaff(null)}
                    className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Worker Card Action Buttons */}
                <div className="flex items-center gap-2 flex-wrap pt-2">
                  <button
                    onClick={() => openEditModal(activeStaff)}
                    className="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-sky-400 hover:text-sky-300 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Изменить данные</span>
                  </button>

                  <button
                    onClick={() => copyCredentials(activeStaff)}
                    className="py-1 px-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 font-semibold">Скопировано</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>Скопировать доступ</span>
                      </>
                    )}
                  </button>

                  {activeStaff.status === 'active' ? (
                    <>
                      <button
                        onClick={() => setStaffActionConfirm({ type: 'block', staff: activeStaff })}
                        className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-rose-400 hover:text-rose-300 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ml-auto cursor-pointer"
                      >
                        <UserX className="w-3.5 h-3.5" />
                        <span>Заблокировать</span>
                      </button>
                      <button
                        onClick={() => setStaffActionConfirm({ type: 'archive', staff: activeStaff })}
                        className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-amber-200 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Archive className="w-3.5 h-3.5" />
                        <span>В архив</span>
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => setStaffActionConfirm({ type: 'restore', staff: activeStaff })}
                        className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors ml-auto cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Восстановить доступ</span>
                      </button>
                      <button
                        onClick={() => setStaffActionConfirm({ type: 'delete', staff: activeStaff })}
                        className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-red-400 hover:text-red-300 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Удалить</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

            <div className="p-4 sm:p-5 space-y-5 flex-1 overflow-y-auto">
              
              {/* Feedback Alert Message */}
              {shiftActionMsg && (
                <div
                  className={`p-3 rounded-xl border text-xs flex items-center gap-2 animate-fade-in ${
                    shiftActionMsg.type === 'success'
                      ? 'bg-emerald-950/50 border-emerald-800 text-emerald-300'
                      : 'bg-red-950/50 border-red-800 text-red-300'
                  }`}
                >
                  {shiftActionMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                  <span>{shiftActionMsg.text}</span>
                </div>
              )}

              {/* Month Comparative Overview Cards & Navigation Tabs */}
              {(() => {
                const displayMonths = [...allAvailableMonths.slice(0, 3)];
                if (!displayMonths.some(m => m.key === selectedStaffMonth)) {
                  const currentM = allAvailableMonths.find(m => m.key === selectedStaffMonth) || {
                    key: selectedStaffMonth,
                    label: formatMonthName(selectedStaffMonth),
                    isCurrent: false,
                  };
                  displayMonths.push(currentM);
                }

                return (
                  <div className="space-y-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                        <span>Статистика по месяцам</span>
                      </div>
                      <CustomPeriodSelect
                        value={selectedStaffMonth}
                        onChange={val => {
                          setSelectedStaffMonth(val);
                          setIsAddShiftOpen(false);
                          setEditingRecordId(null);
                        }}
                        options={allAvailableMonths}
                        labelPrefix="Период:"
                        align="right"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {displayMonths.map(m => {
                        const mStats = aggregateMonthlyStats(records, m.key, selectedStaff.id);
                        const mStat = mStats.get(selectedStaff.id);
                        const mFot = calculateFOT(selectedStaff, mStat);
                        const mBonus = mStat?.sales.totalBonus || 0;
                        const mTotal = mFot + mBonus;
                        const isSelected = selectedStaffMonth === m.key;

                        return (
                          <button
                            key={m.key}
                            onClick={() => {
                              setSelectedStaffMonth(m.key);
                              setIsAddShiftOpen(false);
                              setEditingRecordId(null);
                            }}
                            className={`p-3 rounded-xl text-left transition-all relative overflow-hidden ${
                              isSelected
                                ? 'bg-slate-950 ring-1 ring-emerald-500/50 shadow-sm'
                                : 'bg-slate-950/60 hover:bg-slate-950'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className={`text-xs font-semibold ${isSelected ? 'text-emerald-400' : 'text-slate-300'}`}>
                                {m.label}
                              </span>
                              {m.isCurrent && (
                                <span className="text-[9px] font-medium uppercase bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded">
                                  Текущий
                                </span>
                              )}
                            </div>

                            <div className="flex items-baseline justify-between mt-2 font-mono">
                              <div>
                                <div className="text-[10px] text-slate-500 font-sans">Смен</div>
                                <div className="text-sm font-semibold text-slate-100">{mStat?.shiftsCount.total || 0}</div>
                              </div>
                              <div className="text-right">
                                <div className="text-[10px] text-sky-400 font-sans">Начислено</div>
                                <div className="text-sm font-semibold text-emerald-400">{formatCurrency(mTotal)}</div>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

              {/* Active Selected Month Detailed KPIs */}
              {(() => {
                const activeMonthStats = aggregateMonthlyStats(records, selectedStaffMonth, selectedStaff.id);
                const stat = activeMonthStats.get(selectedStaff.id);
                const fot = calculateFOT(selectedStaff, stat);
                const bonus = stat?.sales.totalBonus || 0;
                const totalEarned = fot + bonus;

                // Unique shifts worked in this month
                const monthShifts = (stat?.records || []).slice().sort((a, b) => b.date.localeCompare(a.date));

                return (
                  <div className="space-y-4 pt-2 border-t border-slate-800">
                    
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="text-xs font-medium text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                        <span>Детализация за:</span>
                        <span className="text-emerald-400 font-semibold">{formatMonthName(selectedStaffMonth)}</span>
                      </div>

                      <div className="text-xs font-mono font-semibold text-emerald-400 px-2.5 py-1 bg-emerald-950/60 rounded-lg">
                        Итого доход: {formatCurrency(totalEarned)}
                      </div>
                    </div>

                    {/* 4 Metrics Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div className="p-3 bg-slate-950 rounded-xl text-center">
                        <div className="text-[11px] text-slate-400 font-medium">Отработано смен</div>
                        <div className="text-base font-semibold font-mono text-slate-100 mt-0.5">
                          {stat?.shiftsCount?.total || 0}
                        </div>
                      </div>

                      <div className="p-3 bg-slate-950 rounded-xl text-center">
                        <div className="text-[11px] text-slate-400 font-medium">Выручка (доп. услуги)</div>
                        <div className="text-base font-semibold font-mono text-slate-100 mt-0.5 truncate">
                          {formatCurrency(stat?.sales?.totalRevenue || 0)}
                        </div>
                      </div>

                      <div className="p-3 bg-slate-950 rounded-xl text-center">
                        <div className="text-[11px] text-sky-400 font-medium">ФОТ (Оклады)</div>
                        <div className="text-base font-semibold font-mono text-sky-400 mt-0.5 truncate">
                          {formatCurrency(fot)}
                        </div>
                      </div>

                      <div className="p-3 bg-slate-950 rounded-xl text-center">
                        <div className="text-[11px] text-emerald-300 font-medium">Премия 5%</div>
                        <div className="text-base font-semibold font-mono text-emerald-400 mt-0.5 truncate">
                          +{formatCurrency(bonus)}
                        </div>
                      </div>
                    </div>

                    {/* Shift Categories & Sales breakdown */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {(() => {
                        const staffShiftCountsMap = new Map<string, number>();
                        stat?.records?.forEach((rec: any) => {
                          if (rec.shiftType) {
                            staffShiftCountsMap.set(rec.shiftType, (staffShiftCountsMap.get(rec.shiftType) || 0) + 1);
                          }
                        });
                        const staffWorkedShifts = Array.from(staffShiftCountsMap.entries());

                        return (
                          <div className="p-3 bg-slate-950/80 rounded-xl text-xs space-y-2">
                            <div className="text-slate-400 font-medium">Смены по типам:</div>
                            {staffWorkedShifts.length > 0 ? (
                              <div className="grid grid-cols-2 gap-2 text-slate-300 font-mono">
                                {staffWorkedShifts.map(([code, count]) => (
                                  <div key={code} className="truncate" title={getShiftLabel(code, rates)}>
                                    <span className="text-slate-400">{getShiftLabel(code, rates)}:</span>{' '}
                                    <span className="font-semibold text-slate-200">{count}</span>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <div className="text-slate-500 italic py-1">Нет отмеченных смен</div>
                            )}
                          </div>
                        );
                      })()}

                      <div className="p-3 bg-slate-950/80 rounded-xl text-xs space-y-1.5 font-mono">
                        <div className="text-slate-400 font-medium font-sans">Выручка по оплате:</div>
                        <div className="flex justify-between text-slate-300">
                          <span>Наличные:</span>
                          <span className="font-medium text-slate-100">{formatCurrency(stat?.sales?.totalCash || 0)}</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Безналичные:</span>
                          <span className="font-medium text-slate-100">{formatCurrency(stat?.sales?.totalCard || 0)}</span>
                        </div>
                        <div className="flex justify-between text-emerald-400 pt-1 border-t border-slate-850 font-semibold">
                          <span>Общая выручка:</span>
                          <span>{formatCurrency(stat?.sales?.totalRevenue || 0)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Manual Shift Management Section (Add / Edit / Cancel shifts) */}
                    <div className="pt-3 border-t border-slate-800 space-y-3">
                      
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div>
                          <h4 className="text-xs font-medium text-white uppercase tracking-wider flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Журнал и управление сменами ({monthShifts.length})</span>
                          </h4>
                          <p className="text-[11px] text-slate-500">
                            Вы можете вручную добавить пропущенную смену, изменить категорию или отменить смену
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            setIsAddShiftOpen(!isAddShiftOpen);
                            setNewShiftDate(`${selectedStaffMonth}-01`);
                          }}
                          className="py-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>{isAddShiftOpen ? 'Скрыть форму' : 'Добавить смену'}</span>
                        </button>
                      </div>

                      {/* Add Shift Inline Form */}
                      {isAddShiftOpen && (
                        <form
                          onSubmit={handleSaveNewShift}
                          className="p-4 bg-slate-900 border border-emerald-500/40 rounded-2xl space-y-3.5 shadow-lg animate-fade-in"
                        >
                          <div className="text-xs font-semibold text-emerald-400 flex items-center gap-2">
                            <CalendarPlus className="w-4 h-4" />
                            <span>Добавление / Назначение смены сотруднику</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                            {/* Control 1: Дата смены */}
                            <div>
                              <label className="block text-[11px] font-medium text-slate-300 mb-1.5">
                                Дата смены <span className="text-emerald-400">*</span>
                              </label>
                              <CustomDatePicker
                                value={newShiftDate}
                                onChange={v => setNewShiftDate(v)}
                              />
                            </div>

                            {/* Control 2: Категория смены */}
                            <div>
                              <label className="block text-[11px] font-medium text-slate-300 mb-1.5">
                                Категория смены <span className="text-emerald-400">*</span>
                              </label>
                              <CustomSelect<ShiftType>
                                value={newShiftType}
                                onChange={v => setNewShiftType(v)}
                                menuHeaderTitle="Категория смены"
                                options={[
                                  { value: 'standard', label: 'Стандартная смена' },
                                  { value: '400+', label: 'Смена 400+' },
                                  { value: '500+', label: 'Смена 500+' },
                                  { value: '8h', label: 'Смена 8 часов' },
                                  { value: '4h', label: 'Смена 4 часа' },
                                ]}
                              />
                            </div>

                            {/* Control 3: Пункт (Локация) */}
                            <div>
                              <label className="block text-[11px] font-medium text-slate-300 mb-1.5">
                                Пункт выдачи (ПВЗ) <span className="text-emerald-400">*</span>
                              </label>
                              <CustomSelect<LocationType>
                                value={newShiftLocation}
                                onChange={v => setNewShiftLocation(v)}
                                align="right"
                                menuHeaderTitle="Выберите пункт выдачи"
                                options={(pickupPoints || []).map(pt => ({
                                  value: pt.code as LocationType,
                                  label: pt.code,
                                  sublabel: pt.name && pt.name !== pt.code ? pt.name : undefined,
                                  badge: (pt as any).isArchived ? 'Архив' : undefined,
                                  badgeColor: (pt as any).isArchived ? ('amber' as const) : undefined,
                                }))}
                              />
                            </div>
                          </div>

                          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                            <button
                              type="button"
                              onClick={() => setIsAddShiftOpen(false)}
                              className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-750 rounded-xl transition-all cursor-pointer font-medium"
                            >
                              Отмена
                            </button>
                            <button
                              type="submit"
                              disabled={shiftActionLoading}
                              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-500 hover:bg-emerald-400 rounded-xl transition-all shadow-sm disabled:opacity-50 cursor-pointer"
                            >
                              {shiftActionLoading ? 'Сохранение...' : 'Сохранить смену'}
                            </button>
                          </div>
                        </form>
                      )}

                      {/* Shifts Table / Cards */}
                      {monthShifts.length === 0 ? (
                        <div className="p-6 text-center text-xs text-slate-500 bg-slate-950/60 rounded-xl">
                          В {formatMonthName(selectedStaffMonth)} смен пока нет. Вы можете нажать «+ Добавить смену», чтобы внести смену вручную.
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {monthShifts.map(rec => {
                            const shiftSalary = calculateShiftSinglePay(selectedStaff, rec);
                            const dailyCalc = calculateDailySales(rec.sales);
                            const isEditing = editingRecordId === rec.id;

                            return (
                              <div
                                key={rec.id}
                                className="p-3 bg-slate-950/80 rounded-xl hover:bg-slate-950 transition-colors text-xs space-y-2.5"
                              >
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                  {/* Left info */}
                                  <div className="space-y-1">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span className="font-medium text-slate-100 font-mono">{formatDateRuDMY(rec.date)}</span>
                                      
                                       {isEditing ? (
                                        <div className="flex items-center gap-2">
                                          <CustomSelect<ShiftType>
                                            value={editingShiftType}
                                            onChange={v => setEditingShiftType(v)}
                                            className="w-36"
                                            triggerClassName="!h-8 !min-h-[32px] !py-1 !px-2.5 !bg-slate-900 !border-slate-700"
                                            options={[
                                              { value: 'standard', label: 'Стандартная' },
                                              { value: '400+', label: '400+' },
                                              { value: '500+', label: '500+' },
                                              { value: '8h', label: '8 часов' },
                                              { value: '4h', label: '4 часа' },
                                            ]}
                                          />
                                          <CustomSelect<LocationType>
                                            value={editingShiftLocation}
                                            onChange={v => setEditingShiftLocation(v)}
                                            className="w-28"
                                            triggerClassName="!h-8 !min-h-[32px] !py-1 !px-2.5 !bg-slate-900 !border-slate-700"
                                            options={(pickupPoints || []).map(pt => ({
                                              value: pt.code as LocationType,
                                              label: pt.code,
                                            }))}
                                          />
                                        </div>
                                      ) : (
                                        <>
                                          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 font-medium">
                                            {getShiftLabel(rec.shiftType, rates)}
                                          </span>
                                          <span className="px-1.5 py-0.5 rounded bg-slate-800 text-emerald-400 font-medium">
                                            {rec.location || '—'}
                                          </span>
                                        </>
                                      )}

                                      <span className="text-slate-500 text-[11px]">
                                        {rec.checkedInAt ? rec.checkedInAt.slice(11, 16) : rec.timestamp ? rec.timestamp.slice(11, 16) : ''}
                                      </span>
                                    </div>

                                    <div className="text-[11px] text-slate-400 flex items-center gap-3 font-mono flex-wrap">
                                      <span>Оклад: <strong className="text-sky-400 font-medium">{formatCurrency(shiftSalary)}</strong></span>
                                      {dailyCalc.totalSales > 0 ? (
                                        <>
                                          <span>Выручка: {formatCurrency(dailyCalc.totalSales)} (Премия: <strong className="text-emerald-400 font-medium">+{formatCurrency(dailyCalc.bonus)}</strong>)</span>
                                          <span>Итого за смену: <strong className="text-emerald-400 font-medium">{formatCurrency(shiftSalary + dailyCalc.bonus)}</strong></span>
                                        </>
                                      ) : (
                                        <span>Итого за смену: <strong className="text-slate-100 font-medium">{formatCurrency(shiftSalary)}</strong></span>
                                      )}
                                    </div>
                                  </div>

                                  {/* Right actions */}
                                  <div className="flex items-center gap-1.5 shrink-0">
                                    {isEditing ? (
                                      <>
                                        <button
                                          onClick={() => handleSaveEditedShift(rec)}
                                          disabled={shiftActionLoading}
                                          className="py-1 px-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-lg text-xs transition-colors"
                                        >
                                          Сохранить
                                        </button>
                                        <button
                                          onClick={() => setEditingRecordId(null)}
                                          className="py-1 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium"
                                        >
                                          Отмена
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => setShiftToDelete(rec)}
                                          className="py-1 px-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors"
                                          title="Удалить смену"
                                        >
                                          <Trash2 className="w-3.5 h-3.5" />
                                          <span>Удалить</span>
                                        </button>
                                      </>
                                    ) : (
                                      <>
                                        <button
                                          onClick={() => {
                                            setEditingRecordId(rec.id);
                                            setEditingShiftType(normalizeShiftType(rec.shiftType));
                                            setEditingShiftLocation(rec.location || (pickupPoints[0]?.code || ''));
                                            const sCalc = calculateDailySales(rec.sales);
                                            setEditingCashSales(rec.sales?.cash !== undefined ? String(rec.sales.cash) : (sCalc.totalCash > 0 ? String(sCalc.totalCash) : ''));
                                            setEditingCardSales(rec.sales?.card !== undefined ? String(rec.sales.card) : (sCalc.totalCard > 0 ? String(sCalc.totalCard) : ''));
                                          }}
                                          className="p-1.5 text-sky-400 hover:bg-sky-950/40 rounded-lg transition-colors"
                                          title="Изменить смену"
                                        >
                                          <Edit2 className="w-3.5 h-3.5" />
                                        </button>
                                        <button
                                          onClick={() => setShiftToDelete(rec)}
                                          className="p-1.5 text-red-400 hover:bg-red-950/40 rounded-lg transition-colors"
                                          title="Отменить смену"
                                        >
                                          <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                      </>
                                    )}
                                  </div>
                                </div>

                                {isEditing && !selectedStaff.isPartTime && (
                                  <div className="p-3 bg-slate-900 rounded-xl space-y-2.5 animate-fade-in shadow-sm">
                                    <div className="text-[10px] font-medium text-slate-400 uppercase tracking-wider pb-1 flex items-center justify-between">
                                      <span>Выручка за смену (продажи):</span>
                                      <span className="text-emerald-400 font-mono font-medium">
                                        Итого: {formatCurrency((Math.max(0, parseInt(editingCashSales, 10) || 0)) + (Math.max(0, parseInt(editingCardSales, 10) || 0)))}
                                      </span>
                                    </div>
                                    <div className="grid grid-cols-2 gap-2.5">
                                      <div>
                                        <label className="flex items-center gap-1 text-[10px] text-slate-400 mb-1 font-medium">
                                          <Banknote className="w-3 h-3 text-emerald-400" />
                                          <span>Наличные (₽)</span>
                                        </label>
                                        <input
                                          type="text"
                                          inputMode="numeric"
                                          pattern="[0-9]*"
                                          placeholder="0"
                                          value={editingCashSales}
                                          onFocus={e => e.target.select()}
                                          onClick={e => (e.target as HTMLInputElement).select()}
                                          onChange={e => setEditingCashSales(e.target.value.replace(/\D/g, ''))}
                                          className="w-full px-2.5 py-1.5 bg-slate-950 rounded-lg font-mono text-white text-xs focus:outline-none focus:ring-1 focus:ring-emerald-500/50 border border-slate-800"
                                        />
                                      </div>
                                      <div>
                                        <label className="flex items-center gap-1 text-[10px] text-slate-400 mb-1 font-medium">
                                          <CreditCard className="w-3 h-3 text-sky-400" />
                                          <span>Безналичные / Карта (₽)</span>
                                        </label>
                                        <input
                                          type="text"
                                          inputMode="numeric"
                                          pattern="[0-9]*"
                                          placeholder="0"
                                          value={editingCardSales}
                                          onFocus={e => e.target.select()}
                                          onClick={e => (e.target as HTMLInputElement).select()}
                                          onChange={e => setEditingCardSales(e.target.value.replace(/\D/g, ''))}
                                          className="w-full px-2.5 py-1.5 bg-slate-950 rounded-lg font-mono text-white text-xs focus:outline-none focus:ring-1 focus:ring-sky-500/50 border border-slate-800"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}

                    </div>

                  </div>
                );
              })()}

            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end">
              <button
                onClick={() => setSelectedStaff(null)}
                className="px-4 py-2 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition-colors"
              >
                Закрыть
              </button>
            </div>

          </div>
        </div>
        );
      })()}

      {/* Staff Action Confirmation Modal (Block, Archive, Restore, Delete) */}
      {staffActionConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center border shrink-0 ${
                  staffActionConfirm.type === 'block'
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                    : staffActionConfirm.type === 'archive'
                    ? 'bg-sky-500/20 text-sky-400 border-sky-500/30'
                    : staffActionConfirm.type === 'restore'
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    : 'bg-red-500/20 text-red-400 border-red-500/30'
                }`}
              >
                {staffActionConfirm.type === 'block' && <UserX className="w-5 h-5" />}
                {staffActionConfirm.type === 'archive' && <Archive className="w-5 h-5" />}
                {staffActionConfirm.type === 'restore' && <RotateCcw className="w-5 h-5" />}
                {staffActionConfirm.type === 'delete' && <Trash2 className="w-5 h-5" />}
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">
                  {staffActionConfirm.type === 'block' && 'Заблокировать доступ'}
                  {staffActionConfirm.type === 'archive' && 'Переместить в архив'}
                  {staffActionConfirm.type === 'restore' && 'Восстановить доступ'}
                  {staffActionConfirm.type === 'delete' && 'Удалить сотрудника навсегда'}
                </h4>
                <p className="text-xs text-slate-400 font-normal">
                  {staffActionConfirm.type === 'delete'
                    ? 'Действие нельзя отменить'
                    : 'Подтвердите действие'}
                </p>
              </div>
            </div>

            {staffActionError && (
              <div className="p-2.5 bg-red-950/50 border border-red-800/80 rounded-xl text-red-300 flex items-center gap-2 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{staffActionError}</span>
              </div>
            )}

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed">
              {staffActionConfirm.type === 'block' && (
                <>
                  Вы действительно хотите заблокировать доступ в систему для сотрудника{' '}
                  <strong className="text-white">{staffActionConfirm.staff.name}</strong>? Он не сможет входить в систему и отмечать смены.
                </>
              )}
              {staffActionConfirm.type === 'archive' && (
                <>
                  Переместить сотрудника <strong className="text-white">{staffActionConfirm.staff.name}</strong> в архив?
                  Сотрудник будет скрыт из списков активного персонала, но все его смены и история выплат сохранятся.
                </>
              )}
              {staffActionConfirm.type === 'restore' && (
                <>
                  Восстановить доступ для сотрудника <strong className="text-white">{staffActionConfirm.staff.name}</strong>?
                  Аккаунт снова станет активным.
                </>
              )}
              {staffActionConfirm.type === 'delete' && (
                <>
                  Внимание! Вы собираетесь навсегда удалить сотрудника <strong className="text-white">{staffActionConfirm.staff.name}</strong> и все связанные данные.
                </>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setStaffActionConfirm(null);
                  setStaffActionError(null);
                }}
                disabled={staffActionProcessing}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors disabled:opacity-50"
              >
                Отмена
              </button>
              <button
                type="button"
                onClick={handleExecuteStaffAction}
                disabled={staffActionProcessing}
                className={`px-4 py-2 text-xs font-semibold text-white rounded-xl transition-colors shadow-sm disabled:opacity-50 flex items-center gap-1.5 ${
                  staffActionConfirm.type === 'block'
                    ? 'bg-amber-600 hover:bg-amber-500'
                    : staffActionConfirm.type === 'archive'
                    ? 'bg-sky-600 hover:bg-sky-500'
                    : staffActionConfirm.type === 'restore'
                    ? 'bg-emerald-600 hover:bg-emerald-500'
                    : 'bg-red-600 hover:bg-red-500'
                }`}
              >
                {staffActionProcessing ? (
                  <span>Выполнение...</span>
                ) : (
                  <span>
                    {staffActionConfirm.type === 'block' && 'Заблокировать'}
                    {staffActionConfirm.type === 'archive' && 'В архив'}
                    {staffActionConfirm.type === 'restore' && 'Восстановить'}
                    {staffActionConfirm.type === 'delete' && 'Да, удалить'}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Shift Confirmation Modal */}
      {shiftToDelete && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center border border-red-500/30 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Подтверждение удаления</h4>
                <p className="text-xs text-slate-400">Действие нельзя отменить</p>
              </div>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed">
              Вы точно хотите удалить смену сотрудника <strong className="text-white">{selectedStaff?.name}</strong> за дату{' '}
              <strong className="text-emerald-400">{formatDateRuDMY(shiftToDelete.date)}</strong>?
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShiftToDelete(null)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
              >
                Отмена
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteShift}
                disabled={shiftActionLoading}
                className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-500 rounded-xl transition-colors shadow-sm disabled:opacity-50 flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{shiftActionLoading ? 'Удаление...' : 'Да, точно удалить'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Account Modal */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2 text-white font-semibold">
                <UserPlus className="w-5 h-5 text-emerald-400" />
                <span>Создание доступа сотруднику</span>
              </div>
              <button
                onClick={() => setIsCreateOpen(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-4 space-y-3.5 text-xs flex-1 overflow-y-auto">
              {createError && (
                <div className="p-2.5 bg-red-950/50 border border-red-800/80 rounded-xl text-red-300 flex items-center gap-2 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{createError}</span>
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-medium mb-1">ФИО сотрудника *</label>
                <input
                  type="text"
                  required
                  placeholder="Иванов Иван Иванович"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Логин *</label>
                  <input
                    type="text"
                    required
                    value={newLogin}
                    onChange={e => setNewLogin(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Пароль *</label>
                  <input
                    type="text"
                    required
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Telegram (юзернейм, опционально)</label>
                <input
                  type="text"
                  placeholder="@username"
                  value={newTelegram}
                  onChange={e => setNewTelegram(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                />
              </div>

              {/* Workplace Locations Multi-select */}
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">Разрешенные пункты выдачи (ПВЗ):</label>
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl overflow-y-auto max-h-40">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {pickupPoints.map(pt => {
                      const code = pt.code;
                      const isSelected = newLocations.includes(code);
                      return (
                        <button
                          key={code}
                          type="button"
                          onClick={() => toggleLocationSelection(code, newLocations, setNewLocations)}
                          className={`py-1.5 px-2.5 rounded-xl border transition-all flex items-center justify-between text-xs box-border focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-1 focus:ring-offset-slate-950 ${
                            isSelected
                              ? 'bg-emerald-950/90 border-emerald-500 text-emerald-300 font-medium shadow-sm ring-1 ring-emerald-500/50'
                              : 'bg-slate-900/90 border-slate-700 text-slate-300 hover:border-slate-500 hover:text-white'
                          }`}
                        >
                          <span className="truncate">{pt.code}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 ml-1" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Status Toggles: Senior & Part-time */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newIsSenior}
                    onChange={e => setNewIsSenior(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-500 focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-950 w-4 h-4 bg-slate-900 accent-emerald-500 cursor-pointer"
                  />
                  <span className="text-slate-300 font-medium">Старший смены (доплата за смену)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={newIsPartTime}
                    onChange={e => setNewIsPartTime(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-500 focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-950 w-4 h-4 bg-slate-900 accent-emerald-500 cursor-pointer"
                  />
                  <span className="text-slate-300 font-medium">Подработчик (сменный график)</span>
                </label>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-400"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-2 focus:ring-offset-slate-900"
                >
                  Создать доступ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Credentials Modal */}
      {editCredStaff && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md max-h-[92dvh] sm:max-h-[88vh] flex flex-col overflow-hidden shadow-2xl my-auto">
            <div className="flex items-center justify-between p-4 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2 text-white font-semibold">
                <Edit2 className="w-4 h-4 text-sky-400" />
                <span>Редактирование данных: {editCredStaff.name}</span>
              </div>
              <button
                onClick={() => setEditCredStaff(null)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="p-4 space-y-3.5 text-xs flex-1 overflow-y-auto">
              {editError && (
                <div className="p-2.5 bg-red-950/50 border border-red-800/80 rounded-xl text-red-300 flex items-center gap-2 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{editError}</span>
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-medium mb-1">Имя сотрудника *</label>
                <input
                  type="text"
                  required
                  placeholder="Иван Иванов"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Логин *</label>
                <input
                  type="text"
                  required
                  value={editLogin}
                  onChange={e => setEditLogin(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Новый пароль (оставьте пустым, если не меняется)</label>
                <input
                  type="text"
                  placeholder="Оставить без изменений"
                  value={editPassword}
                  onChange={e => setEditPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Telegram (юзернейм, опционально)</label>
                <input
                  type="text"
                  placeholder="@username"
                  value={editTelegram}
                  onChange={e => setEditTelegram(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700/80 rounded-xl text-white font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 focus:bg-slate-900 transition-all shadow-sm"
                />
              </div>

              {/* Workplaces Multi-select */}
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">Разрешенные пункты выдачи (ПВЗ):</label>
                <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl overflow-y-auto max-h-40">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {pickupPoints.map(pt => {
                      const code = pt.code;
                      const isSelected = editLocations.includes(code);
                      return (
                        <button
                          key={code}
                          type="button"
                          onClick={() => toggleLocationSelection(code, editLocations, setEditLocations)}
                          className={`py-1.5 px-2.5 rounded-xl border transition-all flex items-center justify-between text-xs box-border focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-1 focus:ring-offset-slate-950 ${
                            isSelected
                              ? 'bg-emerald-950/90 border-emerald-500 text-emerald-300 font-medium shadow-sm ring-1 ring-emerald-500/50'
                              : 'bg-slate-900/90 border-slate-700 text-slate-300 hover:border-slate-500 hover:text-white'
                          }`}
                        >
                          <span className="truncate">{pt.code}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 ml-1" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Status Toggles: Senior & Part-time */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={editIsSenior}
                    onChange={e => setEditIsSenior(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-500 focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-950 w-4 h-4 bg-slate-900 accent-emerald-500 cursor-pointer"
                  />
                  <span className="text-slate-300 font-medium">Старший смены (доплата за смену)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={editIsPartTime}
                    onChange={e => setEditIsPartTime(e.target.checked)}
                    className="rounded border-slate-700 text-emerald-500 focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-950 w-4 h-4 bg-slate-900 accent-emerald-500 cursor-pointer"
                  />
                  <span className="text-slate-300 font-medium">Подработчик (сменный график)</span>
                </label>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditCredStaff(null)}
                  className="px-4 py-2 text-slate-400 hover:text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-400"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:ring-offset-2 focus:ring-offset-slate-900"
                >
                  Сохранить
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
