import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ExternalLink,
  Eye,
  EyeOff,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  X,
  Edit2,
  Lock,
  Check,
  FileText,
} from 'lucide-react';

interface TelegramTemplateItem {
  id: string;
  name: string;
  description: string;
  variables: string[];
  template: string;
}

const DEFAULT_TEMPLATES: Record<string, TelegramTemplateItem> = {
  checkin: {
    id: 'checkin',
    name: 'Отметка Check-in',
    description: 'Уведомление руководителю о начале смены сотрудником на пункте выдачи',
    variables: ['{employeeName}', '{location}', '{shiftType}', '{date}'],
    template: '🔔 *Новая отметка Check-in!*\n\n👤 *Сотрудник:* {employeeName}\n📍 *Пункт:* {location}\n🕒 *Смена:* {shiftType}\n📅 *Дата:* {date}',
  },
  daily_report: {
    id: 'daily_report',
    name: 'Вечерний сводный отчет (21:15)',
    description: 'Итоговая сводка выручки по сотрудникам, наличным, картам и премиям',
    variables: ['{date}', '{staffList}', '{totalRevenue}', '{totalBonus}', '{totalCash}', '{totalCard}'],
    template: '💰 *Отчёт по продажам на {date}*\n\n{staffList}\n\n─────────────────\n💵 Итог дня: *{totalRevenue} ₽*\n🎁 Премия: *{totalBonus} ₽*\n💵 Наличные: *{totalCash} ₽*\n💳 Безналичные: *{totalCard} ₽*',
  },
  swap_status: {
    id: 'swap_status',
    name: 'Решение по бирже смен',
    description: 'Оповещение о согласовании или отклонении заявки на передачу смены',
    variables: ['{status}', '{date}', '{location}', '{requesterName}', '{candidateName}'],
    template: '📋 *Решение по замене смены: {status}*\n📅 Дата: *{date}* ({location})\n👤 Передал: *{requesterName}*\n👤 Принял: *{candidateName}*',
  },
};

export const TelegramSettingsView: React.FC = () => {
  const {
    telegramSettings,
    fetchTelegramSettings,
    saveTelegramSettings,
    testTelegramConnection,
    disconnectTelegram,
    apiFetch,
    csrfToken,
  } = useApp();

  const [botToken, setBotToken] = useState('');
  const [managerChatId, setManagerChatId] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [isDisconnecting, setIsDisconnecting] = useState(false);
  const [isEditingParams, setIsEditingParams] = useState(false);

  const [saveStatus, setSaveStatus] = useState<{ type: 'idle' | 'success' | 'error'; message?: string }>({
    type: 'idle',
  });
  const [testStatus, setTestStatus] = useState<{ type: 'idle' | 'success' | 'error'; message?: string }>({
    type: 'idle',
  });
  const [isInstructionsOpen, setIsInstructionsOpen] = useState(false);

  // Templates state
  const [templates, setTemplates] = useState<Record<string, TelegramTemplateItem>>(DEFAULT_TEMPLATES);
  const [activeTemplateKey, setActiveTemplateKey] = useState<string>('daily_report');

  const isConfigured = !!telegramSettings?.isConfigured;

  useEffect(() => {
    if (telegramSettings) {
      if (telegramSettings.botToken) {
        setBotToken(telegramSettings.botToken);
      }
      if (telegramSettings.managerChatId) {
        setManagerChatId(telegramSettings.managerChatId);
      }
    }
  }, [telegramSettings]);

  useEffect(() => {
    fetchTelegramSettings();
    loadTemplates();
  }, [fetchTelegramSettings]);

  const loadTemplates = async () => {
    try {
      const res = await apiFetch('/api/v1/telegram/templates');
      const data = await res.json();
      if (data.success && data.templates && typeof data.templates === 'object') {
        setTemplates(prev => ({
          ...prev,
          ...data.templates,
        }));
      }
    } catch (e) {
      console.warn('Failed to load telegram templates:', e);
    }
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanToken = botToken.trim();
    const cleanChatId = managerChatId.trim();

    if (!cleanToken) {
      setSaveStatus({ type: 'error', message: 'Укажите токен бота Telegram.' });
      return;
    }
    if (!cleanChatId) {
      setSaveStatus({ type: 'error', message: 'Укажите Chat ID руководителя.' });
      return;
    }

    if (cleanChatId.startsWith('@')) {
      setSaveStatus({
        type: 'error',
        message: 'Chat ID должен быть числовым (например, 123456789), а не юзернеймом (@имя). Узнайте свой числовой ID у бота @userinfobot.',
      });
      return;
    }

    if (!/^-?\d+$/.test(cleanChatId)) {
      setSaveStatus({
        type: 'error',
        message: 'Chat ID должен состоять только из цифр (например: 320314713). Узнайте свой числовой ID у бота @userinfobot в Telegram.',
      });
      return;
    }

    setIsSaving(true);
    setSaveStatus({ type: 'idle' });
    setTestStatus({ type: 'idle' });

    try {
      const result = await saveTelegramSettings(cleanToken, cleanChatId);
      if (result.success) {
        setIsEditingParams(false);
        setSaveStatus({
          type: 'success',
          message: `Параметры успешно сохранены.${
            result.botUsername ? ` Имя бота: @${result.botUsername}.` : ''
          } Параметры защищены от случайной правки.`,
        });
        setTimeout(() => setSaveStatus({ type: 'idle' }), 6000);
      } else {
        setSaveStatus({
          type: 'error',
          message: result.error || 'Не удалось применить параметры. Проверьте корректность токена.',
        });
      }
    } catch (err: any) {
      setSaveStatus({
        type: 'error',
        message: err.message || 'Ошибка связи с сервером при сохранении.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancelEditParams = () => {
    setIsEditingParams(false);
    if (telegramSettings) {
      setBotToken(telegramSettings.botToken || '');
      setManagerChatId(telegramSettings.managerChatId || '');
    }
    setSaveStatus({ type: 'idle' });
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestStatus({ type: 'idle' });

    try {
      const result = await testTelegramConnection();
      if (result.success) {
        setTestStatus({
          type: 'success',
          message: 'Тестовое сообщение доставлено. Соединение с Telegram установлено.',
        });
      } else {
        const errorMsg = result.error || 'Не удалось доставить тестовое сообщение.';
        if (
          errorMsg.includes('403') ||
          errorMsg.toLowerCase().includes('initiate') ||
          errorMsg.toLowerCase().includes('start')
        ) {
          setTestStatus({
            type: 'error',
            message: `${errorMsg} Требуется активация диалога: откройте диалог с ботом в Telegram и отправьте команду /start, затем повторите проверку.`,
          });
        } else {
          setTestStatus({
            type: 'error',
            message: errorMsg,
          });
        }
      }
    } catch (err: any) {
      setTestStatus({
        type: 'error',
        message: err.message || 'Ошибка сети при отправке тестового сообщения.',
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleDisconnect = async () => {
    if (!window.confirm('Отключить интеграцию с Telegram? Отправка уведомлений руководителю будет приостановлена.')) {
      return;
    }

    setIsDisconnecting(true);
    try {
      const result = await disconnectTelegram();
      if (result.success) {
        setBotToken('');
        setManagerChatId('');
        setIsEditingParams(true);
        setSaveStatus({
          type: 'success',
          message: 'Интеграция отключена. Параметры очищены.',
        });
        setTimeout(() => setSaveStatus({ type: 'idle' }), 5000);
      } else {
        setSaveStatus({
          type: 'error',
          message: result.error || 'Не удалось отключить интеграцию.',
        });
      }
    } catch (err: any) {
      setSaveStatus({
        type: 'error',
        message: err.message || 'Ошибка при обращении к серверу.',
      });
    } finally {
      setIsDisconnecting(false);
    }
  };

  const activeTemplate = templates[activeTemplateKey] || DEFAULT_TEMPLATES[activeTemplateKey];

  // Helper to generate simulated preview for the active template
  const getSimulatedPreview = (tplText: string) => {
    return tplText
      .replace(/{employeeName}/g, 'Иван Смирнов')
      .replace(/{location}/g, 'ПВЗ-1 (Ленина)')
      .replace(/{shiftType}/g, 'Обычная смена')
      .replace(/{date}/g, '29.10.2026')
      .replace(/{status}/g, 'ОДОБРЕНА ✅')
      .replace(/{requesterName}/g, 'Анна Кузнецова')
      .replace(/{candidateName}/g, 'Иван Смирнов')
      .replace(/{staffList}/g, '🟢 Иван Смирнов (Обычная смена, ПВЗ-1): 18 400 ₽\n🟢 Анна К. (400+, ПВЗ-2): 24 100 ₽')
      .replace(/{totalRevenue}/g, '42 500')
      .replace(/{totalBonus}/g, '1 500')
      .replace(/{totalCash}/g, '12 000')
      .replace(/{totalCard}/g, '30 500');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-10">
      {/* Page Header */}
      <div className="pb-3 border-b border-slate-800">
        <h1 className="text-lg font-semibold text-white tracking-tight">
          Интеграция с Telegram
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Параметры бота, управление доступом, шаблоны отчетов для руководителя и рассылка сотрудникам.
        </p>
      </div>

      {/* Status Panel */}
      <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start md:items-center gap-3">
          <span
            className={`w-2 h-2 rounded-full mt-1.5 md:mt-0 shrink-0 ${
              isConfigured ? 'bg-emerald-500' : 'bg-slate-600'
            }`}
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-200">
                {isConfigured ? 'Интеграция активна' : 'Интеграция не настроена'}
              </span>
              {isConfigured && telegramSettings?.botUsername && (
                <span className="text-[11px] font-mono text-emerald-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                  @{telegramSettings.botUsername}
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
              {isConfigured
                ? `Chat ID: ${telegramSettings?.managerChatId || '—'}${
                    telegramSettings?.updatedAt
                      ? ` · Изменено: ${new Date(telegramSettings.updatedAt).toLocaleDateString('ru-RU')}`
                      : ''
                  }`
                : 'По умолчанию отправка отключена. Заполните токен бота и ID получателя ниже.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
          {isConfigured && (
            <>
              <button
                type="button"
                onClick={handleTestConnection}
                disabled={isTesting}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-medium transition-colors disabled:opacity-50"
              >
                {isTesting ? 'Проверка...' : 'Проверить связь'}
              </button>

              <button
                type="button"
                onClick={handleDisconnect}
                disabled={isDisconnecting}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-red-950/60 hover:text-red-300 hover:border-red-800/60 text-slate-400 border border-slate-700 text-xs transition-colors disabled:opacity-50"
              >
                {isDisconnecting ? 'Отключение...' : 'Отключить'}
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => fetchTelegramSettings()}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-slate-200 border border-slate-700 transition-colors"
            title="Синхронизировать статус"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Status Notifications */}
      {testStatus.type !== 'idle' && (
        <div
          className={`p-3 rounded-lg border text-xs leading-relaxed flex items-start justify-between gap-2 bg-slate-900 text-white shadow-md ${
            testStatus.type === 'success'
              ? 'border-emerald-500/50'
              : 'border-red-500/50'
          }`}
        >
          <span className="text-white font-medium">{testStatus.message}</span>
          <button
            onClick={() => setTestStatus({ type: 'idle' })}
            className="text-slate-400 hover:text-white shrink-0 ml-2 p-0.5"
            title="Закрыть"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {saveStatus.type !== 'idle' && (
        <div
          className={`p-3 rounded-lg border text-xs leading-relaxed flex items-start justify-between gap-2 bg-slate-900 text-white shadow-md ${
            saveStatus.type === 'success'
              ? 'border-emerald-500/50'
              : 'border-red-500/50'
          }`}
        >
          <span className="text-white font-medium">{saveStatus.message}</span>
          <button
            onClick={() => setSaveStatus({ type: 'idle' })}
            className="text-slate-400 hover:text-white shrink-0 ml-2 p-0.5"
            title="Закрыть"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Settings Form with Accidental Edit Protection & Prominent Buttons */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Параметры подключения
            </h2>
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium border ${
                isEditingParams
                  ? 'bg-amber-950/30 text-amber-300 border-amber-800/50'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {isEditingParams ? (
                <>
                  <Edit2 className="w-2.5 h-2.5 text-amber-400" />
                  <span>Режим редактирования</span>
                </>
              ) : (
                <>
                  <Lock className="w-2.5 h-2.5 text-slate-400" />
                  <span>Защищено от случайной правки</span>
                </>
              )}
            </span>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs text-slate-300 flex items-center gap-1.5">
                <span>Токен бота (Bot Token)</span>
                <span className="text-red-400">*</span>
                {!isEditingParams && <Lock className="w-3 h-3 text-slate-500" />}
              </label>
              <a
                href="https://t.me/BotFather"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] text-slate-400 hover:text-slate-200 inline-flex items-center gap-1"
              >
                <span>@BotFather</span>
                <ExternalLink className="w-3 h-3 text-slate-500" />
              </a>
            </div>

            <div className="relative">
              <input
                type={showToken ? 'text' : 'password'}
                value={botToken}
                onChange={e => setBotToken(e.target.value)}
                disabled={!isEditingParams}
                placeholder="1234567890:ABCdefGhIJKlmNoPQRsTUVwxyZ_1234567"
                required
                className={`w-full bg-slate-950 border rounded px-3 py-2 text-xs text-white font-mono placeholder:text-slate-600 focus:outline-none transition-colors pr-9 ${
                  !isEditingParams
                    ? 'border-slate-800/80 bg-slate-950/70 text-slate-400 cursor-not-allowed select-none'
                    : 'border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowToken(!showToken)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-0.5"
                title={showToken ? 'Скрыть' : 'Показать'}
              >
                {showToken ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Ключ доступа к Bot API, полученный от @BotFather в Telegram.
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs text-slate-300 flex items-center gap-1.5">
                <span>Chat ID руководителя</span>
                <span className="text-red-400">*</span>
                {!isEditingParams && <Lock className="w-3 h-3 text-slate-500" />}
              </label>
              <a
                href="https://t.me/userinfobot"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] text-slate-400 hover:text-slate-200 inline-flex items-center gap-1"
              >
                <span>@userinfobot</span>
                <ExternalLink className="w-3 h-3 text-slate-500" />
              </a>
            </div>

            <input
              type="text"
              value={managerChatId}
              onChange={e => setManagerChatId(e.target.value)}
              disabled={!isEditingParams}
              placeholder="320314713"
              required
              className={`w-full bg-slate-950 border rounded px-3 py-2 text-xs text-white font-mono placeholder:text-slate-600 focus:outline-none transition-colors ${
                !isEditingParams
                  ? 'border-slate-800/80 bg-slate-950/70 text-slate-400 cursor-not-allowed select-none'
                  : 'border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500'
              }`}
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Идентификатор руководителя в Telegram (числовой Chat ID, например: 320314713).
            </p>
          </div>

          {isEditingParams && (
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded text-[11px] text-slate-400 leading-relaxed">
              <span className="text-slate-300 font-medium">Важно:</span> Перед сохранением и проверкой связи обязательно откройте диалог с созданным ботом в приложении Telegram и выполните команду <span className="font-mono text-slate-200">/start</span>.
            </div>
          )}

          {/* Explicit Action Buttons: Редактировать and Сохранить */}
          <div className="pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-[11px] text-slate-500">
              {!isEditingParams ? (
                <span>Для изменения токена или Chat ID нажмите кнопку «Редактировать».</span>
              ) : (
                <span className="text-amber-300/90 font-medium">Поля открыты для редактирования. Внесите изменения и нажмите «Сохранить».</span>
              )}
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              {!isEditingParams ? (
                <>
                  <button
                    type="button"
                    onClick={() => setIsEditingParams(true)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Редактировать</span>
                  </button>

                  <button
                    type="button"
                    disabled
                    className="px-4 py-2 bg-emerald-600/30 text-emerald-300/40 rounded text-xs font-semibold flex items-center gap-1.5 cursor-not-allowed light:bg-white light:text-slate-800 light:border light:border-slate-300 shadow-xs"
                    title="Нажмите «Редактировать» перед сохранением"
                  >
                    <Check className="w-3.5 h-3.5 light:text-slate-700" />
                    <span>Сохранить</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={handleCancelEditParams}
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs rounded font-medium transition-colors cursor-pointer"
                  >
                    Отмена
                  </button>

                  <button
                    type="submit"
                    disabled={isSaving}
                    className="py-1.5 px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-medium text-xs rounded-md transition-colors shadow-sm disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{isSaving ? 'Сохранение...' : 'Сохранить'}</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </form>
      </div>

      {/* Telegram Report Templates Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="pb-3 border-b border-slate-800">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            <span>Шаблоны Telegram-отчетов для руководителя</span>
          </h2>
        </div>

        {/* Template Selector Tabs */}
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800">
          {Object.entries(templates).map(([key, tpl]) => {
            const isActive = activeTemplateKey === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => {
                  setActiveTemplateKey(key);
                }}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-800 text-white font-semibold shadow-sm border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                {tpl.name}
              </button>
            );
          })}
        </div>

        {/* Template Preview (Read-only View) */}
        <div className="space-y-3 pt-1">
          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg space-y-2">
            <div className="text-[11px] text-slate-400 font-medium">
              <span>Пример отображения в Telegram:</span>
            </div>
            <div className="p-3 rounded bg-slate-900 border border-slate-800/80 text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed">
              {getSimulatedPreview(activeTemplate.template)}
            </div>
          </div>
        </div>
      </div>

      {/* Technical Documentation / Setup Reference */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <button
          type="button"
          onClick={() => setIsInstructionsOpen(!isInstructionsOpen)}
          className="w-full px-4 py-3 flex items-center justify-between text-left hover:bg-slate-850/60 transition-colors cursor-pointer"
        >
          <span className="text-xs font-medium text-slate-300">
            Справка по регистрации и настройке бота
          </span>
          {isInstructionsOpen ? (
            <ChevronUp className="w-3.5 h-3.5 text-slate-500" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
          )}
        </button>

        {isInstructionsOpen && (
          <div className="px-4 pb-4 pt-1 border-t border-slate-800 text-xs text-slate-400 space-y-2.5">
            <div className="space-y-1">
              <span className="text-slate-200 font-medium">1. Регистрация бота:</span>
              <p className="text-[11px] leading-relaxed">
                Откройте диалог с официальным сервисом @BotFather в Telegram. Отправьте команду <span className="font-mono text-slate-300">/newbot</span>. Укажите экранное имя бота и системный username с окончанием bot (например, <span className="font-mono text-slate-300">pvz_alerts_bot</span>). Скопируйте предоставленный HTTP API токен.
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-slate-200 font-medium">2. Определение Chat ID:</span>
              <p className="text-[11px] leading-relaxed">
                Откройте бот @userinfobot или @getmyid_bot в Telegram и отправьте команду <span className="font-mono text-slate-300">/start</span>. Скопируйте цифровое значение из строки Id.
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-slate-200 font-medium">3. Рассылка сотрудникам:</span>
              <p className="text-[11px] leading-relaxed">
                Если в карточке сотрудника указан Telegram юзернейм (например, @ivan_pvz), планировщик автоматически доставляет рассылки и напоминания сотруднику в личные сообщения Telegram.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Monolithic Notification Scenarios Reference - Fully Restored */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 pb-2 border-b border-slate-800">
          Сценарии автоматической отправки
        </h3>

        <div className="divide-y divide-slate-800/60 text-xs">
          <div className="py-2 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <span className="font-medium text-slate-200 shrink-0 sm:w-56">Открытие смены (Check-in)</span>
            <span className="text-slate-400 text-[11px]">Фиксация выхода сотрудника на точку, время явки, остаток разменной кассы.</span>
          </div>

          <div className="py-2 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <span className="font-medium text-slate-200 shrink-0 sm:w-56">Закрытие смены и касса</span>
            <span className="text-slate-400 text-[11px]">Фактическая сумма наличных, безналичный расчет, фотоуслуги, печать, ламинация.</span>
          </div>

          <div className="py-2 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <span className="font-medium text-slate-200 shrink-0 sm:w-56">Контроль открытия точек</span>
            <span className="text-slate-400 text-[11px]">Оповещение руководителя при отсутствии явки сотрудника к 09:00 / 10:00.</span>
          </div>

          <div className="py-2 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <span className="font-medium text-slate-200 shrink-0 sm:w-56">Биржа смен</span>
            <span className="text-slate-400 text-[11px]">Публикация запроса на подмену, принятие смены коллегой или отмена запроса.</span>
          </div>

          <div className="py-2 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <span className="font-medium text-slate-200 shrink-0 sm:w-56">Анкеты кандидатов</span>
            <span className="text-slate-400 text-[11px]">Поступление новой заявки соискателя на регистрацию в учетной системе.</span>
          </div>

          <div className="py-2 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <span className="font-medium text-slate-200 shrink-0 sm:w-56">Обращения персонала</span>
            <span className="text-slate-400 text-[11px]">Оперативные сообщения сотрудников из интерфейса рабочего места.</span>
          </div>

          <div className="py-2 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
            <span className="font-medium text-slate-200 shrink-0 sm:w-56">Сводная отчетность</span>
            <span className="text-slate-400 text-[11px]">Ежедневная финансовая сводка по всем ПВЗ сети по запросу или расписанию.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
