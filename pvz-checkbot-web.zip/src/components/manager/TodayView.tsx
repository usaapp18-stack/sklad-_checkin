import React from 'react';
import { useApp } from '../../context/AppContext';
import { SHIFT_LABELS } from '../../types';
import { calculateDailySales, formatCurrency, getBaseShiftPay, normalizeShiftType, calculateShiftTotalSalary, getShiftLabel } from '../../utils/calculations';
import { formatDisplayDate, parseDateSafe } from '../../utils/time';
import { CheckCircle2, Clock, AlertCircle, TrendingUp, DollarSign, Camera, Printer, Layers, Banknote } from 'lucide-react';

export const TodayView: React.FC = () => {
  const { staffList, records, todayDate, rates } = useApp();

  const activeStaff = staffList.filter(s => s.status === 'active');

  let dayTotalRevenue = 0;
  let dayTotalBonus = 0;
  let dayTotalCash = 0;
  let dayTotalCard = 0;
  let dayTotalSalary = 0;
  let dayTotalBaseSalary = 0;
  let checkedInCount = 0;
  let checkedInRegularCount = 0;
  let salesSubmittedCount = 0;

  const staffTodayStatus = activeStaff.map(staff => {
    const record = records.find(r => r.employeeId === staff.id && r.date === todayDate);
    const hasCheckedIn = !!record?.shiftType;
    const hasSales = !!record?.sales;
    const calc = calculateDailySales(record?.sales);

    let baseSalary = 0;
    let totalSalary = 0;

    if (hasCheckedIn && record?.shiftType) {
      checkedInCount++;
      if (!staff.isPartTime) checkedInRegularCount++;

      let pay = calculateShiftTotalSalary(record, staff, rates);

      baseSalary = pay;
      totalSalary = baseSalary + calc.bonus;

      dayTotalBaseSalary += baseSalary;
      dayTotalSalary += totalSalary;
    }

    if (hasSales) {
      salesSubmittedCount++;
      dayTotalRevenue += calc.totalSales;
      dayTotalBonus += calc.bonus;
      dayTotalCash += calc.totalCash;
      dayTotalCard += calc.totalCard;
    }

    return {
      staff,
      record,
      hasCheckedIn,
      hasSales,
      calc,
      baseSalary,
      totalSalary,
    };
  });

  return (
    <div className="space-y-5">
      
      {/* Top Unified KPI Summary Strip (ERP standard) */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-800 overflow-hidden shadow-sm">
        <div className="p-4 sm:p-5">
          <div className="text-xs text-slate-400 font-medium">Явка сотрудников</div>
          <div className="text-2xl font-semibold text-white font-mono tabular-nums tracking-tight mt-1">
            {checkedInCount} <span className="text-xs font-normal text-slate-500 font-sans">из {activeStaff.length}</span>
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            {checkedInCount === activeStaff.length ? 'Все на месте' : `Ожидают: ${activeStaff.length - checkedInCount}`}
          </div>
        </div>

        <div className="p-4 sm:p-5">
          <div className="text-xs text-slate-400 font-medium">ФОТ за сегодня</div>
          <div className="text-2xl font-semibold text-white font-mono tabular-nums tracking-tight mt-1">
            {formatCurrency(dayTotalSalary)}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            Оклад {formatCurrency(dayTotalBaseSalary)} · Премия +{formatCurrency(dayTotalBonus)}
          </div>
        </div>

        <div className="p-4 sm:p-5">
          <div className="text-xs text-slate-400 font-medium">Выручка за сегодня</div>
          <div className="text-2xl font-semibold text-white font-mono tabular-nums tracking-tight mt-1">
            {formatCurrency(dayTotalRevenue)}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            Нал {formatCurrency(dayTotalCash)} · Безнал {formatCurrency(dayTotalCard)}
          </div>
        </div>

        <div className="p-4 sm:p-5">
          <div className="text-xs text-slate-400 font-medium">Премиальный фонд (5%)</div>
          <div className="text-2xl font-semibold text-emerald-400 font-mono tabular-nums tracking-tight mt-1">
            +{formatCurrency(dayTotalBonus)}
          </div>
          <div className="text-xs text-slate-500 mt-1.5 truncate">
            5% от выручки за смену
          </div>
        </div>
      </div>

      {/* Staff Table / Today Status List */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium text-white">Текущая смена сотрудников</h3>
            <p className="text-xs text-slate-400 mt-0.5">{formatDisplayDate(todayDate)} (МСК)</p>
          </div>
          <span className="text-xs text-slate-400 font-mono tabular-nums">
            Активных: {activeStaff.length}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs font-medium text-slate-400 bg-slate-950/70">
                <th className="py-2.5 px-4 font-medium">Сотрудник</th>
                <th className="py-2.5 px-4 font-medium">Пункт смены</th>
                <th className="py-2.5 px-4 font-medium">Статус Check-in</th>
                <th className="py-2.5 px-4 font-medium">Тип смены</th>
                <th className="py-2.5 px-4 font-medium">Продажи</th>
                <th className="py-2.5 px-4 font-medium text-right whitespace-nowrap min-w-[105px]">Выручка</th>
                <th className="py-2.5 px-4 font-medium text-right whitespace-nowrap min-w-[110px]">ЗП</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {staffTodayStatus.map(({ staff, record, hasCheckedIn, hasSales, calc, baseSalary, totalSalary }) => {
                const staffLocs = staff.locations || (staff.location ? [staff.location] : []);

                return (
                  <tr key={staff.id} className="hover:bg-slate-800/30 transition-colors">
                    
                    {/* Staff Info */}
                    <td className="py-3 px-4">
                      <div className="font-medium text-white">
                        {staff.name}
                      </div>
                      <div className="text-xs text-slate-400">{staff.telegramUsername || '—'}</div>
                    </td>

                    {/* Workplace for Today */}
                    <td className="py-3 px-4">
                      {hasCheckedIn && record?.location ? (
                        <span className="text-xs font-mono font-medium text-slate-200">
                          {record.location}
                        </span>
                      ) : (
                        <span className="text-slate-500 font-normal">—</span>
                      )}
                    </td>

                    {/* Check-in Status */}
                    <td className="py-3 px-4">
                      {hasCheckedIn ? (
                        <div className="inline-flex items-center gap-1.5 text-slate-200 font-normal">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                          <span>Отмечен ({parseDateSafe(record!.checkedInAt || record!.timestamp).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })})</span>
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-1.5 text-slate-400 font-normal">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                          <span>Не отмечен</span>
                        </div>
                      )}
                    </td>

                    {/* Shift Type */}
                    <td className="py-3 px-4">
                      {hasCheckedIn && record?.shiftType ? (
                        <span className="font-medium text-slate-200">
                          {getShiftLabel(record.shiftType, rates)}
                        </span>
                      ) : (
                        <span className="text-slate-500">—</span>
                      )}
                    </td>

                    {/* Sales Status & Breakdown */}
                    <td className="py-3 px-4">
                      {hasSales ? (
                        <div className="space-y-0.5 text-xs">
                          <div className="text-emerald-400 font-medium">Внесены</div>
                          <div className="text-slate-400 font-mono tabular-nums text-[11px]">
                            Нал: {calc.totalCash} ₽ · Карта: {calc.totalCard} ₽
                          </div>
                        </div>
                      ) : staff.isPartTime ? (
                        <span className="text-slate-500 text-xs">Не требуется (подработчик)</span>
                      ) : hasCheckedIn ? (
                        <span className="text-sky-400 text-xs font-normal">Ожидает внесения</span>
                      ) : (
                        <span className="text-slate-500 text-xs">После Check-in</span>
                      )}
                    </td>

                    {/* Daily Revenue */}
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-white whitespace-nowrap">
                      {hasSales ? formatCurrency(calc.totalSales) : '—'}
                    </td>

                    {/* Daily Salary */}
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-emerald-400 whitespace-nowrap">
                      {hasCheckedIn ? (
                        <div>
                          <div className="whitespace-nowrap">{formatCurrency(totalSalary)}</div>
                          {calc.bonus > 0 && (
                            <div className="text-[11px] text-slate-500 font-normal whitespace-nowrap">
                              {formatCurrency(baseSalary)} + {formatCurrency(calc.bonus)}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-500">—</span>
                      )}
                    </td>

                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="border-t border-slate-800 bg-slate-950 font-medium text-xs">
                <td colSpan={5} className="py-3 px-4 text-slate-300">
                  Итого за день (по всем сотрудникам):
                </td>
                <td className="py-3 px-4 text-right font-mono tabular-nums text-white text-sm font-semibold whitespace-nowrap">
                  {formatCurrency(dayTotalRevenue)}
                </td>
                <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-400 text-sm font-semibold whitespace-nowrap">
                  {formatCurrency(dayTotalSalary)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

    </div>
  );
};
