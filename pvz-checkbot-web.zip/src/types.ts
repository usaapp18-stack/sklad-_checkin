export type ShiftType = 'standard' | '400+' | '500+' | '8h' | '4h' | 'rate400' | 'rate500' | 'shift8h' | 'shift4h' | (string & {});

export const SHIFT_LABELS: Record<string, string> = {
  'standard': 'Обычная смена',
  '400+': '400+',
  '500+': '500+',
  '8h': '8 часов',
  '4h': '4 часа',
  'rate400': '400+',
  'rate500': '500+',
  'shift8h': '8 часов',
  'shift4h': '4 часа',
};

export type StaffStatus = 'pending' | 'active' | 'deactivated' | 'blocked' | 'archived';

export interface CategorySales {
  cash: number;
  card: number;
}

export interface DailySales {
  cash?: number;
  card?: number;
  total?: number;
  photo?: CategorySales;
  print?: CategorySales;
  lamination?: CategorySales;
}

export interface PickupPoint {
  id: string;
  code: string; // e.g. "СД", "БД", "ПВЗ-1", "Л15"
  name: string; // e.g. "ПВЗ Северный", "ПВЗ Ленина 15"
  address?: string;
  active: boolean;
  isArchived?: boolean;
  archivedAt?: string;
  assignedStaffIds?: string[];
  contactPhone?: string;
  notes?: string;
  createdAt?: string;
}

export type LocationType = string;

export interface CheckInRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // YYYY-MM-DD
  shiftType: ShiftType | null;
  location?: LocationType; // Workplace chosen for the day: СД or БД
  checkedInAt?: string; // ISO string
  timestamp?: string; // fallback historical ISO string
  editCount?: number; // Количество изменений сотрудником (макс 1 раз)
  cancelCount?: number; // Количество отмен Check-in сотрудником (макс 1 раз)
  initialCash?: number; // Размен / остаток в кассе на начало смены
  finalCash?: number; // Остаток в кассе на конец смены
  collectedCash?: number; // Сумма инкассации / передачи
  cashNotes?: string;
  sales: DailySales | null;
  salesSubmittedAt?: string;
  notes?: string;
  baseRate?: number;
}

export interface ShiftSwapRequest {
  id: string;
  requesterId: string;
  requesterName: string;
  date: string; // YYYY-MM-DD
  shiftType: ShiftType;
  location: LocationType;
  reason?: string;
  candidateId?: string;
  candidateName?: string;
  status: 'open' | 'claimed' | 'approved' | 'rejected' | 'cancelled';
  createdAt: string;
  resolvedAt?: string;
}

export interface PlannedShift {
  id: string;
  date: string; // YYYY-MM-DD
  location: LocationType;
  employeeId: string;
  employeeName: string;
  shiftType: ShiftType;
  note?: string;
  createdAt?: string;
}

export interface ScheduleTemplate {
  id: string;
  name: string;
  location: string;
  scenarioType: '2/2' | '3/3' | '2/2+P' | '5/2' | 'custom';
  mainStaffIds: string[];
  partTimeStaffIds?: string[];
  defaultShiftType?: ShiftType;
  notes?: string;
  createdAt: string;
}

export interface AvailabilityRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // YYYY-MM-DD
  type: 'unavailable' | 'vacation' | 'study' | 'sick' | 'preferred';
  comment?: string;
  createdAt: string;
  status?: 'pending' | 'approved' | 'rejected';
}

export interface IncomeGoal {
  employeeId: string;
  month: string; // YYYY-MM
  targetAmount: number;
}

export interface StaffMember {
  id: string;
  name: string;
  login: string;
  hasAccess: boolean;
  telegramUsername?: string;
  role: 'employee';
  status: StaffStatus;
  registeredAt: string;
  locations: LocationType[];
  location?: LocationType; // fallback for legacy data
  isPartTime?: boolean; // статус "Подработчик"
  isSenior?: boolean; // статус старшего сотрудника "Ст.С."
  password?: string;
}

export interface AuthSession {
  role: 'manager' | 'employee';
  staffId?: string;
  name: string;
  login: string;
  locations?: LocationType[];
  isPartTime?: boolean;
  isSenior?: boolean; // статус старшего сотрудника "Ст.С."
  telegramUsername?: string;
}

export interface ApplicationRequest {
  id: string;
  name: string;
  telegramUsername?: string;
  createdAt: string;
  status: 'pending' | 'approved' | 'accepted' | 'rejected' | 'cancelled';
  decidedAt?: string;
  note?: string;
  generatedLogin?: string;
  submittedAt?: string;
}

export interface ManagerMessage {
  id: string;
  fromEmployeeId: string;
  fromEmployeeName: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export interface StaffNotification {
  id: string;
  toEmployeeId: string | 'all';
  title: string;
  text: string;
  type: 'status_update' | 'thank_you' | 'reminder' | 'system' | 'report';
  timestamp: string;
  read: boolean;
  location?: string;
}

export interface BotRestartLog {
  id: string;
  timestamp: string;
  initiatedBy: string;
  status: 'success' | 'running' | 'failed';
  outputLogs: string[];
}

export interface PaybackArticleItem {
  id: string;
  name: string;
  amount: number;
  isDefault?: boolean;
}

export interface PaybackPvzRecord {
  pvzCode: string; // e.g. "pvz-1"
  month: string; // YYYY-MM
  incomes: PaybackArticleItem[];
  expenses: PaybackArticleItem[];
  updatedAt?: string;
}

export interface PaybackArticleTemplates {
  incomeArticles?: string[];
  expenseArticles?: string[];
  customIncomeArticles?: string[];
  customExpenseArticles?: string[];
}

export interface TelegramSettings {
  isConfigured: boolean;
  botToken: string;
  managerChatId: string;
  botUsername?: string;
  updatedAt?: string;
}
