import * as XLSX from 'xlsx';
import { CheckInRecord, StaffMember, SHIFT_LABELS, ShiftType } from '../types';
import { calculateDailySales, aggregateMonthlyStats, calculateShiftTotalSalary } from './calculations';
import { formatMonthName } from './time';

export function exportMonthlyReportToExcel(
  records: CheckInRecord[],
  staffList: StaffMember[],
  months: string[], // e.g. ['2026-09', '2026-08', '2026-07']
  rates: any
) {
  const wb = XLSX.utils.book_new();

  // 1. Summary Sheet across selected months
  const summaryRows: any[] = [];
  summaryRows.push([
    'Сотрудник',
    'Статус',
    'Период (Месяц)',
    'Обычная смена',
    '400+',
    '500+',
    '8 часов',
    '4 часа',
    'Всего смен',
    'Наличные (₽)',
    'Безналичные / Карта (₽)',
    'Общая выручка (₽)',
    'Оклады смен (ФОТ)',
    'Премия (5%)',
    'Итого начислено (ФОТ + Премии)'
  ]);

  for (const m of months) {
    const statsMap = aggregateMonthlyStats(records, m);
    for (const staff of staffList) {
      const stat = statsMap.get(staff.id);
      
      let statusLabel = 'Обычный';
      if (staff.isSenior) statusLabel = 'Старший';
      if (staff.isPartTime) statusLabel = 'Подработчик';

      if (stat) {
        // Calculate shift salary exactly
        let totalShiftSalary = 0;
        stat.records.forEach(rec => {
          if (rec.shiftType) {
            totalShiftSalary += calculateShiftTotalSalary(rec, staff, rates);
          }
        });

        const totalBonus = stat.sales.totalBonus;
        const totalEarnings = totalShiftSalary + totalBonus;

        summaryRows.push([
          staff.name,
          statusLabel,
          formatMonthName(m),
          stat.shiftsCount.standard || 0,
          stat.shiftsCount['400+'] || 0,
          stat.shiftsCount['500+'] || 0,
          stat.shiftsCount['8h'] || 0,
          stat.shiftsCount['4h'] || 0,
          stat.shiftsCount.total,
          stat.sales.totalCash,
          stat.sales.totalCard,
          stat.sales.totalRevenue,
          totalShiftSalary,
          totalBonus,
          totalEarnings
        ]);
      } else if (staff.status === 'active') {
        summaryRows.push([
          staff.name,
          statusLabel,
          formatMonthName(m),
          0, 0, 0, 0, 0, 0,
          0, 0, 0,
          0, 0, 0
        ]);
      }
    }
  }

  const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Сводный отчет');

  // 2. Detailed Daily Records Sheet
  const dailyRows: any[] = [];
  dailyRows.push([
    'Дата',
    'Сотрудник',
    'Статус',
    'Пункт',
    'Тип смены',
    'Время Check-in',
    'Наличные (₽)',
    'Безналичные / Карта (₽)',
    'Выручка за день (₽)',
    'Оклад за смену',
    'Премия за день (5%)',
    'Всего начислено за день'
  ]);

  const filteredRecords = records
    .filter(r => months.some(m => r.date.startsWith(m)))
    .sort((a, b) => b.date.localeCompare(a.date));

  for (const r of filteredRecords) {
    const calc = calculateDailySales(r.sales);
    const staff = staffList.find(s => s.id === r.employeeId);
    
    let statusLabel = 'Обычный';
    if (staff?.isSenior) statusLabel = 'Старший';
    if (staff?.isPartTime) statusLabel = 'Подработчик';

    // Calculate shift-specific pay
    let shiftPay = 0;
    if (r.shiftType) {
      shiftPay = calculateShiftTotalSalary(r, staff, rates);
    }

    const totalDayEarnings = shiftPay + calc.bonus;

    const timeVal = r.checkedInAt || r.timestamp;

    dailyRows.push([
      r.date,
      r.employeeName,
      statusLabel,
      r.location || '—',
      r.shiftType ? SHIFT_LABELS[r.shiftType] : '—',
      timeVal ? new Date(timeVal).toLocaleTimeString('ru-RU') : '—',
      calc.totalCash,
      calc.totalCard,
      calc.totalSales,
      shiftPay,
      calc.bonus,
      totalDayEarnings
    ]);
  }

  const wsDaily = XLSX.utils.aoa_to_sheet(dailyRows);
  XLSX.utils.book_append_sheet(wb, wsDaily, 'Дневной журнал продаж');

  // Generate file and trigger download
  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `PVZ_Otchet_${dateStr}.xlsx`);
}
