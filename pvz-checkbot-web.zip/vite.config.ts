import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import path from 'path';
import fs from 'fs';
import url from 'url';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [
      react(), 
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png'],
        manifest: {
          id: '/',
          name: 'Смена ПВЗ',
          short_name: 'Смена ПВЗ',
          description: 'Удобный личный кабинет сотрудника ПВЗ с контролем смен, показателей и отчетов',
          theme_color: '#0f172a', // Slate 900
          background_color: '#020617', // Slate 950
          display: 'standalone',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
        },
        devOptions: {
          enabled: true,
          type: 'module',
        },
      }),
      {
        name: 'php-api-middleware',
        configureServer(server) {
          server.middlewares.use((req, res, next) => {
            if (req.url) {
              const parsedUrl = url.parse(req.url, true);
              if (parsedUrl.pathname === '/api.php' || parsedUrl.pathname === '/api/telegram/notify') {
                const action = parsedUrl.query.action || (parsedUrl.pathname === '/api/telegram/notify' ? 'telegram_notify' : '');
                const rootDir = url.fileURLToPath(new URL('.', import.meta.url));
                const dbCandidates = [
                  path.resolve(rootDir, 'pvz_database.json'),
                  path.resolve(rootDir, 'data/pvz_database.json'),
                  path.resolve(rootDir, 'db.json')
                ];
                const dbFilePath = dbCandidates.find(p => fs.existsSync(p)) || dbCandidates[0];

                if (req.method === 'GET' || action === 'data') {
                  res.setHeader('Content-Type', 'application/json; charset=utf-8');
                  if (fs.existsSync(dbFilePath)) {
                    try {
                      const content = fs.readFileSync(dbFilePath, 'utf8');
                      res.end(content);
                      return;
                    } catch (err) {
                      res.statusCode = 500;
                      res.end(JSON.stringify({ error: 'Failed to read database' }));
                      return;
                    }
                  }
                  res.end(JSON.stringify({}));
                  return;
                }

                if (req.method === 'POST' && action === 'telegram_notify') {
                  let body = '';
                  req.on('data', chunk => {
                    body += chunk.toString();
                  });
                  req.on('end', async () => {
                    try {
                      const { message } = JSON.parse(body);
                      const botToken = process.env.TELEGRAM_BOT_TOKEN || '8663529094:AAEtWNltIPqCXVIhy-b8j7ikeptcn-DsZzk';
                      const managerId = process.env.TELEGRAM_MANAGER_CHAT_ID || '320314713';
                      const tgRes = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          chat_id: managerId,
                          text: message,
                          parse_mode: 'Markdown'
                        })
                      });
                      const tgData = await tgRes.json();
                      res.setHeader('Content-Type', 'application/json; charset=utf-8');
                      if (tgRes.ok && tgData.ok) {
                        res.end(JSON.stringify({ success: true }));
                      } else {
                        res.statusCode = 502;
                        res.end(JSON.stringify({ error: 'Telegram error', details: tgData }));
                      }
                    } catch (err: any) {
                      res.statusCode = 500;
                      res.end(JSON.stringify({ error: err.message }));
                    }
                  });
                  return;
                }

                if (req.method === 'POST' || action === 'save') {
                  let body = '';
                  req.on('data', chunk => {
                    body += chunk.toString();
                  });
                  req.on('end', () => {
                    try {
                      const data = JSON.parse(body);
                      fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2), 'utf8');
                      res.setHeader('Content-Type', 'application/json; charset=utf-8');
                      res.end(JSON.stringify({ success: true }));
                    } catch (err) {
                      res.statusCode = 500;
                      res.end(JSON.stringify({ error: 'Failed to save database' }));
                    }
                  });
                  return;
                }
              }
            }
            next();
          });
        }
      }
    ],
    resolve: {
      alias: {
        '@': path.resolve(url.fileURLToPath(new URL('.', import.meta.url)), '.'),
      },
    },
    build: {
      target: 'es2020',
      cssTarget: 'safari14',
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
